import { gql } from '@apollo/client';
import * as Apollo from '@apollo/client';
export type Maybe<T> = T | null;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
const defaultOptions =  {}
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: string;
  String: string;
  Boolean: boolean;
  Int: number;
  Float: number;
  Json: any;
  DateTime: any;
};

export type PaginationOutput = {
  /** The page that results are in. */
  page: Scalars['Int'];
  /** The page size */
  pageSize: Scalars['Int'];
  /** The total number of pages */
  totalPages: Scalars['Int'];
  /** The total number of results */
  totalResults: Scalars['Int'];
};

export enum PlanType {
  Individual = 'Individual',
  Business = 'Business'
}

export type Plan = {
  __typename?: 'Plan';
  id: Scalars['String'];
  name: Scalars['String'];
  isRecurring: Scalars['Boolean'];
  numberOfScans: Scalars['Int'];
  price: Scalars['Int'];
  type: PlanType;
  stripePlanId: Scalars['String'];
  isArchived: Scalars['Boolean'];
};

export type PricingQueryArgs = {
  email: Scalars['String'];
  industry: Scalars['String'];
  employeeCount: Scalars['Int'];
};

export type PricingResponse = {
  __typename?: 'PricingResponse';
  numberOfScans: Scalars['String'];
  pricePerEmployee: Scalars['Float'];
  totalPrice: Scalars['Float'];
  employeeCount: Scalars['Int'];
};

export type PromoQueryArgs = {
  code: Scalars['String'];
};

export type PromoResponse = {
  __typename?: 'PromoResponse';
  isFound: Scalars['Boolean'];
  isActive: Scalars['Boolean'];
  percentOff?: Maybe<Scalars['Float']>;
  amountOff?: Maybe<Scalars['Float']>;
};

export enum SubscriptionStatus {
  Active = 'Active',
  Canceled = 'Canceled',
  Incomplete = 'Incomplete',
  IncompleteExpired = 'IncompleteExpired',
  PastDue = 'PastDue',
  Trialing = 'Trialing',
  Unpaid = 'Unpaid'
}

export type StripeSubscription = {
  __typename?: 'StripeSubscription';
  id: Scalars['String'];
  status: SubscriptionStatus;
  created: Scalars['DateTime'];
  currentPeriodStart: Scalars['DateTime'];
  currentPeriodEnd: Scalars['DateTime'];
  cancelAtPeriodEnd: Scalars['Boolean'];
  cancelAt?: Maybe<Scalars['DateTime']>;
  canceledAt?: Maybe<Scalars['DateTime']>;
  endedAt?: Maybe<Scalars['DateTime']>;
};

export type PurchaseAmountQueryArgs = {
  role: Scalars['String'];
  /** Formerly subscription type , id of plan on database  */
  planId?: Maybe<Scalars['String']>;
  promoCode?: Maybe<Scalars['String']>;
  taxRateId?: Maybe<Scalars['String']>;
  numberOfEmployees?: Maybe<Scalars['Float']>;
};

export type PurchaseAmountResponse = {
  __typename?: 'PurchaseAmountResponse';
  planName: Scalars['String'];
  price: Scalars['String'];
  monthlyPrice?: Maybe<Scalars['String']>;
  promoAmountOff?: Maybe<Scalars['String']>;
  taxAmount?: Maybe<Scalars['String']>;
  taxPercentage?: Maybe<Scalars['Float']>;
  totalAmount: Scalars['String'];
};

export type CardPaymentMethod = {
  __typename?: 'CardPaymentMethod';
  brand: Scalars['String'];
  last4: Scalars['String'];
  exp_month: Scalars['Int'];
  exp_year: Scalars['Int'];
};

export type CardOwnerInfo = {
  __typename?: 'CardOwnerInfo';
  email: Scalars['String'];
  name: Scalars['String'];
};

export type PaymentMethod = {
  __typename?: 'PaymentMethod';
  id: Scalars['ID'];
  card: CardPaymentMethod;
  owner: CardOwnerInfo;
};

export type FeatureFlag = {
  __typename?: 'FeatureFlag';
  id: Scalars['String'];
  description?: Maybe<Scalars['String']>;
  payload: Scalars['Json'];
  createdAt: Scalars['DateTime'];
  updatedAt: Scalars['DateTime'];
};

export type FeatureFlagConfiguration = {
  __typename?: 'FeatureFlagConfiguration';
  id: Scalars['String'];
  featureFlagId: Scalars['String'];
  platformId?: Maybe<Scalars['String']>;
  groupId?: Maybe<Scalars['String']>;
  userId?: Maybe<Scalars['String']>;
  enabled: Scalars['Boolean'];
  createdAt: Scalars['DateTime'];
  updatedAt: Scalars['DateTime'];
};

export type CreateFeatureFlagInput = {
  featureFlagId: Scalars['String'];
  description?: Maybe<Scalars['String']>;
  payload: Scalars['Json'];
};

export type CreateFeatureFlagConfigInput = {
  featureFlagId: Scalars['String'];
  platformId?: Maybe<Scalars['String']>;
  userId?: Maybe<Scalars['String']>;
  groupId?: Maybe<Scalars['String']>;
  enabled: Scalars['Boolean'];
};

export type FeatureFlagUniqueKeyInput = {
  featureFlagId: Scalars['String'];
  platformId?: Maybe<Scalars['String']>;
  userId?: Maybe<Scalars['String']>;
  groupId?: Maybe<Scalars['String']>;
};

export type SendEmailToLifeBrandInput = {
  name: Scalars['String'];
  email: Scalars['String'];
  text: Scalars['String'];
};

export type StripeCharge = {
  __typename?: 'StripeCharge';
  id: Scalars['String'];
  amount?: Maybe<Scalars['Int']>;
  currency?: Maybe<Scalars['String']>;
  description?: Maybe<Scalars['String']>;
  failureCode?: Maybe<Scalars['String']>;
  failureMessage?: Maybe<Scalars['String']>;
  invoiceId?: Maybe<Scalars['String']>;
  invoiceUrl?: Maybe<Scalars['String']>;
  receiptEmail?: Maybe<Scalars['String']>;
  receiptUrl?: Maybe<Scalars['String']>;
  status?: Maybe<Scalars['String']>;
  date: Scalars['DateTime'];
};

export type StripeTaxRate = {
  __typename?: 'StripeTaxRate';
  id: Scalars['String'];
  active: Scalars['Boolean'];
  livemode: Scalars['Boolean'];
  percentage: Scalars['Float'];
  country?: Maybe<Scalars['String']>;
  state?: Maybe<Scalars['String']>;
};

export type CreateIndividualSubscriptionInput = {
  email?: Maybe<Scalars['String']>;
  stripeSource?: Maybe<Scalars['String']>;
  /** Formerly subscription type , id of plan on database  */
  planId: Scalars['String'];
  promoCode?: Maybe<Scalars['String']>;
  taxRateId?: Maybe<Scalars['String']>;
};

export type IndividualPurchaseAmountQueryArgs = {
  /** Formerly subscription type , id of plan on database  */
  planId: Scalars['String'];
  promoCode?: Maybe<Scalars['String']>;
  taxRateId?: Maybe<Scalars['String']>;
};

export type IndividualPurchaseAmountResponse = {
  __typename?: 'IndividualPurchaseAmountResponse';
  planName: Scalars['String'];
  price: Scalars['Float'];
  recurringPrice?: Maybe<Scalars['Float']>;
  promoAmountOff?: Maybe<Scalars['Float']>;
  taxAmount?: Maybe<Scalars['Float']>;
  taxPercentage?: Maybe<Scalars['Float']>;
  totalPrice: Scalars['Float'];
};

export type Report = {
  __typename?: 'Report';
  id: Scalars['String'];
  name: Scalars['String'];
  type: ReportType;
  startDate: Scalars['DateTime'];
  endDate: Scalars['DateTime'];
  isFCRACompliant: Scalars['Boolean'];
  isShared: Scalars['Boolean'];
  flaggedContentsCount: Scalars['Int'];
  nonFlaggedContentsCount: Scalars['Int'];
  deletedFlaggedContentsCount: Scalars['Int'];
  businessDictionaryContentsCount?: Maybe<Scalars['Int']>;
  userId: Scalars['String'];
  User: User;
  createdAt: Scalars['DateTime'];
  updatedAt: Scalars['DateTime'];
  flaggedByTimelineBreakdown: Scalars['Json'];
  allByTimelineBreakdown: Scalars['Json'];
  allByLabelsByTimelineByOriginsBreakdown?: Maybe<Scalars['Json']>;
  countByBusinessDictionaryBreakdown?: Maybe<Scalars['Json']>;
  originsLastScannedBreakdown: ScanDateOriginsBreakdown;
  flaggedByOriginsBreakdown: OriginsBreakdown;
  allByOriginsBreakdown: OriginsBreakdown;
  deletedFlaggedByOriginsBreakdown: OriginsBreakdown;
  flaggedByLabelsBreakdown: FlaggedPostLabelsBreakdownResponse;
  /** Signed URL of the PDF file. It expires in 15 min. */
  pdfUrl: Scalars['String'];
  /** When the Report was read by the current Business. */
  readAt?: Maybe<Scalars['DateTime']>;
};

export type ReportRequest = {
  __typename?: 'ReportRequest';
  id: Scalars['String'];
  status: ReportRequestStatus;
  origin: ReportRequestOrigin;
  userId?: Maybe<Scalars['String']>;
  businessId: Scalars['String'];
  Business: Business;
  reportId?: Maybe<Scalars['String']>;
  createdAt: Scalars['DateTime'];
  updatedAt: Scalars['DateTime'];
};

export type ReportOld = {
  __typename?: 'ReportOld';
  id: Scalars['String'];
  startDate: Scalars['DateTime'];
  endDate: Scalars['DateTime'];
  harmfulBreakdown?: Maybe<Scalars['Json']>;
  timelineBreakdown?: Maybe<Scalars['Json']>;
  profanitiesBreakdown?: Maybe<Scalars['Json']>;
  harmfulPostCount: Scalars['Int'];
  deletedPostCount: Scalars['Int'];
  ignoredPostCount: Scalars['Int'];
  userId?: Maybe<Scalars['String']>;
  User?: Maybe<User>;
  /** Signed URL of the PDF file. It expires in 15 min. */
  pdfUrl?: Maybe<Scalars['String']>;
  createdAt: Scalars['DateTime'];
  sentAt?: Maybe<Scalars['DateTime']>;
  isSent: Scalars['Boolean'];
};

export type HarmfulBreakdown = {
  __typename?: 'HarmfulBreakdown';
  Facebook: Scalars['Int'];
  Twitter: Scalars['Int'];
  Instagram: Scalars['Int'];
};

export type ProfanitiesBreakdown = {
  __typename?: 'ProfanitiesBreakdown';
  Identity: Scalars['Int'];
  Insult: Scalars['Int'];
  Obscene: Scalars['Int'];
  Threat: Scalars['Int'];
  Sexual: Scalars['Int'];
  Toxic: Scalars['Int'];
};

export enum Profanities {
  Identity = 'Identity',
  Insult = 'Insult',
  Obscene = 'Obscene',
  Threat = 'Threat',
  Sexual = 'Sexual',
  Toxic = 'Toxic'
}

export enum SocialMedia {
  Facebook = 'Facebook',
  Twitter = 'Twitter',
  Instagram = 'Instagram'
}

export type Scan = {
  __typename?: 'Scan';
  id: Scalars['String'];
  userId: Scalars['String'];
  User: User;
  type: ScanType;
  origins: Array<SocialMedia>;
  status: ScanStatus;
  startedAt?: Maybe<Scalars['DateTime']>;
  createdAt: Scalars['DateTime'];
  updatedAt: Scalars['DateTime'];
  duration?: Maybe<Scalars['Float']>;
  contentsFound?: Maybe<Scalars['Json']>;
  newContentsFound?: Maybe<Scalars['Json']>;
  editedContentsFound?: Maybe<Scalars['Json']>;
};

export type User = {
  __typename?: 'User';
  id: Scalars['String'];
  name: Scalars['String'];
  email?: Maybe<Scalars['String']>;
  photo: Scalars['String'];
  scanAmount: Scalars['Int'];
  authId: Scalars['String'];
  stripeId?: Maybe<Scalars['String']>;
  planId?: Maybe<Scalars['String']>;
  Plan?: Maybe<Plan>;
  ReportOld: Array<ReportOld>;
  createdAt: Scalars['DateTime'];
  updatedAt: Scalars['DateTime'];
  deletedAt?: Maybe<Scalars['DateTime']>;
  lastRefresh?: Maybe<Scalars['DateTime']>;
  acceptedFcraVersion?: Maybe<Scalars['String']>;
  acceptedPolicyVersion: Scalars['String'];
  BusinessCustomer: Array<BusinessCustomer>;
  BusinessCustomerInvitation: Array<BusinessCustomerInvitation>;
  partnerId?: Maybe<Scalars['String']>;
  referrerId?: Maybe<Scalars['String']>;
  providerTokens: Scalars['Json'];
  connectedSocialMedia: Array<Scalars['String']>;
  performedScans: Scalars['Int'];
  hasPassword: Scalars['Boolean'];
  hasScanAvailable: Scalars['Boolean'];
  Integrations: Array<SocialMedia>;
};


export type UserReportOldArgs = {
  first?: Maybe<Scalars['Int']>;
  last?: Maybe<Scalars['Int']>;
  before?: Maybe<ReportOldWhereUniqueInput>;
  after?: Maybe<ReportOldWhereUniqueInput>;
};


export type UserBusinessCustomerArgs = {
  first?: Maybe<Scalars['Int']>;
  last?: Maybe<Scalars['Int']>;
  before?: Maybe<BusinessCustomerWhereUniqueInput>;
  after?: Maybe<BusinessCustomerWhereUniqueInput>;
};


export type UserBusinessCustomerInvitationArgs = {
  first?: Maybe<Scalars['Int']>;
  last?: Maybe<Scalars['Int']>;
  before?: Maybe<BusinessCustomerInvitationWhereUniqueInput>;
  after?: Maybe<BusinessCustomerInvitationWhereUniqueInput>;
};

export type PublicUser = {
  __typename?: 'PublicUser';
  id: Scalars['String'];
  partnerId?: Maybe<Scalars['String']>;
  partner?: Maybe<PublicPartner>;
};

export type SignupAsIndividualInput = {
  name?: Maybe<Scalars['String']>;
  photo?: Maybe<Scalars['String']>;
  email?: Maybe<Scalars['String']>;
  acceptedPolicyVersion: Scalars['String'];
  invitationId?: Maybe<Scalars['String']>;
  partnerId?: Maybe<Scalars['String']>;
  partnerUserSubscriptionId?: Maybe<Scalars['String']>;
  referrerId?: Maybe<Scalars['String']>;
};

export type SignupAsIndividualWithEmailInput = {
  email: Scalars['String'];
  name: Scalars['String'];
  password: Scalars['String'];
  acceptedPolicyVersion: Scalars['String'];
  invitationId?: Maybe<Scalars['String']>;
  partnerId?: Maybe<Scalars['String']>;
  partnerUserSubscriptionId?: Maybe<Scalars['String']>;
  referrerId?: Maybe<Scalars['String']>;
};

export type SocialMediaConnection = {
  __typename?: 'SocialMediaConnection';
  /** User's social media name. */
  userName?: Maybe<Scalars['String']>;
  /** User's social media photo. */
  userPhoto?: Maybe<Scalars['String']>;
  /** Social media's to connect */
  socialMedia: SocialMedia;
  /** Identifier for original account on creation */
  isMainIdentity: Scalars['Boolean'];
  /** Social media connection status */
  isConnected: Scalars['Boolean'];
  /** Social media connection expiration status */
  isExpired?: Maybe<Scalars['Boolean']>;
};

export type LoginAsIndividualWithEmailInput = {
  email: Scalars['String'];
  password: Scalars['String'];
};

export type UpdateIndividualProfileInput = {
  email?: Maybe<Scalars['String']>;
  name?: Maybe<Scalars['String']>;
};

export type LoginIndividualResponse = {
  __typename?: 'LoginIndividualResponse';
  accessToken: Scalars['String'];
  expiresIn?: Maybe<Scalars['Int']>;
  idToken?: Maybe<Scalars['String']>;
  refreshToken?: Maybe<Scalars['String']>;
  scope?: Maybe<Scalars['String']>;
  tokenType?: Maybe<Scalars['String']>;
};

export type IndividualFeatureAccess = {
  __typename?: 'IndividualFeatureAccess';
  canAccessAnalytics: Scalars['Boolean'];
  canUseAdvancedDashboard: Scalars['Boolean'];
  canUpgrade: Scalars['Boolean'];
  canScan: Scalars['Boolean'];
};

export type IndividualCurrentPlan = {
  __typename?: 'IndividualCurrentPlan';
  name: Scalars['String'];
  currentPeriodEnds?: Maybe<Scalars['DateTime']>;
  isCancelled: Scalars['Boolean'];
  isCancellable: Scalars['Boolean'];
};

export type IndividualFeatureAccessOutput = {
  __typename?: 'IndividualFeatureAccessOutput';
  features: IndividualFeatureAccess;
  plan?: Maybe<IndividualCurrentPlan>;
};

export type IndividualNotification = {
  __typename?: 'IndividualNotification';
  id: Scalars['String'];
  type: Scalars['String'];
  title: Scalars['String'];
  text: Scalars['String'];
  userId: Scalars['String'];
  createdAt: Scalars['DateTime'];
  readAt?: Maybe<Scalars['DateTime']>;
  deletedAt?: Maybe<Scalars['DateTime']>;
  isRead: Scalars['Boolean'];
  isDeleted: Scalars['Boolean'];
};

export type IndividualNotificationsInput = {
  cursorId?: Maybe<Scalars['String']>;
  take?: Scalars['Int'];
};

export type IndividualNotificationsResponse = {
  __typename?: 'IndividualNotificationsResponse';
  list: Array<IndividualNotification>;
  nextCursorId?: Maybe<Scalars['String']>;
};

export type Content = {
  __typename?: 'Content';
  id: Scalars['String'];
  text: Scalars['String'];
  type: ContentType;
  userId: Scalars['String'];
  score: Scalars['Float'];
  origin: SocialMedia;
  originId: Scalars['String'];
  url: Scalars['String'];
  postedAt: Scalars['DateTime'];
  interactions: Scalars['Json'];
  isFlagged: Scalars['Boolean'];
  isDeleted: Scalars['Boolean'];
  isSafe: Scalars['Boolean'];
  safeReason?: Maybe<Scalars['String']>;
  createdAt: Scalars['DateTime'];
  ContentAnalysis: Array<ContentAnalysis>;
  language?: Maybe<SupportedLanguage>;
  media: Scalars['Json'];
};


export type ContentContentAnalysisArgs = {
  first?: Maybe<Scalars['Int']>;
  last?: Maybe<Scalars['Int']>;
  before?: Maybe<ContentAnalysisWhereUniqueInput>;
  after?: Maybe<ContentAnalysisWhereUniqueInput>;
};

export type ContentsInput = {
  socialMedia?: Maybe<Array<SocialMedia>>;
  labels?: Maybe<Array<Scalars['String']>>;
  search?: Maybe<Scalars['String']>;
  isDeleted?: Maybe<Scalars['Boolean']>;
  cursorId?: Maybe<Scalars['String']>;
  take?: Scalars['Int'];
  sorting?: Maybe<ContentsSortingInput>;
  isFlagged?: Maybe<Scalars['Boolean']>;
  isBusinessDictionary?: Maybe<Scalars['Boolean']>;
};

export type ContentsSortingInput = {
  field?: Maybe<ContentsSortingField>;
  direction?: Maybe<ContentsSortingDirection>;
};

export enum ContentsSortingField {
  PostedAt = 'postedAt',
  Score = 'score'
}

export enum ContentsSortingDirection {
  Asc = 'asc',
  Desc = 'desc'
}

export type ContentsResponse = {
  __typename?: 'ContentsResponse';
  list: Array<Content>;
  nextCursorId?: Maybe<Scalars['String']>;
};

export type OriginsBreakdown = {
  __typename?: 'OriginsBreakdown';
  Facebook: Scalars['Int'];
  Twitter: Scalars['Int'];
  Instagram: Scalars['Int'];
};

export type CountBreakdown = {
  __typename?: 'CountBreakdown';
  nonFlaggedPosts: Scalars['Int'];
  flaggedPosts: Scalars['Int'];
  totalPosts: Scalars['Int'];
};

export type ScanDateOriginsBreakdown = {
  __typename?: 'ScanDateOriginsBreakdown';
  Facebook?: Maybe<Scalars['DateTime']>;
  Twitter?: Maybe<Scalars['DateTime']>;
  Instagram?: Maybe<Scalars['DateTime']>;
};

export type FlaggedPostLabelsBreakdownResponse = {
  __typename?: 'FlaggedPostLabelsBreakdownResponse';
  identity_attack: Scalars['Int'];
  insult: Scalars['Int'];
  obscene: Scalars['Int'];
  threat: Scalars['Int'];
  sexual_explicit: Scalars['Int'];
  sexual: Scalars['Int'];
  severe_toxicity: Scalars['Int'];
  toxicity: Scalars['Int'];
  inappropriate: Scalars['Int'];
  blasphemy: Scalars['Int'];
  discriminatory: Scalars['Int'];
};

export type DashboardContentBreakdownsResponse = {
  __typename?: 'DashboardContentBreakdownsResponse';
  originsBreakdown: OriginsBreakdown;
  labelsBreakdown: FlaggedPostLabelsBreakdownResponse;
  flaggedByOriginsBreakdown: OriginsBreakdown;
  nonFlaggedCount: Scalars['Int'];
  flaggedCount: Scalars['Int'];
  allContentsCount: Scalars['Int'];
  businessDictionaryCount: Scalars['Int'];
  businessDictionaryByOriginsBreakdown: OriginsBreakdown;
};

export type OverviewContentBreakdownsInput = {
  FCRACompliant?: Scalars['Boolean'];
  startDate?: Maybe<Scalars['DateTime']>;
  endDate?: Maybe<Scalars['DateTime']>;
};

export type OverviewContentBreakdownsResponse = {
  __typename?: 'OverviewContentBreakdownsResponse';
  flaggedByOriginsBreakdown: OriginsBreakdown;
  flaggedByLabelsBreakdown: FlaggedPostLabelsBreakdownResponse;
  deletedFlaggedContentsCount: Scalars['Int'];
  nonFlaggedContentsCount: Scalars['Int'];
  flaggedContentsCount: Scalars['Int'];
  flaggedByTimelineBreakdown: Scalars['Json'];
  businessDictionaryContentsCount?: Maybe<Scalars['Int']>;
  countByBusinessDictionaryBreakdown?: Maybe<Scalars['Json']>;
};

export type DeleteContentInput = {
  contentId: Scalars['String'];
  origin: SocialMedia;
};

export type DeleteContentResponse = {
  __typename?: 'DeleteContentResponse';
  contentId: Scalars['String'];
  isDeleted: Scalars['Boolean'];
  errorMessage?: Maybe<Scalars['String']>;
};

export type ContentAnalysis = {
  __typename?: 'ContentAnalysis';
  id: Scalars['String'];
  contentId: Scalars['String'];
  type: ContentAnalysisType;
  status: ContentAnalysisStatus;
  passed?: Maybe<Scalars['Boolean']>;
  score?: Maybe<Scalars['Float']>;
  results?: Maybe<Scalars['Json']>;
  labels: Array<Scalars['String']>;
  finishedAt?: Maybe<Scalars['DateTime']>;
  createdAt: Scalars['DateTime'];
  updatedAt: Scalars['DateTime'];
};

export type Photobook = {
  __typename?: 'Photobook';
  id: Scalars['String'];
  title: Scalars['String'];
  dateFrom: Scalars['DateTime'];
  dateTo: Scalars['DateTime'];
  coverImage: Scalars['String'];
  pdfUrl: Scalars['String'];
  userId?: Maybe<Scalars['String']>;
  User?: Maybe<User>;
  createdAt: Scalars['DateTime'];
};

export type PhotobookPost = {
  __typename?: 'PhotobookPost';
  id: Scalars['String'];
  originId: Scalars['String'];
  attachmentUrls: Array<Scalars['String']>;
  text?: Maybe<Scalars['String']>;
  userId?: Maybe<Scalars['String']>;
  User?: Maybe<User>;
  postedAt: Scalars['DateTime'];
};

export type PostsDatesOutput = {
  __typename?: 'PostsDatesOutput';
  count: Scalars['Int'];
  date: Scalars['DateTime'];
};

export type BusinessApiKey = {
  __typename?: 'BusinessApiKey';
  key: Scalars['String'];
  status: ApiKeyStatus;
  businessId: Scalars['String'];
};

export type Business = {
  __typename?: 'Business';
  id: Scalars['String'];
  name: Scalars['String'];
  contactEmail: Scalars['String'];
  type: BusinessType;
  invitationAmount: Scalars['Int'];
  monthlyInvitationAmount: Scalars['Int'];
  stripeId?: Maybe<Scalars['String']>;
  planId?: Maybe<Scalars['String']>;
  Plan?: Maybe<Plan>;
  partnerId?: Maybe<Scalars['String']>;
  BusinessDictionary?: Maybe<BusinessDictionary>;
  features: Array<BusinessFeature>;
  PartnerBusinessSubscription: Array<PublicUser>;
  createdAt: Scalars['DateTime'];
  updatedAt: Scalars['DateTime'];
  settings?: Maybe<Scalars['Json']>;
};


export type BusinessPartnerBusinessSubscriptionArgs = {
  first?: Maybe<Scalars['Int']>;
  last?: Maybe<Scalars['Int']>;
  before?: Maybe<PartnerBusinessSubscriptionWhereUniqueInput>;
  after?: Maybe<PartnerBusinessSubscriptionWhereUniqueInput>;
};

export type PublicBusiness = {
  __typename?: 'PublicBusiness';
  id: Scalars['String'];
  name: Scalars['String'];
  contactEmail: Scalars['String'];
  partnerId?: Maybe<Scalars['String']>;
  BusinessDictionary?: Maybe<BusinessDictionary>;
  features: Array<BusinessFeature>;
  createdAt: Scalars['DateTime'];
  updatedAt: Scalars['DateTime'];
};

export type CreateBusinessInput = {
  name: Scalars['String'];
  referrerId?: Maybe<Scalars['String']>;
  partnerId?: Maybe<Scalars['String']>;
  partnerBusinessSubscriptionId?: Maybe<Scalars['String']>;
};

export enum BusinessFeature {
  CustomDictionary = 'CustomDictionary'
}

export type UpdateBusinessProfileInput = {
  email: Scalars['String'];
  name: Scalars['String'];
};

export type BusinessCustomer = {
  __typename?: 'BusinessCustomer';
  id: Scalars['String'];
  type: BusinessCustomerType;
  businessId: Scalars['String'];
  Business: PublicBusiness;
  userId: Scalars['String'];
  User: User;
  isActive: Scalars['Boolean'];
  createdAt: Scalars['DateTime'];
  updatedAt: Scalars['DateTime'];
  expiresAt?: Maybe<Scalars['DateTime']>;
  status: BusinessCustomerStatus;
  lastReport?: Maybe<Report>;
  /** The email that has been used to invite this Business Customer. */
  invitationEmail?: Maybe<Scalars['String']>;
};

export type BusinessCustomerBreakdownOutput = {
  __typename?: 'BusinessCustomerBreakdownOutput';
  CurrentEmployee: Scalars['Int'];
  PotentialEmployee: Scalars['Int'];
  invited: Scalars['Int'];
  deactivated: Scalars['Int'];
  total: Scalars['Int'];
};

export type BusinessCustomersOutput = PaginationOutput & {
  __typename?: 'BusinessCustomersOutput';
  /** The page that results are in. */
  page: Scalars['Int'];
  /** The page size */
  pageSize: Scalars['Int'];
  /** The total number of pages */
  totalPages: Scalars['Int'];
  /** The total number of results */
  totalResults: Scalars['Int'];
  list: Array<BusinessCustomer>;
};

export type BusinessCustomersInput = {
  /** Page that is requested */
  page: Scalars['Int'];
  /** Page size */
  pageSize: Scalars['Int'];
  searchString?: Maybe<Scalars['String']>;
  sortBy?: Maybe<BusinessCustomersSortBy>;
  type?: Maybe<BusinessCustomerType>;
};

export enum BusinessCustomersSortBy {
  CreatedAtAsc = 'CreatedAtASC',
  CreatedAtDesc = 'CreatedAtDESC',
  EmailAsc = 'EmailASC',
  EmailDesc = 'EmailDESC',
  NameAsc = 'NameASC',
  NameDesc = 'NameDESC',
  ScansAmountAsc = 'ScansAmountASC',
  ScansAmountDesc = 'ScansAmountDESC',
  ExpiresAtAsc = 'ExpiresAtASC',
  ExpiresAtDesc = 'ExpiresAtDESC',
  LastReportAsc = 'LastReportASC',
  LastReportDesc = 'LastReportDESC',
  UserStatusAsc = 'UserStatusASC',
  UserStatusDesc = 'UserStatusDESC'
}

export enum BusinessCustomerStatus {
  Active = 'Active',
  Invited = 'Invited',
  Deactivated = 'Deactivated'
}

export type BusinessUser = {
  __typename?: 'BusinessUser';
  id: Scalars['String'];
  email: Scalars['String'];
  authId: Scalars['String'];
  hasPassword: Scalars['Boolean'];
  role: BusinessUserRole;
  businessId: Scalars['String'];
  Business: Business;
  createdAt: Scalars['DateTime'];
  updatedAt: Scalars['DateTime'];
};

export type PublicBusinessUser = {
  __typename?: 'PublicBusinessUser';
  id: Scalars['String'];
  email: Scalars['String'];
  authId: Scalars['String'];
  businessId: Scalars['String'];
  Business: Business;
  createdAt: Scalars['DateTime'];
};

export type BusinessCustomerInvitation = {
  __typename?: 'BusinessCustomerInvitation';
  id: Scalars['String'];
  email: Scalars['String'];
  inviteeId?: Maybe<Scalars['String']>;
  Invitee?: Maybe<User>;
  businessId: Scalars['String'];
  Business: Business;
  type: BusinessCustomerType;
  usedAt?: Maybe<Scalars['DateTime']>;
  createdAt: Scalars['DateTime'];
  lastSentAt: Scalars['DateTime'];
  expiresAt?: Maybe<Scalars['DateTime']>;
};

export type BusinessCustomerInvitationsOutput = PaginationOutput & {
  __typename?: 'BusinessCustomerInvitationsOutput';
  /** The page that results are in. */
  page: Scalars['Int'];
  /** The page size */
  pageSize: Scalars['Int'];
  /** The total number of pages */
  totalPages: Scalars['Int'];
  /** The total number of results */
  totalResults: Scalars['Int'];
  list: Array<BusinessCustomerInvitation>;
};

export type BusinessCustomerInvitationsInput = {
  /** Page that is requested */
  page: Scalars['Int'];
  /** Page size */
  pageSize: Scalars['Int'];
  searchString?: Maybe<Scalars['String']>;
  sortBy?: Maybe<BusinessCustomerInvitationsSortBy>;
};

export enum BusinessCustomerInvitationsSortBy {
  LastSentAtAsc = 'LastSentAtASC',
  LastSentAtDesc = 'LastSentAtDESC',
  EmailAsc = 'EmailASC'
}

export type CreateBusinessSubscriptionInput = {
  email?: Maybe<Scalars['String']>;
  stripeSource?: Maybe<Scalars['String']>;
  promoCode?: Maybe<Scalars['String']>;
  numberOfEmployees: Scalars['Int'];
};

export type BusinessQuote = {
  __typename?: 'BusinessQuote';
  email: Scalars['String'];
  industry?: Maybe<Scalars['String']>;
  numberOfEmployees: Scalars['Int'];
  pricePerEmployee: Scalars['Float'];
  totalPrice: Scalars['Float'];
};

export type BusinessPurchaseAmountQueryArgs = {
  promoCode?: Maybe<Scalars['String']>;
  taxRateId?: Maybe<Scalars['String']>;
  numberOfEmployees: Scalars['Int'];
};

export type BusinessPurchaseAmountResponse = {
  __typename?: 'BusinessPurchaseAmountResponse';
  planName: Scalars['String'];
  monthlyPrice: Scalars['Float'];
  totalPrice: Scalars['Float'];
  numberOfScans: Scalars['Float'];
  price?: Maybe<Scalars['Float']>;
  promoAmountOff?: Maybe<Scalars['Float']>;
  taxAmount?: Maybe<Scalars['Float']>;
  taxPercentage?: Maybe<Scalars['Float']>;
};

export type BusinessDashboardAggregates = {
  __typename?: 'BusinessDashboardAggregates';
  flaggedByOriginBreakdown: OriginsBreakdown;
  flaggedByLabelsBreakdown: FlaggedPostLabelsBreakdownResponse;
  countBreakdown: CountBreakdown;
  allByLabelsByTimelineByOriginsBreakdown: Scalars['Json'];
};

export type BusinessNotification = {
  __typename?: 'BusinessNotification';
  id: Scalars['String'];
  type: Scalars['String'];
  title: Scalars['String'];
  text: Scalars['String'];
  businessUserId: Scalars['String'];
  createdAt: Scalars['DateTime'];
  readAt?: Maybe<Scalars['DateTime']>;
  deletedAt?: Maybe<Scalars['DateTime']>;
  isRead: Scalars['Boolean'];
  isDeleted: Scalars['Boolean'];
};

export type BusinessNotificationsInput = {
  cursorId?: Maybe<Scalars['String']>;
  take?: Scalars['Int'];
};

export type BusinessNotificationsResponse = {
  __typename?: 'BusinessNotificationsResponse';
  list: Array<BusinessNotification>;
  nextCursorId?: Maybe<Scalars['String']>;
};

export type BusinessStatistics = {
  __typename?: 'BusinessStatistics';
  id: Scalars['String'];
  type: BusinessCustomerType;
  flaggedByOriginsBreakdown: OriginsBreakdown;
  flaggedByLabelsBreakdown: FlaggedPostLabelsBreakdownResponse;
  countBreakdown?: Maybe<Scalars['Json']>;
  allByLabelsByTimelineByOriginsBreakdown?: Maybe<Scalars['Json']>;
  dictionaryFlaggedByOriginBreakdown?: Maybe<OriginsBreakdown>;
  dictionaryFlaggedCount?: Maybe<Scalars['Int']>;
  updatedAt: Scalars['DateTime'];
  createdAt: Scalars['DateTime'];
};

export type BusinessDictionary = {
  __typename?: 'BusinessDictionary';
  id: Scalars['String'];
  businessId: Scalars['String'];
  Business?: Maybe<Business>;
  updatedAt: Scalars['DateTime'];
  createdAt: Scalars['DateTime'];
  BusinessDictionaryEntries: Array<BusinessDictionaryEntry>;
};


export type BusinessDictionaryBusinessDictionaryEntriesArgs = {
  first?: Maybe<Scalars['Int']>;
  last?: Maybe<Scalars['Int']>;
  before?: Maybe<BusinessDictionaryEntryWhereUniqueInput>;
  after?: Maybe<BusinessDictionaryEntryWhereUniqueInput>;
};

export type BusinessDictionaryEntry = {
  __typename?: 'BusinessDictionaryEntry';
  id: Scalars['String'];
  text: Scalars['String'];
  dictionaryId: Scalars['String'];
  BusinessDictionary: BusinessDictionary;
};

export type BusinessDictionaryResponse = {
  __typename?: 'BusinessDictionaryResponse';
  list: Array<BusinessDictionaryEntry>;
  flaggedPostsCount?: Maybe<Scalars['Int']>;
  flaggedDictionaryCount?: Maybe<Scalars['Int']>;
};

export type PublicPartner = {
  __typename?: 'PublicPartner';
  id: Scalars['String'];
  domain: Scalars['String'];
  homepageUrl?: Maybe<Scalars['String']>;
  name: Scalars['String'];
  paymentMethod: PartnerPaymentMethod;
  branding?: Maybe<PartnerBranding>;
  disabledAt?: Maybe<Scalars['DateTime']>;
};

export type PartnerBranding = {
  __typename?: 'PartnerBranding';
  id: Scalars['ID'];
  partnerId: Scalars['String'];
  logo: Scalars['String'];
  primaryColor: Scalars['String'];
};

export type ServiceCreatePartnerInput = {
  domain: Scalars['String'];
  paymentMethod: PartnerPaymentMethod;
  logo: Scalars['String'];
  primaryColor: Scalars['String'];
};

export type Referrer = {
  __typename?: 'Referrer';
  id: Scalars['String'];
  name: Scalars['String'];
  email?: Maybe<Scalars['String']>;
  isActive: Scalars['Boolean'];
};

export type QueryPlansWhereInput = {
  isArchived?: Maybe<BoolFilter>;
};

export type PlanWhereUniqueInput = {
  id?: Maybe<Scalars['String']>;
};



export enum ReportType {
  Employer = 'Employer',
  Personal = 'Personal'
}

export enum ReportRequestStatus {
  InProgress = 'InProgress',
  Completed = 'Completed',
  Clear = 'Clear',
  NeedsAttention = 'NeedsAttention',
  Cancelled = 'Cancelled',
  PendingRecruiterConfirmation = 'PendingRecruiterConfirmation',
  SentToCandidate = 'SentToCandidate',
  InviteExpired = 'InviteExpired'
}

export enum ReportRequestOrigin {
  Internal = 'Internal',
  JazzHr = 'JazzHR'
}

export enum ScanType {
  Full = 'Full',
  SyncUp = 'SyncUp'
}

export enum ScanStatus {
  New = 'New',
  Running = 'Running',
  Finished = 'Finished',
  Failed = 'Failed'
}

export type ReportOldWhereUniqueInput = {
  id?: Maybe<Scalars['String']>;
  scanId?: Maybe<Scalars['String']>;
};

export type BusinessCustomerWhereUniqueInput = {
  id?: Maybe<Scalars['String']>;
};

export type BusinessCustomerInvitationWhereUniqueInput = {
  id?: Maybe<Scalars['String']>;
};

export enum ContentType {
  Post = 'Post'
}

export type ContentAnalysisWhereUniqueInput = {
  id?: Maybe<Scalars['String']>;
  ContentId_Type?: Maybe<ContentAnalysisContentId_TypeCompoundUniqueInput>;
};

export enum SupportedLanguage {
  English = 'English',
  Spanish = 'Spanish'
}

export enum ContentAnalysisType {
  Profanity = 'Profanity',
  Toxicity = 'Toxicity',
  ImageOcr = 'ImageOCR',
  BusinessDictionary = 'BusinessDictionary',
  ImageModeration = 'ImageModeration',
  VideoModeration = 'VideoModeration',
  MultiLingual = 'MultiLingual'
}

export enum ContentAnalysisStatus {
  Pending = 'Pending',
  Running = 'Running',
  Finished = 'Finished',
  Failed = 'Failed'
}

export enum ApiKeyStatus {
  Active = 'Active',
  Revoked = 'Revoked'
}

export enum BusinessType {
  Business = 'Business',
  University = 'University'
}

export type PartnerBusinessSubscriptionWhereUniqueInput = {
  id?: Maybe<Scalars['String']>;
};

export enum BusinessCustomerType {
  CurrentEmployee = 'CurrentEmployee',
  PotentialEmployee = 'PotentialEmployee'
}

export enum BusinessUserRole {
  Admin = 'Admin'
}

export type BusinessQuoteWhereUniqueInput = {
  email?: Maybe<Scalars['String']>;
};

export type BusinessDictionaryEntryWhereUniqueInput = {
  id?: Maybe<Scalars['String']>;
  Text_DictionaryId?: Maybe<BusinessDictionaryEntryText_DictionaryIdCompoundUniqueInput>;
};

export enum PartnerPaymentMethod {
  Invoice = 'INVOICE',
  InvoiceUnlimited = 'INVOICE_UNLIMITED',
  Stripe = 'STRIPE'
}

export type BoolFilter = {
  equals?: Maybe<Scalars['Boolean']>;
  not?: Maybe<NestedBoolFilter>;
};

export type ContentAnalysisContentId_TypeCompoundUniqueInput = {
  contentId: Scalars['String'];
  type: ContentAnalysisType;
};

export type BusinessDictionaryEntryText_DictionaryIdCompoundUniqueInput = {
  dictionaryId: Scalars['String'];
  text: Scalars['String'];
};

export type NestedBoolFilter = {
  equals?: Maybe<Scalars['Boolean']>;
  not?: Maybe<NestedBoolFilter>;
};

export type Query = {
  __typename?: 'Query';
  plans: Array<Plan>;
  plan?: Maybe<Plan>;
  promoCode: PromoResponse;
  /** For manually retrieving Feature Flag payload */
  featureFlagPayload: Scalars['Json'];
  /** For manually checking if Feature flag for platformId/groupId/userId is enabled */
  featureFlagEnabled: Scalars['Boolean'];
  /**
   * For manually request the list of Feature Flags and their Configuration
   * @deprecated TBD: This is a service mutation it should not be used on Production
   */
  serviceFeatureFlagList: Scalars['Json'];
  listOfProfanities: Array<Scalars['String']>;
  taxRates: Array<StripeTaxRate>;
  servicePlatformStatistics: Scalars['Json'];
  individualCharges: Array<StripeCharge>;
  individualLastSubscription?: Maybe<StripeSubscription>;
  individualPurchaseAmount: IndividualPurchaseAmountResponse;
  individualPaymentMethod?: Maybe<PaymentMethod>;
  individualReport: Report;
  individualReports: Array<Report>;
  serviceUserAnalytics: Scalars['Json'];
  reportRequests: Array<ReportRequest>;
  reportRequest: ReportRequest;
  serviceReportRequests: Array<ReportRequest>;
  individualLegacyReport: ReportOld;
  individualLegacyReports: Array<ReportOld>;
  hasLegacyReports: Scalars['Boolean'];
  hasScanRunning: Scalars['Boolean'];
  lastScan?: Maybe<Scan>;
  finishedScansCount: Scalars['Int'];
  individualMe?: Maybe<User>;
  /** Mainly for fetching (business) user after change password via Auth0 */
  publicUserByEmail?: Maybe<PublicUser>;
  /** Fetching individual user's social media information through auth0 */
  socialMediaConnection: Array<SocialMediaConnection>;
  /**
   * For manually changing the scan amount based on User id or email and role
   * @deprecated This is a service mutation it should not be used on Production
   */
  serviceUserList?: Maybe<Array<User>>;
  /** Output determines main platform features access for user. */
  individualFeatureAccess: IndividualFeatureAccessOutput;
  /** Get all notifications for individual user. */
  individualUserNotifications: IndividualNotificationsResponse;
  serviceUserNotifications: Array<IndividualNotification>;
  individualNotificationsUnreadCount: Scalars['Int'];
  contents: ContentsResponse;
  dashboardContentBreakdowns: DashboardContentBreakdownsResponse;
  flaggedPostLabelsBreakdown: FlaggedPostLabelsBreakdownResponse;
  overviewContentBreakdowns: OverviewContentBreakdownsResponse;
  photobooks: Array<Photobook>;
  photobook?: Maybe<Photobook>;
  /** Returns posts between dates the ones has photo attachment for photobook */
  postsBetweenDate: Array<Content>;
  /** Returns counts of posts that has photo attachment grouped up by Month/Year */
  postDates: Array<PostsDatesOutput>;
  apiKey?: Maybe<BusinessApiKey>;
  serviceViewUserApiKey?: Maybe<BusinessApiKey>;
  serviceBusinessByApiKey: Business;
  /** @deprecated This is a service mutation it should not be used on Production */
  serviceBusinessList?: Maybe<Array<Business>>;
  businessCustomers: BusinessCustomersOutput;
  businessCustomerBreakdown: BusinessCustomerBreakdownOutput;
  businessMe?: Maybe<BusinessUser>;
  /** Mainly for fetching (business) user after change password via Auth0 */
  publicBusinessUserByEmail?: Maybe<PublicBusinessUser>;
  businessCustomerInvitations: BusinessCustomerInvitationsOutput;
  businessQuote?: Maybe<BusinessQuote>;
  businessPricing: PricingResponse;
  businessCharges: Array<StripeCharge>;
  businessLastSubscription?: Maybe<StripeSubscription>;
  businessPurchaseAmount: BusinessPurchaseAmountResponse;
  businessPaymentMethod?: Maybe<PaymentMethod>;
  businessLegacyReports: Array<ReportOld>;
  businessReports: Array<Report>;
  /** A aggregated breakdown of business dashboard related data */
  businessDashboardAggregates: BusinessDashboardAggregates;
  /** A aggregated breakdown of business dashboard related data */
  serviceBusinessAggregates: BusinessDashboardAggregates;
  businessReport: Report;
  businessReportsCount: Scalars['Int'];
  /** Get all notifications for business user. */
  businessUserNotifications: BusinessNotificationsResponse;
  serviceBusinessUserNotifications: Array<BusinessNotification>;
  businessNotificationsUnreadCount: Scalars['Int'];
  businessStatistics?: Maybe<BusinessStatistics>;
  businessDictionaryEntries: BusinessDictionaryResponse;
  /** Fetches public information about partner. The id argument has a preference to the domain argument */
  publicPartner?: Maybe<PublicPartner>;
  servicePartnerStripePayments: Scalars['Json'];
  servicePartnerInvoiceInvitations: Scalars['Json'];
  getReferrer?: Maybe<Referrer>;
  serviceReferrerReport: Scalars['Json'];
};


export type QueryPlansArgs = {
  where?: Maybe<QueryPlansWhereInput>;
  first?: Maybe<Scalars['Int']>;
  last?: Maybe<Scalars['Int']>;
  before?: Maybe<PlanWhereUniqueInput>;
  after?: Maybe<PlanWhereUniqueInput>;
};


export type QueryPlanArgs = {
  where: PlanWhereUniqueInput;
};


export type QueryPromoCodeArgs = {
  input: PromoQueryArgs;
};


export type QueryFeatureFlagPayloadArgs = {
  featureFlagId: Scalars['String'];
};


export type QueryFeatureFlagEnabledArgs = {
  featureFlagId: Scalars['String'];
};


export type QueryIndividualPurchaseAmountArgs = {
  input: IndividualPurchaseAmountQueryArgs;
};


export type QueryIndividualReportArgs = {
  reportId: Scalars['ID'];
};


export type QueryServiceUserAnalyticsArgs = {
  userId: Scalars['String'];
  FCRACompliant: Scalars['Boolean'];
  startDate?: Maybe<Scalars['DateTime']>;
  endDate?: Maybe<Scalars['DateTime']>;
};


export type QueryReportRequestsArgs = {
  onlyPending?: Maybe<Scalars['Boolean']>;
};


export type QueryReportRequestArgs = {
  id: Scalars['ID'];
};


export type QueryServiceReportRequestsArgs = {
  userId: Scalars['ID'];
  onlyPending?: Maybe<Scalars['Boolean']>;
};


export type QueryIndividualLegacyReportArgs = {
  reportId: Scalars['ID'];
};


export type QueryHasLegacyReportsArgs = {
  userId: Scalars['ID'];
};


export type QueryPublicUserByEmailArgs = {
  email: Scalars['String'];
};


export type QueryServiceUserListArgs = {
  email: Scalars['String'];
};


export type QueryIndividualUserNotificationsArgs = {
  input: IndividualNotificationsInput;
};


export type QueryServiceUserNotificationsArgs = {
  userId: Scalars['String'];
};


export type QueryContentsArgs = {
  input: ContentsInput;
};


export type QueryOverviewContentBreakdownsArgs = {
  input: OverviewContentBreakdownsInput;
};


export type QueryPhotobookArgs = {
  id: Scalars['ID'];
};


export type QueryPostsBetweenDateArgs = {
  dateFrom?: Maybe<Scalars['DateTime']>;
  dateTo?: Maybe<Scalars['DateTime']>;
};


export type QueryServiceViewUserApiKeyArgs = {
  businessId: Scalars['String'];
};


export type QueryServiceBusinessByApiKeyArgs = {
  key: Scalars['String'];
};


export type QueryServiceBusinessListArgs = {
  email: Scalars['String'];
};


export type QueryBusinessCustomersArgs = {
  input: BusinessCustomersInput;
};


export type QueryPublicBusinessUserByEmailArgs = {
  email: Scalars['String'];
};


export type QueryBusinessCustomerInvitationsArgs = {
  input: BusinessCustomerInvitationsInput;
};


export type QueryBusinessQuoteArgs = {
  where: BusinessQuoteWhereUniqueInput;
};


export type QueryBusinessPricingArgs = {
  input: PricingQueryArgs;
};


export type QueryBusinessPurchaseAmountArgs = {
  input: BusinessPurchaseAmountQueryArgs;
};


export type QueryBusinessLegacyReportsArgs = {
  userId: Scalars['ID'];
};


export type QueryBusinessReportsArgs = {
  userId: Scalars['ID'];
};


export type QueryBusinessDashboardAggregatesArgs = {
  type?: Maybe<BusinessCustomerType>;
};


export type QueryServiceBusinessAggregatesArgs = {
  businessId: Scalars['ID'];
  type?: Maybe<BusinessCustomerType>;
};


export type QueryBusinessReportArgs = {
  reportId: Scalars['ID'];
};


export type QueryBusinessReportsCountArgs = {
  userId: Scalars['ID'];
};


export type QueryBusinessUserNotificationsArgs = {
  input: BusinessNotificationsInput;
};


export type QueryServiceBusinessUserNotificationsArgs = {
  businessUserId: Scalars['String'];
};


export type QueryBusinessStatisticsArgs = {
  type: BusinessCustomerType;
};


export type QueryPublicPartnerArgs = {
  id?: Maybe<Scalars['String']>;
  domain?: Maybe<Scalars['String']>;
};


export type QueryServicePartnerStripePaymentsArgs = {
  startDate: Scalars['DateTime'];
  endDate: Scalars['DateTime'];
};


export type QueryServicePartnerInvoiceInvitationsArgs = {
  startDate?: Maybe<Scalars['DateTime']>;
  endDate?: Maybe<Scalars['DateTime']>;
};


export type QueryGetReferrerArgs = {
  id: Scalars['String'];
};


export type QueryServiceReferrerReportArgs = {
  startDate: Scalars['DateTime'];
  endDate: Scalars['DateTime'];
};

export type Mutation = {
  __typename?: 'Mutation';
  /**
   * For manually creating Feature Flag - expected to be done by JSON file during deployment
   * @deprecated This is a service mutation it should not be used on Production
   */
  serviceCreateFeatureFlag: FeatureFlag;
  /**
   * For manually creating Feature Flag Configuration line - assuming a Feature Flag Id already exists.
   * @deprecated TBD: This is a service mutation it should not be used on Production
   */
  serviceCreateFeatureFlagConfiguration: FeatureFlagConfiguration;
  /**
   * For manually deleting Feature Flags. It is set up, to remove in cascade, including Feature Flag Configuration lines related with this Feature Flag
   * @deprecated TBD: This is a service mutation it should not be used on Production
   */
  serviceDeleteFeatureFlag: Scalars['Boolean'];
  /**
   * For manually deleting Feature Flags. It is set up, to remove in cascade, including Feature Flag Configuration lines related with this Feature Flag
   * @deprecated TBD: This is a service mutation it should not be used on Production
   */
  serviceDeleteFeatureFlagConfiguration: Scalars['Boolean'];
  /**
   * For manually toggle the availability of an specific feature flag configuration
   * @deprecated TBD: This is a service mutation it should not be used on Production
   */
  serviceToggleFeatureFlagConfigurationEnable: Scalars['Boolean'];
  /**
   * For manually toggle the availability of an specific feature flag configuration
   * @deprecated TBD: This is a service mutation it should not be used on Production
   */
  serviceSetFeatureFlagPayload: Scalars['Json'];
  sendEmailToLifebrand: Scalars['Boolean'];
  serviceTriggerError: Scalars['Boolean'];
  serviceSendPlatformStatistics: Scalars['Boolean'];
  /**
   * Update on Privacy Policy and Terms and Conditions
   * @deprecated Service mutation to send Notification email about PP and TaC to all the Individual and Business users, should not be used in an app
   */
  serviceSendUpdateLegalDocuments: Scalars['Boolean'];
  createIndividualSubscription: Scalars['Boolean'];
  cancelIndividualSubscription: Scalars['Boolean'];
  updateIndividualPaymentMethod: Scalars['Boolean'];
  createReport: Report;
  sendReportPDF: Scalars['Boolean'];
  shareReport: Report;
  serviceCreateReport: Report;
  serviceShareReport: Report;
  serviceCreateReportRequest: ReportRequest;
  serviceFulfillReportRequest: ReportRequest;
  fulfillReportRequest: ReportRequest;
  rejectReportRequest: ReportRequest;
  runScan: Scan;
  /**
   * For testing purposes related to status of the scan
   * @deprecated This is a service mutation it should not be used on Production
   */
  serviceSetScanStatus: Scan;
  /**
   * For fixing issue with stuck scans for given user.
   * @deprecated This is a service mutation it should not be used on Production
   */
  serviceStopRunningScans: Scalars['Int'];
  signupAsIndividual: User;
  signupAsIndividualWithEmail?: Maybe<User>;
  loginAsIndividualWithEmail: LoginIndividualResponse;
  updateIndividualProfile: User;
  deleteIndividualUser: Scalars['Boolean'];
  linkSocialMedia: Array<SocialMediaConnection>;
  unlinkSocialMedia: Array<SocialMediaConnection>;
  /**
   * provider use: "facebook", "twitter", "oauth2" (instagram)
   * @deprecated Service mutation to unlink social media from the account
   */
  serviceUnlinkSocialMedia: Array<SocialMediaConnection>;
  changeIndividualPassword: Scalars['Boolean'];
  resetIndividualPassword: Scalars['Boolean'];
  acceptInvitation: Scalars['Boolean'];
  activatePartnerUserSubscription: Scalars['Boolean'];
  /**
   * For manually changing the scan amount based on User id or email and role
   * @deprecated This is a service mutation it should not be used on Production
   */
  serviceUserUpdateScanAmount: User;
  acceptFcra: User;
  /** Accepts a single version for both PP and T&C */
  acceptPolicy: User;
  /** Marks all (by default) or selected notifications as read. */
  markIndividualNotificationsAsRead: Scalars['Boolean'];
  /** Deletes selected notifications. */
  deleteIndividualNotifications: Scalars['Boolean'];
  /** @deprecated Service mutation to create an individual user notification, should not be used in an app */
  serviceCreateIndividualNotification: Scalars['Boolean'];
  serviceAutoSharingNotification: Scalars['Boolean'];
  deleteContent: Content;
  massDeleteContent: Array<DeleteContentResponse>;
  rescanContent: Content;
  createPhotobook: Photobook;
  deletePhotobook: Scalars['Boolean'];
  generateApiKey: BusinessApiKey;
  revokeApiKey: BusinessApiKey;
  serviceGenerateApiKey: BusinessApiKey;
  serviceRevokeApiKey: BusinessApiKey;
  createBusiness: BusinessUser;
  updateBusinessProfile: Business;
  changeBusinessUserPassword: Scalars['Boolean'];
  sendSupportForm: Scalars['Boolean'];
  activatePartnerBusinessSubscription: Scalars['Boolean'];
  /**
   * For manually changing the scan amount based on User id or email and role
   * @deprecated This is a service mutation it should not be used on Production
   */
  serviceBusinessUpdateInvitationAmount: Business;
  deactivateBusinessCustomer: Array<BusinessCustomer>;
  reactivateBusinessCustomer: Array<BusinessCustomer>;
  convertPotentialToCurrentEmployee: Array<BusinessCustomer>;
  changeBusinessCustomerExpirationDate: Scalars['Boolean'];
  serviceAddUserToBusiness: BusinessCustomer;
  /** Renamed from inviteToScan */
  sendInvitation: Array<BusinessCustomerInvitation>;
  importInvitations: Scalars['Boolean'];
  /** Renamed from reInviteScan */
  removeInvitation: Scalars['Boolean'];
  /** Renamed from reInviteScan */
  resendInvitation: Array<BusinessCustomerInvitation>;
  createBusinessSubscription: Scalars['Boolean'];
  cancelBusinessSubscription: Scalars['Boolean'];
  updateBusinessPaymentMethod: Scalars['Boolean'];
  markReportAsReadByBusiness: Report;
  /** Marks all (by default) or seleted notifications as read. */
  markBusinessNotificationsAsRead: Scalars['Boolean'];
  /** Deletes selected notifications. */
  deleteBusinessNotifications: Scalars['Boolean'];
  /** @deprecated Service mutation to create an business user notification, should not be used in an app */
  serviceCreateBusinessNotification: Scalars['Boolean'];
  updateBusinessStatistics: BusinessStatistics;
  addToDictionary: Scalars['Boolean'];
  deleteFromDictionary: Scalars['Boolean'];
  serviceEnableFeatureForBusiness: Business;
  serviceDisableFeatureForBusiness: Business;
  /** @deprecated Service mutation to create a new partner, should not be used in an app */
  servicePartnerCreate: PublicPartner;
  /** @deprecated Service mutation to update a partner, should not be used in an app */
  servicePartnerUpdate: PublicPartner;
  /** @deprecated Service mutation to toggle disableAt timestamp on a partner, should not be used in an app */
  servicePartnerToggleDisable: PublicPartner;
  serviceCreateReferrer: Referrer;
  serviceReferrerToggleActive: Referrer;
};


export type MutationServiceCreateFeatureFlagArgs = {
  input: CreateFeatureFlagInput;
};


export type MutationServiceCreateFeatureFlagConfigurationArgs = {
  input: CreateFeatureFlagConfigInput;
};


export type MutationServiceDeleteFeatureFlagArgs = {
  featureFlagId: Scalars['ID'];
};


export type MutationServiceDeleteFeatureFlagConfigurationArgs = {
  input: FeatureFlagUniqueKeyInput;
};


export type MutationServiceToggleFeatureFlagConfigurationEnableArgs = {
  input: FeatureFlagUniqueKeyInput;
};


export type MutationServiceSetFeatureFlagPayloadArgs = {
  featureFlagId: Scalars['ID'];
  payload?: Maybe<Scalars['Json']>;
};


export type MutationSendEmailToLifebrandArgs = {
  input: SendEmailToLifeBrandInput;
};


export type MutationServiceTriggerErrorArgs = {
  message?: Maybe<Scalars['String']>;
};


export type MutationCreateIndividualSubscriptionArgs = {
  input: CreateIndividualSubscriptionInput;
};


export type MutationUpdateIndividualPaymentMethodArgs = {
  stripeSource: Scalars['String'];
};


export type MutationCreateReportArgs = {
  type: ReportType;
  name: Scalars['String'];
};


export type MutationSendReportPdfArgs = {
  reportId: Scalars['ID'];
  emails: Array<Scalars['String']>;
};


export type MutationShareReportArgs = {
  reportId: Scalars['ID'];
};


export type MutationServiceCreateReportArgs = {
  userId: Scalars['ID'];
  type: ReportType;
  name: Scalars['String'];
};


export type MutationServiceShareReportArgs = {
  userId: Scalars['ID'];
  reportId: Scalars['ID'];
};


export type MutationServiceCreateReportRequestArgs = {
  userId: Scalars['ID'];
  businessId: Scalars['ID'];
  origin: ReportRequestOrigin;
};


export type MutationServiceFulfillReportRequestArgs = {
  userId: Scalars['ID'];
  reportRequestId: Scalars['ID'];
  reportId: Scalars['ID'];
};


export type MutationFulfillReportRequestArgs = {
  reportRequestId: Scalars['ID'];
  reportId: Scalars['ID'];
};


export type MutationRejectReportRequestArgs = {
  reportRequestId: Scalars['ID'];
};


export type MutationRunScanArgs = {
  origins: Array<SocialMedia>;
  type: ScanType;
};


export type MutationServiceSetScanStatusArgs = {
  id: Scalars['ID'];
  status: ScanStatus;
};


export type MutationServiceStopRunningScansArgs = {
  id: Scalars['ID'];
};


export type MutationSignupAsIndividualArgs = {
  input: SignupAsIndividualInput;
};


export type MutationSignupAsIndividualWithEmailArgs = {
  input: SignupAsIndividualWithEmailInput;
};


export type MutationLoginAsIndividualWithEmailArgs = {
  input: LoginAsIndividualWithEmailInput;
};


export type MutationUpdateIndividualProfileArgs = {
  input: UpdateIndividualProfileInput;
};


export type MutationDeleteIndividualUserArgs = {
  reasons: Array<Scalars['String']>;
};


export type MutationLinkSocialMediaArgs = {
  provider: Scalars['String'];
  identityId: Scalars['String'];
};


export type MutationUnlinkSocialMediaArgs = {
  provider: Scalars['String'];
};


export type MutationServiceUnlinkSocialMediaArgs = {
  id: Scalars['ID'];
  provider: Scalars['String'];
};


export type MutationChangeIndividualPasswordArgs = {
  currentPassword: Scalars['String'];
  newPassword: Scalars['String'];
};


export type MutationResetIndividualPasswordArgs = {
  email: Scalars['String'];
};


export type MutationAcceptInvitationArgs = {
  invitationId: Scalars['ID'];
};


export type MutationActivatePartnerUserSubscriptionArgs = {
  subscriptionId: Scalars['ID'];
};


export type MutationServiceUserUpdateScanAmountArgs = {
  id?: Maybe<Scalars['ID']>;
  email?: Maybe<Scalars['String']>;
  newScanAmount: Scalars['Int'];
};


export type MutationAcceptFcraArgs = {
  fcraVersion: Scalars['String'];
};


export type MutationAcceptPolicyArgs = {
  policyVersion: Scalars['String'];
};


export type MutationMarkIndividualNotificationsAsReadArgs = {
  notificationIds?: Maybe<Array<Scalars['ID']>>;
};


export type MutationDeleteIndividualNotificationsArgs = {
  notificationIds: Array<Scalars['ID']>;
};


export type MutationServiceCreateIndividualNotificationArgs = {
  userId: Scalars['String'];
  type: Scalars['String'];
};


export type MutationServiceAutoSharingNotificationArgs = {
  currentEmployeeEmail?: Maybe<Scalars['String']>;
};


export type MutationDeleteContentArgs = {
  input: DeleteContentInput;
};


export type MutationMassDeleteContentArgs = {
  contentIds: Array<Scalars['ID']>;
};


export type MutationRescanContentArgs = {
  id: Scalars['ID'];
  reanalyze?: Scalars['Boolean'];
};


export type MutationCreatePhotobookArgs = {
  dateFrom: Scalars['DateTime'];
  dateTo: Scalars['DateTime'];
  title: Scalars['String'];
  coverImage: Scalars['String'];
};


export type MutationDeletePhotobookArgs = {
  id: Scalars['ID'];
};


export type MutationRevokeApiKeyArgs = {
  key: Scalars['String'];
};


export type MutationServiceGenerateApiKeyArgs = {
  userId: Scalars['String'];
};


export type MutationServiceRevokeApiKeyArgs = {
  key: Scalars['String'];
};


export type MutationCreateBusinessArgs = {
  input: CreateBusinessInput;
};


export type MutationUpdateBusinessProfileArgs = {
  input: UpdateBusinessProfileInput;
};


export type MutationChangeBusinessUserPasswordArgs = {
  currentPassword: Scalars['String'];
  newPassword: Scalars['String'];
};


export type MutationSendSupportFormArgs = {
  firstName: Scalars['String'];
  lastName: Scalars['String'];
  email: Scalars['String'];
  subject: Scalars['String'];
  message: Scalars['String'];
};


export type MutationActivatePartnerBusinessSubscriptionArgs = {
  subscriptionId: Scalars['ID'];
};


export type MutationServiceBusinessUpdateInvitationAmountArgs = {
  id?: Maybe<Scalars['ID']>;
  email?: Maybe<Scalars['String']>;
  newInvitationAmount: Scalars['Int'];
};


export type MutationDeactivateBusinessCustomerArgs = {
  ids: Array<Scalars['ID']>;
};


export type MutationReactivateBusinessCustomerArgs = {
  ids: Array<Scalars['ID']>;
};


export type MutationConvertPotentialToCurrentEmployeeArgs = {
  ids: Array<Scalars['ID']>;
};


export type MutationChangeBusinessCustomerExpirationDateArgs = {
  ids: Array<Scalars['ID']>;
  expiresAt?: Maybe<Scalars['DateTime']>;
};


export type MutationServiceAddUserToBusinessArgs = {
  userId: Scalars['ID'];
  businessId: Scalars['ID'];
  type: BusinessCustomerType;
};


export type MutationSendInvitationArgs = {
  emails: Array<Scalars['String']>;
  type: BusinessCustomerType;
  expiresAt?: Maybe<Scalars['DateTime']>;
};


export type MutationImportInvitationsArgs = {
  fileUrl: Scalars['String'];
  type: BusinessCustomerType;
};


export type MutationRemoveInvitationArgs = {
  invitationIds: Array<Scalars['ID']>;
};


export type MutationResendInvitationArgs = {
  invitationIds: Array<Scalars['String']>;
};


export type MutationCreateBusinessSubscriptionArgs = {
  input: CreateBusinessSubscriptionInput;
};


export type MutationUpdateBusinessPaymentMethodArgs = {
  stripeSource: Scalars['String'];
};


export type MutationMarkReportAsReadByBusinessArgs = {
  reportId: Scalars['ID'];
};


export type MutationMarkBusinessNotificationsAsReadArgs = {
  notificationIds?: Maybe<Array<Scalars['ID']>>;
};


export type MutationDeleteBusinessNotificationsArgs = {
  notificationIds: Array<Scalars['ID']>;
};


export type MutationServiceCreateBusinessNotificationArgs = {
  businessId: Scalars['String'];
  type: Scalars['String'];
};


export type MutationUpdateBusinessStatisticsArgs = {
  type: BusinessCustomerType;
};


export type MutationAddToDictionaryArgs = {
  text: Scalars['String'];
};


export type MutationDeleteFromDictionaryArgs = {
  dictionaryEntryIds: Array<Scalars['ID']>;
};


export type MutationServiceEnableFeatureForBusinessArgs = {
  businessId: Scalars['ID'];
  feature: BusinessFeature;
};


export type MutationServiceDisableFeatureForBusinessArgs = {
  businessId: Scalars['ID'];
  feature: BusinessFeature;
};


export type MutationServicePartnerCreateArgs = {
  domain: Scalars['String'];
  paymentMethod: PartnerPaymentMethod;
  logo: Scalars['String'];
  primaryColor: Scalars['String'];
};


export type MutationServicePartnerUpdateArgs = {
  id: Scalars['ID'];
  domain: Scalars['String'];
  paymentMethod: PartnerPaymentMethod;
  logo: Scalars['String'];
  primaryColor: Scalars['String'];
};


export type MutationServicePartnerToggleDisableArgs = {
  id: Scalars['ID'];
  disable: Scalars['Boolean'];
};


export type MutationServiceCreateReferrerArgs = {
  name: Scalars['String'];
  email: Scalars['String'];
};


export type MutationServiceReferrerToggleActiveArgs = {
  id: Scalars['String'];
};

export type PlanDataFragment = (
  { __typename?: 'Plan' }
  & Pick<Plan, 'id' | 'name' | 'type' | 'numberOfScans' | 'isRecurring' | 'price'>
);

export type ChargeDataFragment = (
  { __typename?: 'StripeCharge' }
  & Pick<StripeCharge, 'id' | 'date' | 'amount' | 'currency' | 'description' | 'receiptUrl' | 'invoiceUrl'>
);

export type PromoCodeFragment = (
  { __typename?: 'PromoResponse' }
  & Pick<PromoResponse, 'amountOff' | 'percentOff' | 'isActive' | 'isFound'>
);

export type IndividualPurchaseAmountDataFragment = (
  { __typename?: 'IndividualPurchaseAmountResponse' }
  & Pick<IndividualPurchaseAmountResponse, 'planName' | 'price' | 'recurringPrice' | 'promoAmountOff' | 'taxAmount' | 'taxPercentage' | 'totalPrice'>
);

export type TaxRateDataFragment = (
  { __typename?: 'StripeTaxRate' }
  & Pick<StripeTaxRate, 'id' | 'active' | 'livemode' | 'percentage' | 'country' | 'state'>
);

export type CreateIndividualSubscriptionMutationVariables = Exact<{
  input: CreateIndividualSubscriptionInput;
}>;


export type CreateIndividualSubscriptionMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'createIndividualSubscription'>
);

export type CancelIndividualSubscriptionMutationVariables = Exact<{ [key: string]: never; }>;


export type CancelIndividualSubscriptionMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'cancelIndividualSubscription'>
);

export type UpdateIndividualPaymentMethodMutationVariables = Exact<{
  stripeSource: Scalars['String'];
}>;


export type UpdateIndividualPaymentMethodMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'updateIndividualPaymentMethod'>
);

export type SearchPromoQueryVariables = Exact<{
  input: PromoQueryArgs;
}>;


export type SearchPromoQuery = (
  { __typename?: 'Query' }
  & { promoCode: (
    { __typename?: 'PromoResponse' }
    & PromoCodeFragment
  ) }
);

export type SearchIndividualPurchaseAmountQueryVariables = Exact<{
  input: IndividualPurchaseAmountQueryArgs;
}>;


export type SearchIndividualPurchaseAmountQuery = (
  { __typename?: 'Query' }
  & { individualPurchaseAmount: (
    { __typename?: 'IndividualPurchaseAmountResponse' }
    & IndividualPurchaseAmountDataFragment
  ) }
);

export type PlansQueryVariables = Exact<{ [key: string]: never; }>;


export type PlansQuery = (
  { __typename?: 'Query' }
  & { plans: Array<(
    { __typename?: 'Plan' }
    & PlanDataFragment
  )> }
);

export type BillingHistoryQueryVariables = Exact<{ [key: string]: never; }>;


export type BillingHistoryQuery = (
  { __typename?: 'Query' }
  & { individualCharges: Array<(
    { __typename?: 'StripeCharge' }
    & ChargeDataFragment
  )> }
);

export type TaxRatesQueryVariables = Exact<{ [key: string]: never; }>;


export type TaxRatesQuery = (
  { __typename?: 'Query' }
  & { taxRates: Array<(
    { __typename?: 'StripeTaxRate' }
    & TaxRateDataFragment
  )> }
);

export type IndividualPaymentMethodQueryVariables = Exact<{ [key: string]: never; }>;


export type IndividualPaymentMethodQuery = (
  { __typename?: 'Query' }
  & { individualPaymentMethod?: Maybe<(
    { __typename?: 'PaymentMethod' }
    & Pick<PaymentMethod, 'id'>
    & { card: (
      { __typename?: 'CardPaymentMethod' }
      & Pick<CardPaymentMethod, 'last4' | 'exp_month' | 'exp_year'>
    ) }
  )> }
);

export type ContentAnalysisDataFragment = (
  { __typename?: 'ContentAnalysis' }
  & Pick<ContentAnalysis, 'id' | 'contentId' | 'type' | 'status' | 'passed' | 'score' | 'results' | 'labels' | 'finishedAt' | 'createdAt' | 'updatedAt'>
);

export type ContentDataFragment = (
  { __typename?: 'Content' }
  & Pick<Content, 'id' | 'text' | 'type' | 'score' | 'origin' | 'url' | 'postedAt' | 'interactions' | 'media' | 'isFlagged' | 'isDeleted' | 'createdAt' | 'language'>
  & { ContentAnalysis: Array<(
    { __typename?: 'ContentAnalysis' }
    & ContentAnalysisDataFragment
  )> }
);

export type DashboardContentBreakdownsDataFragment = (
  { __typename?: 'DashboardContentBreakdownsResponse' }
  & Pick<DashboardContentBreakdownsResponse, 'nonFlaggedCount' | 'flaggedCount' | 'allContentsCount' | 'businessDictionaryCount'>
  & { labelsBreakdown: (
    { __typename?: 'FlaggedPostLabelsBreakdownResponse' }
    & FlaggedPostLabelsBreakdownDataFragment
  ), originsBreakdown: (
    { __typename?: 'OriginsBreakdown' }
    & OriginsBreakdownDataFragment
  ), flaggedByOriginsBreakdown: (
    { __typename?: 'OriginsBreakdown' }
    & OriginsBreakdownDataFragment
  ), businessDictionaryByOriginsBreakdown: (
    { __typename?: 'OriginsBreakdown' }
    & OriginsBreakdownDataFragment
  ) }
);

export type OverviewContentBreakdownsDataFragment = (
  { __typename?: 'OverviewContentBreakdownsResponse' }
  & Pick<OverviewContentBreakdownsResponse, 'flaggedContentsCount' | 'nonFlaggedContentsCount' | 'deletedFlaggedContentsCount' | 'businessDictionaryContentsCount' | 'flaggedByTimelineBreakdown'>
  & { flaggedByOriginsBreakdown: (
    { __typename?: 'OriginsBreakdown' }
    & OriginsBreakdownDataFragment
  ), flaggedByLabelsBreakdown: (
    { __typename?: 'FlaggedPostLabelsBreakdownResponse' }
    & FlaggedPostLabelsBreakdownDataFragment
  ) }
);

export type OriginsBreakdownDataFragment = (
  { __typename?: 'OriginsBreakdown' }
  & Pick<OriginsBreakdown, 'Facebook' | 'Twitter' | 'Instagram'>
);

export type FlaggedPostLabelsBreakdownDataFragment = (
  { __typename?: 'FlaggedPostLabelsBreakdownResponse' }
  & Pick<FlaggedPostLabelsBreakdownResponse, 'identity_attack' | 'insult' | 'obscene' | 'threat' | 'sexual_explicit' | 'sexual' | 'severe_toxicity' | 'toxicity' | 'inappropriate' | 'blasphemy' | 'discriminatory'>
);

export type DeleteContentMutationVariables = Exact<{
  input: DeleteContentInput;
}>;


export type DeleteContentMutation = (
  { __typename?: 'Mutation' }
  & { deleteContent: (
    { __typename?: 'Content' }
    & Pick<Content, 'id' | 'isDeleted'>
  ) }
);

export type MassDeleteContentMutationVariables = Exact<{
  contentIds: Array<Scalars['ID']> | Scalars['ID'];
}>;


export type MassDeleteContentMutation = (
  { __typename?: 'Mutation' }
  & { massDeleteContent: Array<(
    { __typename?: 'DeleteContentResponse' }
    & Pick<DeleteContentResponse, 'contentId' | 'isDeleted' | 'errorMessage'>
  )> }
);

export type DashboardContentBreakdownsQueryVariables = Exact<{ [key: string]: never; }>;


export type DashboardContentBreakdownsQuery = (
  { __typename?: 'Query' }
  & { dashboardContentBreakdowns: (
    { __typename?: 'DashboardContentBreakdownsResponse' }
    & DashboardContentBreakdownsDataFragment
  ) }
);

export type FlaggedPostLabelsBreakdownQueryVariables = Exact<{ [key: string]: never; }>;


export type FlaggedPostLabelsBreakdownQuery = (
  { __typename?: 'Query' }
  & { flaggedPostLabelsBreakdown: (
    { __typename?: 'FlaggedPostLabelsBreakdownResponse' }
    & FlaggedPostLabelsBreakdownDataFragment
  ) }
);

export type ContentsQueryVariables = Exact<{
  input: ContentsInput;
}>;


export type ContentsQuery = (
  { __typename?: 'Query' }
  & { contents: (
    { __typename?: 'ContentsResponse' }
    & Pick<ContentsResponse, 'nextCursorId'>
    & { list: Array<(
      { __typename?: 'Content' }
      & ContentDataFragment
    )> }
  ) }
);

export type OverviewContentBreakdownsQueryVariables = Exact<{
  input: OverviewContentBreakdownsInput;
}>;


export type OverviewContentBreakdownsQuery = (
  { __typename?: 'Query' }
  & { overviewContentBreakdowns: (
    { __typename?: 'OverviewContentBreakdownsResponse' }
    & OverviewContentBreakdownsDataFragment
  ) }
);

export type BusinessCustomerDataFragment = (
  { __typename?: 'BusinessCustomer' }
  & Pick<BusinessCustomer, 'id' | 'type' | 'isActive' | 'updatedAt'>
  & { Business: (
    { __typename?: 'PublicBusiness' }
    & Pick<PublicBusiness, 'id' | 'name' | 'contactEmail' | 'features'>
    & { BusinessDictionary?: Maybe<(
      { __typename?: 'BusinessDictionary' }
      & Pick<BusinessDictionary, 'id' | 'createdAt' | 'updatedAt'>
    )> }
  ) }
);

export type UserDataFragment = (
  { __typename?: 'User' }
  & Pick<User, 'id' | 'name' | 'email' | 'photo' | 'scanAmount' | 'authId' | 'stripeId' | 'planId' | 'createdAt' | 'updatedAt' | 'lastRefresh' | 'acceptedFcraVersion' | 'acceptedPolicyVersion' | 'hasPassword' | 'referrerId'>
  & { BusinessCustomer: Array<(
    { __typename?: 'BusinessCustomer' }
    & BusinessCustomerDataFragment
  )> }
);

export type SubscriptionDataFragment = (
  { __typename: 'StripeSubscription' }
  & Pick<StripeSubscription, 'id' | 'status' | 'created' | 'currentPeriodStart' | 'currentPeriodEnd' | 'cancelAtPeriodEnd' | 'cancelAt' | 'canceledAt' | 'endedAt'>
);

export type SocialMediaConnectionFragment = (
  { __typename?: 'SocialMediaConnection' }
  & Pick<SocialMediaConnection, 'userName' | 'userPhoto' | 'socialMedia' | 'isMainIdentity' | 'isConnected' | 'isExpired'>
);

export type IndividualFeatureAccessDataFragment = (
  { __typename?: 'IndividualFeatureAccess' }
  & Pick<IndividualFeatureAccess, 'canAccessAnalytics' | 'canUseAdvancedDashboard' | 'canUpgrade' | 'canScan'>
);

export type IndividualCurrentPlanDataFragment = (
  { __typename?: 'IndividualCurrentPlan' }
  & Pick<IndividualCurrentPlan, 'name' | 'currentPeriodEnds' | 'isCancelled' | 'isCancellable'>
);

export type SignupAsIndividualMutationVariables = Exact<{
  input: SignupAsIndividualInput;
}>;


export type SignupAsIndividualMutation = (
  { __typename?: 'Mutation' }
  & { signupAsIndividual: (
    { __typename?: 'User' }
    & { Plan?: Maybe<(
      { __typename?: 'Plan' }
      & PlanDataFragment
    )> }
    & UserDataFragment
  ) }
);

export type SignupAsIndividualWithEmailMutationVariables = Exact<{
  input: SignupAsIndividualWithEmailInput;
}>;


export type SignupAsIndividualWithEmailMutation = (
  { __typename?: 'Mutation' }
  & { signupAsIndividualWithEmail?: Maybe<(
    { __typename?: 'User' }
    & Pick<User, 'id'>
  )> }
);

export type LoginAsIndividualWithEmailMutationVariables = Exact<{
  input: LoginAsIndividualWithEmailInput;
}>;


export type LoginAsIndividualWithEmailMutation = (
  { __typename?: 'Mutation' }
  & { loginAsIndividualWithEmail: (
    { __typename?: 'LoginIndividualResponse' }
    & Pick<LoginIndividualResponse, 'accessToken'>
  ) }
);

export type DeleteIndividualUserMutationVariables = Exact<{
  reasons: Array<Scalars['String']> | Scalars['String'];
}>;


export type DeleteIndividualUserMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'deleteIndividualUser'>
);

export type AcceptInvitationMutationVariables = Exact<{
  invitationId: Scalars['ID'];
}>;


export type AcceptInvitationMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'acceptInvitation'>
);

export type ActivatePartnerSubscriptionMutationVariables = Exact<{
  subscriptionId: Scalars['ID'];
}>;


export type ActivatePartnerSubscriptionMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'activatePartnerUserSubscription'>
);

export type LinkSocialMediaMutationVariables = Exact<{
  provider: Scalars['String'];
  identityId: Scalars['String'];
}>;


export type LinkSocialMediaMutation = (
  { __typename?: 'Mutation' }
  & { linkSocialMedia: Array<(
    { __typename?: 'SocialMediaConnection' }
    & SocialMediaConnectionFragment
  )> }
);

export type UnlinkSocialMediaMutationVariables = Exact<{
  provider: Scalars['String'];
}>;


export type UnlinkSocialMediaMutation = (
  { __typename?: 'Mutation' }
  & { unlinkSocialMedia: Array<(
    { __typename?: 'SocialMediaConnection' }
    & SocialMediaConnectionFragment
  )> }
);

export type UpdateIndividualProfileMutationVariables = Exact<{
  input: UpdateIndividualProfileInput;
}>;


export type UpdateIndividualProfileMutation = (
  { __typename?: 'Mutation' }
  & { updateIndividualProfile: (
    { __typename: 'User' }
    & Pick<User, 'id' | 'name' | 'email'>
  ) }
);

export type IndividualChangePasswordMutationVariables = Exact<{
  currentPassword: Scalars['String'];
  newPassword: Scalars['String'];
}>;


export type IndividualChangePasswordMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'changeIndividualPassword'>
);

export type ResetIndividualPasswordMutationVariables = Exact<{
  email: Scalars['String'];
}>;


export type ResetIndividualPasswordMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'resetIndividualPassword'>
);

export type AcceptFcraMutationVariables = Exact<{
  fcraVersion: Scalars['String'];
}>;


export type AcceptFcraMutation = (
  { __typename?: 'Mutation' }
  & { acceptFcra: (
    { __typename?: 'User' }
    & Pick<User, 'id' | 'acceptedFcraVersion'>
  ) }
);

export type AcceptPolicyMutationVariables = Exact<{
  policyVersion: Scalars['String'];
}>;


export type AcceptPolicyMutation = (
  { __typename?: 'Mutation' }
  & { acceptPolicy: (
    { __typename?: 'User' }
    & Pick<User, 'id' | 'acceptedPolicyVersion'>
  ) }
);

export type AuthQueryVariables = Exact<{ [key: string]: never; }>;


export type AuthQuery = (
  { __typename?: 'Query' }
  & { individualMe?: Maybe<(
    { __typename?: 'User' }
    & { Plan?: Maybe<(
      { __typename?: 'Plan' }
      & PlanDataFragment
    )> }
    & UserDataFragment
  )> }
);

export type MySocialMediaConnectionsQueryVariables = Exact<{ [key: string]: never; }>;


export type MySocialMediaConnectionsQuery = (
  { __typename?: 'Query' }
  & { socialMediaConnection: Array<(
    { __typename?: 'SocialMediaConnection' }
    & SocialMediaConnectionFragment
  )> }
);

export type PublicUserQueryVariables = Exact<{
  email: Scalars['String'];
}>;


export type PublicUserQuery = (
  { __typename?: 'Query' }
  & { publicUserByEmail?: Maybe<(
    { __typename?: 'PublicUser' }
    & Pick<PublicUser, 'id' | 'partnerId'>
    & { partner?: Maybe<(
      { __typename?: 'PublicPartner' }
      & Pick<PublicPartner, 'domain'>
    )> }
  )> }
);

export type IndividualFeatureAccessQueryVariables = Exact<{ [key: string]: never; }>;


export type IndividualFeatureAccessQuery = (
  { __typename?: 'Query' }
  & { individualFeatureAccess: (
    { __typename?: 'IndividualFeatureAccessOutput' }
    & { features: (
      { __typename?: 'IndividualFeatureAccess' }
      & IndividualFeatureAccessDataFragment
    ), plan?: Maybe<(
      { __typename?: 'IndividualCurrentPlan' }
      & IndividualCurrentPlanDataFragment
    )> }
  ) }
);

export type ReferrerIdCheckQueryVariables = Exact<{
  id: Scalars['String'];
}>;


export type ReferrerIdCheckQuery = (
  { __typename?: 'Query' }
  & { getReferrer?: Maybe<(
    { __typename?: 'Referrer' }
    & Pick<Referrer, 'id' | 'isActive'>
  )> }
);

export type GetFeatureFlagPayloadQueryVariables = Exact<{
  featureFlagId: Scalars['String'];
}>;


export type GetFeatureFlagPayloadQuery = (
  { __typename?: 'Query' }
  & Pick<Query, 'featureFlagPayload'>
);

export type IsFeatureFlagEnabledQueryVariables = Exact<{
  featureFlagId: Scalars['String'];
}>;


export type IsFeatureFlagEnabledQuery = (
  { __typename?: 'Query' }
  & Pick<Query, 'featureFlagEnabled'>
);

export type IndividualNotificationDataFragment = (
  { __typename: 'IndividualNotification' }
  & Pick<IndividualNotification, 'id' | 'type' | 'title' | 'text' | 'userId' | 'createdAt' | 'readAt' | 'deletedAt' | 'isRead' | 'isDeleted'>
);

export type MarkIndividualNotificationsAsReadMutationVariables = Exact<{
  notificationIds?: Maybe<Array<Scalars['ID']> | Scalars['ID']>;
}>;


export type MarkIndividualNotificationsAsReadMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'markIndividualNotificationsAsRead'>
);

export type DeleteIndividualNotificationsMutationVariables = Exact<{
  notificationIds: Array<Scalars['ID']> | Scalars['ID'];
}>;


export type DeleteIndividualNotificationsMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'deleteIndividualNotifications'>
);

export type IndividualNotificationsQueryVariables = Exact<{
  input: IndividualNotificationsInput;
}>;


export type IndividualNotificationsQuery = (
  { __typename?: 'Query' }
  & Pick<Query, 'individualNotificationsUnreadCount'>
  & { individualUserNotifications: (
    { __typename?: 'IndividualNotificationsResponse' }
    & Pick<IndividualNotificationsResponse, 'nextCursorId'>
    & { list: Array<(
      { __typename?: 'IndividualNotification' }
      & IndividualNotificationDataFragment
    )> }
  ) }
);

export type IndividualNotificationUnreadCountQueryVariables = Exact<{ [key: string]: never; }>;


export type IndividualNotificationUnreadCountQuery = (
  { __typename?: 'Query' }
  & Pick<Query, 'individualNotificationsUnreadCount'>
);

export type PhotobookFragment = (
  { __typename?: 'Photobook' }
  & Pick<Photobook, 'id' | 'title' | 'dateFrom' | 'dateTo' | 'coverImage' | 'pdfUrl' | 'userId'>
);

export type CreatePhotobookMutationVariables = Exact<{
  dateFrom: Scalars['DateTime'];
  dateTo: Scalars['DateTime'];
  title: Scalars['String'];
  coverImage: Scalars['String'];
}>;


export type CreatePhotobookMutation = (
  { __typename?: 'Mutation' }
  & { createPhotobook: (
    { __typename?: 'Photobook' }
    & PhotobookFragment
  ) }
);

export type DeletePhotobookMutationVariables = Exact<{
  id: Scalars['ID'];
}>;


export type DeletePhotobookMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'deletePhotobook'>
);

export type PostsBetweenDatesQueryVariables = Exact<{
  dateFrom?: Maybe<Scalars['DateTime']>;
  dateTo?: Maybe<Scalars['DateTime']>;
}>;


export type PostsBetweenDatesQuery = (
  { __typename?: 'Query' }
  & { postsBetweenDate: Array<(
    { __typename?: 'Content' }
    & Pick<Content, 'id' | 'text' | 'interactions' | 'media'>
  )> }
);

export type PhotobookPhotoDatesQueryVariables = Exact<{ [key: string]: never; }>;


export type PhotobookPhotoDatesQuery = (
  { __typename?: 'Query' }
  & { postDates: Array<(
    { __typename?: 'PostsDatesOutput' }
    & Pick<PostsDatesOutput, 'count' | 'date'>
  )> }
);

export type PhotobooksQueryVariables = Exact<{ [key: string]: never; }>;


export type PhotobooksQuery = (
  { __typename?: 'Query' }
  & { photobooks: Array<(
    { __typename?: 'Photobook' }
    & PhotobookFragment
  )> }
);

export type PhotobookQueryVariables = Exact<{
  id: Scalars['ID'];
}>;


export type PhotobookQuery = (
  { __typename?: 'Query' }
  & { photobook?: Maybe<(
    { __typename?: 'Photobook' }
    & PhotobookFragment
  )> }
);

export type ReportDataFragment = (
  { __typename?: 'Report' }
  & Pick<Report, 'id' | 'userId' | 'type' | 'name' | 'isFCRACompliant' | 'createdAt' | 'startDate' | 'endDate' | 'isShared' | 'pdfUrl' | 'flaggedContentsCount' | 'nonFlaggedContentsCount' | 'deletedFlaggedContentsCount' | 'businessDictionaryContentsCount' | 'allByTimelineBreakdown' | 'flaggedByTimelineBreakdown'>
  & { originsLastScannedBreakdown: (
    { __typename?: 'ScanDateOriginsBreakdown' }
    & Pick<ScanDateOriginsBreakdown, 'Facebook' | 'Twitter' | 'Instagram'>
  ), flaggedByOriginsBreakdown: (
    { __typename?: 'OriginsBreakdown' }
    & Pick<OriginsBreakdown, 'Facebook' | 'Twitter' | 'Instagram'>
  ), flaggedByLabelsBreakdown: (
    { __typename?: 'FlaggedPostLabelsBreakdownResponse' }
    & Pick<FlaggedPostLabelsBreakdownResponse, 'identity_attack' | 'insult' | 'obscene' | 'threat' | 'sexual_explicit' | 'sexual' | 'severe_toxicity' | 'toxicity' | 'inappropriate' | 'blasphemy' | 'discriminatory'>
  ), allByOriginsBreakdown: (
    { __typename?: 'OriginsBreakdown' }
    & Pick<OriginsBreakdown, 'Facebook' | 'Twitter' | 'Instagram'>
  ) }
);

export type ReportOldDataFragment = (
  { __typename?: 'ReportOld' }
  & Pick<ReportOld, 'id' | 'harmfulBreakdown' | 'timelineBreakdown' | 'profanitiesBreakdown' | 'harmfulPostCount' | 'deletedPostCount' | 'ignoredPostCount' | 'pdfUrl' | 'createdAt' | 'sentAt' | 'startDate' | 'endDate'>
  & { User?: Maybe<(
    { __typename?: 'User' }
    & Pick<User, 'id' | 'name' | 'Integrations'>
  )> }
);

export type IndividualLegacyReportsQueryVariables = Exact<{ [key: string]: never; }>;


export type IndividualLegacyReportsQuery = (
  { __typename?: 'Query' }
  & { individualLegacyReports: Array<(
    { __typename?: 'ReportOld' }
    & ReportOldDataFragment
  )> }
);

export type HasLegacyReportsQueryVariables = Exact<{
  userId: Scalars['ID'];
}>;


export type HasLegacyReportsQuery = (
  { __typename?: 'Query' }
  & Pick<Query, 'hasLegacyReports'>
);

export type CreateReportMutationVariables = Exact<{
  type: ReportType;
  name: Scalars['String'];
}>;


export type CreateReportMutation = (
  { __typename?: 'Mutation' }
  & { createReport: (
    { __typename?: 'Report' }
    & Pick<Report, 'id'>
  ) }
);

export type ShareReportMutationVariables = Exact<{
  reportId: Scalars['ID'];
}>;


export type ShareReportMutation = (
  { __typename?: 'Mutation' }
  & { shareReport: (
    { __typename?: 'Report' }
    & Pick<Report, 'id' | 'isShared'>
  ) }
);

export type SendReportPdfMutationVariables = Exact<{
  reportId: Scalars['ID'];
  emails: Array<Scalars['String']> | Scalars['String'];
}>;


export type SendReportPdfMutation = (
  { __typename?: 'Mutation' }
  & Pick<Mutation, 'sendReportPDF'>
);

export type IndividualReportQueryVariables = Exact<{
  id: Scalars['ID'];
}>;


export type IndividualReportQuery = (
  { __typename?: 'Query' }
  & { individualReport: (
    { __typename?: 'Report' }
    & ReportDataFragment
  ) }
);

export type IndividualReportsQueryVariables = Exact<{ [key: string]: never; }>;


export type IndividualReportsQuery = (
  { __typename?: 'Query' }
  & { individualReports: Array<(
    { __typename?: 'Report' }
    & ReportDataFragment
  )> }
);

export type ReportRequestDataFragment = (
  { __typename?: 'ReportRequest' }
  & Pick<ReportRequest, 'id' | 'status' | 'origin' | 'userId' | 'createdAt' | 'updatedAt'>
  & { Business: (
    { __typename?: 'Business' }
    & Pick<Business, 'id' | 'name' | 'contactEmail'>
  ) }
);

export type RejectReportRequestMutationVariables = Exact<{
  reportRequestId: Scalars['ID'];
}>;


export type RejectReportRequestMutation = (
  { __typename?: 'Mutation' }
  & { rejectReportRequest: (
    { __typename?: 'ReportRequest' }
    & ReportRequestDataFragment
  ) }
);

export type FulfillReportRequestMutationVariables = Exact<{
  reportRequestId: Scalars['ID'];
  reportId: Scalars['ID'];
}>;


export type FulfillReportRequestMutation = (
  { __typename?: 'Mutation' }
  & { fulfillReportRequest: (
    { __typename?: 'ReportRequest' }
    & ReportRequestDataFragment
  ) }
);

export type PendingReportRequestsQueryVariables = Exact<{ [key: string]: never; }>;


export type PendingReportRequestsQuery = (
  { __typename?: 'Query' }
  & { reportRequests: Array<(
    { __typename?: 'ReportRequest' }
    & ReportRequestDataFragment
  )> }
);

export type ReportRequestQueryVariables = Exact<{
  id: Scalars['ID'];
}>;


export type ReportRequestQuery = (
  { __typename?: 'Query' }
  & { reportRequest: (
    { __typename?: 'ReportRequest' }
    & ReportRequestDataFragment
  ) }
);

export type ScanDataFragment = (
  { __typename?: 'Scan' }
  & Pick<Scan, 'id' | 'type' | 'status' | 'startedAt' | 'createdAt' | 'updatedAt' | 'duration'>
);

export type RunScanMutationVariables = Exact<{
  origins: Array<SocialMedia> | SocialMedia;
  type: ScanType;
}>;


export type RunScanMutation = (
  { __typename?: 'Mutation' }
  & { runScan: (
    { __typename?: 'Scan' }
    & ScanDataFragment
  ) }
);

export type LastScanQueryVariables = Exact<{ [key: string]: never; }>;


export type LastScanQuery = (
  { __typename?: 'Query' }
  & { lastScan?: Maybe<(
    { __typename?: 'Scan' }
    & ScanDataFragment
  )> }
);

export type HasScanRunningQueryVariables = Exact<{ [key: string]: never; }>;


export type HasScanRunningQuery = (
  { __typename?: 'Query' }
  & Pick<Query, 'hasScanRunning'>
);

export type FinishedScansCountQueryVariables = Exact<{ [key: string]: never; }>;


export type FinishedScansCountQuery = (
  { __typename?: 'Query' }
  & Pick<Query, 'finishedScansCount'>
);

export type PublicPartnerDataFragment = (
  { __typename?: 'PublicPartner' }
  & Pick<PublicPartner, 'id' | 'domain' | 'paymentMethod' | 'name' | 'homepageUrl' | 'disabledAt'>
  & { branding?: Maybe<(
    { __typename?: 'PartnerBranding' }
    & Pick<PartnerBranding, 'logo' | 'primaryColor'>
  )> }
);

export type PublicPartnerQueryVariables = Exact<{
  domain: Scalars['String'];
}>;


export type PublicPartnerQuery = (
  { __typename?: 'Query' }
  & { publicPartner?: Maybe<(
    { __typename?: 'PublicPartner' }
    & PublicPartnerDataFragment
  )> }
);

export const PlanDataFragmentDoc = gql`
    fragment PlanData on Plan {
  id
  name
  type
  numberOfScans
  isRecurring
  price
}
    `;
export const ChargeDataFragmentDoc = gql`
    fragment ChargeData on StripeCharge {
  id
  date
  amount
  currency
  description
  receiptUrl
  invoiceUrl
}
    `;
export const PromoCodeFragmentDoc = gql`
    fragment PromoCode on PromoResponse {
  amountOff
  percentOff
  isActive
  isFound
}
    `;
export const IndividualPurchaseAmountDataFragmentDoc = gql`
    fragment IndividualPurchaseAmountData on IndividualPurchaseAmountResponse {
  planName
  price
  recurringPrice
  promoAmountOff
  taxAmount
  taxPercentage
  totalPrice
}
    `;
export const TaxRateDataFragmentDoc = gql`
    fragment TaxRateData on StripeTaxRate {
  id
  active
  livemode
  percentage
  country
  state
}
    `;
export const ContentAnalysisDataFragmentDoc = gql`
    fragment ContentAnalysisData on ContentAnalysis {
  id
  contentId
  type
  status
  passed
  score
  results
  labels
  finishedAt
  createdAt
  updatedAt
}
    `;
export const ContentDataFragmentDoc = gql`
    fragment ContentData on Content {
  id
  text
  type
  score
  origin
  url
  postedAt
  interactions
  media
  isFlagged
  isDeleted
  createdAt
  language
  ContentAnalysis {
    ...ContentAnalysisData
  }
}
    ${ContentAnalysisDataFragmentDoc}`;
export const FlaggedPostLabelsBreakdownDataFragmentDoc = gql`
    fragment FlaggedPostLabelsBreakdownData on FlaggedPostLabelsBreakdownResponse {
  identity_attack
  insult
  obscene
  threat
  sexual_explicit
  sexual
  severe_toxicity
  toxicity
  inappropriate
  blasphemy
  discriminatory
}
    `;
export const OriginsBreakdownDataFragmentDoc = gql`
    fragment OriginsBreakdownData on OriginsBreakdown {
  Facebook
  Twitter
  Instagram
}
    `;
export const DashboardContentBreakdownsDataFragmentDoc = gql`
    fragment DashboardContentBreakdownsData on DashboardContentBreakdownsResponse {
  labelsBreakdown {
    ...FlaggedPostLabelsBreakdownData
  }
  originsBreakdown {
    ...OriginsBreakdownData
  }
  flaggedByOriginsBreakdown {
    ...OriginsBreakdownData
  }
  businessDictionaryByOriginsBreakdown {
    ...OriginsBreakdownData
  }
  nonFlaggedCount
  flaggedCount
  allContentsCount
  businessDictionaryCount
}
    ${FlaggedPostLabelsBreakdownDataFragmentDoc}
${OriginsBreakdownDataFragmentDoc}`;
export const OverviewContentBreakdownsDataFragmentDoc = gql`
    fragment OverviewContentBreakdownsData on OverviewContentBreakdownsResponse {
  flaggedContentsCount
  nonFlaggedContentsCount
  deletedFlaggedContentsCount
  businessDictionaryContentsCount
  flaggedByTimelineBreakdown
  flaggedByOriginsBreakdown {
    ...OriginsBreakdownData
  }
  flaggedByLabelsBreakdown {
    ...FlaggedPostLabelsBreakdownData
  }
}
    ${OriginsBreakdownDataFragmentDoc}
${FlaggedPostLabelsBreakdownDataFragmentDoc}`;
export const BusinessCustomerDataFragmentDoc = gql`
    fragment BusinessCustomerData on BusinessCustomer {
  id
  type
  isActive
  updatedAt
  Business {
    id
    name
    contactEmail
    features
    BusinessDictionary {
      id
      createdAt
      updatedAt
    }
  }
}
    `;
export const UserDataFragmentDoc = gql`
    fragment UserData on User {
  id
  name
  email
  photo
  scanAmount
  authId
  stripeId
  planId
  createdAt
  updatedAt
  lastRefresh
  acceptedFcraVersion
  acceptedPolicyVersion
  hasPassword
  referrerId
  BusinessCustomer {
    ...BusinessCustomerData
  }
}
    ${BusinessCustomerDataFragmentDoc}`;
export const SubscriptionDataFragmentDoc = gql`
    fragment SubscriptionData on StripeSubscription {
  __typename
  id
  status
  created
  currentPeriodStart
  currentPeriodEnd
  cancelAtPeriodEnd
  cancelAt
  canceledAt
  endedAt
}
    `;
export const SocialMediaConnectionFragmentDoc = gql`
    fragment SocialMediaConnection on SocialMediaConnection {
  userName
  userPhoto
  socialMedia
  isMainIdentity
  isConnected
  isExpired
}
    `;
export const IndividualFeatureAccessDataFragmentDoc = gql`
    fragment IndividualFeatureAccessData on IndividualFeatureAccess {
  canAccessAnalytics
  canUseAdvancedDashboard
  canUpgrade
  canScan
}
    `;
export const IndividualCurrentPlanDataFragmentDoc = gql`
    fragment IndividualCurrentPlanData on IndividualCurrentPlan {
  name
  currentPeriodEnds
  isCancelled
  isCancellable
}
    `;
export const IndividualNotificationDataFragmentDoc = gql`
    fragment IndividualNotificationData on IndividualNotification {
  __typename
  id
  type
  title
  text
  userId
  createdAt
  readAt
  deletedAt
  isRead
  isDeleted
}
    `;
export const PhotobookFragmentDoc = gql`
    fragment Photobook on Photobook {
  id
  title
  dateFrom
  dateTo
  coverImage
  pdfUrl
  userId
}
    `;
export const ReportDataFragmentDoc = gql`
    fragment ReportData on Report {
  id
  userId
  type
  name
  isFCRACompliant
  createdAt
  startDate
  endDate
  isShared
  pdfUrl
  flaggedContentsCount
  nonFlaggedContentsCount
  deletedFlaggedContentsCount
  businessDictionaryContentsCount
  allByTimelineBreakdown
  flaggedByTimelineBreakdown
  originsLastScannedBreakdown {
    Facebook
    Twitter
    Instagram
  }
  flaggedByOriginsBreakdown {
    Facebook
    Twitter
    Instagram
  }
  flaggedByLabelsBreakdown {
    identity_attack
    insult
    obscene
    threat
    sexual_explicit
    sexual
    severe_toxicity
    toxicity
    inappropriate
    blasphemy
    discriminatory
  }
  allByOriginsBreakdown {
    Facebook
    Twitter
    Instagram
  }
}
    `;
export const ReportOldDataFragmentDoc = gql`
    fragment ReportOldData on ReportOld {
  id
  harmfulBreakdown
  timelineBreakdown
  profanitiesBreakdown
  harmfulPostCount
  deletedPostCount
  ignoredPostCount
  User {
    id
    name
    Integrations
  }
  pdfUrl
  createdAt
  sentAt
  startDate
  endDate
}
    `;
export const ReportRequestDataFragmentDoc = gql`
    fragment ReportRequestData on ReportRequest {
  id
  status
  origin
  userId
  createdAt
  updatedAt
  Business {
    id
    name
    contactEmail
  }
}
    `;
export const ScanDataFragmentDoc = gql`
    fragment ScanData on Scan {
  id
  type
  status
  startedAt
  createdAt
  updatedAt
  duration
}
    `;
export const PublicPartnerDataFragmentDoc = gql`
    fragment PublicPartnerData on PublicPartner {
  id
  domain
  paymentMethod
  name
  homepageUrl
  branding {
    logo
    primaryColor
  }
  disabledAt
}
    `;
export const CreateIndividualSubscriptionDocument = gql`
    mutation CreateIndividualSubscription($input: CreateIndividualSubscriptionInput!) {
  createIndividualSubscription(input: $input)
}
    `;
export type CreateIndividualSubscriptionMutationFn = Apollo.MutationFunction<CreateIndividualSubscriptionMutation, CreateIndividualSubscriptionMutationVariables>;

/**
 * __useCreateIndividualSubscriptionMutation__
 *
 * To run a mutation, you first call `useCreateIndividualSubscriptionMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateIndividualSubscriptionMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createIndividualSubscriptionMutation, { data, loading, error }] = useCreateIndividualSubscriptionMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useCreateIndividualSubscriptionMutation(baseOptions?: Apollo.MutationHookOptions<CreateIndividualSubscriptionMutation, CreateIndividualSubscriptionMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateIndividualSubscriptionMutation, CreateIndividualSubscriptionMutationVariables>(CreateIndividualSubscriptionDocument, options);
      }
export type CreateIndividualSubscriptionMutationHookResult = ReturnType<typeof useCreateIndividualSubscriptionMutation>;
export type CreateIndividualSubscriptionMutationResult = Apollo.MutationResult<CreateIndividualSubscriptionMutation>;
export type CreateIndividualSubscriptionMutationOptions = Apollo.BaseMutationOptions<CreateIndividualSubscriptionMutation, CreateIndividualSubscriptionMutationVariables>;
export const CancelIndividualSubscriptionDocument = gql`
    mutation CancelIndividualSubscription {
  cancelIndividualSubscription
}
    `;
export type CancelIndividualSubscriptionMutationFn = Apollo.MutationFunction<CancelIndividualSubscriptionMutation, CancelIndividualSubscriptionMutationVariables>;

/**
 * __useCancelIndividualSubscriptionMutation__
 *
 * To run a mutation, you first call `useCancelIndividualSubscriptionMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCancelIndividualSubscriptionMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [cancelIndividualSubscriptionMutation, { data, loading, error }] = useCancelIndividualSubscriptionMutation({
 *   variables: {
 *   },
 * });
 */
export function useCancelIndividualSubscriptionMutation(baseOptions?: Apollo.MutationHookOptions<CancelIndividualSubscriptionMutation, CancelIndividualSubscriptionMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CancelIndividualSubscriptionMutation, CancelIndividualSubscriptionMutationVariables>(CancelIndividualSubscriptionDocument, options);
      }
export type CancelIndividualSubscriptionMutationHookResult = ReturnType<typeof useCancelIndividualSubscriptionMutation>;
export type CancelIndividualSubscriptionMutationResult = Apollo.MutationResult<CancelIndividualSubscriptionMutation>;
export type CancelIndividualSubscriptionMutationOptions = Apollo.BaseMutationOptions<CancelIndividualSubscriptionMutation, CancelIndividualSubscriptionMutationVariables>;
export const UpdateIndividualPaymentMethodDocument = gql`
    mutation UpdateIndividualPaymentMethod($stripeSource: String!) {
  updateIndividualPaymentMethod(stripeSource: $stripeSource)
}
    `;
export type UpdateIndividualPaymentMethodMutationFn = Apollo.MutationFunction<UpdateIndividualPaymentMethodMutation, UpdateIndividualPaymentMethodMutationVariables>;

/**
 * __useUpdateIndividualPaymentMethodMutation__
 *
 * To run a mutation, you first call `useUpdateIndividualPaymentMethodMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUpdateIndividualPaymentMethodMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [updateIndividualPaymentMethodMutation, { data, loading, error }] = useUpdateIndividualPaymentMethodMutation({
 *   variables: {
 *      stripeSource: // value for 'stripeSource'
 *   },
 * });
 */
export function useUpdateIndividualPaymentMethodMutation(baseOptions?: Apollo.MutationHookOptions<UpdateIndividualPaymentMethodMutation, UpdateIndividualPaymentMethodMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UpdateIndividualPaymentMethodMutation, UpdateIndividualPaymentMethodMutationVariables>(UpdateIndividualPaymentMethodDocument, options);
      }
export type UpdateIndividualPaymentMethodMutationHookResult = ReturnType<typeof useUpdateIndividualPaymentMethodMutation>;
export type UpdateIndividualPaymentMethodMutationResult = Apollo.MutationResult<UpdateIndividualPaymentMethodMutation>;
export type UpdateIndividualPaymentMethodMutationOptions = Apollo.BaseMutationOptions<UpdateIndividualPaymentMethodMutation, UpdateIndividualPaymentMethodMutationVariables>;
export const SearchPromoDocument = gql`
    query SearchPromo($input: PromoQueryArgs!) {
  promoCode(input: $input) {
    ...PromoCode
  }
}
    ${PromoCodeFragmentDoc}`;

/**
 * __useSearchPromoQuery__
 *
 * To run a query within a React component, call `useSearchPromoQuery` and pass it any options that fit your needs.
 * When your component renders, `useSearchPromoQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useSearchPromoQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useSearchPromoQuery(baseOptions: Apollo.QueryHookOptions<SearchPromoQuery, SearchPromoQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<SearchPromoQuery, SearchPromoQueryVariables>(SearchPromoDocument, options);
      }
export function useSearchPromoLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<SearchPromoQuery, SearchPromoQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<SearchPromoQuery, SearchPromoQueryVariables>(SearchPromoDocument, options);
        }
export type SearchPromoQueryHookResult = ReturnType<typeof useSearchPromoQuery>;
export type SearchPromoLazyQueryHookResult = ReturnType<typeof useSearchPromoLazyQuery>;
export type SearchPromoQueryResult = Apollo.QueryResult<SearchPromoQuery, SearchPromoQueryVariables>;
export const SearchIndividualPurchaseAmountDocument = gql`
    query SearchIndividualPurchaseAmount($input: IndividualPurchaseAmountQueryArgs!) {
  individualPurchaseAmount(input: $input) {
    ...IndividualPurchaseAmountData
  }
}
    ${IndividualPurchaseAmountDataFragmentDoc}`;

/**
 * __useSearchIndividualPurchaseAmountQuery__
 *
 * To run a query within a React component, call `useSearchIndividualPurchaseAmountQuery` and pass it any options that fit your needs.
 * When your component renders, `useSearchIndividualPurchaseAmountQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useSearchIndividualPurchaseAmountQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useSearchIndividualPurchaseAmountQuery(baseOptions: Apollo.QueryHookOptions<SearchIndividualPurchaseAmountQuery, SearchIndividualPurchaseAmountQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<SearchIndividualPurchaseAmountQuery, SearchIndividualPurchaseAmountQueryVariables>(SearchIndividualPurchaseAmountDocument, options);
      }
export function useSearchIndividualPurchaseAmountLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<SearchIndividualPurchaseAmountQuery, SearchIndividualPurchaseAmountQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<SearchIndividualPurchaseAmountQuery, SearchIndividualPurchaseAmountQueryVariables>(SearchIndividualPurchaseAmountDocument, options);
        }
export type SearchIndividualPurchaseAmountQueryHookResult = ReturnType<typeof useSearchIndividualPurchaseAmountQuery>;
export type SearchIndividualPurchaseAmountLazyQueryHookResult = ReturnType<typeof useSearchIndividualPurchaseAmountLazyQuery>;
export type SearchIndividualPurchaseAmountQueryResult = Apollo.QueryResult<SearchIndividualPurchaseAmountQuery, SearchIndividualPurchaseAmountQueryVariables>;
export const PlansDocument = gql`
    query Plans {
  plans(where: {isArchived: {equals: false}}) {
    ...PlanData
  }
}
    ${PlanDataFragmentDoc}`;

/**
 * __usePlansQuery__
 *
 * To run a query within a React component, call `usePlansQuery` and pass it any options that fit your needs.
 * When your component renders, `usePlansQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = usePlansQuery({
 *   variables: {
 *   },
 * });
 */
export function usePlansQuery(baseOptions?: Apollo.QueryHookOptions<PlansQuery, PlansQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<PlansQuery, PlansQueryVariables>(PlansDocument, options);
      }
export function usePlansLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<PlansQuery, PlansQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<PlansQuery, PlansQueryVariables>(PlansDocument, options);
        }
export type PlansQueryHookResult = ReturnType<typeof usePlansQuery>;
export type PlansLazyQueryHookResult = ReturnType<typeof usePlansLazyQuery>;
export type PlansQueryResult = Apollo.QueryResult<PlansQuery, PlansQueryVariables>;
export const BillingHistoryDocument = gql`
    query BillingHistory {
  individualCharges {
    ...ChargeData
  }
}
    ${ChargeDataFragmentDoc}`;

/**
 * __useBillingHistoryQuery__
 *
 * To run a query within a React component, call `useBillingHistoryQuery` and pass it any options that fit your needs.
 * When your component renders, `useBillingHistoryQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useBillingHistoryQuery({
 *   variables: {
 *   },
 * });
 */
export function useBillingHistoryQuery(baseOptions?: Apollo.QueryHookOptions<BillingHistoryQuery, BillingHistoryQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<BillingHistoryQuery, BillingHistoryQueryVariables>(BillingHistoryDocument, options);
      }
export function useBillingHistoryLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<BillingHistoryQuery, BillingHistoryQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<BillingHistoryQuery, BillingHistoryQueryVariables>(BillingHistoryDocument, options);
        }
export type BillingHistoryQueryHookResult = ReturnType<typeof useBillingHistoryQuery>;
export type BillingHistoryLazyQueryHookResult = ReturnType<typeof useBillingHistoryLazyQuery>;
export type BillingHistoryQueryResult = Apollo.QueryResult<BillingHistoryQuery, BillingHistoryQueryVariables>;
export const TaxRatesDocument = gql`
    query TaxRates {
  taxRates {
    ...TaxRateData
  }
}
    ${TaxRateDataFragmentDoc}`;

/**
 * __useTaxRatesQuery__
 *
 * To run a query within a React component, call `useTaxRatesQuery` and pass it any options that fit your needs.
 * When your component renders, `useTaxRatesQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useTaxRatesQuery({
 *   variables: {
 *   },
 * });
 */
export function useTaxRatesQuery(baseOptions?: Apollo.QueryHookOptions<TaxRatesQuery, TaxRatesQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<TaxRatesQuery, TaxRatesQueryVariables>(TaxRatesDocument, options);
      }
export function useTaxRatesLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<TaxRatesQuery, TaxRatesQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<TaxRatesQuery, TaxRatesQueryVariables>(TaxRatesDocument, options);
        }
export type TaxRatesQueryHookResult = ReturnType<typeof useTaxRatesQuery>;
export type TaxRatesLazyQueryHookResult = ReturnType<typeof useTaxRatesLazyQuery>;
export type TaxRatesQueryResult = Apollo.QueryResult<TaxRatesQuery, TaxRatesQueryVariables>;
export const IndividualPaymentMethodDocument = gql`
    query IndividualPaymentMethod {
  individualPaymentMethod {
    id
    card {
      last4
      exp_month
      exp_year
    }
  }
}
    `;

/**
 * __useIndividualPaymentMethodQuery__
 *
 * To run a query within a React component, call `useIndividualPaymentMethodQuery` and pass it any options that fit your needs.
 * When your component renders, `useIndividualPaymentMethodQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useIndividualPaymentMethodQuery({
 *   variables: {
 *   },
 * });
 */
export function useIndividualPaymentMethodQuery(baseOptions?: Apollo.QueryHookOptions<IndividualPaymentMethodQuery, IndividualPaymentMethodQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<IndividualPaymentMethodQuery, IndividualPaymentMethodQueryVariables>(IndividualPaymentMethodDocument, options);
      }
export function useIndividualPaymentMethodLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<IndividualPaymentMethodQuery, IndividualPaymentMethodQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<IndividualPaymentMethodQuery, IndividualPaymentMethodQueryVariables>(IndividualPaymentMethodDocument, options);
        }
export type IndividualPaymentMethodQueryHookResult = ReturnType<typeof useIndividualPaymentMethodQuery>;
export type IndividualPaymentMethodLazyQueryHookResult = ReturnType<typeof useIndividualPaymentMethodLazyQuery>;
export type IndividualPaymentMethodQueryResult = Apollo.QueryResult<IndividualPaymentMethodQuery, IndividualPaymentMethodQueryVariables>;
export const DeleteContentDocument = gql`
    mutation deleteContent($input: DeleteContentInput!) {
  deleteContent(input: $input) {
    id
    isDeleted
  }
}
    `;
export type DeleteContentMutationFn = Apollo.MutationFunction<DeleteContentMutation, DeleteContentMutationVariables>;

/**
 * __useDeleteContentMutation__
 *
 * To run a mutation, you first call `useDeleteContentMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useDeleteContentMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [deleteContentMutation, { data, loading, error }] = useDeleteContentMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useDeleteContentMutation(baseOptions?: Apollo.MutationHookOptions<DeleteContentMutation, DeleteContentMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<DeleteContentMutation, DeleteContentMutationVariables>(DeleteContentDocument, options);
      }
export type DeleteContentMutationHookResult = ReturnType<typeof useDeleteContentMutation>;
export type DeleteContentMutationResult = Apollo.MutationResult<DeleteContentMutation>;
export type DeleteContentMutationOptions = Apollo.BaseMutationOptions<DeleteContentMutation, DeleteContentMutationVariables>;
export const MassDeleteContentDocument = gql`
    mutation massDeleteContent($contentIds: [ID!]!) {
  massDeleteContent(contentIds: $contentIds) {
    contentId
    isDeleted
    errorMessage
  }
}
    `;
export type MassDeleteContentMutationFn = Apollo.MutationFunction<MassDeleteContentMutation, MassDeleteContentMutationVariables>;

/**
 * __useMassDeleteContentMutation__
 *
 * To run a mutation, you first call `useMassDeleteContentMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useMassDeleteContentMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [massDeleteContentMutation, { data, loading, error }] = useMassDeleteContentMutation({
 *   variables: {
 *      contentIds: // value for 'contentIds'
 *   },
 * });
 */
export function useMassDeleteContentMutation(baseOptions?: Apollo.MutationHookOptions<MassDeleteContentMutation, MassDeleteContentMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<MassDeleteContentMutation, MassDeleteContentMutationVariables>(MassDeleteContentDocument, options);
      }
export type MassDeleteContentMutationHookResult = ReturnType<typeof useMassDeleteContentMutation>;
export type MassDeleteContentMutationResult = Apollo.MutationResult<MassDeleteContentMutation>;
export type MassDeleteContentMutationOptions = Apollo.BaseMutationOptions<MassDeleteContentMutation, MassDeleteContentMutationVariables>;
export const DashboardContentBreakdownsDocument = gql`
    query DashboardContentBreakdowns {
  dashboardContentBreakdowns {
    ...DashboardContentBreakdownsData
  }
}
    ${DashboardContentBreakdownsDataFragmentDoc}`;

/**
 * __useDashboardContentBreakdownsQuery__
 *
 * To run a query within a React component, call `useDashboardContentBreakdownsQuery` and pass it any options that fit your needs.
 * When your component renders, `useDashboardContentBreakdownsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useDashboardContentBreakdownsQuery({
 *   variables: {
 *   },
 * });
 */
export function useDashboardContentBreakdownsQuery(baseOptions?: Apollo.QueryHookOptions<DashboardContentBreakdownsQuery, DashboardContentBreakdownsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<DashboardContentBreakdownsQuery, DashboardContentBreakdownsQueryVariables>(DashboardContentBreakdownsDocument, options);
      }
export function useDashboardContentBreakdownsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<DashboardContentBreakdownsQuery, DashboardContentBreakdownsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<DashboardContentBreakdownsQuery, DashboardContentBreakdownsQueryVariables>(DashboardContentBreakdownsDocument, options);
        }
export type DashboardContentBreakdownsQueryHookResult = ReturnType<typeof useDashboardContentBreakdownsQuery>;
export type DashboardContentBreakdownsLazyQueryHookResult = ReturnType<typeof useDashboardContentBreakdownsLazyQuery>;
export type DashboardContentBreakdownsQueryResult = Apollo.QueryResult<DashboardContentBreakdownsQuery, DashboardContentBreakdownsQueryVariables>;
export const FlaggedPostLabelsBreakdownDocument = gql`
    query FlaggedPostLabelsBreakdown {
  flaggedPostLabelsBreakdown {
    ...FlaggedPostLabelsBreakdownData
  }
}
    ${FlaggedPostLabelsBreakdownDataFragmentDoc}`;

/**
 * __useFlaggedPostLabelsBreakdownQuery__
 *
 * To run a query within a React component, call `useFlaggedPostLabelsBreakdownQuery` and pass it any options that fit your needs.
 * When your component renders, `useFlaggedPostLabelsBreakdownQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useFlaggedPostLabelsBreakdownQuery({
 *   variables: {
 *   },
 * });
 */
export function useFlaggedPostLabelsBreakdownQuery(baseOptions?: Apollo.QueryHookOptions<FlaggedPostLabelsBreakdownQuery, FlaggedPostLabelsBreakdownQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<FlaggedPostLabelsBreakdownQuery, FlaggedPostLabelsBreakdownQueryVariables>(FlaggedPostLabelsBreakdownDocument, options);
      }
export function useFlaggedPostLabelsBreakdownLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<FlaggedPostLabelsBreakdownQuery, FlaggedPostLabelsBreakdownQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<FlaggedPostLabelsBreakdownQuery, FlaggedPostLabelsBreakdownQueryVariables>(FlaggedPostLabelsBreakdownDocument, options);
        }
export type FlaggedPostLabelsBreakdownQueryHookResult = ReturnType<typeof useFlaggedPostLabelsBreakdownQuery>;
export type FlaggedPostLabelsBreakdownLazyQueryHookResult = ReturnType<typeof useFlaggedPostLabelsBreakdownLazyQuery>;
export type FlaggedPostLabelsBreakdownQueryResult = Apollo.QueryResult<FlaggedPostLabelsBreakdownQuery, FlaggedPostLabelsBreakdownQueryVariables>;
export const ContentsDocument = gql`
    query Contents($input: ContentsInput!) {
  contents(input: $input) {
    nextCursorId
    list {
      ...ContentData
    }
  }
}
    ${ContentDataFragmentDoc}`;

/**
 * __useContentsQuery__
 *
 * To run a query within a React component, call `useContentsQuery` and pass it any options that fit your needs.
 * When your component renders, `useContentsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useContentsQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useContentsQuery(baseOptions: Apollo.QueryHookOptions<ContentsQuery, ContentsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<ContentsQuery, ContentsQueryVariables>(ContentsDocument, options);
      }
export function useContentsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<ContentsQuery, ContentsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<ContentsQuery, ContentsQueryVariables>(ContentsDocument, options);
        }
export type ContentsQueryHookResult = ReturnType<typeof useContentsQuery>;
export type ContentsLazyQueryHookResult = ReturnType<typeof useContentsLazyQuery>;
export type ContentsQueryResult = Apollo.QueryResult<ContentsQuery, ContentsQueryVariables>;
export const OverviewContentBreakdownsDocument = gql`
    query OverviewContentBreakdowns($input: OverviewContentBreakdownsInput!) {
  overviewContentBreakdowns(input: $input) {
    ...OverviewContentBreakdownsData
  }
}
    ${OverviewContentBreakdownsDataFragmentDoc}`;

/**
 * __useOverviewContentBreakdownsQuery__
 *
 * To run a query within a React component, call `useOverviewContentBreakdownsQuery` and pass it any options that fit your needs.
 * When your component renders, `useOverviewContentBreakdownsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useOverviewContentBreakdownsQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useOverviewContentBreakdownsQuery(baseOptions: Apollo.QueryHookOptions<OverviewContentBreakdownsQuery, OverviewContentBreakdownsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<OverviewContentBreakdownsQuery, OverviewContentBreakdownsQueryVariables>(OverviewContentBreakdownsDocument, options);
      }
export function useOverviewContentBreakdownsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<OverviewContentBreakdownsQuery, OverviewContentBreakdownsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<OverviewContentBreakdownsQuery, OverviewContentBreakdownsQueryVariables>(OverviewContentBreakdownsDocument, options);
        }
export type OverviewContentBreakdownsQueryHookResult = ReturnType<typeof useOverviewContentBreakdownsQuery>;
export type OverviewContentBreakdownsLazyQueryHookResult = ReturnType<typeof useOverviewContentBreakdownsLazyQuery>;
export type OverviewContentBreakdownsQueryResult = Apollo.QueryResult<OverviewContentBreakdownsQuery, OverviewContentBreakdownsQueryVariables>;
export const SignupAsIndividualDocument = gql`
    mutation SignupAsIndividual($input: SignupAsIndividualInput!) {
  signupAsIndividual(input: $input) {
    ...UserData
    Plan {
      ...PlanData
    }
  }
}
    ${UserDataFragmentDoc}
${PlanDataFragmentDoc}`;
export type SignupAsIndividualMutationFn = Apollo.MutationFunction<SignupAsIndividualMutation, SignupAsIndividualMutationVariables>;

/**
 * __useSignupAsIndividualMutation__
 *
 * To run a mutation, you first call `useSignupAsIndividualMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useSignupAsIndividualMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [signupAsIndividualMutation, { data, loading, error }] = useSignupAsIndividualMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useSignupAsIndividualMutation(baseOptions?: Apollo.MutationHookOptions<SignupAsIndividualMutation, SignupAsIndividualMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<SignupAsIndividualMutation, SignupAsIndividualMutationVariables>(SignupAsIndividualDocument, options);
      }
export type SignupAsIndividualMutationHookResult = ReturnType<typeof useSignupAsIndividualMutation>;
export type SignupAsIndividualMutationResult = Apollo.MutationResult<SignupAsIndividualMutation>;
export type SignupAsIndividualMutationOptions = Apollo.BaseMutationOptions<SignupAsIndividualMutation, SignupAsIndividualMutationVariables>;
export const SignupAsIndividualWithEmailDocument = gql`
    mutation SignupAsIndividualWithEmail($input: SignupAsIndividualWithEmailInput!) {
  signupAsIndividualWithEmail(input: $input) {
    id
  }
}
    `;
export type SignupAsIndividualWithEmailMutationFn = Apollo.MutationFunction<SignupAsIndividualWithEmailMutation, SignupAsIndividualWithEmailMutationVariables>;

/**
 * __useSignupAsIndividualWithEmailMutation__
 *
 * To run a mutation, you first call `useSignupAsIndividualWithEmailMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useSignupAsIndividualWithEmailMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [signupAsIndividualWithEmailMutation, { data, loading, error }] = useSignupAsIndividualWithEmailMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useSignupAsIndividualWithEmailMutation(baseOptions?: Apollo.MutationHookOptions<SignupAsIndividualWithEmailMutation, SignupAsIndividualWithEmailMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<SignupAsIndividualWithEmailMutation, SignupAsIndividualWithEmailMutationVariables>(SignupAsIndividualWithEmailDocument, options);
      }
export type SignupAsIndividualWithEmailMutationHookResult = ReturnType<typeof useSignupAsIndividualWithEmailMutation>;
export type SignupAsIndividualWithEmailMutationResult = Apollo.MutationResult<SignupAsIndividualWithEmailMutation>;
export type SignupAsIndividualWithEmailMutationOptions = Apollo.BaseMutationOptions<SignupAsIndividualWithEmailMutation, SignupAsIndividualWithEmailMutationVariables>;
export const LoginAsIndividualWithEmailDocument = gql`
    mutation LoginAsIndividualWithEmail($input: LoginAsIndividualWithEmailInput!) {
  loginAsIndividualWithEmail(input: $input) {
    accessToken
  }
}
    `;
export type LoginAsIndividualWithEmailMutationFn = Apollo.MutationFunction<LoginAsIndividualWithEmailMutation, LoginAsIndividualWithEmailMutationVariables>;

/**
 * __useLoginAsIndividualWithEmailMutation__
 *
 * To run a mutation, you first call `useLoginAsIndividualWithEmailMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useLoginAsIndividualWithEmailMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [loginAsIndividualWithEmailMutation, { data, loading, error }] = useLoginAsIndividualWithEmailMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useLoginAsIndividualWithEmailMutation(baseOptions?: Apollo.MutationHookOptions<LoginAsIndividualWithEmailMutation, LoginAsIndividualWithEmailMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<LoginAsIndividualWithEmailMutation, LoginAsIndividualWithEmailMutationVariables>(LoginAsIndividualWithEmailDocument, options);
      }
export type LoginAsIndividualWithEmailMutationHookResult = ReturnType<typeof useLoginAsIndividualWithEmailMutation>;
export type LoginAsIndividualWithEmailMutationResult = Apollo.MutationResult<LoginAsIndividualWithEmailMutation>;
export type LoginAsIndividualWithEmailMutationOptions = Apollo.BaseMutationOptions<LoginAsIndividualWithEmailMutation, LoginAsIndividualWithEmailMutationVariables>;
export const DeleteIndividualUserDocument = gql`
    mutation DeleteIndividualUser($reasons: [String!]!) {
  deleteIndividualUser(reasons: $reasons)
}
    `;
export type DeleteIndividualUserMutationFn = Apollo.MutationFunction<DeleteIndividualUserMutation, DeleteIndividualUserMutationVariables>;

/**
 * __useDeleteIndividualUserMutation__
 *
 * To run a mutation, you first call `useDeleteIndividualUserMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useDeleteIndividualUserMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [deleteIndividualUserMutation, { data, loading, error }] = useDeleteIndividualUserMutation({
 *   variables: {
 *      reasons: // value for 'reasons'
 *   },
 * });
 */
export function useDeleteIndividualUserMutation(baseOptions?: Apollo.MutationHookOptions<DeleteIndividualUserMutation, DeleteIndividualUserMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<DeleteIndividualUserMutation, DeleteIndividualUserMutationVariables>(DeleteIndividualUserDocument, options);
      }
export type DeleteIndividualUserMutationHookResult = ReturnType<typeof useDeleteIndividualUserMutation>;
export type DeleteIndividualUserMutationResult = Apollo.MutationResult<DeleteIndividualUserMutation>;
export type DeleteIndividualUserMutationOptions = Apollo.BaseMutationOptions<DeleteIndividualUserMutation, DeleteIndividualUserMutationVariables>;
export const AcceptInvitationDocument = gql`
    mutation AcceptInvitation($invitationId: ID!) {
  acceptInvitation(invitationId: $invitationId)
}
    `;
export type AcceptInvitationMutationFn = Apollo.MutationFunction<AcceptInvitationMutation, AcceptInvitationMutationVariables>;

/**
 * __useAcceptInvitationMutation__
 *
 * To run a mutation, you first call `useAcceptInvitationMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useAcceptInvitationMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [acceptInvitationMutation, { data, loading, error }] = useAcceptInvitationMutation({
 *   variables: {
 *      invitationId: // value for 'invitationId'
 *   },
 * });
 */
export function useAcceptInvitationMutation(baseOptions?: Apollo.MutationHookOptions<AcceptInvitationMutation, AcceptInvitationMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<AcceptInvitationMutation, AcceptInvitationMutationVariables>(AcceptInvitationDocument, options);
      }
export type AcceptInvitationMutationHookResult = ReturnType<typeof useAcceptInvitationMutation>;
export type AcceptInvitationMutationResult = Apollo.MutationResult<AcceptInvitationMutation>;
export type AcceptInvitationMutationOptions = Apollo.BaseMutationOptions<AcceptInvitationMutation, AcceptInvitationMutationVariables>;
export const ActivatePartnerSubscriptionDocument = gql`
    mutation ActivatePartnerSubscription($subscriptionId: ID!) {
  activatePartnerUserSubscription(subscriptionId: $subscriptionId)
}
    `;
export type ActivatePartnerSubscriptionMutationFn = Apollo.MutationFunction<ActivatePartnerSubscriptionMutation, ActivatePartnerSubscriptionMutationVariables>;

/**
 * __useActivatePartnerSubscriptionMutation__
 *
 * To run a mutation, you first call `useActivatePartnerSubscriptionMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useActivatePartnerSubscriptionMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [activatePartnerSubscriptionMutation, { data, loading, error }] = useActivatePartnerSubscriptionMutation({
 *   variables: {
 *      subscriptionId: // value for 'subscriptionId'
 *   },
 * });
 */
export function useActivatePartnerSubscriptionMutation(baseOptions?: Apollo.MutationHookOptions<ActivatePartnerSubscriptionMutation, ActivatePartnerSubscriptionMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<ActivatePartnerSubscriptionMutation, ActivatePartnerSubscriptionMutationVariables>(ActivatePartnerSubscriptionDocument, options);
      }
export type ActivatePartnerSubscriptionMutationHookResult = ReturnType<typeof useActivatePartnerSubscriptionMutation>;
export type ActivatePartnerSubscriptionMutationResult = Apollo.MutationResult<ActivatePartnerSubscriptionMutation>;
export type ActivatePartnerSubscriptionMutationOptions = Apollo.BaseMutationOptions<ActivatePartnerSubscriptionMutation, ActivatePartnerSubscriptionMutationVariables>;
export const LinkSocialMediaDocument = gql`
    mutation LinkSocialMedia($provider: String!, $identityId: String!) {
  linkSocialMedia(provider: $provider, identityId: $identityId) {
    ...SocialMediaConnection
  }
}
    ${SocialMediaConnectionFragmentDoc}`;
export type LinkSocialMediaMutationFn = Apollo.MutationFunction<LinkSocialMediaMutation, LinkSocialMediaMutationVariables>;

/**
 * __useLinkSocialMediaMutation__
 *
 * To run a mutation, you first call `useLinkSocialMediaMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useLinkSocialMediaMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [linkSocialMediaMutation, { data, loading, error }] = useLinkSocialMediaMutation({
 *   variables: {
 *      provider: // value for 'provider'
 *      identityId: // value for 'identityId'
 *   },
 * });
 */
export function useLinkSocialMediaMutation(baseOptions?: Apollo.MutationHookOptions<LinkSocialMediaMutation, LinkSocialMediaMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<LinkSocialMediaMutation, LinkSocialMediaMutationVariables>(LinkSocialMediaDocument, options);
      }
export type LinkSocialMediaMutationHookResult = ReturnType<typeof useLinkSocialMediaMutation>;
export type LinkSocialMediaMutationResult = Apollo.MutationResult<LinkSocialMediaMutation>;
export type LinkSocialMediaMutationOptions = Apollo.BaseMutationOptions<LinkSocialMediaMutation, LinkSocialMediaMutationVariables>;
export const UnlinkSocialMediaDocument = gql`
    mutation UnlinkSocialMedia($provider: String!) {
  unlinkSocialMedia(provider: $provider) {
    ...SocialMediaConnection
  }
}
    ${SocialMediaConnectionFragmentDoc}`;
export type UnlinkSocialMediaMutationFn = Apollo.MutationFunction<UnlinkSocialMediaMutation, UnlinkSocialMediaMutationVariables>;

/**
 * __useUnlinkSocialMediaMutation__
 *
 * To run a mutation, you first call `useUnlinkSocialMediaMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUnlinkSocialMediaMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [unlinkSocialMediaMutation, { data, loading, error }] = useUnlinkSocialMediaMutation({
 *   variables: {
 *      provider: // value for 'provider'
 *   },
 * });
 */
export function useUnlinkSocialMediaMutation(baseOptions?: Apollo.MutationHookOptions<UnlinkSocialMediaMutation, UnlinkSocialMediaMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UnlinkSocialMediaMutation, UnlinkSocialMediaMutationVariables>(UnlinkSocialMediaDocument, options);
      }
export type UnlinkSocialMediaMutationHookResult = ReturnType<typeof useUnlinkSocialMediaMutation>;
export type UnlinkSocialMediaMutationResult = Apollo.MutationResult<UnlinkSocialMediaMutation>;
export type UnlinkSocialMediaMutationOptions = Apollo.BaseMutationOptions<UnlinkSocialMediaMutation, UnlinkSocialMediaMutationVariables>;
export const UpdateIndividualProfileDocument = gql`
    mutation UpdateIndividualProfile($input: UpdateIndividualProfileInput!) {
  updateIndividualProfile(input: $input) {
    __typename
    id
    name
    email
  }
}
    `;
export type UpdateIndividualProfileMutationFn = Apollo.MutationFunction<UpdateIndividualProfileMutation, UpdateIndividualProfileMutationVariables>;

/**
 * __useUpdateIndividualProfileMutation__
 *
 * To run a mutation, you first call `useUpdateIndividualProfileMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUpdateIndividualProfileMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [updateIndividualProfileMutation, { data, loading, error }] = useUpdateIndividualProfileMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useUpdateIndividualProfileMutation(baseOptions?: Apollo.MutationHookOptions<UpdateIndividualProfileMutation, UpdateIndividualProfileMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UpdateIndividualProfileMutation, UpdateIndividualProfileMutationVariables>(UpdateIndividualProfileDocument, options);
      }
export type UpdateIndividualProfileMutationHookResult = ReturnType<typeof useUpdateIndividualProfileMutation>;
export type UpdateIndividualProfileMutationResult = Apollo.MutationResult<UpdateIndividualProfileMutation>;
export type UpdateIndividualProfileMutationOptions = Apollo.BaseMutationOptions<UpdateIndividualProfileMutation, UpdateIndividualProfileMutationVariables>;
export const IndividualChangePasswordDocument = gql`
    mutation individualChangePassword($currentPassword: String!, $newPassword: String!) {
  changeIndividualPassword(
    currentPassword: $currentPassword
    newPassword: $newPassword
  )
}
    `;
export type IndividualChangePasswordMutationFn = Apollo.MutationFunction<IndividualChangePasswordMutation, IndividualChangePasswordMutationVariables>;

/**
 * __useIndividualChangePasswordMutation__
 *
 * To run a mutation, you first call `useIndividualChangePasswordMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useIndividualChangePasswordMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [individualChangePasswordMutation, { data, loading, error }] = useIndividualChangePasswordMutation({
 *   variables: {
 *      currentPassword: // value for 'currentPassword'
 *      newPassword: // value for 'newPassword'
 *   },
 * });
 */
export function useIndividualChangePasswordMutation(baseOptions?: Apollo.MutationHookOptions<IndividualChangePasswordMutation, IndividualChangePasswordMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<IndividualChangePasswordMutation, IndividualChangePasswordMutationVariables>(IndividualChangePasswordDocument, options);
      }
export type IndividualChangePasswordMutationHookResult = ReturnType<typeof useIndividualChangePasswordMutation>;
export type IndividualChangePasswordMutationResult = Apollo.MutationResult<IndividualChangePasswordMutation>;
export type IndividualChangePasswordMutationOptions = Apollo.BaseMutationOptions<IndividualChangePasswordMutation, IndividualChangePasswordMutationVariables>;
export const ResetIndividualPasswordDocument = gql`
    mutation ResetIndividualPassword($email: String!) {
  resetIndividualPassword(email: $email)
}
    `;
export type ResetIndividualPasswordMutationFn = Apollo.MutationFunction<ResetIndividualPasswordMutation, ResetIndividualPasswordMutationVariables>;

/**
 * __useResetIndividualPasswordMutation__
 *
 * To run a mutation, you first call `useResetIndividualPasswordMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useResetIndividualPasswordMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [resetIndividualPasswordMutation, { data, loading, error }] = useResetIndividualPasswordMutation({
 *   variables: {
 *      email: // value for 'email'
 *   },
 * });
 */
export function useResetIndividualPasswordMutation(baseOptions?: Apollo.MutationHookOptions<ResetIndividualPasswordMutation, ResetIndividualPasswordMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<ResetIndividualPasswordMutation, ResetIndividualPasswordMutationVariables>(ResetIndividualPasswordDocument, options);
      }
export type ResetIndividualPasswordMutationHookResult = ReturnType<typeof useResetIndividualPasswordMutation>;
export type ResetIndividualPasswordMutationResult = Apollo.MutationResult<ResetIndividualPasswordMutation>;
export type ResetIndividualPasswordMutationOptions = Apollo.BaseMutationOptions<ResetIndividualPasswordMutation, ResetIndividualPasswordMutationVariables>;
export const AcceptFcraDocument = gql`
    mutation AcceptFcra($fcraVersion: String!) {
  acceptFcra(fcraVersion: $fcraVersion) {
    id
    acceptedFcraVersion
  }
}
    `;
export type AcceptFcraMutationFn = Apollo.MutationFunction<AcceptFcraMutation, AcceptFcraMutationVariables>;

/**
 * __useAcceptFcraMutation__
 *
 * To run a mutation, you first call `useAcceptFcraMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useAcceptFcraMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [acceptFcraMutation, { data, loading, error }] = useAcceptFcraMutation({
 *   variables: {
 *      fcraVersion: // value for 'fcraVersion'
 *   },
 * });
 */
export function useAcceptFcraMutation(baseOptions?: Apollo.MutationHookOptions<AcceptFcraMutation, AcceptFcraMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<AcceptFcraMutation, AcceptFcraMutationVariables>(AcceptFcraDocument, options);
      }
export type AcceptFcraMutationHookResult = ReturnType<typeof useAcceptFcraMutation>;
export type AcceptFcraMutationResult = Apollo.MutationResult<AcceptFcraMutation>;
export type AcceptFcraMutationOptions = Apollo.BaseMutationOptions<AcceptFcraMutation, AcceptFcraMutationVariables>;
export const AcceptPolicyDocument = gql`
    mutation AcceptPolicy($policyVersion: String!) {
  acceptPolicy(policyVersion: $policyVersion) {
    id
    acceptedPolicyVersion
  }
}
    `;
export type AcceptPolicyMutationFn = Apollo.MutationFunction<AcceptPolicyMutation, AcceptPolicyMutationVariables>;

/**
 * __useAcceptPolicyMutation__
 *
 * To run a mutation, you first call `useAcceptPolicyMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useAcceptPolicyMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [acceptPolicyMutation, { data, loading, error }] = useAcceptPolicyMutation({
 *   variables: {
 *      policyVersion: // value for 'policyVersion'
 *   },
 * });
 */
export function useAcceptPolicyMutation(baseOptions?: Apollo.MutationHookOptions<AcceptPolicyMutation, AcceptPolicyMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<AcceptPolicyMutation, AcceptPolicyMutationVariables>(AcceptPolicyDocument, options);
      }
export type AcceptPolicyMutationHookResult = ReturnType<typeof useAcceptPolicyMutation>;
export type AcceptPolicyMutationResult = Apollo.MutationResult<AcceptPolicyMutation>;
export type AcceptPolicyMutationOptions = Apollo.BaseMutationOptions<AcceptPolicyMutation, AcceptPolicyMutationVariables>;
export const AuthDocument = gql`
    query Auth {
  individualMe {
    ...UserData
    Plan {
      ...PlanData
    }
  }
}
    ${UserDataFragmentDoc}
${PlanDataFragmentDoc}`;

/**
 * __useAuthQuery__
 *
 * To run a query within a React component, call `useAuthQuery` and pass it any options that fit your needs.
 * When your component renders, `useAuthQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useAuthQuery({
 *   variables: {
 *   },
 * });
 */
export function useAuthQuery(baseOptions?: Apollo.QueryHookOptions<AuthQuery, AuthQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<AuthQuery, AuthQueryVariables>(AuthDocument, options);
      }
export function useAuthLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<AuthQuery, AuthQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<AuthQuery, AuthQueryVariables>(AuthDocument, options);
        }
export type AuthQueryHookResult = ReturnType<typeof useAuthQuery>;
export type AuthLazyQueryHookResult = ReturnType<typeof useAuthLazyQuery>;
export type AuthQueryResult = Apollo.QueryResult<AuthQuery, AuthQueryVariables>;
export const MySocialMediaConnectionsDocument = gql`
    query MySocialMediaConnections {
  socialMediaConnection {
    ...SocialMediaConnection
  }
}
    ${SocialMediaConnectionFragmentDoc}`;

/**
 * __useMySocialMediaConnectionsQuery__
 *
 * To run a query within a React component, call `useMySocialMediaConnectionsQuery` and pass it any options that fit your needs.
 * When your component renders, `useMySocialMediaConnectionsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useMySocialMediaConnectionsQuery({
 *   variables: {
 *   },
 * });
 */
export function useMySocialMediaConnectionsQuery(baseOptions?: Apollo.QueryHookOptions<MySocialMediaConnectionsQuery, MySocialMediaConnectionsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<MySocialMediaConnectionsQuery, MySocialMediaConnectionsQueryVariables>(MySocialMediaConnectionsDocument, options);
      }
export function useMySocialMediaConnectionsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<MySocialMediaConnectionsQuery, MySocialMediaConnectionsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<MySocialMediaConnectionsQuery, MySocialMediaConnectionsQueryVariables>(MySocialMediaConnectionsDocument, options);
        }
export type MySocialMediaConnectionsQueryHookResult = ReturnType<typeof useMySocialMediaConnectionsQuery>;
export type MySocialMediaConnectionsLazyQueryHookResult = ReturnType<typeof useMySocialMediaConnectionsLazyQuery>;
export type MySocialMediaConnectionsQueryResult = Apollo.QueryResult<MySocialMediaConnectionsQuery, MySocialMediaConnectionsQueryVariables>;
export const PublicUserDocument = gql`
    query PublicUser($email: String!) {
  publicUserByEmail(email: $email) {
    id
    partnerId
    partner {
      domain
    }
  }
}
    `;

/**
 * __usePublicUserQuery__
 *
 * To run a query within a React component, call `usePublicUserQuery` and pass it any options that fit your needs.
 * When your component renders, `usePublicUserQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = usePublicUserQuery({
 *   variables: {
 *      email: // value for 'email'
 *   },
 * });
 */
export function usePublicUserQuery(baseOptions: Apollo.QueryHookOptions<PublicUserQuery, PublicUserQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<PublicUserQuery, PublicUserQueryVariables>(PublicUserDocument, options);
      }
export function usePublicUserLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<PublicUserQuery, PublicUserQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<PublicUserQuery, PublicUserQueryVariables>(PublicUserDocument, options);
        }
export type PublicUserQueryHookResult = ReturnType<typeof usePublicUserQuery>;
export type PublicUserLazyQueryHookResult = ReturnType<typeof usePublicUserLazyQuery>;
export type PublicUserQueryResult = Apollo.QueryResult<PublicUserQuery, PublicUserQueryVariables>;
export const IndividualFeatureAccessDocument = gql`
    query IndividualFeatureAccess {
  individualFeatureAccess {
    features {
      ...IndividualFeatureAccessData
    }
    plan {
      ...IndividualCurrentPlanData
    }
  }
}
    ${IndividualFeatureAccessDataFragmentDoc}
${IndividualCurrentPlanDataFragmentDoc}`;

/**
 * __useIndividualFeatureAccessQuery__
 *
 * To run a query within a React component, call `useIndividualFeatureAccessQuery` and pass it any options that fit your needs.
 * When your component renders, `useIndividualFeatureAccessQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useIndividualFeatureAccessQuery({
 *   variables: {
 *   },
 * });
 */
export function useIndividualFeatureAccessQuery(baseOptions?: Apollo.QueryHookOptions<IndividualFeatureAccessQuery, IndividualFeatureAccessQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<IndividualFeatureAccessQuery, IndividualFeatureAccessQueryVariables>(IndividualFeatureAccessDocument, options);
      }
export function useIndividualFeatureAccessLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<IndividualFeatureAccessQuery, IndividualFeatureAccessQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<IndividualFeatureAccessQuery, IndividualFeatureAccessQueryVariables>(IndividualFeatureAccessDocument, options);
        }
export type IndividualFeatureAccessQueryHookResult = ReturnType<typeof useIndividualFeatureAccessQuery>;
export type IndividualFeatureAccessLazyQueryHookResult = ReturnType<typeof useIndividualFeatureAccessLazyQuery>;
export type IndividualFeatureAccessQueryResult = Apollo.QueryResult<IndividualFeatureAccessQuery, IndividualFeatureAccessQueryVariables>;
export const ReferrerIdCheckDocument = gql`
    query ReferrerIdCheck($id: String!) {
  getReferrer(id: $id) {
    id
    isActive
  }
}
    `;

/**
 * __useReferrerIdCheckQuery__
 *
 * To run a query within a React component, call `useReferrerIdCheckQuery` and pass it any options that fit your needs.
 * When your component renders, `useReferrerIdCheckQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useReferrerIdCheckQuery({
 *   variables: {
 *      id: // value for 'id'
 *   },
 * });
 */
export function useReferrerIdCheckQuery(baseOptions: Apollo.QueryHookOptions<ReferrerIdCheckQuery, ReferrerIdCheckQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<ReferrerIdCheckQuery, ReferrerIdCheckQueryVariables>(ReferrerIdCheckDocument, options);
      }
export function useReferrerIdCheckLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<ReferrerIdCheckQuery, ReferrerIdCheckQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<ReferrerIdCheckQuery, ReferrerIdCheckQueryVariables>(ReferrerIdCheckDocument, options);
        }
export type ReferrerIdCheckQueryHookResult = ReturnType<typeof useReferrerIdCheckQuery>;
export type ReferrerIdCheckLazyQueryHookResult = ReturnType<typeof useReferrerIdCheckLazyQuery>;
export type ReferrerIdCheckQueryResult = Apollo.QueryResult<ReferrerIdCheckQuery, ReferrerIdCheckQueryVariables>;
export const GetFeatureFlagPayloadDocument = gql`
    query GetFeatureFlagPayload($featureFlagId: String!) {
  featureFlagPayload(featureFlagId: $featureFlagId)
}
    `;

/**
 * __useGetFeatureFlagPayloadQuery__
 *
 * To run a query within a React component, call `useGetFeatureFlagPayloadQuery` and pass it any options that fit your needs.
 * When your component renders, `useGetFeatureFlagPayloadQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useGetFeatureFlagPayloadQuery({
 *   variables: {
 *      featureFlagId: // value for 'featureFlagId'
 *   },
 * });
 */
export function useGetFeatureFlagPayloadQuery(baseOptions: Apollo.QueryHookOptions<GetFeatureFlagPayloadQuery, GetFeatureFlagPayloadQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<GetFeatureFlagPayloadQuery, GetFeatureFlagPayloadQueryVariables>(GetFeatureFlagPayloadDocument, options);
      }
export function useGetFeatureFlagPayloadLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<GetFeatureFlagPayloadQuery, GetFeatureFlagPayloadQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<GetFeatureFlagPayloadQuery, GetFeatureFlagPayloadQueryVariables>(GetFeatureFlagPayloadDocument, options);
        }
export type GetFeatureFlagPayloadQueryHookResult = ReturnType<typeof useGetFeatureFlagPayloadQuery>;
export type GetFeatureFlagPayloadLazyQueryHookResult = ReturnType<typeof useGetFeatureFlagPayloadLazyQuery>;
export type GetFeatureFlagPayloadQueryResult = Apollo.QueryResult<GetFeatureFlagPayloadQuery, GetFeatureFlagPayloadQueryVariables>;
export const IsFeatureFlagEnabledDocument = gql`
    query IsFeatureFlagEnabled($featureFlagId: String!) {
  featureFlagEnabled(featureFlagId: $featureFlagId)
}
    `;

/**
 * __useIsFeatureFlagEnabledQuery__
 *
 * To run a query within a React component, call `useIsFeatureFlagEnabledQuery` and pass it any options that fit your needs.
 * When your component renders, `useIsFeatureFlagEnabledQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useIsFeatureFlagEnabledQuery({
 *   variables: {
 *      featureFlagId: // value for 'featureFlagId'
 *   },
 * });
 */
export function useIsFeatureFlagEnabledQuery(baseOptions: Apollo.QueryHookOptions<IsFeatureFlagEnabledQuery, IsFeatureFlagEnabledQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<IsFeatureFlagEnabledQuery, IsFeatureFlagEnabledQueryVariables>(IsFeatureFlagEnabledDocument, options);
      }
export function useIsFeatureFlagEnabledLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<IsFeatureFlagEnabledQuery, IsFeatureFlagEnabledQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<IsFeatureFlagEnabledQuery, IsFeatureFlagEnabledQueryVariables>(IsFeatureFlagEnabledDocument, options);
        }
export type IsFeatureFlagEnabledQueryHookResult = ReturnType<typeof useIsFeatureFlagEnabledQuery>;
export type IsFeatureFlagEnabledLazyQueryHookResult = ReturnType<typeof useIsFeatureFlagEnabledLazyQuery>;
export type IsFeatureFlagEnabledQueryResult = Apollo.QueryResult<IsFeatureFlagEnabledQuery, IsFeatureFlagEnabledQueryVariables>;
export const MarkIndividualNotificationsAsReadDocument = gql`
    mutation MarkIndividualNotificationsAsRead($notificationIds: [ID!]) {
  markIndividualNotificationsAsRead(notificationIds: $notificationIds)
}
    `;
export type MarkIndividualNotificationsAsReadMutationFn = Apollo.MutationFunction<MarkIndividualNotificationsAsReadMutation, MarkIndividualNotificationsAsReadMutationVariables>;

/**
 * __useMarkIndividualNotificationsAsReadMutation__
 *
 * To run a mutation, you first call `useMarkIndividualNotificationsAsReadMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useMarkIndividualNotificationsAsReadMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [markIndividualNotificationsAsReadMutation, { data, loading, error }] = useMarkIndividualNotificationsAsReadMutation({
 *   variables: {
 *      notificationIds: // value for 'notificationIds'
 *   },
 * });
 */
export function useMarkIndividualNotificationsAsReadMutation(baseOptions?: Apollo.MutationHookOptions<MarkIndividualNotificationsAsReadMutation, MarkIndividualNotificationsAsReadMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<MarkIndividualNotificationsAsReadMutation, MarkIndividualNotificationsAsReadMutationVariables>(MarkIndividualNotificationsAsReadDocument, options);
      }
export type MarkIndividualNotificationsAsReadMutationHookResult = ReturnType<typeof useMarkIndividualNotificationsAsReadMutation>;
export type MarkIndividualNotificationsAsReadMutationResult = Apollo.MutationResult<MarkIndividualNotificationsAsReadMutation>;
export type MarkIndividualNotificationsAsReadMutationOptions = Apollo.BaseMutationOptions<MarkIndividualNotificationsAsReadMutation, MarkIndividualNotificationsAsReadMutationVariables>;
export const DeleteIndividualNotificationsDocument = gql`
    mutation DeleteIndividualNotifications($notificationIds: [ID!]!) {
  deleteIndividualNotifications(notificationIds: $notificationIds)
}
    `;
export type DeleteIndividualNotificationsMutationFn = Apollo.MutationFunction<DeleteIndividualNotificationsMutation, DeleteIndividualNotificationsMutationVariables>;

/**
 * __useDeleteIndividualNotificationsMutation__
 *
 * To run a mutation, you first call `useDeleteIndividualNotificationsMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useDeleteIndividualNotificationsMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [deleteIndividualNotificationsMutation, { data, loading, error }] = useDeleteIndividualNotificationsMutation({
 *   variables: {
 *      notificationIds: // value for 'notificationIds'
 *   },
 * });
 */
export function useDeleteIndividualNotificationsMutation(baseOptions?: Apollo.MutationHookOptions<DeleteIndividualNotificationsMutation, DeleteIndividualNotificationsMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<DeleteIndividualNotificationsMutation, DeleteIndividualNotificationsMutationVariables>(DeleteIndividualNotificationsDocument, options);
      }
export type DeleteIndividualNotificationsMutationHookResult = ReturnType<typeof useDeleteIndividualNotificationsMutation>;
export type DeleteIndividualNotificationsMutationResult = Apollo.MutationResult<DeleteIndividualNotificationsMutation>;
export type DeleteIndividualNotificationsMutationOptions = Apollo.BaseMutationOptions<DeleteIndividualNotificationsMutation, DeleteIndividualNotificationsMutationVariables>;
export const IndividualNotificationsDocument = gql`
    query IndividualNotifications($input: IndividualNotificationsInput!) {
  individualUserNotifications(input: $input) {
    nextCursorId
    list {
      ...IndividualNotificationData
    }
  }
  individualNotificationsUnreadCount
}
    ${IndividualNotificationDataFragmentDoc}`;

/**
 * __useIndividualNotificationsQuery__
 *
 * To run a query within a React component, call `useIndividualNotificationsQuery` and pass it any options that fit your needs.
 * When your component renders, `useIndividualNotificationsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useIndividualNotificationsQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useIndividualNotificationsQuery(baseOptions: Apollo.QueryHookOptions<IndividualNotificationsQuery, IndividualNotificationsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<IndividualNotificationsQuery, IndividualNotificationsQueryVariables>(IndividualNotificationsDocument, options);
      }
export function useIndividualNotificationsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<IndividualNotificationsQuery, IndividualNotificationsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<IndividualNotificationsQuery, IndividualNotificationsQueryVariables>(IndividualNotificationsDocument, options);
        }
export type IndividualNotificationsQueryHookResult = ReturnType<typeof useIndividualNotificationsQuery>;
export type IndividualNotificationsLazyQueryHookResult = ReturnType<typeof useIndividualNotificationsLazyQuery>;
export type IndividualNotificationsQueryResult = Apollo.QueryResult<IndividualNotificationsQuery, IndividualNotificationsQueryVariables>;
export const IndividualNotificationUnreadCountDocument = gql`
    query IndividualNotificationUnreadCount {
  individualNotificationsUnreadCount
}
    `;

/**
 * __useIndividualNotificationUnreadCountQuery__
 *
 * To run a query within a React component, call `useIndividualNotificationUnreadCountQuery` and pass it any options that fit your needs.
 * When your component renders, `useIndividualNotificationUnreadCountQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useIndividualNotificationUnreadCountQuery({
 *   variables: {
 *   },
 * });
 */
export function useIndividualNotificationUnreadCountQuery(baseOptions?: Apollo.QueryHookOptions<IndividualNotificationUnreadCountQuery, IndividualNotificationUnreadCountQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<IndividualNotificationUnreadCountQuery, IndividualNotificationUnreadCountQueryVariables>(IndividualNotificationUnreadCountDocument, options);
      }
export function useIndividualNotificationUnreadCountLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<IndividualNotificationUnreadCountQuery, IndividualNotificationUnreadCountQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<IndividualNotificationUnreadCountQuery, IndividualNotificationUnreadCountQueryVariables>(IndividualNotificationUnreadCountDocument, options);
        }
export type IndividualNotificationUnreadCountQueryHookResult = ReturnType<typeof useIndividualNotificationUnreadCountQuery>;
export type IndividualNotificationUnreadCountLazyQueryHookResult = ReturnType<typeof useIndividualNotificationUnreadCountLazyQuery>;
export type IndividualNotificationUnreadCountQueryResult = Apollo.QueryResult<IndividualNotificationUnreadCountQuery, IndividualNotificationUnreadCountQueryVariables>;
export const CreatePhotobookDocument = gql`
    mutation CreatePhotobook($dateFrom: DateTime!, $dateTo: DateTime!, $title: String!, $coverImage: String!) {
  createPhotobook(
    dateFrom: $dateFrom
    dateTo: $dateTo
    title: $title
    coverImage: $coverImage
  ) {
    ...Photobook
  }
}
    ${PhotobookFragmentDoc}`;
export type CreatePhotobookMutationFn = Apollo.MutationFunction<CreatePhotobookMutation, CreatePhotobookMutationVariables>;

/**
 * __useCreatePhotobookMutation__
 *
 * To run a mutation, you first call `useCreatePhotobookMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreatePhotobookMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createPhotobookMutation, { data, loading, error }] = useCreatePhotobookMutation({
 *   variables: {
 *      dateFrom: // value for 'dateFrom'
 *      dateTo: // value for 'dateTo'
 *      title: // value for 'title'
 *      coverImage: // value for 'coverImage'
 *   },
 * });
 */
export function useCreatePhotobookMutation(baseOptions?: Apollo.MutationHookOptions<CreatePhotobookMutation, CreatePhotobookMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreatePhotobookMutation, CreatePhotobookMutationVariables>(CreatePhotobookDocument, options);
      }
export type CreatePhotobookMutationHookResult = ReturnType<typeof useCreatePhotobookMutation>;
export type CreatePhotobookMutationResult = Apollo.MutationResult<CreatePhotobookMutation>;
export type CreatePhotobookMutationOptions = Apollo.BaseMutationOptions<CreatePhotobookMutation, CreatePhotobookMutationVariables>;
export const DeletePhotobookDocument = gql`
    mutation DeletePhotobook($id: ID!) {
  deletePhotobook(id: $id)
}
    `;
export type DeletePhotobookMutationFn = Apollo.MutationFunction<DeletePhotobookMutation, DeletePhotobookMutationVariables>;

/**
 * __useDeletePhotobookMutation__
 *
 * To run a mutation, you first call `useDeletePhotobookMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useDeletePhotobookMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [deletePhotobookMutation, { data, loading, error }] = useDeletePhotobookMutation({
 *   variables: {
 *      id: // value for 'id'
 *   },
 * });
 */
export function useDeletePhotobookMutation(baseOptions?: Apollo.MutationHookOptions<DeletePhotobookMutation, DeletePhotobookMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<DeletePhotobookMutation, DeletePhotobookMutationVariables>(DeletePhotobookDocument, options);
      }
export type DeletePhotobookMutationHookResult = ReturnType<typeof useDeletePhotobookMutation>;
export type DeletePhotobookMutationResult = Apollo.MutationResult<DeletePhotobookMutation>;
export type DeletePhotobookMutationOptions = Apollo.BaseMutationOptions<DeletePhotobookMutation, DeletePhotobookMutationVariables>;
export const PostsBetweenDatesDocument = gql`
    query PostsBetweenDates($dateFrom: DateTime, $dateTo: DateTime) {
  postsBetweenDate(dateFrom: $dateFrom, dateTo: $dateTo) {
    id
    text
    interactions
    media
  }
}
    `;

/**
 * __usePostsBetweenDatesQuery__
 *
 * To run a query within a React component, call `usePostsBetweenDatesQuery` and pass it any options that fit your needs.
 * When your component renders, `usePostsBetweenDatesQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = usePostsBetweenDatesQuery({
 *   variables: {
 *      dateFrom: // value for 'dateFrom'
 *      dateTo: // value for 'dateTo'
 *   },
 * });
 */
export function usePostsBetweenDatesQuery(baseOptions?: Apollo.QueryHookOptions<PostsBetweenDatesQuery, PostsBetweenDatesQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<PostsBetweenDatesQuery, PostsBetweenDatesQueryVariables>(PostsBetweenDatesDocument, options);
      }
export function usePostsBetweenDatesLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<PostsBetweenDatesQuery, PostsBetweenDatesQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<PostsBetweenDatesQuery, PostsBetweenDatesQueryVariables>(PostsBetweenDatesDocument, options);
        }
export type PostsBetweenDatesQueryHookResult = ReturnType<typeof usePostsBetweenDatesQuery>;
export type PostsBetweenDatesLazyQueryHookResult = ReturnType<typeof usePostsBetweenDatesLazyQuery>;
export type PostsBetweenDatesQueryResult = Apollo.QueryResult<PostsBetweenDatesQuery, PostsBetweenDatesQueryVariables>;
export const PhotobookPhotoDatesDocument = gql`
    query PhotobookPhotoDates {
  postDates {
    count
    date
  }
}
    `;

/**
 * __usePhotobookPhotoDatesQuery__
 *
 * To run a query within a React component, call `usePhotobookPhotoDatesQuery` and pass it any options that fit your needs.
 * When your component renders, `usePhotobookPhotoDatesQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = usePhotobookPhotoDatesQuery({
 *   variables: {
 *   },
 * });
 */
export function usePhotobookPhotoDatesQuery(baseOptions?: Apollo.QueryHookOptions<PhotobookPhotoDatesQuery, PhotobookPhotoDatesQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<PhotobookPhotoDatesQuery, PhotobookPhotoDatesQueryVariables>(PhotobookPhotoDatesDocument, options);
      }
export function usePhotobookPhotoDatesLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<PhotobookPhotoDatesQuery, PhotobookPhotoDatesQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<PhotobookPhotoDatesQuery, PhotobookPhotoDatesQueryVariables>(PhotobookPhotoDatesDocument, options);
        }
export type PhotobookPhotoDatesQueryHookResult = ReturnType<typeof usePhotobookPhotoDatesQuery>;
export type PhotobookPhotoDatesLazyQueryHookResult = ReturnType<typeof usePhotobookPhotoDatesLazyQuery>;
export type PhotobookPhotoDatesQueryResult = Apollo.QueryResult<PhotobookPhotoDatesQuery, PhotobookPhotoDatesQueryVariables>;
export const PhotobooksDocument = gql`
    query Photobooks {
  photobooks {
    ...Photobook
  }
}
    ${PhotobookFragmentDoc}`;

/**
 * __usePhotobooksQuery__
 *
 * To run a query within a React component, call `usePhotobooksQuery` and pass it any options that fit your needs.
 * When your component renders, `usePhotobooksQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = usePhotobooksQuery({
 *   variables: {
 *   },
 * });
 */
export function usePhotobooksQuery(baseOptions?: Apollo.QueryHookOptions<PhotobooksQuery, PhotobooksQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<PhotobooksQuery, PhotobooksQueryVariables>(PhotobooksDocument, options);
      }
export function usePhotobooksLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<PhotobooksQuery, PhotobooksQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<PhotobooksQuery, PhotobooksQueryVariables>(PhotobooksDocument, options);
        }
export type PhotobooksQueryHookResult = ReturnType<typeof usePhotobooksQuery>;
export type PhotobooksLazyQueryHookResult = ReturnType<typeof usePhotobooksLazyQuery>;
export type PhotobooksQueryResult = Apollo.QueryResult<PhotobooksQuery, PhotobooksQueryVariables>;
export const PhotobookDocument = gql`
    query Photobook($id: ID!) {
  photobook(id: $id) {
    ...Photobook
  }
}
    ${PhotobookFragmentDoc}`;

/**
 * __usePhotobookQuery__
 *
 * To run a query within a React component, call `usePhotobookQuery` and pass it any options that fit your needs.
 * When your component renders, `usePhotobookQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = usePhotobookQuery({
 *   variables: {
 *      id: // value for 'id'
 *   },
 * });
 */
export function usePhotobookQuery(baseOptions: Apollo.QueryHookOptions<PhotobookQuery, PhotobookQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<PhotobookQuery, PhotobookQueryVariables>(PhotobookDocument, options);
      }
export function usePhotobookLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<PhotobookQuery, PhotobookQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<PhotobookQuery, PhotobookQueryVariables>(PhotobookDocument, options);
        }
export type PhotobookQueryHookResult = ReturnType<typeof usePhotobookQuery>;
export type PhotobookLazyQueryHookResult = ReturnType<typeof usePhotobookLazyQuery>;
export type PhotobookQueryResult = Apollo.QueryResult<PhotobookQuery, PhotobookQueryVariables>;
export const IndividualLegacyReportsDocument = gql`
    query IndividualLegacyReports {
  individualLegacyReports {
    ...ReportOldData
  }
}
    ${ReportOldDataFragmentDoc}`;

/**
 * __useIndividualLegacyReportsQuery__
 *
 * To run a query within a React component, call `useIndividualLegacyReportsQuery` and pass it any options that fit your needs.
 * When your component renders, `useIndividualLegacyReportsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useIndividualLegacyReportsQuery({
 *   variables: {
 *   },
 * });
 */
export function useIndividualLegacyReportsQuery(baseOptions?: Apollo.QueryHookOptions<IndividualLegacyReportsQuery, IndividualLegacyReportsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<IndividualLegacyReportsQuery, IndividualLegacyReportsQueryVariables>(IndividualLegacyReportsDocument, options);
      }
export function useIndividualLegacyReportsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<IndividualLegacyReportsQuery, IndividualLegacyReportsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<IndividualLegacyReportsQuery, IndividualLegacyReportsQueryVariables>(IndividualLegacyReportsDocument, options);
        }
export type IndividualLegacyReportsQueryHookResult = ReturnType<typeof useIndividualLegacyReportsQuery>;
export type IndividualLegacyReportsLazyQueryHookResult = ReturnType<typeof useIndividualLegacyReportsLazyQuery>;
export type IndividualLegacyReportsQueryResult = Apollo.QueryResult<IndividualLegacyReportsQuery, IndividualLegacyReportsQueryVariables>;
export const HasLegacyReportsDocument = gql`
    query hasLegacyReports($userId: ID!) {
  hasLegacyReports(userId: $userId)
}
    `;

/**
 * __useHasLegacyReportsQuery__
 *
 * To run a query within a React component, call `useHasLegacyReportsQuery` and pass it any options that fit your needs.
 * When your component renders, `useHasLegacyReportsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useHasLegacyReportsQuery({
 *   variables: {
 *      userId: // value for 'userId'
 *   },
 * });
 */
export function useHasLegacyReportsQuery(baseOptions: Apollo.QueryHookOptions<HasLegacyReportsQuery, HasLegacyReportsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<HasLegacyReportsQuery, HasLegacyReportsQueryVariables>(HasLegacyReportsDocument, options);
      }
export function useHasLegacyReportsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<HasLegacyReportsQuery, HasLegacyReportsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<HasLegacyReportsQuery, HasLegacyReportsQueryVariables>(HasLegacyReportsDocument, options);
        }
export type HasLegacyReportsQueryHookResult = ReturnType<typeof useHasLegacyReportsQuery>;
export type HasLegacyReportsLazyQueryHookResult = ReturnType<typeof useHasLegacyReportsLazyQuery>;
export type HasLegacyReportsQueryResult = Apollo.QueryResult<HasLegacyReportsQuery, HasLegacyReportsQueryVariables>;
export const CreateReportDocument = gql`
    mutation CreateReport($type: ReportType!, $name: String!) {
  createReport(type: $type, name: $name) {
    id
  }
}
    `;
export type CreateReportMutationFn = Apollo.MutationFunction<CreateReportMutation, CreateReportMutationVariables>;

/**
 * __useCreateReportMutation__
 *
 * To run a mutation, you first call `useCreateReportMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateReportMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createReportMutation, { data, loading, error }] = useCreateReportMutation({
 *   variables: {
 *      type: // value for 'type'
 *      name: // value for 'name'
 *   },
 * });
 */
export function useCreateReportMutation(baseOptions?: Apollo.MutationHookOptions<CreateReportMutation, CreateReportMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateReportMutation, CreateReportMutationVariables>(CreateReportDocument, options);
      }
export type CreateReportMutationHookResult = ReturnType<typeof useCreateReportMutation>;
export type CreateReportMutationResult = Apollo.MutationResult<CreateReportMutation>;
export type CreateReportMutationOptions = Apollo.BaseMutationOptions<CreateReportMutation, CreateReportMutationVariables>;
export const ShareReportDocument = gql`
    mutation ShareReport($reportId: ID!) {
  shareReport(reportId: $reportId) {
    id
    isShared
  }
}
    `;
export type ShareReportMutationFn = Apollo.MutationFunction<ShareReportMutation, ShareReportMutationVariables>;

/**
 * __useShareReportMutation__
 *
 * To run a mutation, you first call `useShareReportMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useShareReportMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [shareReportMutation, { data, loading, error }] = useShareReportMutation({
 *   variables: {
 *      reportId: // value for 'reportId'
 *   },
 * });
 */
export function useShareReportMutation(baseOptions?: Apollo.MutationHookOptions<ShareReportMutation, ShareReportMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<ShareReportMutation, ShareReportMutationVariables>(ShareReportDocument, options);
      }
export type ShareReportMutationHookResult = ReturnType<typeof useShareReportMutation>;
export type ShareReportMutationResult = Apollo.MutationResult<ShareReportMutation>;
export type ShareReportMutationOptions = Apollo.BaseMutationOptions<ShareReportMutation, ShareReportMutationVariables>;
export const SendReportPdfDocument = gql`
    mutation SendReportPDF($reportId: ID!, $emails: [String!]!) {
  sendReportPDF(reportId: $reportId, emails: $emails)
}
    `;
export type SendReportPdfMutationFn = Apollo.MutationFunction<SendReportPdfMutation, SendReportPdfMutationVariables>;

/**
 * __useSendReportPdfMutation__
 *
 * To run a mutation, you first call `useSendReportPdfMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useSendReportPdfMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [sendReportPdfMutation, { data, loading, error }] = useSendReportPdfMutation({
 *   variables: {
 *      reportId: // value for 'reportId'
 *      emails: // value for 'emails'
 *   },
 * });
 */
export function useSendReportPdfMutation(baseOptions?: Apollo.MutationHookOptions<SendReportPdfMutation, SendReportPdfMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<SendReportPdfMutation, SendReportPdfMutationVariables>(SendReportPdfDocument, options);
      }
export type SendReportPdfMutationHookResult = ReturnType<typeof useSendReportPdfMutation>;
export type SendReportPdfMutationResult = Apollo.MutationResult<SendReportPdfMutation>;
export type SendReportPdfMutationOptions = Apollo.BaseMutationOptions<SendReportPdfMutation, SendReportPdfMutationVariables>;
export const IndividualReportDocument = gql`
    query IndividualReport($id: ID!) {
  individualReport(reportId: $id) {
    ...ReportData
  }
}
    ${ReportDataFragmentDoc}`;

/**
 * __useIndividualReportQuery__
 *
 * To run a query within a React component, call `useIndividualReportQuery` and pass it any options that fit your needs.
 * When your component renders, `useIndividualReportQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useIndividualReportQuery({
 *   variables: {
 *      id: // value for 'id'
 *   },
 * });
 */
export function useIndividualReportQuery(baseOptions: Apollo.QueryHookOptions<IndividualReportQuery, IndividualReportQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<IndividualReportQuery, IndividualReportQueryVariables>(IndividualReportDocument, options);
      }
export function useIndividualReportLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<IndividualReportQuery, IndividualReportQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<IndividualReportQuery, IndividualReportQueryVariables>(IndividualReportDocument, options);
        }
export type IndividualReportQueryHookResult = ReturnType<typeof useIndividualReportQuery>;
export type IndividualReportLazyQueryHookResult = ReturnType<typeof useIndividualReportLazyQuery>;
export type IndividualReportQueryResult = Apollo.QueryResult<IndividualReportQuery, IndividualReportQueryVariables>;
export const IndividualReportsDocument = gql`
    query IndividualReports {
  individualReports {
    ...ReportData
  }
}
    ${ReportDataFragmentDoc}`;

/**
 * __useIndividualReportsQuery__
 *
 * To run a query within a React component, call `useIndividualReportsQuery` and pass it any options that fit your needs.
 * When your component renders, `useIndividualReportsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useIndividualReportsQuery({
 *   variables: {
 *   },
 * });
 */
export function useIndividualReportsQuery(baseOptions?: Apollo.QueryHookOptions<IndividualReportsQuery, IndividualReportsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<IndividualReportsQuery, IndividualReportsQueryVariables>(IndividualReportsDocument, options);
      }
export function useIndividualReportsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<IndividualReportsQuery, IndividualReportsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<IndividualReportsQuery, IndividualReportsQueryVariables>(IndividualReportsDocument, options);
        }
export type IndividualReportsQueryHookResult = ReturnType<typeof useIndividualReportsQuery>;
export type IndividualReportsLazyQueryHookResult = ReturnType<typeof useIndividualReportsLazyQuery>;
export type IndividualReportsQueryResult = Apollo.QueryResult<IndividualReportsQuery, IndividualReportsQueryVariables>;
export const RejectReportRequestDocument = gql`
    mutation RejectReportRequest($reportRequestId: ID!) {
  rejectReportRequest(reportRequestId: $reportRequestId) {
    ...ReportRequestData
  }
}
    ${ReportRequestDataFragmentDoc}`;
export type RejectReportRequestMutationFn = Apollo.MutationFunction<RejectReportRequestMutation, RejectReportRequestMutationVariables>;

/**
 * __useRejectReportRequestMutation__
 *
 * To run a mutation, you first call `useRejectReportRequestMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useRejectReportRequestMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [rejectReportRequestMutation, { data, loading, error }] = useRejectReportRequestMutation({
 *   variables: {
 *      reportRequestId: // value for 'reportRequestId'
 *   },
 * });
 */
export function useRejectReportRequestMutation(baseOptions?: Apollo.MutationHookOptions<RejectReportRequestMutation, RejectReportRequestMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<RejectReportRequestMutation, RejectReportRequestMutationVariables>(RejectReportRequestDocument, options);
      }
export type RejectReportRequestMutationHookResult = ReturnType<typeof useRejectReportRequestMutation>;
export type RejectReportRequestMutationResult = Apollo.MutationResult<RejectReportRequestMutation>;
export type RejectReportRequestMutationOptions = Apollo.BaseMutationOptions<RejectReportRequestMutation, RejectReportRequestMutationVariables>;
export const FulfillReportRequestDocument = gql`
    mutation FulfillReportRequest($reportRequestId: ID!, $reportId: ID!) {
  fulfillReportRequest(reportRequestId: $reportRequestId, reportId: $reportId) {
    ...ReportRequestData
  }
}
    ${ReportRequestDataFragmentDoc}`;
export type FulfillReportRequestMutationFn = Apollo.MutationFunction<FulfillReportRequestMutation, FulfillReportRequestMutationVariables>;

/**
 * __useFulfillReportRequestMutation__
 *
 * To run a mutation, you first call `useFulfillReportRequestMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useFulfillReportRequestMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [fulfillReportRequestMutation, { data, loading, error }] = useFulfillReportRequestMutation({
 *   variables: {
 *      reportRequestId: // value for 'reportRequestId'
 *      reportId: // value for 'reportId'
 *   },
 * });
 */
export function useFulfillReportRequestMutation(baseOptions?: Apollo.MutationHookOptions<FulfillReportRequestMutation, FulfillReportRequestMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<FulfillReportRequestMutation, FulfillReportRequestMutationVariables>(FulfillReportRequestDocument, options);
      }
export type FulfillReportRequestMutationHookResult = ReturnType<typeof useFulfillReportRequestMutation>;
export type FulfillReportRequestMutationResult = Apollo.MutationResult<FulfillReportRequestMutation>;
export type FulfillReportRequestMutationOptions = Apollo.BaseMutationOptions<FulfillReportRequestMutation, FulfillReportRequestMutationVariables>;
export const PendingReportRequestsDocument = gql`
    query PendingReportRequests {
  reportRequests(onlyPending: true) {
    ...ReportRequestData
  }
}
    ${ReportRequestDataFragmentDoc}`;

/**
 * __usePendingReportRequestsQuery__
 *
 * To run a query within a React component, call `usePendingReportRequestsQuery` and pass it any options that fit your needs.
 * When your component renders, `usePendingReportRequestsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = usePendingReportRequestsQuery({
 *   variables: {
 *   },
 * });
 */
export function usePendingReportRequestsQuery(baseOptions?: Apollo.QueryHookOptions<PendingReportRequestsQuery, PendingReportRequestsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<PendingReportRequestsQuery, PendingReportRequestsQueryVariables>(PendingReportRequestsDocument, options);
      }
export function usePendingReportRequestsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<PendingReportRequestsQuery, PendingReportRequestsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<PendingReportRequestsQuery, PendingReportRequestsQueryVariables>(PendingReportRequestsDocument, options);
        }
export type PendingReportRequestsQueryHookResult = ReturnType<typeof usePendingReportRequestsQuery>;
export type PendingReportRequestsLazyQueryHookResult = ReturnType<typeof usePendingReportRequestsLazyQuery>;
export type PendingReportRequestsQueryResult = Apollo.QueryResult<PendingReportRequestsQuery, PendingReportRequestsQueryVariables>;
export const ReportRequestDocument = gql`
    query ReportRequest($id: ID!) {
  reportRequest(id: $id) {
    ...ReportRequestData
  }
}
    ${ReportRequestDataFragmentDoc}`;

/**
 * __useReportRequestQuery__
 *
 * To run a query within a React component, call `useReportRequestQuery` and pass it any options that fit your needs.
 * When your component renders, `useReportRequestQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useReportRequestQuery({
 *   variables: {
 *      id: // value for 'id'
 *   },
 * });
 */
export function useReportRequestQuery(baseOptions: Apollo.QueryHookOptions<ReportRequestQuery, ReportRequestQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<ReportRequestQuery, ReportRequestQueryVariables>(ReportRequestDocument, options);
      }
export function useReportRequestLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<ReportRequestQuery, ReportRequestQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<ReportRequestQuery, ReportRequestQueryVariables>(ReportRequestDocument, options);
        }
export type ReportRequestQueryHookResult = ReturnType<typeof useReportRequestQuery>;
export type ReportRequestLazyQueryHookResult = ReturnType<typeof useReportRequestLazyQuery>;
export type ReportRequestQueryResult = Apollo.QueryResult<ReportRequestQuery, ReportRequestQueryVariables>;
export const RunScanDocument = gql`
    mutation RunScan($origins: [SocialMedia!]!, $type: ScanType!) {
  runScan(origins: $origins, type: $type) {
    ...ScanData
  }
}
    ${ScanDataFragmentDoc}`;
export type RunScanMutationFn = Apollo.MutationFunction<RunScanMutation, RunScanMutationVariables>;

/**
 * __useRunScanMutation__
 *
 * To run a mutation, you first call `useRunScanMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useRunScanMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [runScanMutation, { data, loading, error }] = useRunScanMutation({
 *   variables: {
 *      origins: // value for 'origins'
 *      type: // value for 'type'
 *   },
 * });
 */
export function useRunScanMutation(baseOptions?: Apollo.MutationHookOptions<RunScanMutation, RunScanMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<RunScanMutation, RunScanMutationVariables>(RunScanDocument, options);
      }
export type RunScanMutationHookResult = ReturnType<typeof useRunScanMutation>;
export type RunScanMutationResult = Apollo.MutationResult<RunScanMutation>;
export type RunScanMutationOptions = Apollo.BaseMutationOptions<RunScanMutation, RunScanMutationVariables>;
export const LastScanDocument = gql`
    query LastScan {
  lastScan {
    ...ScanData
  }
}
    ${ScanDataFragmentDoc}`;

/**
 * __useLastScanQuery__
 *
 * To run a query within a React component, call `useLastScanQuery` and pass it any options that fit your needs.
 * When your component renders, `useLastScanQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useLastScanQuery({
 *   variables: {
 *   },
 * });
 */
export function useLastScanQuery(baseOptions?: Apollo.QueryHookOptions<LastScanQuery, LastScanQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<LastScanQuery, LastScanQueryVariables>(LastScanDocument, options);
      }
export function useLastScanLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<LastScanQuery, LastScanQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<LastScanQuery, LastScanQueryVariables>(LastScanDocument, options);
        }
export type LastScanQueryHookResult = ReturnType<typeof useLastScanQuery>;
export type LastScanLazyQueryHookResult = ReturnType<typeof useLastScanLazyQuery>;
export type LastScanQueryResult = Apollo.QueryResult<LastScanQuery, LastScanQueryVariables>;
export const HasScanRunningDocument = gql`
    query HasScanRunning {
  hasScanRunning
}
    `;

/**
 * __useHasScanRunningQuery__
 *
 * To run a query within a React component, call `useHasScanRunningQuery` and pass it any options that fit your needs.
 * When your component renders, `useHasScanRunningQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useHasScanRunningQuery({
 *   variables: {
 *   },
 * });
 */
export function useHasScanRunningQuery(baseOptions?: Apollo.QueryHookOptions<HasScanRunningQuery, HasScanRunningQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<HasScanRunningQuery, HasScanRunningQueryVariables>(HasScanRunningDocument, options);
      }
export function useHasScanRunningLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<HasScanRunningQuery, HasScanRunningQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<HasScanRunningQuery, HasScanRunningQueryVariables>(HasScanRunningDocument, options);
        }
export type HasScanRunningQueryHookResult = ReturnType<typeof useHasScanRunningQuery>;
export type HasScanRunningLazyQueryHookResult = ReturnType<typeof useHasScanRunningLazyQuery>;
export type HasScanRunningQueryResult = Apollo.QueryResult<HasScanRunningQuery, HasScanRunningQueryVariables>;
export const FinishedScansCountDocument = gql`
    query FinishedScansCount {
  finishedScansCount
}
    `;

/**
 * __useFinishedScansCountQuery__
 *
 * To run a query within a React component, call `useFinishedScansCountQuery` and pass it any options that fit your needs.
 * When your component renders, `useFinishedScansCountQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useFinishedScansCountQuery({
 *   variables: {
 *   },
 * });
 */
export function useFinishedScansCountQuery(baseOptions?: Apollo.QueryHookOptions<FinishedScansCountQuery, FinishedScansCountQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<FinishedScansCountQuery, FinishedScansCountQueryVariables>(FinishedScansCountDocument, options);
      }
export function useFinishedScansCountLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<FinishedScansCountQuery, FinishedScansCountQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<FinishedScansCountQuery, FinishedScansCountQueryVariables>(FinishedScansCountDocument, options);
        }
export type FinishedScansCountQueryHookResult = ReturnType<typeof useFinishedScansCountQuery>;
export type FinishedScansCountLazyQueryHookResult = ReturnType<typeof useFinishedScansCountLazyQuery>;
export type FinishedScansCountQueryResult = Apollo.QueryResult<FinishedScansCountQuery, FinishedScansCountQueryVariables>;
export const PublicPartnerDocument = gql`
    query PublicPartner($domain: String!) {
  publicPartner(domain: $domain) {
    ...PublicPartnerData
  }
}
    ${PublicPartnerDataFragmentDoc}`;

/**
 * __usePublicPartnerQuery__
 *
 * To run a query within a React component, call `usePublicPartnerQuery` and pass it any options that fit your needs.
 * When your component renders, `usePublicPartnerQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = usePublicPartnerQuery({
 *   variables: {
 *      domain: // value for 'domain'
 *   },
 * });
 */
export function usePublicPartnerQuery(baseOptions: Apollo.QueryHookOptions<PublicPartnerQuery, PublicPartnerQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<PublicPartnerQuery, PublicPartnerQueryVariables>(PublicPartnerDocument, options);
      }
export function usePublicPartnerLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<PublicPartnerQuery, PublicPartnerQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<PublicPartnerQuery, PublicPartnerQueryVariables>(PublicPartnerDocument, options);
        }
export type PublicPartnerQueryHookResult = ReturnType<typeof usePublicPartnerQuery>;
export type PublicPartnerLazyQueryHookResult = ReturnType<typeof usePublicPartnerLazyQuery>;
export type PublicPartnerQueryResult = Apollo.QueryResult<PublicPartnerQuery, PublicPartnerQueryVariables>;