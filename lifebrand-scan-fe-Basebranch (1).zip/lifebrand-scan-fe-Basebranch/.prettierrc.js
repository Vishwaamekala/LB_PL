module.exports = {
  ...require("@oakslab/ooo-config/common/.prettierrc"),
  trailingComma: 'all',
  printWidth: 100,
};
