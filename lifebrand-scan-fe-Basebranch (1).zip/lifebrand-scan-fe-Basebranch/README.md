# LifeBrand App

## Tech Stack

- [NextJS](https://nextjs.org/)
- [Ant Design](https://ant.design/docs/react/introduce)
- [Styled Components](https://styled-components.com/)

## Setup

1. clone the repository
2. [install gcloud cli](https://cloud.google.com/sdk/docs/quickstart-macos)
3. Ask for access to project on GCP if you don't have it yet
4. log into gcloud `gcloud auth login`
5. enable default login `gcloud auth application-default login`
6. install dependencies `npm install`
7. download dev configuration `npm run config:dev`
8. start the app `npm run dev`

### Local Backend

To use your local backend (http://localhost:4000/graphql) instead of the deployed one `LOCAL=true npm run config:dev`.

### Secrets

[Google Secret Manager](https://cloud.google.com/secret-manager/docs/managing-secrets) manages by the secrets on the project.

Secrets are stored as text fields that mimic `.env` file notation.

❗️ Each user and service account needs to have `Secret Manager Secret Accessor` Role in order to access the secret

#### Update

1. Navigate to [GSM](https://console.cloud.google.com/security/secret-manager?project=lifebrand-social-bff-staging&folder=&organizationId=)
2. Locate `[STAGE]-frontend-dotenv` secret to update
3. Create a new version of the secret
4. Destroy old version once sure it's working.

❗️ The configuration is loaded on build time, so in order to apply a new config, service needs to be re-deployed

### Barrel File Structure

1. All components should have barrel files named `index.ts`
2. The structure of the barrel file should always be following:

```
export { default } from './Component';
export * from './Component';
```
