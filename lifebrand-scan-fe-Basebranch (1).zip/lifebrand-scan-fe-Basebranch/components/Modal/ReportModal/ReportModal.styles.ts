import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const HeadingWrap = styled.div`
  margin-bottom: ${({ theme }) => theme.spacing.large}px;
`;

export const ActionButtons = styled.div`
  display: flex;
  justify-content: flex-end;
  margin-top: ${({ theme }) => theme.spacing.large}px;

  & > * + * {
    margin-left: ${({ theme }) => theme.spacing.medium}px;
  }

  ${useBreakpoint.mobile`
    flex-direction: column;

    & > * + * {
      margin-top: ${({ theme }) => theme.spacing.medium}px;
      margin-left: 0px;
    }
    
  `}
`;

export const ImageContainer = styled.div`
  display: flex;
  justify-content: center;
  background-color: ${({ theme }) => theme.meeseeks.color['neutrals.100']};
  border-radius: 2px;
  padding: ${({ theme }) => theme.spacing.medium}px;
`;

export const Image = styled.img`
  height: auto;
  width: 100%;
`;
