import React from 'react';

import { useRouter } from 'next/router';

import { Button, Heading, Icon, Text } from '@UI/meeseeks';
import Modal from '@UI/Modal';
import ScanButton from 'components/ScanButton';
import UpgradeButton from '@Layout/Header/UpgradeButton';

import { ROUTES } from '@Utils/helper/routes';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';
import { removeUrlParameter } from '@Utils/urlParam/helper';
import { TriggerClass } from '@Utils/google-tag-manager';

import { useSubscriptionContext } from '@Utils/SubscriptionContext/useSubscriptionContext';
import { useAuthContext } from '@Utils/AuthContext';

import * as S from './ReportModal.styles';

const ReportModal = () => {
  const router = useRouter();
  const { isMobile } = useBreakpoints();

  const { features } = useSubscriptionContext();
  const { invitedBy } = useAuthContext();

  const businessName = invitedBy.map(({ Business }) => Business.name).join('');

  const handleCancel = () => {
    removeUrlParameter('modal');
  };

  const handleClickReport = () => {
    router.push(ROUTES.REPORT_HISTORY);
  };

  return (
    <Modal visible={true} onCancel={handleCancel} footer={null} width={630}>
      <S.HeadingWrap>
        <Heading
          variant={isMobile ? 'h4' : 'h3'}
          marginBottom={isMobile ? 'small' : 'large'}
          textAlign={isMobile ? 'left' : 'center'}
        >
          Report request
        </Heading>
        <Text variant="regular" textAlign="center">
          {businessName} has requested a report from you. You can start scan and create new report
          or send one of your previous reports.
        </Text>
      </S.HeadingWrap>

      <S.ImageContainer>
        <S.Image src="/images/png/report-request.png" alt="report request" />
      </S.ImageContainer>

      <S.ActionButtons>
        <Button
          variant="tertiary"
          size="medium"
          iconLeft={<Icon name="FilePlus" size={16} color="secondary" />}
          onClick={handleClickReport}
          fluid={isMobile}
        >
          Choose Report
        </Button>
        {features?.canScan && (
          <ScanButton
            variant="primary"
            title="Start Scan"
            size="medium"
            fluid={isMobile}
            triggerClassName={TriggerClass.RunScanReportModal}
          />
        )}
        {features?.canUpgrade && !features.canScan && (
          <UpgradeButton
            variant="primary"
            customIcon={<Icon name="Bolt" color="#fff" />}
            size="medium"
            title="Upgrade"
            fluid={isMobile}
          />
        )}
      </S.ActionButtons>
    </Modal>
  );
};

export default ReportModal;
