import React from 'react';

import ReportModal from '../ReportModal';
import { IndividualNotificationTypeEnum } from 'components/Notification/Notification.types';

type Props = {
  type: string;
};
const modalsByType: Record<string, () => JSX.Element> = {
  [IndividualNotificationTypeEnum.BusinessCustomerInvitationAccepted]: ReportModal,
};

const NotificationModal = ({ type }: Props) => {
  const Modal = modalsByType[type];

  return <Modal />;
};

export default NotificationModal;
