import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Root = styled.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
`;

export const Main = styled.main`
  flex: 1;
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  margin: 0 auto;
  position: relative;
  padding: 0px;
`;

export const LogoContainer = styled.div`
  position: absolute;
  width: 100%;
  text-align: center;
  z-index: 5;

  ${useBreakpoint.mobile`
    top: 80px;
  `}

  ${useBreakpoint.mdDesktop`
    top: 30px;
  `}
`;

export const ButtonContainer = styled.div`
  margin: 0 ${({ theme }) => theme.spacing.medium}px ${({ theme }) => theme.spacing.medium}px;
  position: fixed;
  bottom: 0px;
  width: calc(100% - ${({ theme }) => theme.spacing.medium * 2}px);
  z-index: 5;
`;
