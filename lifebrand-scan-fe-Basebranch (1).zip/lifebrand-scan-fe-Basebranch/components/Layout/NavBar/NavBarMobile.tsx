import React, { useState, useCallback, useMemo } from 'react';

import Skeleton from 'react-loading-skeleton';
import config from 'config';
import { useTour } from '@reactour/tour';

import { NavBarBottomConfig, NavBarConfig, notificationConfig } from './NavBar.config';
import NavBarItem from './NavBarItem';

import { Icon } from '@UI/meeseeks';
import UserAvatar from '@UI/UserAvatar';

import Logo from '@UI/Logo';

import { useConnections } from '@Utils/hooks/useConnections';

import { userSkipOnboarding } from '@Utils/storage/localStorageKeys';

import { useAuthContext } from '@Utils/AuthContext';
import { ROUTES } from '@Utils/helper/routes';
import { getInitials } from '@Utils/formatters/name';

import * as S from './NavBar.styles';

type Props = {
  logoLink?: string;
};

const YEAR = new Date().getFullYear();

const NavBarMobile = ({ logoLink }: Props) => {
  const { loading, userData } = useAuthContext();
  const { isOpen: isOnboardingOn, currentStep } = useTour();
  const userInitials = getInitials(userData?.name);

  const { actions } = useConnections();
  const [isVisible, setVisible] = useState(false);

  const handleClick = () => setVisible(!isVisible);

  const handleLogout = useCallback(() => {
    actions.individualLogout(config.SITE_URL);
    localStorage.removeItem(userSkipOnboarding(userData?.id));
  }, [actions, userData?.id]);

  const userMenuConfig = useMemo(() => {
    return {
      link: ROUTES.MY_ACCOUNT,
      text: userData?.name || '',
      icon: (
        <UserAvatar
          userPhoto={userData?.photo}
          alt={userData?.name}
          width={42}
          height={42}
          userInitials={userInitials}
          initialsSize="h4"
        />
      ),
      children: [
        {
          link: ROUTES.MY_ACCOUNT,
          text: 'My Account',
        },
        {
          link: ROUTES.CONNECTED_SOCIAL_MEDIA,
          text: 'Connected Social Media',
        },
        {
          link: ROUTES.SUBSCRIPTION_PAYMENTS,
          text: 'Subscription',
        },
        {
          link: ROUTES.SECURITY,
          text: 'Security',
        },
        {
          onClick: handleLogout,
          text: 'Log Out',
        },
      ],
    };
  }, [userData, userInitials, handleLogout]);

  return (
    <>
      <S.MenuButton onClick={handleClick} variant="link" size="small">
        <Icon name="Menu" color="neutrals.700" />
      </S.MenuButton>
      <S.Drawer
        title={loading ? <Skeleton width={32} /> : <Logo href={logoLink} small />}
        placement="left"
        onClose={handleClick}
        visible={isVisible || (isOnboardingOn && currentStep === 6)}
        width={300}
        closable={false}
      >
        <NavBarItem item={userMenuConfig} className="user-menu" />
        <S.LinkContainer>
          <div>
            {NavBarConfig.map((el, i) => (
              <NavBarItem item={el} key={i} />
            ))}
          </div>
          <NavBarItem item={notificationConfig} />
        </S.LinkContainer>
        <div>
          <S.NavBarContent>
            {NavBarBottomConfig.map((el, i) => (
              <NavBarItem item={el} key={i} />
            ))}
          </S.NavBarContent>
          <S.Divider />
          <S.Footer>(c) LifeBrand {YEAR}</S.Footer>
        </div>
      </S.Drawer>
    </>
  );
};

export default NavBarMobile;
