import React from 'react';
import { render } from '@testing-library/react';

import { theme } from 'theme/theme';
import { ThemeProvider } from 'styled-components';
import { MockedProvider } from '@apollo/client/testing';

import NavBar from './NavBar';

import { BreakpointProvider } from '@Utils/hooks/useBreakpoints';

jest.mock('next/router', () => ({
  useRouter() {
    return {
      route: '/',
      pathname: '',
      query: '',
      asPath: '',
    };
  },
}));

describe('NavBar', () => {
  beforeAll(() => {
    window.resizeTo = function resizeTo(width, height) {
      Object.assign(this, {
        innerWidth: width,
        innerHeight: height,
        outerWidth: width,
        outerHeight: height,
        configurable: true,
      }).dispatchEvent(new this.Event('resize'));
    };
  });

  it('renders Scan or Upgrade button', async () => {
    // Change resolution to desktop
    window.resizeTo(1400, 1400);
    const { getByRole } = render(
      <ThemeProvider theme={theme}>
        <BreakpointProvider>
          <MockedProvider addTypename>
            <NavBar />
          </MockedProvider>
        </BreakpointProvider>
      </ThemeProvider>,
    );

    expect(getByRole('button', { name: /Upgrade/gi || /Scan/gi })).toBeInTheDocument();
  });
});
