import styled from 'styled-components';

import { Collapse as CollapseBase, Drawer as DrawerBase } from 'antd';

import { Button, Icon } from '@UI/meeseeks';

import { useBreakpoint } from '@Utils/style/breakpoint';

const { Panel: PanelBase } = CollapseBase;

export const navBarDesktopWidth = 284;
export const navBarTabletWidth = 80;

export const NavBar = styled.div`
  display: flex;
  height: 100%;
  width: ${navBarDesktopWidth}px;
  flex-direction: column;
  justify-content: space-between;
  padding: 0 ${({ theme }) => theme.spacing.medium}px;

  ${useBreakpoint.mdDesktop`
    width: ${navBarTabletWidth}px;
  `}
`;

export const Divider = styled.span`
  height: 1px;
  width: 100%;
  background: ${({ theme }) => theme.meeseeks.color['neutrals.200']};
  display: block;
`;

export const NavBarContent = styled.div`
  display: flex;
  flex-direction: column;

  ${useBreakpoint.mdDesktop`
    justify-content: center;
    align-items: center;
  `}

  ${useBreakpoint.mobile`
    align-items: start;
    display: initial;
  `}

  &:first-child {
    padding-bottom: ${({ theme }) => theme.spacing.small + 2}px;
  }

  .scanButton,.scanAllButton {
    width: 46px;
    height: 46px;
  }

  .scanButtonDesktop {
    margin-bottom: ${({ theme }) => theme.spacing.small}px;
  }

  ${useBreakpoint.mdDesktop`
    .scanButton {
      margin-bottom: ${({ theme }) => theme.spacing.small}px;
    }
    span{
      margin: 0;
    }
  `}

  span {
    & > svg {
      width: 20px;
      height: 20px;
    }
  }
}
`;

export const Footer = styled.div`
  padding: ${({ theme }) => theme.spacing.large / 2}px;
  color: ${({ theme }) => theme.meeseeks.color['neutrals.400']};

  ${useBreakpoint.mobile`
    padding-bottom: ${({ theme }) => theme.spacing.large * 2}px;
  `}
`;

export const LinkItem = styled.span<{ isActive: boolean }>`
  font-family: Poppins;
  display: flex;
  cursor: pointer;
  padding: ${({ theme }) => theme.spacing.large / 2}px;
  font-size: ${({ theme }) => theme.typography.text.sm}px;
  color: ${({ isActive, theme }) =>
    isActive ? theme.color.primary : theme.meeseeks.color['neutrals.700']};
  ${({ isActive, theme }) => isActive && `font-weight: ${theme.typography.fontWeight.semiBold}`};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  transition: 0.4s;
  align-items: center;

  & > svg,
  div {
    margin-right: ${({ theme }) => theme.spacing.large / 2}px;
  }

  ${useBreakpoint.mdDesktop`
    padding: ${({ theme }) => theme.spacing.medium}px;

    & > svg {
      margin-right: 0;
    }
  `}

  ${useBreakpoint.tablet`
    & > svg {
      margin-right: ${({ theme }) => theme.spacing.large / 2}px;
    }
  `}

  &:hover {
    background: ${({ theme }) => `rgba(${theme.color.primaryRgb}, 0.08)`};
    color: ${({ theme }) => theme.color.primary};

    & > svg {
      stroke: ${({ theme }) => theme.color.primary};
    }
  }
`;

export const ArrowDownBox = styled.div<{ isActive: boolean }>`
  transition: all 0.15s ease-in;
  box-sizing: border-box;
  ${({ isActive }) => isActive && 'transform: translate(0, -50%) rotate(-180deg) !important'};
`;

export const ArrowDown = styled(Icon)`
  stroke-width: 3px;
`;

export const Panel = styled(PanelBase)`
  .ant-collapse-header {
    padding: 0 !important;

    .ant-collapse-arrow {
      padding: 0 !important;
      top: 50% !important;
      transform: translate(0, -50%);
    }
  }
`;

export const Collapse = styled(CollapseBase)`
  width: 100%;
  .ant-collapse-content {
    .ant-collapse-content-box {
      padding: ${({ theme }) => `0 ${theme.spacing.extraLarge}px`} !important;
    }
  }

  .user-menu {
    .ant-collapse-content {
      .ant-collapse-content-box {
        padding: ${({ theme }) => ` 0 0 ${theme.spacing.large}px 0 `} !important;
      }
    }

    .ant-collapse-header {
      margin: ${({ theme }) => `${theme.spacing.small}px 0`};
      > span {
        padding: ${({ theme }) => `${theme.spacing.large / 2}px ${theme.spacing.medium}px`};
        font-weight: ${({ theme }) => theme.typography.fontWeight.semiBold};
      }
    }
  }
`;

export const LinkWrapper = styled.div`
  padding-top: ${({ theme }) => theme.spacing.medium}px;

  ${useBreakpoint.mdDesktop`
    padding-top: ${({ theme }) => theme.spacing.large}px;
  `}
`;

export const Drawer = styled(DrawerBase)`
  .ant-drawer-body {
    padding: 0;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }

  .ant-drawer-header {
    border-bottom: 1px solid ${({ theme }) => theme.meeseeks.color['neutrals.200']};
    padding: ${({ theme }) =>
      `${theme.spacing.large}px
      ${theme.spacing.medium}px
      ${theme.spacing.large - theme.spacing.small / 2}px
      ${theme.spacing.medium}px`};
  }

  .scanButton {
    margin: ${({ theme }) =>
      `${theme.spacing.large}px
      ${theme.spacing.large / 2}px
      ${theme.spacing.small}px
      ${theme.spacing.large / 2}px`};
    width: auto;
  }

  .scanAllButton {
    margin: 0px ${({ theme }) => theme.spacing.large / 2}px;
    width: auto;
  }
`;

export const MenuButton = styled(Button)`
  padding: 0px;
  margin-right: ${({ theme }) => theme.spacing.large}px;
`;

export const LinkContainer = styled.div`
  flex: 1;
`;

export const NotificationButtonWrapper = styled.div`
  margin-right: ${({ theme }) => theme.spacing.large / 2}px;
  .ant-badge {
    height: ${({ theme }) => theme.spacing.large}px;
    svg {
      margin: 0;
    }
  }
`;
