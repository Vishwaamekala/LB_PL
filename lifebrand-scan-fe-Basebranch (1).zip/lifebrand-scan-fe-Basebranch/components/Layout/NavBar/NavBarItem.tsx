import React from 'react';
import Link from 'next/link';

import { Dropdown, Menu } from 'antd';

import { NavbarInterface } from './NavBar.config';
import { useActiveLink } from './hooks';

import { Icon } from '@UI/meeseeks';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { ROUTES } from '@Utils/helper/routes';

import * as S from './NavBar.styles';

type Props = {
  item: NavbarInterface;
  className?: string;
};

const NavBarItem = ({ item, className }: Props) => {
  const { isMdDesktop } = useBreakpoints();
  const { isActiveItem, isSectionActive, isChildrenLinkActive } = useActiveLink(item);

  const { id, link, icon, iconName, text, children, testId } = item;

  const itemWithChildren = !isMdDesktop ? (
    <S.Collapse
      ghost
      expandIconPosition="right"
      defaultActiveKey={isSectionActive && link}
      expandIcon={({ isActive }) => (
        // if isActive is passed to Icon there is a warning
        // React does not recognize the `isActive` prop on a DOM element
        <S.ArrowDownBox isActive={!!isActive}>
          <S.ArrowDown
            name="ChevronDown"
            color={isSectionActive ? 'primary.600' : 'neutrals.700'}
            size={12}
          />
        </S.ArrowDownBox>
      )}
    >
      <S.Panel
        header={
          <S.LinkItem isActive={!!isSectionActive} id={id} data-test-id={testId}>
            {icon}
            {iconName && (
              <Icon name={iconName} color={isSectionActive ? 'primary' : 'neutrals.700'} />
            )}
            {text}
          </S.LinkItem>
        }
        className={className}
        key={link}
      >
        {children?.map((el) => {
          const { onClick, text: childText, link: childLink, testId: childTestId } = el;
          return onClick ? (
            <S.LinkItem
              onClick={onClick}
              isActive={isChildrenLinkActive(el)}
              key={childText}
              data-test-id={childTestId}
            >
              {childText}
            </S.LinkItem>
          ) : (
            childLink && (
              <Link href={childLink} key={childLink}>
                <a target={childLink === ROUTES.HELP ? '_blank' : ''}>
                  <S.LinkItem isActive={isChildrenLinkActive(el)} data-test-id={childTestId}>
                    {childText}
                  </S.LinkItem>
                </a>
              </Link>
            )
          );
        })}
      </S.Panel>
    </S.Collapse>
  ) : (
    <Dropdown
      overlay={
        <Menu>
          {children?.map((el) => {
            const { link: childLink, text: childText, testId: childTestId } = el;
            return (
              <Menu.Item key={childLink}>
                {childLink && (
                  <Link href={childLink}>
                    <a target={childLink === ROUTES.HELP ? '_blank' : ''}>
                      <S.LinkItem isActive={isChildrenLinkActive(el)} data-test-id={childTestId}>
                        {childText}
                      </S.LinkItem>
                    </a>
                  </Link>
                )}
              </Menu.Item>
            );
          })}
        </Menu>
      }
      trigger={['click']}
    >
      <a>
        <S.LinkItem isActive={!!isSectionActive} id={id}>
          {iconName && (
            <Icon name={iconName} color={isSectionActive ? 'primary' : 'neutrals.700'} />
          )}
        </S.LinkItem>
      </a>
    </Dropdown>
  );

  return children ? (
    itemWithChildren
  ) : (
    <Link href={link} passHref>
      <a>
        <S.LinkItem isActive={isActiveItem} id={id} data-test-id={testId}>
          {icon}
          {iconName && <Icon name={iconName} color={isActiveItem ? 'primary' : 'neutrals.700'} />}
          {!isMdDesktop && text}
        </S.LinkItem>
      </a>
    </Link>
  );
};

export default NavBarItem;
