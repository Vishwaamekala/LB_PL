import React from 'react';

import { IconName } from '@UI/meeseeks';

import { OnboardingStepKeys } from 'components/Onboarding/Onboarding.config';

import NotificationButton from 'components/Notification/NotificationButton';

import { ElementId, SupportId } from 'components/enums';

import { ROUTES } from '@Utils/helper/routes';

import * as S from './NavBar.styles';

export interface NavbarLinkInterface {
  link: typeof ROUTES[keyof typeof ROUTES];
  text: string;
  iconName?: IconName;
  icon?: React.ReactNode;
  onClick?: () => void;
  id?: string;
  testId?: ElementId | SupportId;
}

export interface NavbarInterface extends NavbarLinkInterface {
  children?: Array<
    Pick<NavbarLinkInterface, 'text' | 'onClick'> & {
      link?: typeof ROUTES[keyof typeof ROUTES];
      testId?: ElementId | SupportId;
    }
  >;
}

export const NavBarConfig: NavbarInterface[] = [
  {
    link: ROUTES.DASHBOARD,
    text: 'Dashboard',
    iconName: 'Home',
  },
  {
    link: ROUTES.ANALYTICS_OVERVIEW,
    text: 'Analytics',
    iconName: 'PieChart',
    id: `${OnboardingStepKeys.Analytics}`,
    testId: ElementId.Analytics,
    children: [
      {
        link: ROUTES.ANALYTICS_OVERVIEW,
        text: 'Overview',
        testId: ElementId.Overview,
      },
      {
        link: ROUTES.REPORT_HISTORY,
        text: 'Report History',
        testId: ElementId.ReportHistory,
      },
    ],
  },
  {
    link: ROUTES.DIGITAL_BOOK,
    text: 'My Social Book',
    iconName: 'Book',
  },
];

export const NavBarBottomConfig: NavbarInterface[] = [
  {
    link: ROUTES.PRIVACY,
    text: 'Support',
    iconName: 'MessageCircle',
    testId: SupportId.Support,
    children: [
      {
        link: ROUTES.HELP,
        text: 'Contact Us',
        testId: SupportId.ContactUs,
      },
      {
        link: ROUTES.PRIVACY,
        text: 'Privacy Policy',
        testId: SupportId.PrivacyPolicy,
      },
      {
        link: ROUTES.TERMS_OF_USE,
        text: 'Terms of Use',
        testId: SupportId.TermsOfUse,
      },
    ],
  },
];

export const notificationConfig = {
  icon: (
    <S.NotificationButtonWrapper>
      <NotificationButton sizeIcon={24} />
    </S.NotificationButtonWrapper>
  ),
  link: ROUTES.NOTIFICATION_CENTER,
  text: 'Notifications',
};
