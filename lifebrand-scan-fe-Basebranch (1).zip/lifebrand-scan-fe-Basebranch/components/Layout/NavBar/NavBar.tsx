import React from 'react';
import Skeleton from 'react-loading-skeleton';

import { NavBarBottomConfig, NavBarConfig } from './NavBar.config';
import NavBarItem from './NavBarItem';
import NavBarMobile from './NavBarMobile';

import { Icon } from '@UI/meeseeks';

import ScanButton from 'components/ScanButton';
import UpgradeButton from '@Layout/Header/UpgradeButton';
import { OnboardingStepKeys } from 'components/Onboarding/Onboarding.config';

import { useScanContext } from '@Utils/ScanContext';
import { useSubscriptionContext } from '@Utils/SubscriptionContext/useSubscriptionContext';
import { FeatureFlag, useFeatureFlags } from '@Utils/hooks/useFeatureFlags';
import { useAuthContext } from '@Utils/AuthContext';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';
import { ROUTES } from '@Utils/helper/routes';
import { TriggerClass } from '@Utils/google-tag-manager';
import { BusinessCustomerType, ScanType } from '@Generated/graphql';

import * as S from './NavBar.styles';

const YEAR = new Date().getFullYear();

const UNLIMITED_ACCESS = 'Unlimited Access';

const NavBar = () => {
  const { loading, isLoggedIn, userData } = useAuthContext();
  const { isMdDesktop, isDesktop } = useBreakpoints();
  const { features, loading: subscriptionContextLoading } = useSubscriptionContext();

  const {
    isEnabled: ENABLED_FEAT_NEW_SYNC_SCAN_LOGIC,
    payload: PAYLOAD_FEAT_NEW_SYNC_SCAN_LOGIC,
  } = useFeatureFlags(FeatureFlag.FEAT_NEW_SYNC_SCAN_LOGIC);

  const { hasScanRunning } = useScanContext();

  const logoLink = loading || isLoggedIn ? ROUTES.DASHBOARD : ROUTES.WEBSITE;
  const isDesktopResolution = isMdDesktop || isDesktop;

  const isUserCurrentEmployee = !!userData?.BusinessCustomer.find(
    (businessCustomer) =>
      businessCustomer.type === BusinessCustomerType.CurrentEmployee && businessCustomer.isActive,
  );

  const isScanNewDisabled =
    (userData?.Plan?.name !== UNLIMITED_ACCESS && !isUserCurrentEmployee) || hasScanRunning;

  if (!isDesktopResolution) {
    return <NavBarMobile logoLink={logoLink} />;
  }

  const isNewScanLogicActive: boolean =
    ENABLED_FEAT_NEW_SYNC_SCAN_LOGIC && PAYLOAD_FEAT_NEW_SYNC_SCAN_LOGIC.isActive;

  return (
    <S.NavBar>
      <div>
        <S.NavBarContent>
          {subscriptionContextLoading || loading ? (
            <>
              <Skeleton height={48} />
              {!isNewScanLogicActive && <Skeleton height={48} />}
            </>
          ) : (
            <>
              {features?.canScan && (
                <>
                  {isNewScanLogicActive ? (
                    <ScanButton
                      variant="primary"
                      title={!isMdDesktop ? 'Scan' : ''}
                      size={!isMdDesktop ? 'large' : 'small'}
                      className={isMdDesktop ? 'scanButton' : 'scanButtonDesktop'}
                      customIcon={<Icon name="RefreshCw" color="neutrals.100" />}
                      onBoardingId={OnboardingStepKeys.ScanButton}
                      triggerClassName={TriggerClass.SyncScan}
                      disabled={hasScanRunning}
                      fluid
                    />
                  ) : (
                    <>
                      <ScanButton
                        variant="primary"
                        title={!isMdDesktop ? 'Scan New' : ''}
                        size={!isMdDesktop ? 'large' : 'small'}
                        className={isMdDesktop ? 'scanButton' : 'scanButtonDesktop'}
                        customIcon={<Icon name="RefreshCw" color="neutrals.100" />}
                        disabled={isScanNewDisabled}
                        onBoardingId={OnboardingStepKeys.ScanButton}
                        fluid
                      />
                      <ScanButton
                        variant="tertiary"
                        title={!isMdDesktop ? 'Scan All' : ''}
                        size={!isMdDesktop ? 'large' : 'small'}
                        className={isMdDesktop ? 'scanAllButton' : ''}
                        customIcon={<Icon name="Scan" color="neutrals.700" />}
                        triggerClassName={TriggerClass.RunScanAll}
                        scanType={ScanType.Full}
                        disabled={hasScanRunning}
                        fluid
                      />
                    </>
                  )}
                </>
              )}
              {features?.canUpgrade && !features?.canScan && (
                <UpgradeButton
                  variant="primary"
                  customIcon={<Icon name="Bolt" color="neutrals.100" />}
                  size={!isMdDesktop ? 'large' : 'small'}
                  className={isMdDesktop ? 'scanButton' : ''}
                  title={!isMdDesktop ? 'Upgrade' : ''}
                  fluid
                />
              )}
            </>
          )}
          <S.LinkWrapper>
            {NavBarConfig.map((el, i) => (
              <NavBarItem item={el} key={i} />
            ))}
          </S.LinkWrapper>
        </S.NavBarContent>
      </div>
      <div>
        <S.NavBarContent>
          {NavBarBottomConfig.map((el, i) => (
            <NavBarItem item={el} key={i} />
          ))}
        </S.NavBarContent>
        {!isMdDesktop && <S.Footer>&copy; LifeBrand {YEAR}</S.Footer>}
      </div>
    </S.NavBar>
  );
};

export default NavBar;
