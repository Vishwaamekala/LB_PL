import { useCallback, useMemo } from 'react';
import { useRouter } from 'next/router';

import { NavbarInterface } from './NavBar.config';

export const useActiveLink = (item: NavbarInterface) => {
  const { pathname } = useRouter();
  const { link: itemLink, children = [] } = item;

  const isActiveItem = useMemo(() => itemLink === pathname, [itemLink, pathname]);
  const isSectionActive = useMemo(() => children.find(({ link }) => link === pathname), [
    children,
    pathname,
  ]);
  const isChildrenLinkActive = useCallback(({ link }) => link === pathname, [pathname]);
  return { isActiveItem, isSectionActive, isChildrenLinkActive };
};
