import React from 'react';

import NavBar from './NavBar';

import Header from '@Layout/Header';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { Main, Divider, Left, NavbarSticky, NavbarWrapper } from './Layout.styles';
import { PhotobookWrapper, PhotobookContent } from './PhotobookLayout.styles';

type Props = {
  children: React.ReactNode;
  className?: string;
};

const PhotobookLayout = ({ children }: Props) => {
  const { isMdDesktop, isDesktop } = useBreakpoints();
  const isDesktopResolution = isMdDesktop || isDesktop;

  return (
    <Main>
      <Header />
      <PhotobookWrapper>
        {isDesktopResolution && (
          <>
            <Left />
            <NavbarSticky>
              <NavbarWrapper>
                <Divider />
                <NavBar />
              </NavbarWrapper>
            </NavbarSticky>
          </>
        )}
        <PhotobookContent>{children}</PhotobookContent>
      </PhotobookWrapper>
    </Main>
  );
};

export default PhotobookLayout;
