import React from 'react';

import Footer from '@Layout/Footer';
import Logo from '@UI/Logo';
import { Button } from '@UI/meeseeks';

import { ROUTES } from '@Utils/helper/routes';

import * as S from './LayoutWithoutHeader.styles';

type Props = {
  children: React.ReactNode;
  className?: string;
  isLogoWhite?: boolean;
  withFooter?: boolean;
  buttonText?: string;
  onClick?: () => void;
  disabledButton?: boolean;
};

const LayoutWithoutHeader = ({
  children,
  className,
  isLogoWhite,
  withFooter = true,
  buttonText,
  onClick,
  disabledButton,
}: Props) => {
  return (
    <S.Root className={className}>
      <S.Main>
        <S.LogoContainer>
          <Logo href={ROUTES.WEBSITE} isWhite={isLogoWhite} />
        </S.LogoContainer>
        {children}
      </S.Main>
      {buttonText && (
        <S.ButtonContainer>
          <Button variant="primary" size="large" onClick={onClick} disabled={disabledButton} fluid>
            {buttonText}
          </Button>
        </S.ButtonContainer>
      )}
      {withFooter && <Footer />}
    </S.Root>
  );
};

export default LayoutWithoutHeader;
