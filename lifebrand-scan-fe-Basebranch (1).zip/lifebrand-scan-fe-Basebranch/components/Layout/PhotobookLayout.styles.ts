import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

import { MIN_CONTENT_WIDTH, MAX_CONTENT_WIDTH } from './Layout.styles';

export const PhotobookWrapper = styled.div`
  overflow: auto;
  display: grid;
  grid-template-columns: 1fr auto minmax(${MIN_CONTENT_WIDTH}, ${MAX_CONTENT_WIDTH}) 1fr;
  width: 100%;
  gap: ${({ theme }) => theme.spacing.xxl}px;
  grid-template-areas: 'left navbar content right';
  overflow-x: hidden;

  ${useBreakpoint.lgDesktop`
    grid-template-columns: auto minmax(${MIN_CONTENT_WIDTH}, ${MAX_CONTENT_WIDTH});
    grid-template-areas: "navbar content";
    padding: 0 ${({ theme }) => theme.spacing.medium}px;
  `}

  ${useBreakpoint.lgDesktop`
      grid-template-columns: auto minmax(${MIN_CONTENT_WIDTH}, ${MAX_CONTENT_WIDTH});
      grid-template-areas: "navbar content";
  `}

  ${useBreakpoint.mdDesktop`
    gap: ${({ theme }) => theme.spacing.large}px;
    grid-template-columns: auto minmax(${MIN_CONTENT_WIDTH}, ${MAX_CONTENT_WIDTH});
    grid-template-areas: "navbar content";
    padding-right: ${({ theme }) => theme.spacing.medium}px;
    padding-left: 0;
  `}

  ${useBreakpoint.tablet`
    max-width: 100%;
    padding: ${({ theme }) => `0px ${theme.spacing.medium}px`};
    gap: 0;
    grid-template-columns: minmax(${MIN_CONTENT_WIDTH}, ${MAX_CONTENT_WIDTH});
    grid-template-areas: "content";
  `}


  ${useBreakpoint.mobile`
    padding: ${({ theme }) => `0px ${theme.spacing.medium}px`};
  `}

    @media screen and (max-width: 992px) {
    gap: ${({ theme }) => theme.spacing.medium}px;
  }
`;

export const PhotobookContent = styled.div`
  grid-area: content;
  position: relative;
  align-items: flex-start;
  width: 100%;
`;
