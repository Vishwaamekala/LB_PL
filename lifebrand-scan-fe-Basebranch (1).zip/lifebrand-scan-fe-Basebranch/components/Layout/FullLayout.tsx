import React from 'react';
import styled from 'styled-components';

export const FilledPage = styled.main<{ centered?: boolean }>`
  display: flex;
  flex: 1;
  flex-direction: row;
  width: 100%;
  margin: 0 auto;
  position: relative;
  min-height: 100vh;

  ${({ centered }) =>
    centered &&
    `
    justify-content: center; 
    align-items: center;
    `}
`;

export const Root = styled.div`
  display: flex;
  flex-direction: column;
`;

type Props = {
  centered?: boolean;
  children: React.ReactNode;
};

const FullLayout = ({ centered = false, children }: Props) => {
  return (
    <Root>
      <FilledPage centered={centered}>{children}</FilledPage>
    </Root>
  );
};

export default FullLayout;
