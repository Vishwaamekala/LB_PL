import React from 'react';

import { useTour } from '@reactour/tour';
import router from 'next/router';

import NavBar from './NavBar';

import { Heading } from '@UI/meeseeks';
import Header from '@Layout/Header';
import GoBack, { GoBackProps } from '@UI/GoBack';

import { TestElementIds } from 'components/enums';

import NotificationModal from '../Modal/NotificationModal';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { readUrlParameter } from '@Utils/urlParam/helper';

import * as S from './Layout.styles';

type SubheaderConfig = {
  title?: string;
  actions?: React.ReactNode;
};

type Props = {
  children: React.ReactNode;
  onContentScroll?: (e: React.UIEvent<HTMLElement>) => void;
  contentRef?: React.RefObject<HTMLDivElement>;
  subheader?: SubheaderConfig;
  goBackProps?: GoBackProps & {
    display?: boolean;
  };
  maxContentWidth?: number;
  titleTestId?: TestElementIds;
};

const Layout = ({
  children,
  onContentScroll,
  contentRef,
  subheader,
  goBackProps = { title: 'Back', action: router.back, color: 'neutrals.700', display: false },
  maxContentWidth,
  titleTestId,
}: Props) => {
  const { isMdDesktop, isDesktop } = useBreakpoints();
  const isDesktopResolution = isMdDesktop || isDesktop;

  const { isOpen } = useTour();

  const modalType = readUrlParameter('modal');

  return (
    <S.Main>
      <Header />
      <S.Divider />
      <S.Wrapper isOnboardingOn={isOpen as boolean} onScroll={onContentScroll} ref={contentRef}>
        {isDesktopResolution && (
          <>
            <S.Left />
            <S.NavbarSticky>
              <S.NavbarWrapper>
                <NavBar />
              </S.NavbarWrapper>
            </S.NavbarSticky>
          </>
        )}
        <S.Content maxContentWidth={maxContentWidth}>
          {goBackProps.display && (
            <>
              <GoBack {...goBackProps} />
              <S.Divider />
            </>
          )}
          {subheader && (
            <S.Subheader>
              <S.Title>
                <Heading variant="h2" textColor="secondary" data-test-id={titleTestId}>
                  {subheader.title}
                </Heading>
              </S.Title>
              {subheader.actions && <S.Actions>{subheader.actions}</S.Actions>}
            </S.Subheader>
          )}
          {children}
        </S.Content>
        <S.Right />
      </S.Wrapper>

      {modalType && <NotificationModal type={modalType} />}
    </S.Main>
  );
};

export default Layout;
