import styled from 'styled-components';

import { Header } from '@UI/meeseeks';

import { inlineGap } from '@Utils/style/gap';
import { useBreakpoint } from '@Utils/style/breakpoint';

// whole layout max width is 1248px
// layout sizing is handled with css grid areas
// if change is necessary, make sure that it's aligned with the whole layout
const MAX_LAYOUT_WIDTH = '1248px';

// TODO: adjust in UI Kit once Business Portal UI is adjusted too
// this is scanner 2.0 related change
export const HeaderBase = styled(Header)`
  position: sticky;
  top: 0;
  z-index: 3;

  & > :first-child {
    max-width: ${MAX_LAYOUT_WIDTH};
    padding: ${({ theme }) =>
      `${theme.spacing.large / 2}px 0 ${theme.spacing.large / 2}px ${theme.spacing.medium}px`};

    ${useBreakpoint.mdDesktop`
      padding: ${({ theme }) => `${theme.spacing.large / 2}px ${theme.spacing.medium}px`}
    `}
  }
`;

export const ButtonsWrapper = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  height: 40px;
  margin-left: auto;
  ${({ theme }) => inlineGap(`${theme.spacing.medium}px`)};

  :empty {
    display: none;
  }

  // Center NotificationButton
  & > * {
    display: flex;
    justify-content: center;
    align-items: center;
  }
`;
