import React, { useMemo } from 'react';
import Skeleton from 'react-loading-skeleton';

import { Icon } from '@UI/meeseeks';

import NotificationButton from 'components/Notification/NotificationButton';
import UserMenuDropdown from 'components/UserDropdown';
import Logo from '@UI/Logo';
import NavBar from '@Layout/NavBar';

import DebugTool from 'components/DebugTool';

import ScanButton from 'components/ScanButton';

import UpgradeButton from '@Layout/Header/UpgradeButton';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { useAuthContext } from '@Utils/AuthContext';
import { isProductionAppEnvironment } from '@Utils/environment';
import { useScanContext } from '@Utils/ScanContext';
import { FeatureFlag, useFeatureFlags } from '@Utils/hooks/useFeatureFlags';

import { ROUTES } from '@Utils/helper/routes';

import { useSubscriptionContext } from '@Utils/SubscriptionContext/useSubscriptionContext';

import { TriggerClass } from '@Utils/google-tag-manager';

import { BusinessCustomerType, ScanType } from '@Generated/graphql';

import * as S from './Header.styles';

const UNLIMITED_ACCESS = 'Unlimited Access';

const Header = () => {
  const { loading, isLoggedIn, userData } = useAuthContext();
  const { isMdDesktop, isDesktop } = useBreakpoints();
  const isProduction = isProductionAppEnvironment();
  const { features } = useSubscriptionContext();
  const { hasScanRunning } = useScanContext();

  const {
    isEnabled: ENABLED_FEAT_NEW_SYNC_SCAN_LOGIC,
    payload: PAYLOAD_FEAT_NEW_SYNC_SCAN_LOGIC,
  } = useFeatureFlags(FeatureFlag.FEAT_NEW_SYNC_SCAN_LOGIC);

  const logoLink = loading || isLoggedIn ? ROUTES.DASHBOARD : ROUTES.WEBSITE;
  const isDesktopResolution = isMdDesktop || isDesktop;

  const isUserCurrentEmployee = !!userData?.BusinessCustomer.find(
    (businessCustomer) =>
      businessCustomer.type === BusinessCustomerType.CurrentEmployee && businessCustomer.isActive,
  );

  const isScanNewDisabled =
    (userData?.Plan?.name !== UNLIMITED_ACCESS && !isUserCurrentEmployee) || hasScanRunning;

  const isNewScanLogicActive: boolean =
    ENABLED_FEAT_NEW_SYNC_SCAN_LOGIC && PAYLOAD_FEAT_NEW_SYNC_SCAN_LOGIC.isActive;

  const actionElements = useMemo(() => {
    if (!features?.canScan && features?.canUpgrade) {
      return (
        <UpgradeButton
          variant="primary"
          customIcon={<Icon name="Bolt" color="neutrals.100" />}
          size="small"
          className="scanButton"
          title="Upgrade"
          fluid
        />
      );
    }
    if (features?.canScan) {
      return (
        <S.ButtonsWrapper>
          {isNewScanLogicActive ? (
            <ScanButton
              variant="primary"
              title="Scan"
              size="small"
              className="scanButton"
              customIcon={<Icon name="RefreshCw" color="neutrals.100" />}
              triggerClassName={TriggerClass.SyncScan}
              disabled={hasScanRunning}
            />
          ) : (
            <>
              <ScanButton
                variant="tertiary"
                title="Scan All"
                size="small"
                className="scanAllButton"
                customIcon={<Icon name="Scan" color="neutrals.700" />}
                triggerClassName={TriggerClass.RunScanAll}
                scanType={ScanType.Full}
                disabled={hasScanRunning}
              />
              <ScanButton
                variant="primary"
                title="Scan New"
                size="small"
                className="scanButton"
                customIcon={<Icon name="RefreshCw" color="neutrals.100" />}
                disabled={isScanNewDisabled}
              />
            </>
          )}
        </S.ButtonsWrapper>
      );
    }
    return null;
  }, [features, isScanNewDisabled, hasScanRunning, isNewScanLogicActive]);

  if (!isDesktopResolution) {
    return <S.HeaderBase burgerMenu={<NavBar />} actionElements={actionElements} />;
  }

  return (
    <S.HeaderBase
      burgerMenu={!isDesktopResolution && <NavBar />}
      logo={isDesktopResolution ? <Logo href={logoLink} small /> : undefined}
      actionElements={
        <S.ButtonsWrapper>
          {loading ? (
            <Skeleton width={150} />
          ) : (
            <>
              {!isProduction && <DebugTool />}
              <NotificationButton sizeIcon={24} />
            </>
          )}
          <UserMenuDropdown />
        </S.ButtonsWrapper>
      }
    />
  );
};

export default Header;
