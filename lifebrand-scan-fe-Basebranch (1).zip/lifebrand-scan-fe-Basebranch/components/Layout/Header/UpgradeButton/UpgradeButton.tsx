import React, { ReactNode } from 'react';
import { useRouter } from 'next/router';

import { Button, Icon, ButtonSizes } from '@UI/meeseeks';

import { ROUTES } from '@Utils/helper/routes';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';
import { TriggerClass } from '@Utils/google-tag-manager';

type ExtendedButtonProps = React.ComponentPropsWithRef<typeof Button>;

type UpgradeButtonProps = {
  disabled?: boolean;
  variant: ExtendedButtonProps['variant'];
  hideIcon?: boolean;
  title?: string;
  fluid?: boolean;
  customIcon?: ReactNode;
  size?: ButtonSizes[number];
  className?: string;
};

// Fixed for  Can't perform a React state update on an unmounted component.
// Button is removed from ui before query starts
const UpgradeButton = ({
  disabled,
  variant,
  hideIcon,
  title = 'Upgrade',
  fluid,
  customIcon,
  size = 'medium',
  className,
}: UpgradeButtonProps) => {
  const router = useRouter();
  const { isMobile } = useBreakpoints();

  return (
    <Button
      className={`${TriggerClass.Upgrade} ${className}`}
      variant={variant}
      size={size}
      iconLeft={!hideIcon && (customIcon || <Icon name="ArrowUp" size={16} color="#fff" />)}
      onClick={() => router.push(ROUTES.PLANS)}
      key="upgrade-scans-left-button"
      disabled={disabled}
      fluid={fluid || isMobile}
    >
      {title}
    </Button>
  );
};

export default UpgradeButton;
