import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const HEADER_HEIGHT = '64px';
export const SUBHEADER_HEIGHT = '68px';
export const SPACING_TOP_LARGE = '24px';
export const SPACING_TOP_MEDIUM = '16px';

export const MAX_CONTENT_WIDTH = '924px';
export const MIN_CONTENT_WIDTH = '300px';

export const Main = styled.main`
  display: flex;
  flex-direction: column;
  height: 100vh;
`;

export const Left = styled.div`
  background-color: ${({ theme }) => theme.meeseeks.color.white};
  grid-area: left;

  ${useBreakpoint.lgDesktop`
    display: none;
  `}
`;

export const Right = styled.div`
  background-color: ${({ theme }) => theme.meeseeks.color.white};
  grid-area: right;

  ${useBreakpoint.lgDesktop`
    display: none;
  `}
`;

export const Wrapper = styled.div<{ isOnboardingOn?: boolean }>`
  // disable scroll when onboarding is on in order to prevent unwanted behavior
  overflow: ${({ isOnboardingOn }) => (isOnboardingOn ? 'hidden' : 'auto')};
  display: grid;
  grid-template-columns: 1fr auto minmax(${MIN_CONTENT_WIDTH}, ${MAX_CONTENT_WIDTH}) 1fr;
  width: 100%;
  height: calc(100vh - ${HEADER_HEIGHT});
  gap: ${({ theme }) => theme.spacing.xxl}px;
  grid-template-areas: 'left navbar content right';

  ${useBreakpoint.lgDesktop`
    grid-template-areas: 'navbar content';
    grid-template-columns: auto minmax(${MIN_CONTENT_WIDTH}, ${MAX_CONTENT_WIDTH});
    padding: 0 ${({ theme }) => theme.spacing.medium}px;
  `}

  ${useBreakpoint.mdDesktop`
    gap: ${({ theme }) => theme.spacing.large}px;
    grid-template-columns: auto minmax(${MIN_CONTENT_WIDTH}, ${MAX_CONTENT_WIDTH});
    grid-template-areas: "navbar content";
    padding-right: ${({ theme }) => theme.spacing.medium}px;
    padding-left: 0;
  `}

  ${useBreakpoint.tablet`
    max-width: 100%;
    padding: ${({ theme }) => `0px ${theme.spacing.medium}px`};
    gap: 0;
    grid-template-columns: minmax(${MIN_CONTENT_WIDTH}, ${MAX_CONTENT_WIDTH});
    grid-template-areas: "content";
  `}

    ${useBreakpoint.mobile`
    padding: ${({ theme }) => `0px ${theme.spacing.medium}px`};
  `}

    @media screen and (max-width: 992px) {
    gap: ${({ theme }) => theme.spacing.medium}px;
  }
`;

export const Content = styled.div<{ maxContentWidth?: number }>`
  grid-area: content;
  position: relative;
  align-items: flex-start;
  max-width: ${({ maxContentWidth }) =>
    maxContentWidth ? `${maxContentWidth}px` : MAX_CONTENT_WIDTH};
  width: 100%;
`;

export const NavbarSticky = styled.div`
  grid-area: navbar;
  position: sticky;
  top: 0;
  // header height, spacing from top of the wrapper
  height: calc(100vh - ${HEADER_HEIGHT} - ${SPACING_TOP_LARGE});

  // header height, spacing from top of the wrapper
  ${useBreakpoint.mobile`
    height: calc(100vh - ${HEADER_HEIGHT} - ${SPACING_TOP_MEDIUM});
  `}
`;

export const NavbarWrapper = styled.div`
  height: 100%;
`;

// To handle spacing from top
export const Divider = styled.div`
  height: ${SPACING_TOP_LARGE};
  width: 100%;
  color: ${({ theme }) => theme.meeseeks.color.white};

  ${useBreakpoint.mobile`
    height: ${SPACING_TOP_MEDIUM};
  `}
`;

export const Subheader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  padding-bottom: ${({ theme }) => theme.spacing.large}px;
  min-height: ${SUBHEADER_HEIGHT};

  ${useBreakpoint.mdDesktop`
    justify-content: unset;
    align-items: unset;
  `}

  ${useBreakpoint.mobile`
    flex-direction: column;
  `}
`;

export const Actions = styled.div`
  display: flex;
  align-items: center;

  ${useBreakpoint.mobile`
    width: 100%;
    margin-top: ${({ theme }) => theme.spacing.large}px;
  `}

  & > * {
    margin-left: ${({ theme }) => theme.spacing.medium}px;

    ${useBreakpoint.smDesktop`
      margin-left: ${({ theme }) => theme.spacing.medium / 2}px;
    `}

    ${useBreakpoint.mobile`
      margin: 0px;
    `}
  }
`;

export const Title = styled.div`
  display: flex;
  flex: 1;
  align-items: center;
`;
