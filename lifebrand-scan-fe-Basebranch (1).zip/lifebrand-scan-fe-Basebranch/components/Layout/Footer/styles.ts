import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Footer = styled.footer`
  width: 100%;
  padding: 23px 40px;
  border-top: ${({ theme }) => `1px solid ${theme.meeseeks.color.tertiary}`};

  ${useBreakpoint.mobile`
    padding: ${({ theme }) => theme.spacing.medium}px;
  `};
`;
