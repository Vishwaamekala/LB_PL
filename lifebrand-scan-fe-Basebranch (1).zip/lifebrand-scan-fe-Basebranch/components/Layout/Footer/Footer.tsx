import React from 'react';

import { Text } from '@UI/meeseeks';

import * as S from './styles';

const YEAR = new Date().getFullYear();

const Footer = () => {
  return (
    <S.Footer>
      <Text variant="regular" textColor="body">
        © {YEAR} LifeBrand
      </Text>
    </S.Footer>
  );
};

export default Footer;
