import styled, { createGlobalStyle } from 'styled-components';
import { InfoCircleOutlined } from '@ant-design/icons';

// TODO - COLOR : Review if there are difference between where theme.meeseeks.color['neutrals.400']} is used and designs.

export const PopoverStyle = createGlobalStyle`
.ant-popover > .ant-popover-content > .ant-popover-arrow {
  border-right-color: ${({ theme }) => theme.meeseeks.color.secondary};
  border-bottom-color: ${({ theme }) => theme.meeseeks.color.secondary};
}

.ant-popover-inner {
  padding: ${({ theme }) => theme.spacing.medium}px;
  width: 280px;
  background-color: ${({ theme }) => theme.meeseeks.color.secondary};
    box-shadow: 
      0px 2px 4px rgba(20, 33, 67, 0.08), 0px 1px 10px rgba(40, 69, 145, 0.12);
}

.ant-popover-title {
  padding: 0;
  border: none;
}

.ant-popover-inner-content {
  letter-spacing: 0.01em;
  padding: 0;
}

.anticon-info-circle {
  font-size: 12px;
  vertical-align: middle;
}
`;

export const StyledInfoCircleOutlined = styled(InfoCircleOutlined)`
  color: ${({ theme }) => theme.meeseeks.color['neutrals.400']};
  opacity: 45%;
  margin-left: 5px;
`;
