import React from 'react';
import { Popover } from 'antd';
import { TooltipPlacement } from 'antd/lib/tooltip';

import { Text } from '@UI/meeseeks';

import * as S from './styles';

interface Props {
  title: string | React.ReactNode | React.ReactElement;
  description: string | React.ReactNode | React.ReactElement;
  placement?: TooltipPlacement;
  hideInfoIcon?: boolean;
  children?: React.ReactNode | React.ReactElement;
}

const Info = ({ title, description, placement = 'bottomLeft', hideInfoIcon, children }: Props) => (
  <Popover
    placement={placement}
    destroyTooltipOnHide
    mouseEnterDelay={0}
    mouseLeaveDelay={0}
    title={() => (
      <Text textColor="#fff" variant="body" fontWeight={700} marginBottom="small">
        {title}
      </Text>
    )}
    content={() => (
      <Text variant="small" textColor="tertiary" fontWeight={400}>
        {description}
      </Text>
    )}
  >
    <S.PopoverStyle />
    {!hideInfoIcon ? <S.StyledInfoCircleOutlined /> : children}
  </Popover>
);

export default Info;
