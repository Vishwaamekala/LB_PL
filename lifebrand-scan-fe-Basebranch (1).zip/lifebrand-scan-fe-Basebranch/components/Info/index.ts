export { default } from './Info';
export * from './Info';
