import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import { theme } from 'theme/theme';
import { useRouter } from 'next/router';
import { ThemeProvider } from 'styled-components';
import { MockedProvider } from '@apollo/client/testing';

import { GraphQLError } from 'graphql';

import CreatePhotobook from './CreatePhotobook';

import {
  PhotobookPhotoDatesDocument,
  PostsBetweenDatesDocument,
  CreatePhotobookDocument,
  PhotobooksDocument,
} from '@Generated/graphql';

jest.mock('next/router', () => ({
  useRouter: jest.fn().mockReturnValue({
    route: '/digital-book',
    pathname: '',
    query: '',
    asPath: '',
    push: jest.fn(),
  }),
}));

jest.mock('@Utils/hooks/useConnections');

const Connections = require('@Utils/hooks/useConnections');

jest.mock('./utils.ts', () => ({
  ...jest.requireActual('./utils.ts'),
  useDataWithPassedDates() {
    return {
      monthsWithAll: [
        {
          label: 'All',
          value: 'all',
        },
        {
          label: 'December (3)',
          value: '11',
        },
        {
          label: 'November (8)',
          value: '10',
        },
      ],
      yearsWithAll: [
        {
          label: 'All',
          value: 'all',
        },
        {
          label: '2021',
          value: '2021',
        },
      ],
      dateFrom: 'Wed Dec 01 2021 01:00:00 GMT+0100 (Central European Standard Time)',
      dateTo: 'Sat Jan 01 2022 00:59:59 GMT+0100 (Central European Standard Time)',
    };
  },
}));

const mocks = [
  {
    request: {
      query: PhotobookPhotoDatesDocument,
      variables: {},
    },
    result: {
      data: {
        postDates: [
          {
            __typename: 'PostsDatesOutput',
            count: 3,
            date: '2021-01-01T00:00:00.000Z',
          },
          {
            __typename: 'PostsDatesOutput',
            count: 8,
            date: '2021-11-01T00:00:00.000Z',
          },
        ],
      },
    },
  },
  {
    request: {
      query: PhotobooksDocument,
      variables: {},
    },
    result: {
      data: {
        photobooks: [
          {
            id: 'cl0jk3wvm289250ks6tpruzalo',
            title: 'Title',
            dateFrom: '2021-11-01T00:00:00.000Z',
            dateTo: '2021-11-30T23:59:59.999Z',
            coverImage:
              'https://storage.googleapis.com/lifebrand-social-bff-develop.appspot.com/photobookCover/1646830077860.jpg?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=github-ci-cd%40lifebrand-social-bff-develop.iam.gserviceaccount.com%2F20220309%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20220309T124758Z&X-Goog-Expires=900&X-Goog-SignedHeaders=host&X-Goog-Signature=8ca5201c751067cc152cca14ea57a59ffe261afc902b2cef279f5bb78313fbbc985fca68e495ea2e2134039bf6778b043386047a60802c7427255e4a968b1e858d928a58b240588fec15a0065b66b977b4216084cae2db927edc9fc44767130dc633eb895831fcfd0072d2109a6c119cb1e4a69357878b1b4ca0f420ed4944946e248fbe62b3d91ec72cf3eacb72d1a32212f897a4c9ed2665f820e30bc21cb3f824e8a042516a74f384c270bee99b82f89d1f4506d413159a8f88cbda2efd9d27f6809347b6e1223dc361274ca0435c9b16e3cc081e289c59205019d0b9edd8f3ac960ee687796f9f8901d58e6fda8f801400d09b5c9e26412ff3a7f357322a',
            pdfUrl:
              'https://storage.googleapis.com/lifebrand-social-bff-develop.appspot.com/photobookPdf/1646830070907.pdf?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=github-ci-cd%40lifebrand-social-bff-develop.iam.gserviceaccount.com%2F20220309%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20220309T124758Z&X-Goog-Expires=900&X-Goog-SignedHeaders=host&X-Goog-Signature=c00e14159e281b88773e1d6092720e681261e055c7f5c186678a093fb0b33cf5deb3f9a8cf2da58beada2937ea4c4dab5204ae50f5087d445a7c5d9ef3185036f0efb1c33fd51ed67931eb9eac215cb508afe10aef903907b6a69bc04e318c1cdea6ba0196a96376595acd53aea29281d39c5759e062f02aaf7db517371f9fe137292d0cc8b1a9db7fce570902818b9b21ed5d980c008cfa5e9934515c69015212bfd01be082d82c252a42b4e9a77e483b360b5cdf0a27e6760b2f59fc114bae93dc3d00fa9da5f24855e307e9e32415e1cab82194fb565e59bb1396e2a651bc91888c5e65852df8a5ec2e56aeb3f29603e0733a83e623f0d1df5eae1fe958d8',
            userId: 'ckwq8nqgq20210ls63vqbcgy5',
            __typename: 'Photobook',
          },
        ],
      },
    },
  },
  {
    request: {
      query: PostsBetweenDatesDocument,
      variables: {
        dateFrom: 'Wed Dec 01 2021 01:00:00 GMT+0100 (Central European Standard Time)',
        dateTo: 'Sat Jan 01 2022 00:59:59 GMT+0100 (Central European Standard Time)',
      },
    },
    result: {
      data: {
        postsBetweenDate: [
          {
            __typename: 'Content',
            id: 'ckwqa1ov012310js6hw3ga9ub',
            text: '',
            interactions: {
              shares: 0,
              comments: 0,
              reactions: {
                SAD: 0,
                WOW: 0,
                CARE: 0,
                HAHA: 0,
                LIKE: 0,
                LOVE: 0,
                ANGRY: 0,
              },
            },
            media: [
              {
                id:
                  'https://www.facebook.com/photo.php?fbid=129754416151199&set=p.129754416151199&type=3',
                url:
                  'https://scontent-iad3-2.xx.fbcdn.net/v/t39.30808-6/263469246_129754406151200_7967431361141102554_n.jpg?_nc_cat=101&ccb=1-5&_nc_sid=8024bb&_nc_ohc=YmYgxwLeCE8AX_q5ShJ&_nc_ht=scontent-iad3-2.xx&edm=ADqbNqUEAAAA&oh=00_AT_8No5n1Ylmte8Cyuo3qoLc5J3TUgyWOcABmj47E9aOGw&oe=62262777',
                type: 'Photo',
              },
            ],
          },
        ],
      },
    },
  },
  {
    request: {
      query: CreatePhotobookDocument,
      variables: {
        coverImage:
          'https://scontent-iad3-2.xx.fbcdn.net/v/t39.30808-6/263469246_129754406151200_7967431361141102554_n.jpg?_nc_cat=101&ccb=1-5&_nc_sid=8024bb&_nc_ohc=YmYgxwLeCE8AX_q5ShJ&_nc_ht=scontent-iad3-2.xx&edm=ADqbNqUEAAAA&oh=00_AT_8No5n1Ylmte8Cyuo3qoLc5J3TUgyWOcABmj47E9aOGw&oe=62262777',
        dateFrom: 'Wed Dec 01 2021 01:00:00 GMT+0100 (Central European Standard Time)',
        dateTo: 'Sat Jan 01 2022 00:59:59 GMT+0100 (Central European Standard Time)',
        title: 'Title',
      },
    },
    result: {
      data: {
        createPhotobook: {
          id: 'cl0jk3wvm289250ks6tpruzalo',
          title: 'Title',
          dateFrom: '2021-11-01T00:00:00.000Z',
          dateTo: '2021-11-30T23:59:59.999Z',
          coverImage:
            'https://storage.googleapis.com/lifebrand-social-bff-develop.appspot.com/photobookCover/1646830077860.jpg?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=github-ci-cd%40lifebrand-social-bff-develop.iam.gserviceaccount.com%2F20220309%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20220309T124758Z&X-Goog-Expires=900&X-Goog-SignedHeaders=host&X-Goog-Signature=8ca5201c751067cc152cca14ea57a59ffe261afc902b2cef279f5bb78313fbbc985fca68e495ea2e2134039bf6778b043386047a60802c7427255e4a968b1e858d928a58b240588fec15a0065b66b977b4216084cae2db927edc9fc44767130dc633eb895831fcfd0072d2109a6c119cb1e4a69357878b1b4ca0f420ed4944946e248fbe62b3d91ec72cf3eacb72d1a32212f897a4c9ed2665f820e30bc21cb3f824e8a042516a74f384c270bee99b82f89d1f4506d413159a8f88cbda2efd9d27f6809347b6e1223dc361274ca0435c9b16e3cc081e289c59205019d0b9edd8f3ac960ee687796f9f8901d58e6fda8f801400d09b5c9e26412ff3a7f357322a',
          pdfUrl:
            'https://storage.googleapis.com/lifebrand-social-bff-develop.appspot.com/photobookPdf/1646830070907.pdf?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=github-ci-cd%40lifebrand-social-bff-develop.iam.gserviceaccount.com%2F20220309%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20220309T124758Z&X-Goog-Expires=900&X-Goog-SignedHeaders=host&X-Goog-Signature=c00e14159e281b88773e1d6092720e681261e055c7f5c186678a093fb0b33cf5deb3f9a8cf2da58beada2937ea4c4dab5204ae50f5087d445a7c5d9ef3185036f0efb1c33fd51ed67931eb9eac215cb508afe10aef903907b6a69bc04e318c1cdea6ba0196a96376595acd53aea29281d39c5759e062f02aaf7db517371f9fe137292d0cc8b1a9db7fce570902818b9b21ed5d980c008cfa5e9934515c69015212bfd01be082d82c252a42b4e9a77e483b360b5cdf0a27e6760b2f59fc114bae93dc3d00fa9da5f24855e307e9e32415e1cab82194fb565e59bb1396e2a651bc91888c5e65852df8a5ec2e56aeb3f29603e0733a83e623f0d1df5eae1fe958d8',
          userId: 'ckwq8nqgq20210ls63vqbcgy5',
          __typename: 'Photobook',
        },
      },
    },
  },
  {
    request: {
      query: CreatePhotobookDocument,
      variables: {
        coverImage:
          'https://scontent-iad3-2.xx.fbcdn.net/v/t39.30808-6/263469246_129754406151200_7967431361141102554_n.jpg?_nc_cat=101&ccb=1-5&_nc_sid=8024bb&_nc_ohc=YmYgxwLeCE8AX_q5ShJ&_nc_ht=scontent-iad3-2.xx&edm=ADqbNqUEAAAA&oh=00_AT_8No5n1Ylmte8Cyuo3qoLc5J3TUgyWOcABmj47E9aOGw&oe=62262777',
        dateFrom: 'Wed Dec 01 2021 01:00:00 GMT+0100 (Central European Standard Time)',
        dateTo: 'Sat Jan 01 2022 00:59:59 GMT+0100 (Central European Standard Time)',
        title: 'photobook',
      },
    },
    result: {
      errors: [new GraphQLError('Some backend error!')],
    },
  },
];

const renderComponent = () =>
  render(
    <ThemeProvider theme={theme}>
      <MockedProvider mocks={mocks} addTypename={false}>
        <CreatePhotobook />
      </MockedProvider>
    </ThemeProvider>,
  );

describe('CreatePhotobook', () => {
  it('renders disabled inputs when no social media connected', async () => {
    const { getByRole, getAllByRole } = renderComponent();
    const InputTitle = getByRole('textbox', { name: 'Title' });
    const SelectYear = getAllByRole('textbox')[1];
    const SelectMonth = getAllByRole('textbox')[2];
    expect(InputTitle).toBeDisabled();
    expect(SelectYear).toBeDisabled();
    expect(SelectMonth).toBeDisabled();
  });

  Connections.useConnections.mockImplementation(() => {
    return {
      isActionsDisabled: false,
      isAnySocialMediaConnected: true,
      isAuthenticated: true,
      socialMediaConnection: [
        {
          isConnected: true,
          isMainIdentity: false,
          socialMedia: 'Facebook',
          userName: 'test',
          userPhoto: '',
          __typename: 'SocialMediaConnection',
        },
      ],
    };
  });

  it('renders disabled button while not filled inputs', async () => {
    const { getByTestId } = renderComponent();
    const btn = getByTestId('create-photobook');
    expect(btn).toBeInTheDocument();
    expect(btn).toBeDisabled();
  });

  it('renders success message after creating photobook', async () => {
    const { getByTestId, getByRole, getAllByRole, getByText, getAllByText } = renderComponent();
    const InputTitle = getByRole('textbox', { name: 'Title' });
    const SelectYear = getAllByRole('textbox')[1];
    const SelectMonth = getAllByRole('textbox')[2];
    const CreateBtn = getByTestId('create-photobook');

    fireEvent.change(InputTitle, { target: { value: 'Title' } });
    fireEvent.change(SelectYear, { target: { value: '2021' } });
    fireEvent.change(SelectMonth, { target: { value: 'November (8)' } });

    fireEvent.click(getAllByText('2021')[1]);
    fireEvent.click(getAllByText('November (8)')[1]);

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    const SelectCoverImage = getByTestId('select-image-photobook');
    fireEvent.click(SelectCoverImage);

    fireEvent.click(CreateBtn);

    expect(getByText('Creating Social Memory Photobook')).toBeInTheDocument();

    await waitFor(() => {
      expect(getByText('Photobook successfully created.')).toBeInTheDocument();
    });

    await waitFor(() => {
      expect((useRouter as jest.Mock).mock.results[0].value.push).toBeCalledWith(
        '/photobook/cl0jk3wvm289250ks6tpruzalo',
      );
    });
  });

  it('renders error message while creating photobook without title', async () => {
    const { getByTestId, getAllByRole, getByText, getAllByText } = renderComponent();
    const SelectYear = getAllByRole('textbox')[1];
    const SelectMonth = getAllByRole('textbox')[2];
    const CreateBtn = getByTestId('create-photobook');

    fireEvent.change(SelectYear, { target: { value: '2021' } });
    fireEvent.change(SelectMonth, { target: { value: 'November (8)' } });

    fireEvent.click(getAllByText('2021')[1]);
    fireEvent.click(getAllByText('November (8)')[1]);

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    const SelectCoverImage = getByTestId('select-image-photobook');
    fireEvent.click(SelectCoverImage);

    fireEvent.click(CreateBtn);

    await waitFor(() => {
      expect(getByText('Please enter a title for your photobook!')).toBeInTheDocument();
    });
  });

  it('renders error message while creating photobook', async () => {
    const { getByTestId, getByRole, getAllByRole, getByText, getAllByText } = renderComponent();
    const InputTitle = getByRole('textbox', { name: 'Title' });
    const SelectYear = getAllByRole('textbox')[1];
    const SelectMonth = getAllByRole('textbox')[2];
    const CreateBtn = getByTestId('create-photobook');

    fireEvent.change(InputTitle, { target: { value: 'photobook' } });
    fireEvent.change(SelectYear, { target: { value: '2021' } });
    fireEvent.change(SelectMonth, { target: { value: 'November (8)' } });

    fireEvent.click(getAllByText('2021')[1]);
    fireEvent.click(getAllByText('November (8)')[1]);

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    const SelectCoverImage = getByTestId('select-image-photobook');
    fireEvent.click(SelectCoverImage);

    fireEvent.click(CreateBtn);

    await waitFor(() => {
      expect(getByText('Failed to create photobook. Please, try again.')).toBeInTheDocument();
    });
  });
});
