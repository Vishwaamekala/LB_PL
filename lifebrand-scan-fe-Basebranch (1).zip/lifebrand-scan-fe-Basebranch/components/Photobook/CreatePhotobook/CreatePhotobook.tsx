import React, { useCallback, useEffect, useState } from 'react';

import { useRouter } from 'next/router';

import CoverImageSelection from './CoverImageSelection';
import CreatingPhotobookModal from './CreatingPhotobookModal';
import { useDataWithPassedDates } from './utils';

import { Button, Input, message, Select, Heading } from '@UI/meeseeks';
import Loading from '@UI/Loading';

import { useConnections } from '@Utils/hooks/useConnections';

import {
  PhotobooksDocument,
  useCreatePhotobookMutation,
  usePostsBetweenDatesLazyQuery,
  usePhotobookPhotoDatesQuery,
} from '@Generated/graphql';

import { createLinkWithId, ROUTES } from '@Utils/helper/routes';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import * as S from './CreatePhotobook.styles';

type CoverImageProps = {
  url: string;
  index: number;
};

const CreatePhotobook = () => {
  const { push } = useRouter();
  const { isMobile } = useBreakpoints();

  const { socialMediaConnection } = useConnections();

  const isAnySMConnected = socialMediaConnection.some((socialMedia) => socialMedia.isConnected);

  const { data: datesData, loading: datesLoading } = usePhotobookPhotoDatesQuery();
  const [
    getPostsBetweenDates,
    { data: postsData, loading: postsLoading },
  ] = usePostsBetweenDatesLazyQuery();

  const [title, setTitle] = useState('');
  const [coverImage, setCoverImage] = useState<CoverImageProps>();
  const [selectedYear, setSelectedYear] = useState<string | null>(null);
  const [selectedMonth, setSelectedMonth] = useState<string | null>(null);

  const loading = datesLoading || postsLoading;

  // used to handle month select reset and its label
  // after year select is changed from previous value
  const [monthValueLabel, setMonthValueLabel] = useState<string>('');

  const { monthsWithAll, yearsWithAll, dateFrom, dateTo } = useDataWithPassedDates({
    selectedYear,
    selectedMonth,
    initialData: datesData,
  });

  const [createPhotobook, { loading: createPhotobookLoading }] = useCreatePhotobookMutation();

  const onTitleChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
  }, []);

  useEffect(() => {
    if (!selectedYear || !selectedMonth) {
      return;
    }
    getPostsBetweenDates({
      variables: { dateFrom, dateTo },
    });
  }, [dateFrom, dateTo, selectedMonth, selectedYear]);

  useEffect(() => {
    setCoverImage(undefined);
  }, [postsData]);

  const onCreatePhotobook = useCallback(async () => {
    if (!title) {
      return message.error({
        title: 'Please enter a title for your photobook!',
      });
    }
    if (!coverImage?.url) {
      return message.error({
        title: 'Please select cover image for your photobook!',
      });
    }
    if (!dateFrom || !dateTo) {
      return message.error({
        title: 'Please select date range for your photobook!',
      });
    }
    try {
      const { data: createPhotobookData } = await createPhotobook({
        variables: {
          coverImage: coverImage.url ?? '',
          dateFrom,
          dateTo,
          title,
        },
        awaitRefetchQueries: true,
        refetchQueries: [{ query: PhotobooksDocument }],
      });
      message.success({
        title: 'Photobook successfully created.',
      });
      if (!createPhotobookData) {
        throw new Error('Failed to create photobook. Please, try again.');
      }
      push(createLinkWithId(ROUTES.PHOTOBOOK, createPhotobookData.createPhotobook.id).as);
      return true;
    } catch (e) {
      message.error({
        title: 'Failed to create photobook. Please, try again.',
      });
      return false;
    }
  }, [createPhotobook, dateFrom, dateTo, coverImage?.url, title]);

  return (
    <>
      <CreatingPhotobookModal visible={createPhotobookLoading} />
      <S.Wrapper>
        <S.Card>
          <Heading variant={isMobile ? 'h3' : 'h2'} marginBottom="large">
            Create Your New Memory Photobook
          </Heading>
          <S.FormWrap>
            <Input
              placeholder="Insert your Title"
              label="Title"
              onChange={onTitleChange}
              disabled={loading || !isAnySMConnected}
              value={title}
              fluid
            />
            <S.SelectWrap>
              <Select
                options={yearsWithAll}
                defaultValue={selectedYear ? { value: selectedYear, label: selectedYear } : null}
                onChange={(option) => {
                  if (option) {
                    // set month to null when changing year value
                    setSelectedMonth(null);
                    setSelectedYear(option.value);
                  }
                }}
                isDisabled={loading || !isAnySMConnected}
                placeholder="Year"
              />
              <Select
                options={monthsWithAll}
                // when month is set to null, set its label to null
                defaultValue={selectedMonth ? { value: selectedMonth, label: selectedMonth } : null}
                onChange={(option) => {
                  if (option) {
                    setSelectedMonth(option.value);
                    setMonthValueLabel(option.label);
                  }
                }}
                value={selectedMonth ? { value: selectedMonth, label: monthValueLabel } : null}
                isDisabled={loading || !isAnySMConnected}
                placeholder="Month"
              />
            </S.SelectWrap>
          </S.FormWrap>
          {loading && <Loading />}
          {!loading && isAnySMConnected && (
            <CoverImageSelection
              data={postsData}
              loading={loading}
              setSelectedUrl={setCoverImage}
              selectedUrl={coverImage}
            />
          )}
          <S.ButtonWrap>
            <Button
              variant="primary"
              size="large"
              disabled={!coverImage || loading}
              loading={loading}
              onClick={onCreatePhotobook}
              fluid={isMobile}
              data-testId="create-photobook"
            >
              Create
            </Button>
          </S.ButtonWrap>
        </S.Card>
      </S.Wrapper>
    </>
  );
};

export default CreatePhotobook;
