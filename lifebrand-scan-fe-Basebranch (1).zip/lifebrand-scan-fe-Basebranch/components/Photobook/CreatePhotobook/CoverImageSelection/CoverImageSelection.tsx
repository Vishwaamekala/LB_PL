import React from 'react';
import Skeleton from 'react-loading-skeleton';

import { Text } from '@UI/meeseeks';

import { PostsBetweenDatesQuery } from '@Generated/graphql';

import * as S from './CoverImageSelection.styles';

type UrlProps = {
  url: string;
  index: number;
};

enum MediaType {
  Photo = 'Photo',
  Video = 'Video',
}

type Media = {
  type: MediaType;
  url: string;
};

type Props = {
  loading: boolean;
  data?: PostsBetweenDatesQuery;
  setSelectedUrl: React.Dispatch<React.SetStateAction<UrlProps | undefined>>;
  selectedUrl?: UrlProps;
};

const PlaceholderArray = new Array(12).fill('');

const CoverImageSelection = ({ loading, data, setSelectedUrl, selectedUrl }: Props) => {
  const postImgUrls = (data?.postsBetweenDate ?? [])
    // Media object is non typed json from database
    .map(({ media }: { media: Media[] }) =>
      media.filter((one) => one.type === MediaType.Photo).map((one) => one.url),
    )
    .flat(1);

  const shouldShowSkeletonImages = loading || postImgUrls.length < 1;
  return (
    <>
      <Text variant="regular" textColor="caption" marginBottom="small">
        Select Cover Image
      </Text>
      <S.CoverSelection loading={loading}>
        {shouldShowSkeletonImages
          ? PlaceholderArray.map((_, i) => (
              <Skeleton
                key={i}
                duration={150}
                style={{ borderRadius: '8px', width: '100%', height: 76 }}
              />
            ))
          : postImgUrls.map((url, index) => (
              <S.CoverWrap
                // style attribute used in order to prevent reloading (which caused flickering of background image)
                style={{ backgroundImage: `url(${url})` }}
                key={index}
                onClick={() => setSelectedUrl({ url, index })}
                isSelected={index === selectedUrl?.index}
                disabled={!loading && !data}
                data-testid="select-image-photobook"
              >
                {index === selectedUrl?.index && (
                  <S.Checkmark src="/images/png/badge-connected.png" alt="Selected" width={16} />
                )}
              </S.CoverWrap>
            ))}
      </S.CoverSelection>
    </>
  );
};

export default CoverImageSelection;
