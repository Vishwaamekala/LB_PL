import styled from 'styled-components';

export const CoverSelection = styled.div<{ loading?: boolean }>`
  display: grid;
  grid-template-columns: repeat(4, 76px);
  grid-template-rows: repeat(4, 76px);
  grid-gap: ${({ theme }) => theme.spacing.large / 2}px;
  margin-bottom: ${({ theme }) => theme.spacing.large}px;
  height: 300px;
  max-height: 300px;
  overflow-y: auto;
`;

export const CoverWrap = styled.div<{ isSelected?: boolean; disabled?: boolean }>`
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  border: ${({ theme, isSelected }) =>
    `3px solid ${isSelected ? theme.meeseeks.color['success.500'] : theme.meeseeks.color.white}`};
  pointer-events: ${({ disabled }) => (disabled ? 'none' : 'initial')};
  background-size: cover;
  background-repeat: no-repeat;
  background-position: 50% 50%;
  width: 79px;
  height: 79px;
  position: relative;
`;

export const Checkmark = styled.img`
  position: absolute;
  top: 0;
  right: 0;
`;
