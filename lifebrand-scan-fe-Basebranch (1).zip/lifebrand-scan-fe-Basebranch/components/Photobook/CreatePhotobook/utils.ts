import { useMemo } from 'react';

import { endOfYear, startOfYear, startOfMonth, endOfMonth } from 'date-fns';

import { PhotobookPhotoDatesQuery } from '@Generated/graphql';

export const getMonthsAndYears = (
  data: PhotobookPhotoDatesQuery | undefined,
  selectedYear: string | null,
) => {
  const years = [
    ...new Set(data?.postDates?.map((d) => new Date(d.date).getFullYear().toString())),
  ];
  const months = data?.postDates.filter(
    ({ date }) => new Date(date).getFullYear().toString() === selectedYear,
  );

  const yearsOptions = (years ?? []).map((y) => ({
    label: y,
    value: y,
  }));

  const yearsWithAll = [{ label: 'All', value: 'all' }, ...yearsOptions];

  const monthsOptions = (months ?? []).map((m) => ({
    // might not need the count
    label: `${new Date(m.date).toLocaleString('default', { month: 'long' })} (${m.count})`,
    value: `${new Date(m.date).getMonth()}`,
  }));
  const monthsWithAll = [{ label: 'All', value: 'all' }, ...monthsOptions];

  return {
    yearsWithAll,
    monthsWithAll,
  };
};

interface DataWithPassedDatesProps {
  selectedYear: string | null;
  selectedMonth: string | null;
  initialData?: PhotobookPhotoDatesQuery;
}
export const useDataWithPassedDates = ({
  selectedYear,
  selectedMonth,
  initialData,
}: DataWithPassedDatesProps) => {
  const { yearsWithAll, monthsWithAll } = useMemo(
    () => getMonthsAndYears(initialData, selectedYear),
    [initialData, selectedYear],
  );

  const { dateFrom, dateTo } = useMemo(() => {
    if (!selectedYear || !selectedMonth) {
      return { dateFrom: undefined, dateTo: undefined };
    }

    let newDateFrom = new Date();
    let newDateTo = new Date();

    if (selectedYear === 'all') {
      // If all years it means all the months as well, so starting of the minimum and ending of the maximum
      const filteredYears = yearsWithAll
        .filter((y) => Number(y.value))
        .map((v) => parseInt(v.value as string, 10));
      const maximumYear = Math.max(...filteredYears);
      const minimumYear = Math.min(...filteredYears);

      newDateTo.setFullYear(maximumYear);
      newDateFrom.setFullYear(minimumYear);

      newDateTo = endOfYear(newDateTo);
      newDateFrom = startOfYear(newDateFrom);
    } else if (selectedMonth === 'all') {
      // if all months it means xx year so starting of the year and ending of year
      newDateFrom.setFullYear(parseInt(selectedYear, 10));
      newDateTo.setFullYear(parseInt(selectedYear, 10));

      newDateTo = endOfYear(newDateTo);
      newDateFrom = startOfYear(newDateFrom);
    } else {
      // set starting and ending of selected month
      newDateFrom.setFullYear(parseInt(selectedYear, 10));
      newDateTo.setFullYear(parseInt(selectedYear, 10));

      newDateFrom.setMonth(parseInt(selectedMonth, 10));
      newDateTo.setMonth(parseInt(selectedMonth, 10));

      newDateFrom = startOfMonth(newDateFrom);
      newDateTo = endOfMonth(newDateTo);
    }
    const offset = new Date().getTimezoneOffset() * 60 * 1000;
    const offsetDateFrom = new Date(newDateFrom.getTime() - offset);
    const offsetDateTo = new Date(newDateTo.getTime() - offset);

    return { dateFrom: offsetDateFrom, dateTo: offsetDateTo };
  }, [selectedYear, selectedMonth, yearsWithAll]);

  return {
    monthsWithAll,
    yearsWithAll,
    dateFrom,
    dateTo,
  };
};
