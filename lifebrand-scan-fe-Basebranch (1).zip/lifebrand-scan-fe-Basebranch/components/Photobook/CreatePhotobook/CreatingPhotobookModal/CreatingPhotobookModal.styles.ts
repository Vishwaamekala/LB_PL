import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const ImageWrap = styled.div`
  height: 280px;
  display: grid;
  place-content: center;
  background-color: #5352ed; // not exists in meeseeks theme
  overflow: hidden;

  ${useBreakpoint.mobile`
    place-content: end;
  `}
`;

export const Image = styled.img`
  width: 568px;

  ${useBreakpoint.mobile`
    width: 350px;
  `}
`;
