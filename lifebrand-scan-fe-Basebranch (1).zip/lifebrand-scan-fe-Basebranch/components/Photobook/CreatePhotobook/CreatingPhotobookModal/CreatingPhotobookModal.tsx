import React from 'react';

import { Heading, Text } from '@UI/meeseeks';
import Modal from '@UI/Modal';

import * as S from './CreatingPhotobookModal.styles';

type Props = {
  visible: boolean;
};

const CreatingPhotobookModal = ({ visible }: Props) => {
  return (
    <Modal footer={false} width={630} visible={visible} closable={false}>
      <Heading variant="h3" textAlign="center" marginBottom="xs">
        Creating Social Memory Photobook
      </Heading>
      <Text variant="regular" marginBottom="large" textAlign="center">
        Just a second. We are adding all great moments to your new
        <br />
        Social Memory Photobook...
      </Text>
      <S.ImageWrap>
        <S.Image src="/images/png/creating-photobook.png" />
      </S.ImageWrap>
    </Modal>
  );
};

export default CreatingPhotobookModal;
