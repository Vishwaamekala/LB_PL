import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Wrapper = styled.div`
  padding: ${({ theme }) =>
    `${theme.spacing.large}px ${theme.spacing.extraLarge + theme.spacing.small}px`};

  ${useBreakpoint.mobile`
    padding: 0;
  `}
`;

export const Card = styled.div`
  max-width: 400px;
  padding: ${({ theme }) =>
    `${theme.spacing.extraLarge}px ${theme.spacing.large}px ${theme.spacing.large}px`};
  background: ${({ theme }) => theme.meeseeks.color.white};
  box-shadow: 0px 10px 30px rgba(133, 133, 133, 0.15);
  border-radius: ${({ theme }) => theme.borderRadius.small * 2}px;
  display: flex;
  flex-direction: column;
  height: 680px;

  ${useBreakpoint.mobile`
    box-shadow: none;
    padding: ${({ theme }) => `${theme.spacing.small}px 0 0`};
    height: 610px;
  `}
`;

export const FormWrap = styled.div`
  & > * + * {
    margin-top: ${({ theme }) => theme.spacing.medium}px;
  }

  margin-bottom: ${({ theme }) => theme.spacing.medium}px;
`;

export const SelectWrap = styled.div`
  display: flex;
  justify-content: space-between;

  & > * + * {
    margin-left: ${({ theme }) => theme.spacing.medium}px;
  }
`;

export const ButtonWrap = styled.div`
  margin-top: auto;
  align-self: flex-end;
  margin-top: auto;

  ${useBreakpoint.mobile`
    align-self: auto;
  `}
`;
