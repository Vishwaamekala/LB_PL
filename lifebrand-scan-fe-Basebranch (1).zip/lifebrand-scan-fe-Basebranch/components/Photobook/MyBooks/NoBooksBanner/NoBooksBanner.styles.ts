import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Banner = styled.div`
  background-color: ${({ theme }) => theme.meeseeks.color['highlight.300']};
  border-radius: 8px;
  height: 315px;
  display: flex;
  justify-content: space-between;
  position: relative;
  overflow: hidden;
`;

export const CopyWrap = styled.div`
  padding: 0 0 0 ${({ theme }) => theme.spacing.extraLarge + theme.spacing.small}px;
  align-self: center;
  z-index: 1;

  ${useBreakpoint.mobile`
    padding: ${({ theme }) => theme.spacing.large}px;
    align-self: auto;
  `}
`;

export const Image = styled.img`
  width: 350px;
  position: absolute;
  right: 0;
  bottom: 0;
  border-radius: 8px;

  ${useBreakpoint.mobile`
    width: 395px;
  `}
`;
