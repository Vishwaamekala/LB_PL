import React from 'react';

import { Heading } from '@UI/meeseeks';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import * as S from './NoBooksBanner.styles';

type Props = {
  name?: string;
};

const NoBooksBanner = ({ name }: Props) => {
  const { isMobile } = useBreakpoints();

  return (
    <S.Banner data-testid="no-books-banner">
      <S.CopyWrap>
        <Heading
          variant={isMobile ? 'h4' : 'h2'}
          marginBottom={isMobile ? 'medium' : 'large'}
          textColor="#fff"
        >
          Welcome {name}!😍
        </Heading>
        <Heading variant={isMobile ? 'h5' : 'h4'} textColor="#fff">
          Turn your social media photos
          <br />
          in a beautiful photo book in one click!
        </Heading>
      </S.CopyWrap>
      <S.Image
        src={isMobile ? '/images/png/books-mobile.png' : '/images/png/banner-books.png'}
        alt="Books"
      />
    </S.Banner>
  );
};

export default NoBooksBanner;
