import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import { theme } from 'theme/theme';
import { useRouter } from 'next/router';
import { ThemeProvider } from 'styled-components';
import { MockedProvider } from '@apollo/client/testing';

import MyBooks from './MyBooks';

import { PhotobooksDocument } from '@Generated/graphql';

jest.mock('next/router', () => ({
  useRouter: jest.fn().mockReturnValue({
    route: '/digital-book',
    pathname: '',
    query: '',
    asPath: '',
    push: jest.fn(),
  }),
}));

jest.mock('@Utils/AuthContext', () => ({
  ...jest.requireActual('@Utils/AuthContext'),
  useAuthContext() {
    return {
      userData: {
        __typename: 'User',
        id: 'cl09eax2i128270is67jx0rfno',
        name: 'test',
        email: 'fotova3507@nitynote.com',
        photo: '',
        scanAmount: 1,
        authId: 'facebook|107403778058630',
        stripeId: null,
        planId: 'ckrd5tilh00002jym62ozxvcw',
        Plan: {
          __typename: 'Plan',
          id: 'ckrd5tilh00002jym62ozxvcw',
          name: 'Basic Access',
          type: 'Individual',
          numberOfScans: 1,
          isRecurring: false,
          price: 997,
        },
        createdAt: '2022-02-11T10:45:15.889Z',
        updatedAt: '2022-02-11T10:45:15.890Z',
        lastRefresh: null,
        acceptedFcraVersion: null,
        acceptedPolicyVersion: 'v2022-01-19',
        hasPassword: true,
        BusinessCustomer: [],
      },
      triggerRefetch: () => {},
      loading: false,
      isLoggedIn: true,
      isInvited: false,
      invitedBy: [],
    };
  },
}));

const mocks = [
  {
    request: {
      query: PhotobooksDocument,
      variables: {},
    },
    result: {
      data: {
        photobooks: [
          {
            id: 'cl0jk3wvm289250ks6tpruzalo',
            title: 'Title',
            dateFrom: '2021-11-01T00:00:00.000Z',
            dateTo: '2021-11-30T23:59:59.999Z',
            coverImage:
              'https://storage.googleapis.com/lifebrand-social-bff-develop.appspot.com/photobookCover/1646830077860.jpg?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=github-ci-cd%40lifebrand-social-bff-develop.iam.gserviceaccount.com%2F20220309%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20220309T124758Z&X-Goog-Expires=900&X-Goog-SignedHeaders=host&X-Goog-Signature=8ca5201c751067cc152cca14ea57a59ffe261afc902b2cef279f5bb78313fbbc985fca68e495ea2e2134039bf6778b043386047a60802c7427255e4a968b1e858d928a58b240588fec15a0065b66b977b4216084cae2db927edc9fc44767130dc633eb895831fcfd0072d2109a6c119cb1e4a69357878b1b4ca0f420ed4944946e248fbe62b3d91ec72cf3eacb72d1a32212f897a4c9ed2665f820e30bc21cb3f824e8a042516a74f384c270bee99b82f89d1f4506d413159a8f88cbda2efd9d27f6809347b6e1223dc361274ca0435c9b16e3cc081e289c59205019d0b9edd8f3ac960ee687796f9f8901d58e6fda8f801400d09b5c9e26412ff3a7f357322a',
            pdfUrl:
              'https://storage.googleapis.com/lifebrand-social-bff-develop.appspot.com/photobookPdf/1646830070907.pdf?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=github-ci-cd%40lifebrand-social-bff-develop.iam.gserviceaccount.com%2F20220309%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20220309T124758Z&X-Goog-Expires=900&X-Goog-SignedHeaders=host&X-Goog-Signature=c00e14159e281b88773e1d6092720e681261e055c7f5c186678a093fb0b33cf5deb3f9a8cf2da58beada2937ea4c4dab5204ae50f5087d445a7c5d9ef3185036f0efb1c33fd51ed67931eb9eac215cb508afe10aef903907b6a69bc04e318c1cdea6ba0196a96376595acd53aea29281d39c5759e062f02aaf7db517371f9fe137292d0cc8b1a9db7fce570902818b9b21ed5d980c008cfa5e9934515c69015212bfd01be082d82c252a42b4e9a77e483b360b5cdf0a27e6760b2f59fc114bae93dc3d00fa9da5f24855e307e9e32415e1cab82194fb565e59bb1396e2a651bc91888c5e65852df8a5ec2e56aeb3f29603e0733a83e623f0d1df5eae1fe958d8',
            userId: 'ckwq8nqgq20210ls63vqbcgy5',
            __typename: 'Photobook',
          },
        ],
      },
    },
  },
];

describe('MyBooks', () => {
  it('renders photobooks', async () => {
    const { getByTestId } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider mocks={mocks} addTypename={false}>
          <MyBooks />
        </MockedProvider>
      </ThemeProvider>,
    );

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    const Photobook = getByTestId('photobook-cl0jk3wvm289250ks6tpruzalo');
    expect(Photobook).toBeInTheDocument();
    fireEvent.click(Photobook);

    await waitFor(() => {
      expect((useRouter as jest.Mock).mock.results[0].value.push).toBeCalledWith(
        '/photobook/cl0jk3wvm289250ks6tpruzalo',
      );
    });
  });

  it('renders NoBooksBanner', async () => {
    const { getByTestId } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider
          mocks={[
            {
              request: {
                query: PhotobooksDocument,
                variables: {},
              },
              result: {
                data: {
                  photobooks: [],
                },
              },
            },
          ]}
          addTypename={false}
        >
          <MyBooks />
        </MockedProvider>
      </ThemeProvider>,
    );

    await waitFor(() => {
      expect(getByTestId('no-books-banner')).toBeInTheDocument();
    });
  });
});
