import React from 'react';
import Skeleton from 'react-loading-skeleton';

import Book from './Book';
import NoBooksBanner from './NoBooksBanner';

import { Heading } from '@UI/meeseeks';

import { usePhotobooksQuery } from '@Generated/graphql';

import { useAuthContext } from '@Utils/AuthContext';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';
import { parseToFirstName } from '@Utils/formatters/name';

import * as S from './MyBooks.styles';

const SKELETON_ITEMS = Array(6).fill(null);

const LoadingSkeleton = () => {
  return <Skeleton width={216} height={255} style={{ borderRadius: '8px' }} duration={100} />;
};

const MyBooks = () => {
  const { userData, loading: userDataLoading } = useAuthContext();
  const { isMobile } = useBreakpoints();

  const { data, loading } = usePhotobooksQuery();

  const isLoading = loading && userDataLoading;

  return (
    <S.Container>
      <Heading variant={isMobile ? 'h3' : 'h2'} marginBottom="medium">
        My Books
      </Heading>
      <S.BooksWrap>
        {isLoading
          ? SKELETON_ITEMS.map((_, index) => <LoadingSkeleton key={index} />)
          : data?.photobooks.map((photobook) => <Book key={photobook.id} photobook={photobook} />)}
      </S.BooksWrap>
      {!isLoading && !data?.photobooks.length && (
        <NoBooksBanner name={parseToFirstName(userData?.name)} />
      )}
    </S.Container>
  );
};

export default MyBooks;
