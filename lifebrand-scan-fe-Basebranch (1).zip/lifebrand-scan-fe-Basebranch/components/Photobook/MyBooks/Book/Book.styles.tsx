import styled from 'styled-components';

export const Wrapper = styled.div`
  background-color: ${({ theme }) => theme.meeseeks.color['neutrals.100']};
  padding: ${({ theme }) => `${theme.spacing.large / 2}px ${theme.spacing.large / 2}px 19px`};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  width: 216px;
  cursor: pointer;
`;

export const Image = styled.img`
  width: 192px;
  height: 176px;
  object-fit: cover;
  margin-bottom: ${({ theme }) => theme.spacing.large / 2}px;
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
`;
