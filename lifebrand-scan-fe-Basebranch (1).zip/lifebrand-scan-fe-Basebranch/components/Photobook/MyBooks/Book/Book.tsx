import React from 'react';

import { useRouter } from 'next/router';
import { format as formatDate, isSameMonth, isSameYear } from 'date-fns';

import { Text, Heading } from '@UI/meeseeks';

import { createLinkWithId, ROUTES } from '@Utils/helper/routes';

import { Photobook } from '@Generated/graphql';

import * as S from './Book.styles';

type Props = {
  photobook: Partial<Photobook>;
};

const MONTH_FORMAT = 'MMM';
const MONTH_YEAR_FORMAT = 'MMM yyy';

const TIMEZONE_OFFSET = new Date().getTimezoneOffset() * 60000;

const displayDates = (dateFrom: string, dateTo: string) => {
  // we are getting utc time new date so we turn it around
  const dateFromUTC = new Date(new Date(dateFrom).getTime() + TIMEZONE_OFFSET);
  const dateToUTC = new Date(new Date(dateTo).getTime() + TIMEZONE_OFFSET);

  if (isSameYear(dateFromUTC, dateToUTC)) {
    if (isSameMonth(dateFromUTC, dateToUTC)) {
      return `${formatDate(dateFromUTC, MONTH_YEAR_FORMAT)}`;
    }
    return `${formatDate(dateFromUTC, MONTH_FORMAT)}-${formatDate(dateToUTC, MONTH_YEAR_FORMAT)}`;
  }
  return `${formatDate(dateFromUTC, MONTH_YEAR_FORMAT)}-${formatDate(
    dateToUTC,
    MONTH_YEAR_FORMAT,
  )}`;
};

const Book = ({ photobook }: Props) => {
  const { push } = useRouter();
  return (
    <S.Wrapper
      onClick={() => {
        push(createLinkWithId(ROUTES.PHOTOBOOK, photobook.id!).as);
      }}
      data-testid={`photobook-${photobook.id}`}
    >
      <S.Image src={photobook.coverImage} alt={photobook.title} />
      <Heading variant="h6" marginBottom="xxs" textColor="heading">
        {photobook.title}
      </Heading>
      <Text variant="small" textColor="body">
        {displayDates(photobook.dateFrom, photobook.dateTo)}
      </Text>
    </S.Wrapper>
  );
};

export default Book;
