import React, { useState } from 'react';
import { pdfjs } from 'react-pdf';

import { Heading, Icon } from '@UI/meeseeks';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import * as S from './PDFViewer.styles';

// https://github.com/wojtekmaj/react-pdf/issues/136
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

interface Props {
  url: string;
}

const PDFViewer = ({ url }: Props) => {
  const [numPages, setNumPages] = useState(0);
  const [pageNumber, setPageNumber] = useState(1);

  const { isMobile, isTablet, isDesktop } = useBreakpoints();

  function onDocumentLoadSuccess({ numPages: numberOfPages }: { numPages: number }) {
    setNumPages(numberOfPages);
  }

  const isFirstPage = pageNumber === 1;
  const isSplitScreen = isDesktop && !isFirstPage && pageNumber + 1 <= numPages;

  const prevPage = () => {
    if (pageNumber - 1 > 0) {
      if (isDesktop) {
        setPageNumber(pageNumber - (pageNumber === 2 ? 1 : 2));
      }
      if (isTablet || isMobile) {
        setPageNumber(pageNumber - 1);
      }
    }
  };

  const nextPage = () => {
    if (isDesktop) {
      if (pageNumber === 1 && pageNumber < numPages) {
        setPageNumber(pageNumber + 1);
      } else if (pageNumber < numPages - 1) {
        setPageNumber(pageNumber + 2);
      }
    } else if ((isTablet || isMobile) && pageNumber < numPages) {
      setPageNumber(pageNumber + 1);
    }
  };

  return (
    <>
      <S.StyledDocument file={url} onLoadSuccess={onDocumentLoadSuccess}>
        {pageNumber === 1 || isMobile || isTablet ? (
          <S.StyledPage pageNumber={pageNumber} />
        ) : (
          <>
            <S.StyledPage pageNumber={pageNumber} />
            {isSplitScreen && <S.StyledPage pageNumber={pageNumber + 1} />}
          </>
        )}
      </S.StyledDocument>

      <S.PageChangeContainer>
        <Icon size={28} name="ChevronLeft" onClick={prevPage} />
        <Heading variant="h4">
          {isSplitScreen ? `${pageNumber}-${pageNumber + 1}` : pageNumber} / {numPages}
        </Heading>
        <Icon size={28} name="ChevronRight" onClick={nextPage} />
      </S.PageChangeContainer>
    </>
  );
};

export default PDFViewer;
