import styled from 'styled-components';
import { Document, Page } from 'react-pdf';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const StyledDocument = styled(Document)`
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
`;

export const StyledPage = styled(Page)`
  ${useBreakpoint.tablet`
    width: 100%;

    canvas {
      width: 90% !important;
      height: 70% !important;
      transform: translate(-50%, 0);
      left: 50%;
      position: relative;
    }

    > div{
      width: 100% !important;
    }
  `}
`;

export const PageChangeContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  height: min-content;
  z-index: 5;
  margin-top: -15vh;
  background-color: ${({ theme }) => theme.meeseeks.color.white};
  padding: ${({ theme }) => theme.spacing.medium}px;
  border-radius: ${({ theme }) => theme.borderRadius.small * 2}px;

  ${useBreakpoint.tablet`
    margin-top: 0px;
    position: absolute;
    bottom: 7vh;
  `}

  h4 {
    margin: 0 ${({ theme }) => theme.spacing.small}px;
  }

  svg {
    cursor: pointer;
  }
`;
