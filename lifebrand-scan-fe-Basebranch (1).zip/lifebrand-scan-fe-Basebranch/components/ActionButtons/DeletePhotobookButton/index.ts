export { default } from './DeletePhotobookButton';
export * from './DeletePhotobookButton';
