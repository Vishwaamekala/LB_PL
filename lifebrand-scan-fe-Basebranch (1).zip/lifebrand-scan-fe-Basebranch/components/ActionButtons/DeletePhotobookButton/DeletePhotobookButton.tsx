import React, { useCallback, useState } from 'react';

import { useRouter } from 'next/router';

import { IconButton, message, Tooltip } from '@UI/meeseeks';

import DeletePhotobookModal from '../DeleteButton/DeletePhotobookModal/DeletePhotobookModal';

import { ROUTES } from '@Utils/helper/routes';
import { useDeletePhotobookMutation, Photobook } from '@Generated/graphql';

import * as S from './DeletePhotobookButton.styles';

type Props = {
  photobookId: string;
};

const DeletePhotobookButton = ({ photobookId }: Props) => {
  const router = useRouter();
  const [isVisible, setIsVisible] = useState(false);
  const [deletePhotobook, { loading }] = useDeletePhotobookMutation();

  const handleOpen = useCallback(() => {
    setIsVisible(true);
  }, []);

  const handleClose = useCallback(() => {
    setIsVisible(false);
  }, []);

  const handleConfirm = () => {
    handleClose();
    deletePhotobook({
      variables: {
        id: photobookId,
      },
      update: (cache) =>
        cache.modify({
          fields: {
            photobooks(photobooks: Photobook[], { readField }) {
              return photobooks.filter((photobook) => photobookId !== readField('id', photobook));
            },
          },
        }),
    })
      .then(() => {
        message.success({
          title: 'Photobook was successfully deleted.',
        });
        router.push(ROUTES.DIGITAL_BOOK);
      })
      .catch(() => {
        message.error({
          title: 'Failed to delete Photobook. Please try again.',
        });
      });
  };

  return (
    <>
      <Tooltip title="Delete Photobook" placement="top">
        <S.Box>
          <IconButton name="Trash" onClick={handleOpen} loading={loading} disabled={loading} />
        </S.Box>
      </Tooltip>
      <DeletePhotobookModal isVisible={isVisible} onClose={handleClose} onConfirm={handleConfirm} />
    </>
  );
};

export default DeletePhotobookButton;
