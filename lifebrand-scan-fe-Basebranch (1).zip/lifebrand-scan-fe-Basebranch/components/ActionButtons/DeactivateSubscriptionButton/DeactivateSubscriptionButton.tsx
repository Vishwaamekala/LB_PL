import React, { useState, useCallback } from 'react';
import { useRouter } from 'next/router';
import { Col, Row } from 'antd';
import { format as formatDate } from 'date-fns';
import { useTheme } from 'styled-components';

import { Button, message, Heading, Text } from '@UI/meeseeks';
import Modal from '@UI/Modal';

import { ROUTES } from '@Utils/helper/routes';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import {
  AuthDocument,
  IndividualFeatureAccessDocument,
  useCancelIndividualSubscriptionMutation,
} from '@Generated/graphql';

import * as S from './DeactivateSubscriptionButton.styles';

const DATE_FORMAT = 'MMMM d, yyyy';

type Props = {
  currentPeriodEnd: Date | null;
  disabled?: boolean;
};

const DeactivateSubscriptionButton = ({ currentPeriodEnd }: Props) => {
  const { isMobile } = useBreakpoints();
  const theme = useTheme();
  const router = useRouter();
  const [isVisible, setIsDeactivateVisible] = useState(false);

  const [cancelSubscription, { loading }] = useCancelIndividualSubscriptionMutation({
    refetchQueries: [{ query: AuthDocument }, { query: IndividualFeatureAccessDocument }],
  });

  const handleOpen = useCallback(() => {
    setIsDeactivateVisible(true);
  }, []);

  const handleClose = useCallback(() => {
    setIsDeactivateVisible(false);
  }, []);

  const handleConfirm = useCallback(async () => {
    handleClose();
    try {
      await cancelSubscription();
      message.success({
        title: 'Your subscription was successfully canceled.',
      });
      router.push(ROUTES.DASHBOARD);
    } catch (error) {
      message.error({
        title: 'Failed to cancel subscription. Please try again.',
      });
    }
  }, [cancelSubscription, handleClose, router]);

  return (
    <div>
      <Button
        variant="tertiary"
        size="medium"
        onClick={handleOpen}
        disabled={loading}
        fluid={isMobile}
      >
        Cancel Subscription
      </Button>
      <Modal visible={isVisible} footer={null} onCancel={handleClose} width={680}>
        <Row justify="center" gutter={[0, theme.spacing.small]}>
          <Col>
            <Heading variant="h3" textAlign="center">
              Cancel Subscription
            </Heading>
          </Col>
        </Row>
        <Row gutter={[0, theme.spacing.large]}>
          <Col>
            <Text variant="regular" textAlign="center" fontWeight={700}>
              Your subscription will be canceled, not allowing you to scan and send reports after{' '}
              {currentPeriodEnd ? formatDate(new Date(currentPeriodEnd), DATE_FORMAT) : '-'}. You
              would still be able to scan until the subscription is over. Are you sure you want to
              cancel your subscription?
            </Text>
          </Col>
        </Row>
        <S.RowWithBackground justify="center">
          <Col>
            <S.Image src="/images/png/lightning.png" alt="lightning" />
          </Col>
        </S.RowWithBackground>
        <Row justify="end" gutter={[theme.spacing.medium, theme.spacing.medium]}>
          <Col>
            <Button variant="tertiary" size="medium" onClick={handleClose}>
              Keep Subscription
            </Button>
          </Col>
          <Col>
            <Button
              variant="danger"
              size="medium"
              onClick={handleConfirm}
              data-testid="confirm-cancel-subscription"
            >
              Cancel Subscription
            </Button>
          </Col>
        </Row>
      </Modal>
    </div>
  );
};

export default DeactivateSubscriptionButton;
