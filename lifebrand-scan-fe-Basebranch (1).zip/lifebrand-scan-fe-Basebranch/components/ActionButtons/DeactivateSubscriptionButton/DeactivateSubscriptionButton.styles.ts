import { Row } from 'antd';
import styled from 'styled-components';

export const Image = styled.img`
  display: block;
  height: 150px;
`;

export const RowWithBackground = styled(Row)`
  background-color: ${({ theme }) => theme.meeseeks.color['neutrals.100']};
  margin-bottom: ${({ theme }) => theme.spacing.large}px;
  padding: ${({ theme }) => theme.spacing.large * 2}px 0;
  border-radius: ${({ theme }) => theme.borderRadius.small / 2}px;
`;
