export { default } from './DeleteFBPostModal';
export * from './DeleteFBPostModal';
