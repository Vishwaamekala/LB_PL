import { theme } from 'theme/theme';

import { SocialMedia } from '@Generated/graphql';

export type ConfirmPostDeleteModalProps = {
  provider: SocialMedia | 'Photobook';
  isVisible: boolean;
  onClose: () => void;
  onConfirm: () => void;
};

export const ProvidersConfig: {
  [key in ConfirmPostDeleteModalProps['provider']]: {
    title: string;
    subtitle: string;
    image: string;
    closeLabel: string;
    confirmLabel: string;
    backgroundColor: string;
    shouldShowDismissButton: boolean;
  };
} = {
  [SocialMedia.Facebook]: {
    title: 'Deletion Confirmation.',
    subtitle: 'Please just confirm that you deleted your post. Thanks!',
    image: '/images/png/deletion-confirmation-img.png',
    closeLabel: 'Cancel',
    confirmLabel: 'Confirm',
    backgroundColor: theme.meeseeks.color['neutrals.100'],
    shouldShowDismissButton: false,
  },
  [SocialMedia.Twitter]: {
    title: 'Deletion Confirmation.',
    subtitle: 'Are you sure you want to delete your post?',
    image: '/images/png/deletion-confirmation-img.png',
    closeLabel: 'Cancel',
    confirmLabel: 'Delete',
    backgroundColor: theme.meeseeks.color['neutrals.100'],
    shouldShowDismissButton: true,
  },
  [SocialMedia.Instagram]: {
    title: 'Deletion Confirmation.',
    subtitle: 'Please just confirm that you deleted your post. Thanks!',
    image: '/images/png/deletion-confirmation-img.png',
    closeLabel: 'Cancel',
    confirmLabel: 'Confirm',
    backgroundColor: theme.meeseeks.color['neutrals.100'],
    shouldShowDismissButton: false,
  },
  Photobook: {
    title: 'Deletion Confirmation.',
    subtitle: 'Please confirm that you want to delete this photobook. Thanks!',
    image: '/images/png/my-social-photobook-smaller.png',
    closeLabel: 'Cancel',
    confirmLabel: 'Confirm',
    backgroundColor: theme.color.primary,
    shouldShowDismissButton: true,
  },
};
