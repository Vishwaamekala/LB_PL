import styled from 'styled-components';

export const ImageWrap = styled.div<{ backgroundColor: string }>`
  background-color: ${({ backgroundColor }) => backgroundColor};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  display: flex;
  justify-content: center;
  overflow: hidden;
`;

export const ConfirmImage = styled.img`
  height: 260px;
`;

export const Action = styled.div`
  display: flex;
  justify-content: flex-end;
  padding: ${({ theme }) => `${theme.spacing.large}px 0px 0px`};

  & > * + * {
    margin-left: ${({ theme }) => theme.spacing.medium}px;
  }
`;
