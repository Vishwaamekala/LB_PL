export { default } from './ConfirmPostDeleteModal';
export * from './ConfirmPostDeleteModal';
