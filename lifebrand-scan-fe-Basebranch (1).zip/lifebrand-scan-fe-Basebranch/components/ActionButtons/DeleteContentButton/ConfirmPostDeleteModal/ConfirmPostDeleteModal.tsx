import React from 'react';

import { ConfirmPostDeleteModalProps, ProvidersConfig } from './ConfirmPostDeleteModal.config';

import { Button, Heading } from '@UI/meeseeks';
import Modal from '@UI/Modal';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import * as S from './ConfirmPostDeleteModal.styles';

const ConfirmPostDeleteModal = ({
  isVisible,
  onClose,
  onConfirm,
  provider,
}: ConfirmPostDeleteModalProps) => {
  const { isMobile } = useBreakpoints();
  const config = ProvidersConfig[provider];

  return (
    <Modal
      visible={isVisible}
      footer={null}
      onCancel={onClose}
      width={630}
      closable={config.shouldShowDismissButton}
    >
      <Heading variant="h3" marginBottom="small" textAlign="center">
        {config.title}
      </Heading>
      <Heading variant="h6" textColor="body" marginBottom="large" textAlign="center">
        {config.subtitle}
      </Heading>
      <S.ImageWrap backgroundColor={config.backgroundColor}>
        <S.ConfirmImage src={config.image} alt="delete post" />
      </S.ImageWrap>
      <S.Action>
        <Button variant="tertiary" size="medium" onClick={onClose}>
          {config.closeLabel}
        </Button>
        <Button variant="primary" size="medium" onClick={onConfirm} fluid={isMobile}>
          {config.confirmLabel}
        </Button>
      </S.Action>
    </Modal>
  );
};

export default ConfirmPostDeleteModal;
