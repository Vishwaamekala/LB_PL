import React, { useCallback, useState } from 'react';
import * as Icon from 'react-feather';

import { Reference } from '@apollo/client';

import DeleteFBPostModal from './DeleteFBPostModal';
import DeleteTWPostModal from './DeleteTWPostModal';
import DeleteInstagramPostModal from './DeleteInstagramPostModal';

import { Button, message } from '@UI/meeseeks';

import {
  SocialMedia,
  ContentDataFragment,
  useDeleteContentMutation,
  DashboardContentBreakdownsDocument,
  FlaggedPostLabelsBreakdownDocument,
} from '@Generated/graphql';
import { DLVariable, TriggerClass, TriggerEvent } from '@Utils/google-tag-manager';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';
import { useConnections } from '@Utils/hooks/useConnections';

type Props = {
  content: ContentDataFragment;
  disabled?: boolean;
};

type ModalSelectorProps = Pick<Props, 'content'> & {
  isVisible: boolean;
  handleConfirm: () => void;
  handleClose: () => void;
};

const ModalSelector = ({ content, isVisible, handleConfirm, handleClose }: ModalSelectorProps) => {
  if (!isVisible) return null;
  if (content.origin === SocialMedia.Facebook) {
    return (
      <DeleteFBPostModal
        postUrl={content.url}
        isVisible
        onClose={handleClose}
        onConfirm={handleConfirm}
      />
    );
  }
  if (content.origin === SocialMedia.Twitter) {
    return <DeleteTWPostModal isVisible onClose={handleClose} onConfirm={handleConfirm} />;
  }
  if (content.origin === SocialMedia.Instagram) {
    return (
      <DeleteInstagramPostModal
        postUrl={content.url}
        isVisible
        onClose={handleClose}
        onConfirm={handleConfirm}
      />
    );
  }
  return null;
};

const DeleteContentButton = ({ content, disabled }: Props) => {
  const [isVisible, setIsVisible] = useState(false);
  const [deleteContent, { loading }] = useDeleteContentMutation();

  const { socialMediaConnection } = useConnections();

  const { isMobile } = useBreakpoints();

  const handleOpen = useCallback(() => {
    const currentSocialMedia = socialMediaConnection.find(
      (origin) => origin.socialMedia === content.origin,
    );

    if (currentSocialMedia?.isConnected) {
      setIsVisible(true);
    } else {
      message.error({
        title: `${content.origin} is not connected. Please, reconnect it before deleting`,
      });
    }
  }, [content.origin, socialMediaConnection]);

  const handleClose = useCallback(() => {
    setIsVisible(false);
  }, []);

  const handleConfirm = () => {
    handleClose();
    deleteContent({
      variables: {
        input: {
          contentId: content.id,
          origin: content.origin,
        },
      },
      refetchQueries: [
        { query: DashboardContentBreakdownsDocument },
        { query: FlaggedPostLabelsBreakdownDocument },
      ],
      update: (cache) => {
        cache.modify({
          fields: {
            contents(existing, { readField }) {
              return {
                ...existing,
                list: existing.list.filter(
                  (contentRef: Reference) => content.id !== readField('id', contentRef),
                ),
              };
            },
          },
        });

        // Removes OverviewContentBreakdowns from the cache and forces refetching later.
        // Compared to `refetchQueries`, eviction does not require `variables`.
        cache.evict({ fieldName: 'overviewContentBreakdowns' });
      },
    })
      .then(() => {
        message.success({
          title: 'Post was successfully deleted.',
        });

        window.dataLayer?.push({
          event: TriggerEvent.DeletePostSuccess,
          [DLVariable.SocialMediaType]: content.origin,
        });
      })
      .catch((e) => {
        message.error({
          title: e.message,
        });
      });
  };

  const isButtonDisabled = loading || disabled;

  return (
    <>
      <Button
        className={TriggerClass.DeletePost}
        iconLeft={<Icon.Trash size={14} />}
        size="medium"
        variant="secondary"
        onClick={handleOpen}
        loading={loading}
        disabled={isButtonDisabled}
        fluid={isMobile}
      >
        Delete
      </Button>
      <ModalSelector {...{ isVisible, handleClose, handleConfirm, content }} />
    </>
  );
};

export default DeleteContentButton;
