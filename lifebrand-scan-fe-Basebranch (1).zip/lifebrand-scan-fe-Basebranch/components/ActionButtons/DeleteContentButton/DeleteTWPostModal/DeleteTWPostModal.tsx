import React from 'react';

import ConfirmPostDeleteModal from '../ConfirmPostDeleteModal';

import { SocialMedia } from '@Generated/graphql';

type Props = {
  isVisible: boolean;
  onClose: () => void;
  onConfirm: () => void;
};

const DeleteTWPostModal = ({ isVisible, onClose, onConfirm }: Props) => (
  <ConfirmPostDeleteModal
    provider={SocialMedia.Twitter}
    isVisible={isVisible}
    onClose={onClose}
    onConfirm={onConfirm}
  />
);

export default DeleteTWPostModal;
