export { default } from './DeleteContentButton';
export * from './DeleteContentButton';
