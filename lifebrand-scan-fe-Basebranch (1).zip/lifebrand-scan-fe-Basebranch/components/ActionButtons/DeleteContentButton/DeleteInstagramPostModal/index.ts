export { default } from './DeleteInstagramPostModal';
export * from './DeleteInstagramPostModal';
