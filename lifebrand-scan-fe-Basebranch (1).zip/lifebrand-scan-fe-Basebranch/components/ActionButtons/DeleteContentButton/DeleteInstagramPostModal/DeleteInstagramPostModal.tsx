import React, { useState } from 'react';

import ConfirmPostDeleteModal from '../ConfirmPostDeleteModal';
import InitialPostDeleteModal from '../InitialDeletePostModal';

import { SocialMedia } from '@Generated/graphql';

type Props = {
  postUrl: string;
  isVisible: boolean;
  onClose: () => void;
  onConfirm: () => void;
};

const DeleteInstagramPostModal = ({
  postUrl,
  isVisible: isMainVisible,
  onClose: onMainClose,
  onConfirm: onMainConfirm,
}: Props) => {
  const [isConfirmVisible, setIsConfirmVisible] = useState(false);

  const handleClose = () => {
    onMainClose();
    setIsConfirmVisible(false);
  };

  const handleRedirect = () => {
    window.open(postUrl);
    setIsConfirmVisible(true);
  };

  const handleConfirm = () => {
    handleClose();
    onMainConfirm();
  };

  if (!isMainVisible && !isConfirmVisible) {
    return null;
  }

  return (
    <>
      <InitialPostDeleteModal
        provider={SocialMedia.Instagram}
        isVisible={isMainVisible && !isConfirmVisible}
        onClose={handleClose}
        onConfirm={handleRedirect}
      />
      <ConfirmPostDeleteModal
        provider={SocialMedia.Instagram}
        isVisible={isConfirmVisible}
        onClose={handleClose}
        onConfirm={handleConfirm}
      />
    </>
  );
};

export default DeleteInstagramPostModal;
