import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const StepsWrap = styled.div`
  display: flex;
  justify-content: space-between;
  background-color: ${({ theme }) => theme.meeseeks.color['neutrals.100']};
  border-radius: 2px;
  padding: ${({ theme }) => `${theme.spacing.large}px ${theme.spacing.large}px 0px`};

  ${useBreakpoint.mobile`
    flex-direction: column;

    & > * + * {
      margin-top: ${({ theme }) => theme.spacing.medium}px;
    }
  `}
`;

export const StepWrap = styled.div`
  width: 50%;
  display: inline-flex;
  flex-direction: column;

  ${useBreakpoint.mobile`
    align-self: center;
    width: auto;
  `}
`;

export const CaptionWrap = styled.div`
  display: flex;
  align-items: center;
  margin: ${({ theme }) => `0 0 ${theme.spacing.medium}px ${theme.spacing.medium}px`};

  & > * {
    font-family: 'Poppins';
    font-size: 12px;
    line-height: 120%;
    letter-spacing: 0.01em;
  }
`;

export const StepCount = styled.span`
  border-radius: 50%;
  min-width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: ${({ theme }) => theme.meeseeks.color.secondary};
  color: ${({ theme }) => theme.meeseeks.color.white};
  margin-right: ${({ theme }) => theme.spacing.small}px;
`;

export const StepImage = styled.img`
  width: 100%;
  height: auto;
`;

export const Action = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: ${({ theme }) => theme.spacing.large}px;

  ${useBreakpoint.mobile`
    flex-direction: column;

    & > * + * {
      margin-top: ${({ theme }) => theme.spacing.medium}px;
    }
  `}
`;

export const CheckBoxWrapper = styled.div`
  display: flex;
  align-items: center;

  & > * + * {
    padding-left: ${({ theme }) => theme.spacing.small}px;
  }
`;
