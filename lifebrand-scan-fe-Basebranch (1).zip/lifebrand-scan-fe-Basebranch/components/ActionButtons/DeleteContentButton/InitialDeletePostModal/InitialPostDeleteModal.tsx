import React, { useCallback, useEffect, useState } from 'react';

import { ProvidersConfig } from './InitialPostDeleteModal.config';

import { Button, Checkbox, Heading, Text } from '@UI/meeseeks';
import Modal from '@UI/Modal';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { SocialMedia } from '@Generated/graphql';

import useLocalStorage from '@Utils/storage/useLocalStorage';
import { userAcknowledgesPostDeletionByOrigin } from '@Utils/storage/localStorageKeys';
import { useAuthContext } from '@Utils/AuthContext';

import * as S from './InitialPostDeleteModal.styles';

type Props = {
  provider: Exclude<SocialMedia, 'Twitter'>;
  isVisible: boolean;
  onClose: () => void;
  onConfirm: () => void;
};

export const InitialPostDeleteModal = ({ isVisible, onClose, onConfirm, provider }: Props) => {
  const { userData } = useAuthContext();
  const { isMobile } = useBreakpoints();
  const config = ProvidersConfig[provider];

  const [checked, setChecked] = useState(false);
  const [acknowledgePostDeletion, setAcknowledgePostDeletion] = useLocalStorage<boolean>(
    userAcknowledgesPostDeletionByOrigin(userData?.id, provider),
    false,
  );

  const handleCheck = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    setChecked(event.target.checked);
  }, []);

  const handleConfirm = useCallback(() => {
    if (checked) {
      setAcknowledgePostDeletion(true);
      onConfirm();
    }
    onConfirm();
  }, [checked, setAcknowledgePostDeletion, onConfirm]);

  useEffect(() => {
    if (acknowledgePostDeletion) {
      onConfirm();
    }
  }, [acknowledgePostDeletion, onConfirm]);

  return (
    <Modal visible={isVisible} onCancel={onClose} footer={null} width={630}>
      <Heading variant={isMobile ? 'h4' : 'h3'} textAlign="center" marginBottom="small">
        {config.title}
      </Heading>
      <Heading variant="h6" textColor="body" textAlign="center" marginBottom="large">
        {config.subtitle}
      </Heading>
      <S.StepsWrap>
        <S.StepWrap>
          <S.CaptionWrap>
            <S.StepCount>1</S.StepCount>
            <Heading variant="h6">{config.stepOneText}</Heading>
          </S.CaptionWrap>
          <S.StepImage src={config.stepOneImage} alt="post settings" />
        </S.StepWrap>
        <S.StepWrap>
          <S.CaptionWrap>
            <S.StepCount>2</S.StepCount>
            <Heading variant="h6">{config.stepTwoText}</Heading>
          </S.CaptionWrap>
          <S.StepImage src={config.stepTwoImage} alt="delete post" />
        </S.StepWrap>
      </S.StepsWrap>
      <S.Action>
        <S.CheckBoxWrapper>
          <Checkbox onChange={handleCheck} checked={checked} />
          <Text variant="regular" textColor="body">
            Don’t show me again
          </Text>
        </S.CheckBoxWrapper>
        <Button variant="primary" size="medium" onClick={handleConfirm} fluid={isMobile}>
          Start Cleaning
        </Button>
      </S.Action>
    </Modal>
  );
};

export default InitialPostDeleteModal;
