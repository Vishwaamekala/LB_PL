import React from 'react';

import { SocialMedia } from '@Generated/graphql';

export const ProvidersConfig: {
  [key in Exclude<SocialMedia, 'Twitter'>]: {
    title: string;
    subtitle: React.ReactNode;
    stepOneImage: string;
    stepOneText: string;
    stepTwoImage: string;
    stepTwoText: string;
  };
} = {
  [SocialMedia.Facebook]: {
    title: 'Delete your Facebook Post',
    subtitle: (
      <>
        Ohh bummer. Due to the Facebook Privacy Policy,
        <br />
        we are not able to delete your post directly through our Platform.
      </>
    ),
    stepOneImage: '/images/png/img1+shadows.png',
    stepOneText: 'Click three dots on the top',
    stepTwoImage: '/images/png/img2+shadows.png',
    stepTwoText: 'Move your post to trash',
  },
  [SocialMedia.Instagram]: {
    title: 'Delete your Instagram Post',
    subtitle: (
      <>
        Ohh bummer. Due to the Instagram Privacy Policy,
        <br />
        we are not able to delete your post directly through our Platform. Please delete via your
        mobile device.
      </>
    ),
    stepOneImage: '/images/png/delete-post-instagram-1.png',
    stepOneText: 'Click three dots on the top',
    stepTwoImage: '/images/png/delete-post-instagram-2.png',
    stepTwoText: 'Delete your post.',
  },
};
