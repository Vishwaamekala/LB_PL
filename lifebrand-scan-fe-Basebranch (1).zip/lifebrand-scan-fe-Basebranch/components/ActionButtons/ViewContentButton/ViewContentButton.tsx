import React, { useCallback } from 'react';

import { Button } from '@UI/meeseeks';

import { TriggerClass } from '@Utils/google-tag-manager';

type Props = {
  url: string;
  disabled: boolean;
};

const ViewPostButton = ({ url, disabled }: Props) => {
  const handleClick = useCallback(() => {
    window.open(url);
  }, [url]);

  return (
    <Button
      size="medium"
      variant="tertiary"
      onClick={handleClick}
      className={TriggerClass.ViewPost}
      disabled={disabled}
    >
      View Post
    </Button>
  );
};

export default ViewPostButton;
