import styled from 'styled-components';

import ModalBase from '@UI/Modal';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Modal = styled(ModalBase)`
  .ant-modal-content {
    background-color: ${({ theme }) => theme.meeseeks.color['neutrals.100']};
  }

  ${useBreakpoint.mobile`
    .ant-modal-body {
      padding-left: ${({ theme }) => theme.spacing.medium}px;
      padding-right: ${({ theme }) => theme.spacing.medium}px;
    }
  `}
`;

export const Header = styled.div`
  margin: 0px auto;
`;

export const Actions = styled.div`
  display: flex;
  justify-content: flex-end;
  margin-top: ${({ theme }) => theme.spacing.large}px;

  & > * + * {
    margin-left: ${({ theme }) => theme.spacing.medium}px;
  }
`;
