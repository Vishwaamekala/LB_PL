import React, { useCallback, useState } from 'react';

import router from 'next/router';

import { Button, ButtonProps, Heading, message } from '@UI/meeseeks';

import {
  PendingReportRequestsDocument,
  ReportRequestDataFragment,
  useRejectReportRequestMutation,
} from '@Generated/graphql';

import { ROUTES } from '@Utils/helper/routes';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import * as S from './RejectReportRequestButton.styles';

type Props = {
  reportRequest: ReportRequestDataFragment;
  onSuccess?: () => void;
  fluid?: ButtonProps['fluid'];
  buttonVariant?: ButtonProps['variant'];
};

const RejectReportRequestButton = ({
  reportRequest,
  onSuccess,
  buttonVariant = 'critical',
  fluid,
}: Props) => {
  const [rejectReportRequest, { loading }] = useRejectReportRequestMutation({
    refetchQueries: [{ query: PendingReportRequestsDocument }],
  });
  const { isMobile } = useBreakpoints();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const handleCancel = () => setIsModalOpen(false);

  const handleSuccess = useCallback(() => {
    message.success({
      title: 'Your report request was successfully declined.',
    });
    router.push(ROUTES.DASHBOARD);
    handleCancel();
  }, []);

  const handleFailure = useCallback(() => {
    message.error({
      title: 'Failed to decline report request. Please try again.',
    });
  }, []);

  const handleSubmit = useCallback(async () => {
    try {
      await rejectReportRequest({
        variables: { reportRequestId: reportRequest.id },
      });
      onSuccess?.();
      handleSuccess();
    } catch {
      handleFailure();
    }
  }, [reportRequest]);

  return (
    <>
      <Button
        variant={buttonVariant}
        size="medium"
        onClick={() => setIsModalOpen(true)}
        loading={loading}
        fluid={isMobile || fluid}
        data-testid="reject-report-button"
      >
        Decline
      </Button>
      <S.Modal visible={isModalOpen} width={680} footer={null} onCancel={handleCancel}>
        <S.Header>
          <Heading variant="h3" textAlign="center" marginBottom="small">
            Are you sure you want to decline the report request from{' '}
            {reportRequest.Business.name || reportRequest.Business.contactEmail} ?
          </Heading>
        </S.Header>
        <S.Actions>
          <Button
            variant="tertiary"
            size="medium"
            onClick={handleCancel}
            disabled={loading}
            fluid={isMobile}
          >
            Cancel
          </Button>
          <Button
            variant="primary"
            size="medium"
            onClick={handleSubmit}
            loading={loading}
            fluid={isMobile}
          >
            Submit
          </Button>
        </S.Actions>
      </S.Modal>
    </>
  );
};

export default RejectReportRequestButton;
