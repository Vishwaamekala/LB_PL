import React, { useState, useMemo } from 'react';

import * as dateUtils from 'date-fns';

import { Button, Heading, Icon } from '@UI/meeseeks';

import ViewReportButton from 'components/Analytics/ViewReportButton';
import ReportLog from 'components/Analytics/ReportHistory/ReportHistoryContent/ReportLog';
import CreateReportButton from 'components/Analytics/CreateReportButton';

import {
  ReportRequestDataFragment,
  ReportType,
  useIndividualReportsQuery,
} from '@Generated/graphql';

import { signedQueryOptions } from '@Utils/reports/constants';

import * as S from './SelectReportButton.styles';

type Props = {
  reportRequest: ReportRequestDataFragment;
};

const SelectReportButton = ({ reportRequest }: Props) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedReportId, setSelectedReportId] = useState<string | undefined>(undefined);

  const { data, loading } = useIndividualReportsQuery({
    ...signedQueryOptions,
    variables: {},
  });

  const recentReports = useMemo(() => {
    const now = new Date();
    return data?.individualReports.filter(
      (report) =>
        report &&
        report.isFCRACompliant &&
        dateUtils.add(dateUtils.parseISO(report.createdAt), { weeks: 1 }) > now,
    );
  }, [data]);

  const handleCancel = () => setIsModalOpen(false);

  return (
    <>
      <Button
        variant="primary"
        size="medium"
        onClick={() => setIsModalOpen(true)}
        iconLeft={<Icon name="FilePlus" color="#fff" />}
        disabled={loading}
        loading={loading}
        fluid
        data-testid="select-report-button"
      >
        Select Report
      </Button>
      <S.Modal visible={isModalOpen} footer={null} width={680} onCancel={handleCancel}>
        <S.Header>
          <Heading variant="h3" textAlign="center" marginBottom="small">
            Select a Report to Submit
          </Heading>
          <Heading variant="h6" textColor="body" textAlign="center" marginBottom="large">
            You have {recentReports?.length ?? 0} Report{recentReports?.length !== 1 && 's'}{' '}
            generated within last week, select one to submit to{' '}
            {reportRequest.Business.name || reportRequest.Business.contactEmail}.
          </Heading>
        </S.Header>
        <S.Body>
          {recentReports && recentReports.length > 0 ? (
            recentReports.map((report) => (
              <ReportLog
                key={report.id}
                data={report}
                onClick={setSelectedReportId}
                isSelected={report.id === selectedReportId}
                hideActions
              />
            ))
          ) : (
            <S.EmptyStateWrapper>
              <Heading variant="h5" textColor="body" textAlign="center" marginBottom="large">
                No reports were created in the last week
              </Heading>
              <CreateReportButton currentTab={ReportType.Employer} />{' '}
            </S.EmptyStateWrapper>
          )}
        </S.Body>
        <S.Actions>
          <ViewReportButton
            reportId={selectedReportId ?? ''}
            disabled={!selectedReportId}
            variant="primary"
            size="medium"
            text="View Report"
          />
        </S.Actions>
      </S.Modal>
    </>
  );
};

export default SelectReportButton;
