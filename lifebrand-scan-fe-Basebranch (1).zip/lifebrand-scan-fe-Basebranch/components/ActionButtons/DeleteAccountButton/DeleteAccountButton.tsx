import React, { useCallback, useEffect, useState } from 'react';
import config from 'config';

import { Button, message, Heading } from '@UI/meeseeks';
import Modal from '@UI/Modal';

import { useDeleteIndividualUserMutation, useHasScanRunningQuery } from '@Generated/graphql';

import { useConnections } from '@Utils/hooks/useConnections';

import * as S from './DeleteAccountButton.styles';

const POLL_INTERVAL = 5 * 1000;

type Props = {
  reasons: string[];
  isMobile?: boolean;
};

const DeleteAccountButton = ({ reasons, isMobile }: Props) => {
  const { actions } = useConnections();
  const { data, loading, startPolling, stopPolling } = useHasScanRunningQuery();
  const [deleteUser, { loading: deleting }] = useDeleteIndividualUserMutation();

  // todo fix eslint
  // eslint-disable-next-line consistent-return
  useEffect(() => {
    if (data?.hasScanRunning) {
      startPolling(POLL_INTERVAL);
      return stopPolling;
    }
  }, [data?.hasScanRunning]);

  const [isVisible, setIsVisible] = useState(false);

  const handleOpen = useCallback(() => {
    setIsVisible(true);
  }, []);

  const handleClose = useCallback(() => {
    setIsVisible(false);
  }, []);

  const handleConfirm = useCallback(async () => {
    try {
      await deleteUser({ variables: { reasons } });
      message.success({
        title: 'Your account was successfully deleted.',
      });

      actions.individualLogout(config.SITE_URL);
    } catch {
      message.error({
        title: 'Failed to delete your account. Please try again.',
      });
      handleClose();
    }
  }, [reasons]);

  return (
    <>
      <Button
        variant="primary"
        onClick={handleOpen}
        disabled={loading || data?.hasScanRunning || reasons.length < 1}
        fluid={isMobile}
        size={isMobile ? 'large' : 'medium'}
      >
        Submit And Delete Account
      </Button>
      <Modal visible={isVisible} onCancel={handleClose} footer={null} width={630}>
        <S.Header>
          <Heading variant="h3" marginBottom="small">
            Permanently Delete Account
          </Heading>
          <Heading variant="h6" textColor="body" marginBottom="large">
            Are you sure? Once you confirm, all of your data will be permanently deleted.
          </Heading>
        </S.Header>
        <S.ImageContainer>
          <S.Image src="/images/png/delete-account.png" alt="delete account" />
        </S.ImageContainer>
        <S.Actions>
          <Button variant="tertiary" size="medium" onClick={handleClose} disabled={deleting}>
            Cancel
          </Button>
          <Button
            variant="danger"
            size="medium"
            onClick={handleConfirm}
            loading={deleting}
            disabled={loading || data?.hasScanRunning || deleting}
          >
            Delete
          </Button>
        </S.Actions>
      </Modal>
    </>
  );
};

export default DeleteAccountButton;
