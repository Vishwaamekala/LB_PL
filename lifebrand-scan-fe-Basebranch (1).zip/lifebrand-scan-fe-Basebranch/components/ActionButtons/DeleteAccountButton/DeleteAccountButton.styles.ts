import styled from 'styled-components';

export const Header = styled.div`
  max-width: 460px;
  margin: 0px auto;
  text-align: center;
`;

export const ImageContainer = styled.div`
  display: flex;
  justify-content: center;
  background-color: ${({ theme }) => theme.meeseeks.color['neutrals.100']};
  border-radius: 2px;
  padding: ${({ theme }) => theme.spacing.medium}px;
`;

export const Image = styled.img`
  height: 260px;
`;

export const Actions = styled.div`
  display: flex;
  justify-content: flex-end;
  padding: ${({ theme }) => `${theme.spacing.small}px 0px 0px`};

  & > * + * {
    margin-left: ${({ theme }) => theme.spacing.medium}px;
  }
`;
