import React, { useCallback } from 'react';

import { Icon } from '@UI/meeseeks';

import { createLinkWithId, ROUTES } from '@Utils/helper/routes';

import * as S from './SharePhotobookButtons.styles';

type Props = {
  photobookId: string;
};

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL;

const SharePhotobookButtons = ({ photobookId }: Props) => {
  const photobookURL = `${SITE_URL}${createLinkWithId(ROUTES.PHOTOBOOK, photobookId).as}`; // REVIEW what is the real PDF URL

  // www.facebook.com/sharer.php?u=[URL]
  const handleShareOnFB = useCallback(() => {
    window.open(
      `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
        photobookURL,
      )}&quote=${encodeURIComponent("I've created my PhotoBook full of memories, check it out!")}`,
    );
  }, [photobookURL]);

  // www.twitter.com/intent/tweet?text=[MESSAGE]&url=[URL]
  const handleShareOnTW = useCallback(() => {
    window.open(
      `https://twitter.com/intent/tweet?text=${encodeURIComponent(
        "I've created my PhotoBook full of memories, check it out!",
      )}&url=${encodeURIComponent(photobookURL)}`,
    );
  }, [photobookURL]);

  return (
    <S.Wrapper>
      <S.SharingButton onClick={handleShareOnFB}>
        <Icon name="FacebookFilled" color="#333333" size={24} />
      </S.SharingButton>
      <S.SharingButton onClick={handleShareOnTW}>
        <Icon name="TwitterFilled" color="#333333" size={24} />
      </S.SharingButton>
    </S.Wrapper>
  );
};

export default SharePhotobookButtons;
