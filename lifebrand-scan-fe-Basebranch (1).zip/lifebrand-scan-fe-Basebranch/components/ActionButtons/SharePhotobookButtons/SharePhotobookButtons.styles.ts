import styled from 'styled-components';

export const Wrapper = styled.div`
  display: flex;
  justify-content: space-around;
  align-items: center;
  flex-direction: column;
  background-color: white;
  width: 48px;
  height: 92px;
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
`;

export const SharingButton = styled.div`
  display: flex;
  cursor: pointer;
  align-items: center;
`;
