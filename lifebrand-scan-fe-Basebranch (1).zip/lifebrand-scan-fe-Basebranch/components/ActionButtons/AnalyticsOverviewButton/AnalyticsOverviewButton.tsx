import React from 'react';
import { useRouter } from 'next/router';

import { Button, Icon, ButtonProps } from '@UI/meeseeks';

import { ROUTES } from '@Utils/helper/routes';
// import { FeatureFlag, useFeatureFlags } from '@Utils/hooks/useFeatureFlags';

const AnalyticsOverviewButton = (props: Partial<ButtonProps>) => {
  const router = useRouter();

  // const {
  //   isEnabled: ENABLED_FEAT_VERSION_BUTTON_B2C,
  //   payload: PAYLOAD_FEAT_VERSION_BUTTON_B2C,
  // } = useFeatureFlags(FeatureFlag.FEAT_VERSION_BUTTON_B2C);

  // if (ENABLED_FEAT_VERSION_BUTTON_B2C) {
  //   if (PAYLOAD_FEAT_VERSION_BUTTON_B2C.version) {
  //     return (
  //       <Button
  //         size="medium"
  //         variant="primary"
  //         onClick={() => router.push(ROUTES.ANALYTICS_OVERVIEW)}
  //         iconLeft={<Icon name="PieChart" color="#fff" />}
  //         version={PAYLOAD_FEAT_VERSION_BUTTON_B2C.version}
  //         {...props}
  //       >
  //         Analytics Overview
  //       </Button>
  //     );
  //   }
  // }

  return (
    <Button
      size="medium"
      variant="primary"
      onClick={() => router.push(ROUTES.ANALYTICS_OVERVIEW)}
      iconLeft={<Icon name="PieChart" color="#fff" />}
      {...props}
    >
      Analytics Overview
    </Button>
  );
};

export default AnalyticsOverviewButton;
