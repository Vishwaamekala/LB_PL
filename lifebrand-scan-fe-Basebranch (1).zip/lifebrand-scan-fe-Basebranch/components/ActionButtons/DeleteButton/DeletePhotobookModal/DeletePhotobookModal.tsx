import React from 'react';

import ConfirmPostDeleteModal from 'components/ActionButtons/DeleteContentButton/ConfirmPostDeleteModal';

type Props = {
  isVisible: boolean;
  onClose: () => void;
  onConfirm: () => void;
};

const DeletePhotobookModal = ({ isVisible, onClose, onConfirm }: Props) => (
  <ConfirmPostDeleteModal
    provider="Photobook"
    isVisible={isVisible}
    onClose={onClose}
    onConfirm={onConfirm}
  />
);

export default DeletePhotobookModal;
