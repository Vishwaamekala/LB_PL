export { default } from './DeletePhotobookModal';
export * from './DeletePhotobookModal';
