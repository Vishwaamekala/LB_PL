import styled from 'styled-components';

import { Button } from '@UI/meeseeks';

export const CenteredButton = styled(Button)`
  display: flex;
  justify-content: center;
`;
