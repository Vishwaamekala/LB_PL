import React, { useCallback } from 'react';

import { Icon } from '@UI/meeseeks';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import * as S from './PrintPhotobookButton.styles';

type Props = {
  disabled: boolean;
  pdfUrl: string;
};

const PrintPhotobookButton = ({ disabled, pdfUrl }: Props) => {
  const { isMobile } = useBreakpoints();

  const handlePrint = useCallback(() => {
    // Review which URL is the correct one
    window.open(pdfUrl);
  }, [pdfUrl]);

  return (
    <S.CenteredButton
      size="medium"
      variant="primary"
      onClick={handlePrint}
      iconLeft={<Icon name="Printer" color="#fff" />}
      fluid={isMobile}
      disabled={disabled}
    >
      Print Your Photobook
    </S.CenteredButton>
  );
};

export default PrintPhotobookButton;
