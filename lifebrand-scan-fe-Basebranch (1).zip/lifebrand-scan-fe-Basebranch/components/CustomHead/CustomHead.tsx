import React from 'react';
import { Router } from 'next/router';
import Head from 'next/head';

import { getMetaInfo } from './utils';

import { WhiteLabelPartner } from '@WhiteLabel';

interface Props {
  partner?: WhiteLabelPartner;
  router: Router;
}

// Whitelabel dynamic headings
const CustomHead = ({ partner, router }: Props) => {
  const { name, logo, url, title, metaDescription } = getMetaInfo(router, partner);
  return (
    <Head>
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
      <link
        href={
          'https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Poppins:wght@400;500;600;700&display=swap'
        }
        rel="stylesheet"
      />
      <title>{`${name} - ${title}`}</title>
      <meta name="description" content={metaDescription} />
      <meta property="og:image" content={logo} />
      <meta property="og:site_name" content={name} />
      <meta property="og:url" content={url} />
      <meta name="twitter:title" content={name} />
    </Head>
  );
};

export default CustomHead;
