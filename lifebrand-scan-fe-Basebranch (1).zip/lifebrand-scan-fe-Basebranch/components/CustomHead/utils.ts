import { Router } from 'next/router';

import { WhiteLabelPartner } from '@WhiteLabel';
import { ROUTES } from '@Utils/helper/routes';

type META = {
  title: string;
  metaDescription: string;
};

const DEFAULT_META: META = {
  title: 'Social Media Scanning',
  metaDescription: 'Make sure your your Social Medias and your reputation are clean.',
};

export const META_DATA: {
  [key: string]: META;
} = {
  [ROUTES.INDEX]: {
    title: 'Welcome',
    metaDescription:
      'Clean your Social Media by detecting and deleting potentially harmful posts with the help of our AI technology',
  },
  [ROUTES.ERROR]: {
    title: 'Server Error',
    metaDescription: 'This is the error page.This page appears when the server has problems',
  },
  [ROUTES[404]]: {
    title: 'Not Found',
    metaDescription: 'This is the error page.This page appears when the route cannot be found.',
  },
  [ROUTES[403]]: {
    title: 'No Access',
    metaDescription: 'This is the error page.This page appears when there is missing access',
  },
  [ROUTES.AUTH_CALLBACK]: {
    title: 'Authentication resolver',
    metaDescription: 'Authentication resolver page.',
  },
  [ROUTES.DASHBOARD]: {
    title: 'Dashboard',
    metaDescription: 'Make sure your your Social Medias and your reputation are clean.',
  },
  [ROUTES.REPORT]: {
    title: 'Report',
    metaDescription: 'Make sure your your Social Medias and your reputation are clean.',
  },
  [ROUTES.PLANS]: {
    title: 'Plans',
    metaDescription: 'Make sure your your Social Medias and your reputation are clean.',
  },
  [ROUTES.PAYMENT]: {
    title: 'Payment',
    metaDescription: 'Make sure your your Social Medias and your reputation are clean.',
  },
  [ROUTES.SUBSCRIPTION_PAYMENTS]: {
    title: 'Subscription/Payments',
    metaDescription: 'Make sure your your Social Medias and your reputation are clean.',
  },
  [ROUTES.PUBLIC_REPORT]: {
    title: 'Shared Report',
    metaDescription: 'Make sure your your Social Media and your reputation are clean.',
  },
} as const;

const extractMeta = (key: string): META => {
  return META_DATA[key] ?? DEFAULT_META;
};

interface MetaInfo {
  name: string;
  logo: string;
  url: string;
  title: string;
  metaDescription: string;
}

type GetMetaInfo = (router: Router, partner?: WhiteLabelPartner) => MetaInfo;

export const getMetaInfo: GetMetaInfo = (router, partner) => {
  const meta = extractMeta(router.pathname);
  if (!partner) {
    return {
      name: 'LifeBrand',
      logo: '/images/png/lifebrand-logo.png',
      url: 'https://cleanbrand.lifebrand.life',
      ...meta,
    };
  }

  return {
    name: partner.name,
    logo: partner?.branding!.logo,
    url: `https://${partner!.domain}.lifebrand.life/`,
    ...meta,
  };
};
