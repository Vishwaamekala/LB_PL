import React, { ReactNode } from 'react';
import { useRouter } from 'next/router';

import { message, Button, ButtonProps, Icon } from '@UI/meeseeks';

import { useSubscriptionContext } from '@Utils/SubscriptionContext/useSubscriptionContext';
import { useConnections } from '@Utils/hooks/useConnections';
import { ROUTES } from '@Utils/helper/routes';
import { TriggerClass } from '@Utils/google-tag-manager';

import {
  useRunScanMutation,
  ScanType,
  LastScanDocument,
  LastScanQuery,
  IndividualFeatureAccessDocument,
} from '@Generated/graphql';

type ScanButtonProps = {
  sizeIcon?: number;
  title?: string;
  customIcon?: ReactNode;
  className?: string;
  triggerClassName?: string;
  scanType?: ScanType;
  disabled?: boolean;
  onBoardingId?: string;
} & Omit<ButtonProps, 'children'>;

const ScanButton = ({
  sizeIcon,
  title = 'Scan',
  customIcon,
  className,
  triggerClassName = TriggerClass.RunScanNew,
  scanType = ScanType.SyncUp,
  disabled,
  onBoardingId,
  ...rest
}: ScanButtonProps) => {
  const router = useRouter();

  const { isAnySocialMediaConnected, socialMediaConnection } = useConnections();
  const { features } = useSubscriptionContext();

  const [runScan, { loading }] = useRunScanMutation();

  const isDisabled = !features?.canScan || !isAnySocialMediaConnected || loading || disabled;

  const connectedOrigins = socialMediaConnection
    .filter((connection) => connection.isConnected && !connection.isExpired)
    .map((connected) => connected.socialMedia);

  const handleClick = () =>
    runScan({
      variables: {
        origins: connectedOrigins,
        type: scanType,
      },
      refetchQueries: [{ query: IndividualFeatureAccessDocument }],
      update: async (cache, result) => {
        // `chache.writeQuery` makes more sense, but it breaks polling
        // See: https://github.com/apollographql/apollo-client/issues/7115
        cache.modify({
          fields: {
            hasScanRunning() {
              return true;
            },
          },
        });

        cache.writeQuery<LastScanQuery>({
          query: LastScanDocument,
          data: {
            lastScan: result.data?.runScan,
          },
        });
      },
    })
      .then(() => {
        router.push(ROUTES.DASHBOARD);
      })
      .catch((error) => {
        message.error({
          title: `Failed to start a scan. ${error.message}.`,
        });
      });

  return (
    <Button
      id={onBoardingId}
      className={`${triggerClassName} ${className}`}
      onClick={handleClick}
      disabled={isDisabled || loading}
      loading={loading}
      iconLeft={customIcon || <Icon name="RefreshCw" size={sizeIcon} color="white" />}
      {...rest}
    >
      {title}
    </Button>
  );
};

export default ScanButton;
