import styled from 'styled-components';

export const Button = styled.div<{ id: string }>`
  margin-bottom: ${({ theme, id }) => id && theme.spacing.medium}px;
`;
