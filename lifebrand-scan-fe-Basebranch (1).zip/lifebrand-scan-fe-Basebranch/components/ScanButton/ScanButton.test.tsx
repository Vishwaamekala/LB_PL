import React from 'react';
import { GraphQLError } from 'graphql';
import { render, fireEvent, waitFor, cleanup } from '@testing-library/react';

import { useRouter } from 'next/router';
import { theme } from 'theme/theme';
import { ThemeProvider } from 'styled-components';
import { MockedProvider, MockedResponse } from '@apollo/client/testing';

import { InMemoryCache } from '@apollo/client';

import ScanButton from './ScanButton';

import {
  ScanType,
  RunScanDocument,
  IndividualFeatureAccessDocument,
  HasScanRunningDocument,
  SocialMedia,
} from '@Generated/graphql';

jest.mock('next/router', () => ({
  useRouter: jest.fn().mockReturnValue({
    route: '/',
    pathname: '',
    query: '',
    asPath: '',
    push: jest.fn(),
  }),
}));

jest.mock('@Utils/SubscriptionContext/useSubscriptionContext');

const Subscription = require('@Utils/SubscriptionContext/useSubscriptionContext');

jest.mock('@Utils/hooks/useConnections', () => ({
  ...jest.requireActual('@Utils/hooks/useConnections'),
  useConnections() {
    return {
      ...jest.requireActual('@Utils/hooks/useConnections'),
      isActionsDisabled: false,
      isAnySocialMediaConnected: true,
      isAuthenticated: true,
      socialMediaConnection: [
        {
          isConnected: true,
          isMainIdentity: false,
          socialMedia: 'Facebook',
          userName: 'test',
        },
      ],
    };
  },
}));

const ScanId = 'ckzmnlmj124020js6nr70g5mn';

const mocks: ReadonlyArray<MockedResponse> = [
  {
    request: {
      query: RunScanDocument,
      variables: { origins: [SocialMedia.Facebook], type: ScanType.SyncUp },
    },
    result: {
      data: {
        runScan: {
          id: ScanId,
          type: ScanType.SyncUp,
          status: 'New',
          startedAt: '2022-02-14T12:09:19.691Z',
          createdAt: '2022-02-14T12:09:19.691Z',
          updatedAt: '2022-02-14T12:09:19.691Z',
          duration: null,
          __typename: 'Scan',
        },
      },
    },
  },
  {
    request: {
      query: IndividualFeatureAccessDocument,
      variables: {},
    },
    result: {
      data: {
        individualFeatureAccess: {
          features: {
            canAccessAnalytics: true,
            canUseAdvancedDashboard: true,
            canUpgrade: true,
            canScan: true,
            __typename: 'IndividualFeatureAccess',
          },
          plan: {
            name: 'Free',
            currentPeriodEnds: null,
            isCancelled: false,
            isCancellable: false,
          },
        },
      },
    },
  },
  {
    request: {
      query: HasScanRunningDocument,
      variables: {},
    },
    result: {
      data: {
        hasScanRunning: true,
      },
    },
  },
];

describe('ScanButton', () => {
  afterEach(cleanup);

  describe('canUseAdvancedDashboard - true', () => {
    Subscription.useSubscriptionContext.mockImplementation(() => {
      return {
        features: {
          canAccessAnalytics: true,
          canScan: true,
          canUpgrade: false,
          canUseAdvancedDashboard: true,
          __typename: 'IndividualFeatureAccess',
        },
        loading: false,
        plan: {
          currentPeriodEnds: null,
          isCancelled: false,
          isCancellable: false,
          name: 'Free',
        },
      };
    });

    it('click on button', async () => {
      const handleClick = jest.fn();

      const { getByText } = render(
        <ThemeProvider theme={theme}>
          <MockedProvider addTypename>
            <ScanButton variant="primary" size="medium" onClick={handleClick} />
          </MockedProvider>
        </ThemeProvider>,
      );
      const btn = getByText('Scan');
      expect(btn).toBeInTheDocument();

      fireEvent.click(btn);

      expect(handleClick).toBeCalledTimes(1);
    });

    it('loading after click', async () => {
      const { getByRole } = render(
        <ThemeProvider theme={theme}>
          <MockedProvider addTypename>
            <ScanButton variant="primary" size="medium" />
          </MockedProvider>
        </ThemeProvider>,
      );
      const btn = getByRole('button', { name: 'Scan' });
      expect(btn).toBeInTheDocument();

      fireEvent.click(btn);

      await waitFor(() => {
        expect(btn).toBeDisabled();
      });
    });

    it('error on run scan', async () => {
      const [runScanMock, ...otherMocks] = mocks;
      const { getByText, getByRole } = render(
        <ThemeProvider theme={theme}>
          <MockedProvider
            mocks={[
              {
                request: runScanMock.request,
                result: {
                  errors: [new GraphQLError('Some backend error')],
                },
              },
              ...otherMocks,
            ]}
            addTypename
          >
            <ScanButton variant="primary" size="medium" />
          </MockedProvider>
        </ThemeProvider>,
      );
      const btn = getByRole('button', { name: 'Scan' });
      expect(btn).toBeInTheDocument();

      fireEvent.click(btn);

      await waitFor(() => {
        expect(getByText('Failed to start a scan. Some backend error.')).toBeInTheDocument();
      });
    });

    it('loading appears on run scan', async () => {
      const { getByRole } = render(
        <ThemeProvider theme={theme}>
          <MockedProvider mocks={mocks} addTypename={false}>
            <ScanButton variant="primary" size="medium" />
          </MockedProvider>
        </ThemeProvider>,
      );
      const btn = getByRole('button', { name: 'Scan' });
      expect(btn).toBeInTheDocument();

      fireEvent.click(btn);

      expect(btn).toBeDisabled();
    });

    it('redirect to the dashboard after scan', async () => {
      const cache = new InMemoryCache({ addTypename: false });
      const { getByRole } = render(
        <ThemeProvider theme={theme}>
          <MockedProvider mocks={mocks} addTypename={false} cache={cache}>
            <ScanButton variant="primary" size="medium" />
          </MockedProvider>
        </ThemeProvider>,
      );

      const btn = getByRole('button', { name: 'Scan' });
      expect(btn).toBeInTheDocument();

      fireEvent.click(btn);

      await waitFor(() => {
        expect((useRouter as jest.Mock).mock.results[0].value.push).toBeCalledWith('/dashboard');
      });
    });

    it('check cache update after scan', async () => {
      const cache = new InMemoryCache({ addTypename: false });
      const { getByRole } = render(
        <ThemeProvider theme={theme}>
          <MockedProvider mocks={mocks} addTypename={false} cache={cache}>
            <ScanButton variant="primary" size="medium" />
          </MockedProvider>
        </ThemeProvider>,
      );

      const btn = getByRole('button', { name: 'Scan' });
      expect(btn).toBeInTheDocument();

      fireEvent.click(btn);

      await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

      const updatedCache = cache.extract();

      expect(updatedCache.ROOT_QUERY?.lastScan).toMatchObject({
        __ref: `Scan:${ScanId}`,
      });
    });
  });

  describe('canUseAdvancedDashboard - false', () => {
    it('disabled button', async () => {
      Subscription.useSubscriptionContext.mockImplementation(() => {
        return {
          features: {
            canAccessAnalytics: true,
            canScan: false,
            canUpgrade: false,
            canUseAdvancedDashboard: false,
            __typename: 'IndividualFeatureAccess',
          },
          loading: false,
          plan: {
            currentPeriodEnds: null,
            isCancelled: false,
            isCancellable: false,
            name: 'Free',
          },
        };
      });

      const { getByRole } = render(
        <ThemeProvider theme={theme}>
          <MockedProvider addTypename>
            <ScanButton variant="primary" size="medium" />
          </MockedProvider>
        </ThemeProvider>,
      );
      const btn = getByRole('button', { name: 'Scan' });
      expect(btn).toBeInTheDocument();
      expect(btn).toBeDisabled();
    });
  });
});
