import React from 'react';
import { Typography } from 'antd';

import { Heading, Text } from '@UI/meeseeks';

const TermsOfUse = () => {
  return (
    <>
      <Text variant="body" marginBottom="large" fontWeight={700}>
        Welcome to the LifeBrand website, operated by LifeBrand Inc. (“LifeBrand” “we,” or “our”)
        and located at{' '}
        <Typography.Link href="https://lifebrand.life/" target="_blank" rel="noopener noreferrer">
          https://lifebrand.life/
        </Typography.Link>
        . The Site is provided as a service to our customers. The following terms and conditions
        (“Terms”) govern your use of this Site.{' '}
      </Text>
      <Text variant="body" marginBottom="large">
        The Site may contain content, products, and other materials that some users may find
        objectionable.
      </Text>
      <Text variant="body" marginBottom="large">
        By accessing, viewing, or using the content, material, or services available on or through
        this Site, you indicate that you have read and understand these Terms and LifeBrand’s{' '}
        <Typography.Link
          href="https://lifebrand.life/privacy-policy"
          target="_blank"
          rel="noopener noreferrer"
        >
          Privacy Policy
        </Typography.Link>
        , that you agree to them, and intend to be legally bound by them.{' '}
      </Text>
      <Text variant="body" marginBottom="large">
        By creating an account or using our Services, you confirm that you accept these Terms. You
        also confirm that:
      </Text>
      <ol style={{ listStyleType: 'decimal' }}>
        <li>
          <Text variant="body" marginBottom="xs">
            You have reached the age of 18; or
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            You are 13 or older but younger than 18 (“Minor”), that you have reviewed these Terms
            with your parent or legal guardian before using the Services, and that you and your
            parent or guardian understand and consent to these Terms. If you are a parent or
            guardian of a Minor who is using the Services, you accept and agree to: (i) supervise
            the Minor&quot;s use of the Services; (ii) assume all risks associated with the Minor’s
            use of the Services, (iii) assume any liability resulting from the Minor’s use of the
            Services; (iv) ensure the accuracy and truthfulness of all information submitted by you
            or the Minor; and (v) assume responsibility and are bound by these Terms for the Minor’s
            access and use of the Services.
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="large">
            You may be prevented from creating an account or using our Services due to our children
            accessibility policy in accordance with the applicable laws and regulations in your
            jurisdiction.
          </Text>
        </li>
      </ol>
      <Text variant="body" marginBottom="large">
        We may sometimes need to change these Terms. We will let you know of any changes by posting
        the updated Terms on our{' '}
        <Typography.Link
          href="https://lifebrand.life/terms-of-use"
          target="_blank"
          rel="noopener noreferrer"
        >
          website
        </Typography.Link>
        . If we think the changes are material, we may send a notification to the email address
        linked to your LifeBrand account before the updated Terms become effective. If you do not
        agree to the changes, you may stop using our Services and delete your LifeBrand account. By
        continuing to use our Services after the updated Terms become effective, you confirm that
        you understand and accept the updated Terms.
      </Text>

      <Text variant="body" marginBottom="large">
        These Terms of Service constitute a binding legal agreement between you and LifeBrand,
        including the terms and conditions regarding dispute resolution, set forth on the Governing
        Law and Jurisdiction Section, below
      </Text>

      <Text variant="body" marginBottom="xxl">
        If you have any questions concerning these Terms or wish to exercise your rights as
        described below, please contact{' '}
      </Text>

      <Text variant="body" marginBottom="large" textColor="primary">
        158 W. Gay Street, Suite 300 West Chester, PA 19380
      </Text>
      <Text variant="body" marginBottom="large" textColor="primary">
        info@lifebrand.life
      </Text>
      <Text variant="body" marginBottom="large" textColor="primary">
        1-610-529-8662.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        Registration
      </Heading>
      <Text variant="body" marginBottom="xxs">
        You agree to use the Site and the Services only for purposes that are permitted by these
        Terms in compliance with all applicable laws, regulations, and generally accepted practices
        and guidelines in the relevant jurisdictions. You may only use the Site and Services as
        authorized in these Terms and for no other purposes.
        <br /> You agree not to use the Site:
      </Text>
      <ol style={{ listStyleType: 'lower-alpha' }}>
        <li>
          <Text variant="body" marginBottom="xs">
            In any way that violates any applicable federal, state, provincial/territorial, local,
            or international law or regulation (including, without limitation, any laws regarding
            the export of data or software);
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            To impersonate or attempt to impersonate LifeBrand, a LifeBrand employee, another user
            or any other person or entity (including, without limitation, by using e-mail addresses
            or screen or account names associated with any of the foregoing); and
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="large">
            To engage in any other conduct that restricts or inhibits anyone’s use or enjoyment of
            the Site, or which, as determined by us, may harm LifeBrand or users of the Site or
            expose them to liability, or that may violate these Terms.
          </Text>
        </li>
      </ol>

      <Text variant="body" marginBottom="xxs">
        Without limiting the foregoing, you additionally agree not to:
      </Text>
      <ol style={{ listStyleType: 'lower-alpha' }}>
        <li>
          <Text variant="body" marginBottom="xs">
            Use the Site in any manner that could disable, overburden, damage, or impair the Site or
            any LifeBrand systems, or interfere with any other party’s use of the Site, including
            their ability to engage in real time activities through the Site;
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            Use any bot, crawler, spider, scraper or other automatic device, process or means to
            access the Site or any information transferred through the Site, for any purpose,
            including monitoring, copying or transferring any of the content on the Site;
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            Use any manual process to monitor, copy or transfer any of the content on the Site or
            any information transferred through the Site, or for any other unauthorized purpose
            without our prior written consent;
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            Reproduce, duplicate, copy, sell, trade, or resell any aspect of the Site or the
            Services for any purpose, including commercial purposes;
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            Reproduce, duplicate, copy, sell, trade, or resell any products or services bearing any
            trademark, service mark, trade name, logo, or other signifier owned by LifeBrand in a
            way that is likely or intended to cause confusion about the owner or authorized user of
            materials;
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            Use any device, software or routine that interferes with the proper working of the Site;
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            You will not use our Services in any fraudulent or malicious way, for example to
            introduce viruses, malicious code, Trojan horses, worms, logic bombs, harmful data or
            other material which is malicious or technologically harmful;.
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            Attempt to gain unauthorized access to, interfere with, damage or disrupt any parts of
            the Site, including without limitation any information transferred through the Site, the
            server on which the Site is stored, or any server, computer or database connected to the
            Site;
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            Attack the Site via a denial-of-service attack or a distributed denial-of-service
            attack; or
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            Otherwise attempt to interfere with the proper working of the Site.
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            You will not reverse engineer, decompile, disassemble, or make any attempts to discover
            the source code or algorithms of our Services.
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            You will not modify or disable any features of our Services.
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            You will not create any derivative works based on our Services.
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            You will not rent, lease, lend, sub-license, or provide any commercial hosting services
            using our Services.
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            You will not use our Services in any way that violates these Terms or any laws, rules,
            regulations, codes of practices, guidelines, or any other requirements of regulatory
            authorities, as amended from time to time, within the jurisdiction in which you are a
            resident or from which you are using the Services (“Applicable Law”).
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            You will not use our Services in any fraudulent or malicious way, for example to
            introduce viruses, malicious code, or harmful data.
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            You will not use our Services in any way that could damage, disable, overburden, impair,
            or compromise our systems or security, or interfere with other users of our Services.
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="xs">
            You will not collect or harvest any information or data from our Services or systems or
            attempt to decipher any transmissions to or from the servers running our Services,
            except to the extent allowed by Applicable Law.
          </Text>
        </li>
      </ol>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        Intellectual Property
      </Heading>
      <Text variant="body" marginBottom="large">
        As between you and LifeBrand, LifeBrand owns all patent, copyright, trademark, trade secret,
        ideas, concepts, know-how, documentation or techniques or other intellectual property rights
        that may exist in (i) the Services, the Site, any graphics, texts, icons, buttons, data or
        information we include in the Site, and any products, training materials, deliverables, and
        the LifeBrand network or databases that may be utilized to provide the services (“Site
        Content”), and (ii) any information, data, trends, analysis, metadata or other data which
        may be derived from any of the foregoing that is derived or created by LifeBrand by
        reference to the Services and LifeBrand’s databases and network. All Site Content is
        protected pursuant to copyright, trademark, patent, and other applicable laws. You shall not
        remove or alter any copyright notice or any other proprietary notice on the Site or on any
        Site Content. All names, trademarks, symbols, slogans, or logos appearing on the Site are
        proprietary to LifeBrand or its licensors or suppliers. Use or misuse of these trademarks is
        expressly prohibited and may violate federal and state trademark law. Under no circumstances
        will you have any rights of any kind in or to the Site Content, other than the right to use
        the Site Content in accordance with these Terms.
      </Text>
      <Text variant="body" marginBottom="large">
        Certain features of the Site may allow you to contribute text, images, data, and other
        information and materials to the Site for access, use, viewing, and commentary by other
        users of the Site, and/or LifeBrand (collectively, “User Content”). By posting User Content
        to the Site or otherwise submitting User Content to LifeBrand, you represent that you have
        the full legal right to provide the User Content and that use of the User Content by
        LifeBrand and all other persons and entities, on the Site, and/or in accordance with this
        section, will not:
      </Text>
      <Text variant="body" marginBottom="xs">
        <strong>(a)</strong> infringe any intellectual property rights of any person or entity or
        any rights of publicity, personality, or privacy of any person or entity, including as a
        result of your failure to obtain consent to post personally identifying or otherwise private
        information about a person;
      </Text>
      <Text variant="body" marginBottom="xs">
        <strong>(b)</strong> violate any law, statute, ordinance, regulation, or agreement, or
        promote or provide instructional information about illegal activities, promote physical
        harm, or injury against any group or individual, or promote any act of cruelty to animals,
        including instructions on how to assemble bombs, grenades, and other weapons or how to use
        or obtain illegal drugs;
      </Text>
      <Text variant="body" marginBottom="xs">
        <strong>(c)</strong> be defamatory, libelous or trade libelous, unlawfully threatening, or
        unlawfully harassing, or promote discrimination based on race, sex, religion, nationality,
        disability, sexual orientation, or age;
      </Text>
      <Text variant="body" marginBottom="xs">
        affiliation with a person or entity, or include any falsified, composite, or otherwise
        non-authentic depictions of events, locations, landmarks, entities or persons;
      </Text>
      <Text variant="body" marginBottom="xs">
        <strong>(e)</strong> contain or otherwise transmit any material that contains software
        viruses or any other computer code, files or programs that may interrupt, destroy or limit
        the functionality of any computer software or hardware or telecommunications equipment;
      </Text>
      <Text variant="body" marginBottom="xs">
        <strong>(f)</strong> be obscene, child pornographic, or indecent;
      </Text>
      <Text variant="body" marginBottom="xs">
        <strong>(g)</strong> violate any community or Internet standard;
      </Text>
      <Text variant="body" marginBottom="xs">
        <strong>(h)</strong> constitute misappropriation of any trade secret or know-how; or
      </Text>
      <Text variant="body" marginBottom="xs">
        <strong>(i)</strong> constitute disclosure of any confidential information owned by any
        third party, all as determined by LifeBrand in our sole and absolute discretion. Upon your
        submission of User Content or other material or information to LifeBrand, you grant
        LifeBrand a worldwide, perpetual, irrevocable, transferable, license to access, use,
        distribute, reproduce, display, modify, translate, create derivative works based upon, and
        sublicense the User Content, all without any compensation to you whatsoever. Further, you
        waive all moral rights in and to all User Content that you post or otherwise submit to
        LifeBrand in favor of LifeBrand and any other persons we authorize to use such User Content.
        For avoidance of doubt, LifeBrand shall be under no obligation to:
      </Text>
      <Text variant="body" marginBottom="xxs">
        <strong>(1)</strong> maintain any User Content in confidence;
      </Text>
      <Text variant="body" marginBottom="xxs">
        <strong>(2)</strong> compensate you in any way for your User Content; or{' '}
      </Text>
      <Text variant="body" marginBottom="large">
        <strong>(3)</strong> respond to any User Content.
      </Text>
      <Text variant="body" marginBottom="large">
        You acknowledge that LifeBrand provides professional services for other parties and agree
        that nothing herein will be deemed or construed to prevent LifeBrand from carrying on such
        services, regardless of whether such parties are competitive with you. LifeBrand will have
        the right to use techniques, methodologies, tools, ideas and other know-how gained during
        the course of providing the Services and the Site in the furtherance of its own business and
        to perfect all other intellectual property rights related thereto, including patent,
        copyrights, trademark and trade secrets.
      </Text>
      <Text variant="body" marginBottom="large">
        No right, title or interest in or to the Site or any of the Site Content is transferred to
        you, and all rights not expressly granted herein are reserved by LifeBrand. Any use of the
        Site not expressly permitted by these Terms is a breach of these Terms and may violate
        patent, copyright, trademark and other laws.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        Privacy Policy
      </Heading>
      <Text variant="body" marginBottom="large">
        Your use of the Services is subject to LifeBrand’s Privacy Policy, located at:
        https://www.lifebrand.life/privacy-policy. We provide additional information about our
        privacy practices related to particular Services where appropriate. To the extent a Service
        has its own privacy notice, that privacy notice will also apply to your use of such Service.
        We recommend that you review the privacy notice of each Service for more information about
        our privacy practices.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        Monitoring and Enforcement; Termination
      </Heading>
      <Text variant="body" marginBottom="large">
        LifeBrand has the right to:
      </Text>
      <Text variant="body" marginBottom="large">
        <strong>(a)</strong> take appropriate legal action, including without limitation, referral
        to law enforcement, for any illegal or unauthorized use of the Site; and
      </Text>
      <Text variant="body" marginBottom="large">
        <strong>(b)</strong> terminate or suspend your access to all or part of the Site for any or
        no reason, including without limitation, any violation or suspected violation of these
        Terms. Without limiting the foregoing, LifeBrand has the right to fully cooperate with any
        law enforcement authorities or court order requesting or directing us to disclose the
        identity or other information of anyone providing information on or through the Site. You
        waive and will hold harmless LifeBrand and its affiliates, licensees and services providers,
        from any claims resulting from any action taken by LifeBrand or any of the foregoing parties
        during, or as a result of, its investigations, and from any actions taken as a consequence
        of investigations by such parties or law enforcement authorities.
      </Text>
      <Text variant="body" marginBottom="large">
        The limitations on LifeBrand’s liability to you in this Section 6 shall apply whether or not
        LifeBrand has been advised of or should have been aware of the possibility of any such
        losses arising.
      </Text>
      <Text variant="body" marginBottom="large">
        IF YOU ARE DISSATISFIED WITH THE SITE, THE SERVICES, OR THESE TERMS, YOUR SOLE AND EXCLUSIVE
        REMEDY IS TO DISCONTINUE USING THE SITE.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        Indemnity
      </Heading>
      <Text variant="body" marginBottom="large">
        You agree to defend, indemnify, and hold harmless LifeBrand, its parents, subsidiaries,
        officers, directors, shareholders, members, employees, agents, affiliates, licensors and
        suppliers, from and against all claims, damages, obligations, losses, liabilities, costs or
        debt, and expenses (including but not limited to attorneys’ fees) arising from:
      </Text>
      <Text variant="body" marginBottom="xxs">
        <strong>(a)</strong> your use of and access to the Site and Services;{' '}
      </Text>
      <Text variant="body" marginBottom="xxs">
        <strong>(b)</strong> your violation of any of these Terms, including the Privacy Policy;{' '}
      </Text>
      <Text variant="body" marginBottom="xxs">
        <strong>(c)</strong> your violation of any third party rights, including intellectual
        property or privacy rights; and{' '}
      </Text>
      <Text variant="body" marginBottom="large">
        <strong>(d)</strong> the use of the Site by any person using your account or account login.
      </Text>
      <Text variant="body" marginBottom="large">
        This defense and indemnification obligation will survive the termination or cessation of
        these Terms and your use of the Site. LifeBrand reserves the right, at LifeBrand’s own
        expense, to assume the exclusive defense and control of any matter otherwise subject to
        indemnification by you hereunder, and you shall cooperate in all reasonable respects in such
        defense. You may not settle any claim that is referenced or otherwise covered by this
        Section 7 without the prior written consent of LifeBrand.{' '}
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        Arbitration
      </Heading>
      <Text variant="body" marginBottom="large">
        You and LifeBrand agree that any disputes arising from or relating to these Terms or your
        use of the Site and/or the Services, including disputes arising from or concerning their
        interpretation, violation, invalidity, non-performance, or termination, which cannot be
        resolved informally, shall be submitted to final and binding arbitration before one (1)
        arbitrator; provided, however, in the event that the dispute involves an allegation of
        liability in excess of $250,000 USD, three (3) arbitrators shall be used. Any dispute
        arising out of these Terms shall be resolved exclusively through final and binding
        arbitration conducted by the American Arbitration Association (the “AAA”) pursuant to its
        Commercial Arbitration Rules. Arbitration uses a neutral arbitrator instead of a judge or
        jury, and court review of an arbitration award is very limited. However, an arbitrator can
        award the same damages and relief on an individual basis that a court can award to an
        individual; and an arbitrator must also follow and enforce these Terms, as a court would.
        All issues are for the arbitrator to decide, except that issues relating to arbitrability
        and the scope or enforceability of this agreement to arbitrate shall be for a court of
        competent jurisdiction to decide. Arbitration shall take place in Philadelphia,
        Pennsylvania, unless LifeBrand elects otherwise.
      </Text>
      <Text variant="body" marginBottom="large">
        The arbitrator will decide the substance of all claims in accordance with the laws of the
        Commonwealth of Pennsylvania. The arbitrator shall not be bound by rulings in prior
        arbitrations involving different LifeBrand users, but is bound by rulings in prior
        arbitrations involving the same LifeBrand user to the extent required by applicable law. The
        arbitrator’s award shall be final and binding, and judgment on the award rendered by the
        arbitrator may be entered in any court having jurisdiction thereof. This clause shall not
        preclude parties from seeking provisional remedies in aid of arbitration from a court of
        appropriate jurisdiction.{' '}
      </Text>
      <Text variant="body" marginBottom="large">
        You acknowledge and agree that you and LifeBrand are each waiving the right to a trial by
        jury. You further acknowledge and agree that you waive your right to participate as a
        plaintiff or class member in any purported class action or representative proceeding.
        Further, unless both you and LifeBrand otherwise agree in writing, the arbitrator may not
        consolidate more than one person’s claims, and may not otherwise preside over any form of
        any class or representative proceeding.
      </Text>
      <Text variant="body" marginBottom="large">
        In the event this Section 8 is held unenforceable, then the entirety of this Section 8 will
        be deemed void. Except as provided in the preceding sentence, this Section 8 will survive
        termination of the Terms and your use of the Site.
      </Text>
      <Text variant="body" marginBottom="large">
        Notwithstanding the foregoing, each party retains the right to seek injunctive or other
        equitable relief in a court of competent jurisdiction to prevent the actual or threatened
        infringement, misappropriation or violation of a party’s copyrights, trademarks, trade
        secrets, patents or other intellectual property rights.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        Governing Law and Jurisdiction
      </Heading>
      <Text variant="body" marginBottom="large">
        All matters relating to the Site, the Services, and these Terms and any dispute or claim
        arising therefrom or related thereto (in each case, including non-contractual disputes or
        claims), shall be governed by and construed in accordance with the internal laws of the
        Commonwealth of Pennsylvania without giving effect to its choice or conflict of law
        provisions or rules.{' '}
      </Text>
      <Text variant="body" marginBottom="large">
        Subject to the arbitration requirements set forth herein, to the extent that any legal suit,
        action or proceeding arises out of, or relates to, these Terms, the Privacy Policy, the
        Site, or the Services, such suit shall be instituted exclusively in the U.S. District Court
        for the Eastern District of Pennsylvania or the Court of Common Pleas of Montgomery County,
        Pennsylvania. You waive any objection to the exercise of jurisdiction over you by such
        courts and to venue in such courts.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        Operation of the Site and United States Law
      </Heading>
      <Text variant="body" marginBottom="large">
        The Site is controlled and operated from within the United States. Without limiting anything
        else, LifeBrand makes no representation that the Site, Site Content, User Content, services,
        products, information, or other materials available on, in, or through the Site is
        appropriate or available for use outside the United States, and access to them from
        territories where they are illegal is prohibited. Those who choose to access the Site from
        outside the United States do so on their own will and are responsible for compliance with
        applicable laws.
      </Text>
      <Text variant="body" marginBottom="large">
        The Site may only be used in compliance with applicable statutes or regulations relating to
        the export control laws and regulations of the United States, and any amendment thereof. The
        Site, the Site Content, and all underlying information and technology licensed hereunder
        shall not be accessed, downloaded, used, possessed, or otherwise exported or re-exported to
        (or to a national or resident of) any country outside of the United States without first
        complying strictly and fully with all export controls and other applicable laws that may be
        imposed by the United States Government or any country or organization of nations within
        whose jurisdiction you use the Site, the Site Content, or any underlying information or
        technology.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        Notice of Infringing Content
      </Heading>
      <Text variant="body" marginBottom="large">
        While we are under no legal obligation to actively screen or edit User Content, we reserve
        the right, in our sole and absolute discretion, to modify, edit or remove any User Content,
        or to request a user to modify or edit his or her User Content, if a complaint or notice of
        allegedly infringing materials is received with respect to the User Content, or for any
        other reason.{' '}
      </Text>
      <Text variant="body" marginBottom="large">
        To complain about User Content and/or to provide notice of allegedly infringing materials on
        the Site, please contact us using the contact information provided above.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        Miscellaneous
      </Heading>
      <Text variant="body" marginBottom="large">
        These Terms, including the Privacy Policy, constitute the entire legal agreement between you
        and LifeBrand regarding the Site and govern your use of the Site, Services, and any
        transactions you may have with LifeBrand through the Site. These Terms completely replace
        and supersede any prior agreement or understanding, arrangement, undertaking, or proposal,
        written or oral, between you and LifeBrand regarding these matters. In the event any other
        rule, code of conduct, or other matter posted on the Site conflicts with these Terms, these
        Terms shall govern. No oral explanation or oral information given by any party shall alter
        the interpretation of these Terms.
      </Text>
      <Text variant="body" marginBottom="large">
        You understand that LifeBrand may make changes to these Terms from time to time. Your
        continued use of the Site following the posting of changes to these Terms will be considered
        your consent to those changes. When these changes are made, LifeBrand will make a new copy
        of the Terms available on the Site. You agree that LifeBrand is under no obligation to
        provide you with notices regarding changes to these Terms. You understand that it is your
        responsibility to check the Terms regularly for changes.
      </Text>
      <Text variant="body" marginBottom="large">
        You agree that any failure or delay by LifeBrand to exercise or enforce any legal right or
        remedy contained in or made available by these Terms (or that LifeBrand has the benefit of
        under any applicable law) will not be taken to be a formal waiver of LifeBrand’s rights and
        that those rights or remedies will still be available to LifeBrand. If any court of law,
        having the jurisdiction to decide a matter arising out of these Terms, rules that any
        provision of these Terms is invalid, then that provision will be removed from these Terms
        without affecting the rest of the Terms and the remaining provisions will continue to be
        valid and enforceable.
      </Text>
      <Text variant="body" marginBottom="large">
        You hereby acknowledge and agree that we reserve the right at any time to modify or
        discontinue the whole, or any part of, the Site and the Services, without notice, and that
        we will not be responsible or liable, directly or indirectly, to you or any other person or
        entity for any loss or damage of any kind incurred as a result of any such modifications or
        discontinuance.
      </Text>
      <Text variant="body" marginBottom="large">
        These Terms are binding upon you, your heirs, executors, beneficiaries, successors and
        assigns and you may not assign these Terms to any other party without our prior written
        consent, which consent may be withheld in our sole and absolute discretion.
      </Text>
    </>
  );
};

export default TermsOfUse;
