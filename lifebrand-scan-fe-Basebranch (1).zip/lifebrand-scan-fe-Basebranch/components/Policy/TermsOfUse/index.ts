export { default } from './TermsOfUse';
export * from './TermsOfUse';
