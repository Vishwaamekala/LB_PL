export { default } from './PrivacyPolicy';
export * from './PrivacyPolicy';
