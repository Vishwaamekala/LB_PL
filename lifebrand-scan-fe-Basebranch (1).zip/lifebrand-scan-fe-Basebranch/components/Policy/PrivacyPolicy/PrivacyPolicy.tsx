import React from 'react';
import { Typography } from 'antd';

import { Heading, Text } from '@UI/meeseeks';

const PrivacyPolicy = () => {
  return (
    <>
      <Text variant="body" marginBottom="large">
        LifeBrand Inc., (“LifeBrand”, “we“, “us“, “our”), takes the security and privacy of your
        personal information very seriously.
      </Text>
      <Text variant="body" marginBottom="large">
        We want you to be familiar with how we collect, use, and disclose information relating to
        you, your computer, or your device and that enable your identification (the “Personal
        Information”). This Privacy Policy describes our practices with information that we collect
        through our websites, applications, and our network-connected products and services that
        link to this Privacy Policy (collectively, the “Platform”). This Privacy Policy only
        addresses information collected directly through or from the Platform – it does not address
        or govern any information-gathering, use, or dissemination practices related to information
        collected from you other than directly through or from the Platform, such as from telephone,
        facsimile, postal mail, personal delivery, or other or additional offline means or media. By
        accessing and using the Platform, you agree to the terms and conditions of this Privacy
        Policy.
      </Text>

      <Text variant="body" marginBottom="large">
        If you have any questions concerning this Privacy Policy, please contact LifeBrand by e-mail
        at <Typography.Link href="mailto: info@lifebrand.life">info@lifebrand.life</Typography.Link>
        .
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        1. Information We Collect
      </Heading>
      <ol style={{ listStyleType: 'lower-latin' }}>
        <li>
          <Heading variant="h5" marginBottom="large">
            Information You Provide
          </Heading>
          <Text variant="body" marginBottom="large">
            Some elements of the Platform will ask you to submit Personal Information in order for
            you to benefit from the specified features or to participate in a particular activity.
            For example, we may request Personal Information from you when you purchase products on
            the Platform, including your name, billing address, shipping address, payment
            information (including credit card number), email address, and phone number. You may
            also have the opportunity to submit other data and information about yourself and your
            surroundings, such as your present location, another location of interest, or
            information related to your social media presence. You will be informed what information
            is required to utilize these features of the Platform, and what information is optional.{' '}
          </Text>
          <Text variant="body" marginBottom="large">
            If you contact us, we will keep a record of that correspondence. You may also
            voluntarily provide information to us if you complete a survey or answer questions about
            your experience with the Platform.
          </Text>
          <Text variant="body" marginBottom="large">
            We may combine the information you submit through the Platform with other information we
            have collected from you, whether on- or offline. We may also combine it with information
            we receive about you from other sources, including publicly available information
            sources (such as publicly available social media profiles) as well as our service
            partners and data licensors, in compliance with applicable laws. We may inform you of
            other information collected by or through the Platform at the point of collection.{' '}
          </Text>
        </li>
        <li>
          <Heading variant="h5" marginBottom="large">
            Post Data
          </Heading>
          <Text variant="body" marginBottom="large">
            Our Platform allows users to scan historical posts associated with their social media
            platform accounts (“Posts”) to identify and remove potentially offensive posts. We
            collect data, including Personal Information, associated with Posts, such as the name or
            handle of the social media platform user that submitted the Post, the date of the post,
            any Personal Information contained within the Post itself, and information associated
            with your review and categorization of such posts, including whether you choose to
            delete them (“Post Data”).
          </Text>
        </li>
        <li>
          <Heading variant="h5" marginBottom="large">
            Passive Information Collection, Use, and Choices
          </Heading>
          <Text variant="body" marginBottom="large">
            As you navigate the Platform, certain Personal Information may be passively collected,
            meaning it is gathered without your actively providing it. We may collect and store such
            information automatically whenever you interact with the Platform. This is done using
            the following technologies in the following ways:
          </Text>
          <ol style={{ listStyleType: 'lower-roman' }}>
            <li>
              <Text variant="body" marginBottom="large">
                <strong>Through your browser: </strong>
                <br />
                Certain information is collected by most browsers, such as your Media Access Control
                (MAC) address, computer type and operating system type and version screen
                resolution, and Internet browser type and version.
              </Text>
            </li>
            <li>
              <Text variant="body" marginBottom="large">
                <strong>Through your device: </strong>
                <br />
                If you access the Platform through a mobile device or other network-connected
                product, certain information may be collected about that device, including your
                device type, network service provider, and other identifiers. We may collect unique
                device identifiers (such as IDFA and AID tags and UUID and UDID identifiers)
                associated with the device you use to access the Platform.
              </Text>
            </li>
            <li>
              <Text variant="body" marginBottom="large">
                <strong>Using cookies: </strong>
                <br />
                Cookies are pieces of information stored directly on the computer you are using.
                Cookies allow us to collect information such as browser type, time spent on the
                Platform, pages visited, and language preferences. We and our service providers use
                this information for security purposes, to facilitate navigation, display
                information more effectively, and to personalize your experience while using the
                Platform. More specifically, we use cookies to:{' '}
              </Text>
              <ul>
                <li>
                  <Text variant="body" marginBottom="xs">
                    recognize your computer or device to make your use of the Platform easier, such
                    as to remember your locations of interest and other preferences with the
                    Platform;{' '}
                  </Text>
                </li>
                <li>
                  <Text variant="body" marginBottom="xs">
                    gather statistical information about use of the Platform in order to continually
                    improve its design and functionality, understand how individuals use it, and to
                    assist us with resolving questions regarding it;
                  </Text>
                </li>
                <li>
                  <Text variant="body" marginBottom="xs">
                    select which of our advertisements or offers are most likely to appeal to you
                    and display them while you are on the Platform and on other websites,
                    applications, and online services that you use; and
                  </Text>
                </li>
                <li>
                  <Text variant="body" marginBottom="large">
                    track consumer responses to online advertisements. To learn more about cookies,
                    please visit{' '}
                    <Typography.Link
                      href="http://www.allaboutcookies.org"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      http://www.allaboutcookies.org
                    </Typography.Link>
                    .
                  </Text>
                </li>
              </ul>
            </li>
            <li>
              <Text variant="body" marginBottom="large">
                <strong>Using Monitoring Tools: </strong>
                <br />
                The Platform may utilize pixel tags, web beacons, clear GIFs, Flash Shared Objects,
                HTML5 Local Storage, HTML5 Mini Databases, and other similar technologies
                (collectively, “Pixel(s)”), both on certain aspects of the Platform and in
                HTML-formatted e-mail messages to you. These monitoring tools are used for the
                purpose of, among other things, measuring the success of our marketing campaigns,
                compiling statistics about Platform usage and response rates, and tracking the
                activities of users of the Platform and e-mail recipients.
              </Text>
            </li>
            <li>
              <Text variant="body" marginBottom="large">
                <strong>IP Address: </strong>
                <br />
                Your IP Address is a number that is automatically assigned to the computer that you
                are using by your Internet Service Provider. An IP Address is identified and logged
                automatically in our server log files whenever a user visits the Platform, along
                with the time of the visit and the page(s) that were visited. Collecting IP
                Addresses is standard practice on the Internet and is done automatically by many
                online service providers, including website operators. We use IP Addresses for
                purposes such as calculating Platform usage levels, helping diagnose server
                problems, and administering the Platform.
              </Text>
            </li>
            <li>
              <Text variant="body" marginBottom="large">
                <strong>Analytic Tools: </strong>
                <br />
                We also use tools and third-party services to collect information about usage of the
                Platform, including Google Analytics. You can learn more about Google Analytics, and
                its privacy practices, at the {''}
                <Typography.Link
                  href="https://developers.google.com/analytics/help"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Google Analytics Help Page
                </Typography.Link>
                . Generally speaking, Google Analytics collects information on how often users visit
                the Platform, what aspects of the Platform they visit when they do so, and what
                other websites users visited prior to accessing the Platform. The Platform makes use
                of Google Analytics services for Demographics and Interest Reporting as well as
                Display Advertising features, including Remarketing, Google Display Network
                Impression Reporting, and DoubleClick Campaign Manager integration. You may opt out
                of Google Analytics for Display Advertising or customize Google Display Network ads
                through the{' '}
                <Typography.Link
                  href="https://adssettings.google.com/authenticated"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Google Ads Settings page
                </Typography.Link>
                . You may also prevent your data from being collected and used by Google Analytics
                by opting out through the use of the{' '}
                <Typography.Link
                  href="https://tools.google.com/dlpage/gaoptout"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Google Analytics Opt-out Browser Add-on
                </Typography.Link>
                .
              </Text>
            </li>
            <li>
              <Text variant="body" marginBottom="large">
                <strong>Location-Based Features: </strong>
                <br />
                We may use information about your location to conduct analytics, to improve the
                Platform, and to provide certain location-based features and services, as further
                described in this Privacy Policy and as otherwise described to you at the point of
                collection. To provide these location-based features, in addition to the information
                about your location that you voluntarily submit through the Platform, we may also
                access information about your location using automated means. We generally will
                collect information about your latitude, longitude, and the date and time when you
                accessed the Platform. We may disclose location information as described in Section
                2(a) of this Policy. Some services on the Platform may continuously track your
                location information to allow our third-party advertising partners to deliver
                advertisements that are relevant to your current location. Depending on how you
                access the Platform, your web browser or your mobile device operating system may
                inform you that the Platform would like to collect your location and request
                permission to do so. If you allow such access, the Platform will collect your
                location information. If you decline, you will need to manually enter your location
                information to utilize certain features of the Platform.
              </Text>
            </li>
          </ol>
          <Text variant="body" marginBottom="large">
            If you are uncomfortable with the idea of your Personal Information being collected and
            used in these ways, most computer systems, devices, and web browsers offer privacy
            settings and options, such as disabling cookies, resetting your IDFA, and turning off
            location-based services. See Section 2(d) below for more information on opting out of
            Interest-Based Advertising. We do not override these settings or options and encourage
            you to use them to enhance your choices and personalize your experiences. However, in
            order to access certain content, features, services, products, or benefits of the
            Platform, you may be required to provide us with certain information. If you do not wish
            to provide that information through the Platform or if you opt to utilize the
            aforementioned privacy features, you may be unable to obtain certain content, features,
            services, products, or benefits of the Platform. Changing these settings will not
            prevent you from seeing advertisements and offers, but those advertisements and offers
            may not be tailored to your interests and needs.{' '}
          </Text>
        </li>
        <li>
          <Heading variant="h5" marginBottom="large">
            Social Media and Other Third-Party Platforms
          </Heading>
          <Text variant="body" marginBottom="large">
            You may engage with our content, such as video, applications, and other offerings, on or
            through social media services or other third-party platforms, such as Facebook, Twitter,
            and Pinterest. When you engage with our content on or through social media services or
            other third-party platforms, plug-ins, integrations, or applications, we may have access
            to, and store, certain information in your profile with that service or platform. This
            may include your name, e-mail address, photo, gender, birthday, location, an ID
            associated with the applicable third-party platform or social media account user files,
            photos and videos, your list of friends or connections, people you follow and who
            follows you, and your posts and “likes“. For a description on how such social media
            services and other third-party platforms, plug-ins, integrations, and applications
            handle your information, please refer to their respective privacy policies and terms of
            use, which may permit you to modify your privacy settings with that service or platform.
          </Text>
        </li>
      </ol>
      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        2. How We Use And Disclose Information
      </Heading>
      <ol style={{ listStyleType: 'lower-latin' }}>
        <li>
          <Heading variant="h5" marginBottom="large">
            Overview of Use and Disclosure
          </Heading>
          <Text variant="body" marginBottom="large">
            We use and retain Personal Information, including Post Data, for the purposes described
            in this Privacy Policy and as otherwise described to you at the point of collection.
            Except as otherwise provided herein, we do not sell, trade, or rent your personal
            information to others. Specifically, we may use Personal Information from or about you:
          </Text>
          <Text variant="body" marginBottom="large">
            <strong>i.</strong> to provide the requested services and process transactions with you;
          </Text>
          <Text variant="body" marginBottom="large">
            <strong>ii.</strong> to communicate with you and respond to your inquiries;
          </Text>

          <Text variant="body" marginBottom="large">
            <strong>iii.</strong> to customize the content or services on the Platform for you and
            to present products and offers tailored to you;
          </Text>

          <Text variant="body" marginBottom="large">
            <strong>iv.</strong> to send you important information regarding our relationship with
            you or regarding the Platform, such as changes to our terms, conditions, and policies,
            and other administrative information;
          </Text>

          <Text variant="body" marginBottom="large">
            <strong>v.</strong> to operate, evaluate, and improve our business, including developing
            new products and services, managing our communications, analyzing our Services and
            customer base, conducting market research, aggregating and anonymizing data, performing
            data analytics, and undertaking accounting, auditing, and other internal functions;
          </Text>

          <Text variant="body" marginBottom="large">
            <strong>vi.</strong>to train artificial intelligence models that help identify and flag
            relevant Posts
          </Text>

          <Text variant="body" marginBottom="large">
            <strong>vii.</strong> to protect against, identify, and prevent fraud and other criminal
            activity, claims and other liabilities; and
          </Text>

          <Text variant="body" marginBottom="large">
            <strong>viii.</strong> to comply with and enforce applicable legal requirements,
            relevant industry standards, and our policies, including this Privacy Policy and the
            applicable Terms of Use for a Service.
          </Text>

          <Text variant="body" marginBottom="large">
            <strong>ix.</strong> to promote our products and services, and the products and services
            of our third-party business partners; and
          </Text>

          <Text variant="body" marginBottom="large">
            <strong>x.</strong> for our business purposes, such as data analysis, audits, developing
            new products, enhancing the Platform, improving our products and services, identifying
            Platform usage trends, and determining the effectiveness of our promotional campaigns.
          </Text>

          <Text variant="body" marginBottom="large">
            We may use any information that does not personally identify you, your computer, or your
            device, for any purpose.
          </Text>
          <Text variant="body" marginBottom="xs">
            In order to provide the features and services made available through the Platform and
            accomplish the goals described in this Privacy Policy or at the point when we collect
            the information, we disclose your Personal Information as described below and as
            specifically described elsewhere in this Privacy Policy or at the point we collect
            information from you:
          </Text>
          <ol style={{ listStyleType: 'lower-latin' }}>
            <li>
              <Text variant="body" marginBottom="xs">
                to our affiliates and subsidiaries for the purposes described in this Privacy
                Policy;
              </Text>
            </li>
            <li>
              <Text variant="body" marginBottom="xs">
                to unaffiliated third parties (such as data brokers, marketing companies, and IT
                service providers), including by sharing or selling demographic information,
                location data, advertising and device identifiers, IP address, and usage statistics
                to our advertising partners and other third parties, some of whom may use it to
                offer promotions to you for other products and services;
              </Text>
            </li>
            <li>
              <Text variant="body" marginBottom="xs">
                to our third-party service providers who provide services to us, such as website
                hosting and moderating, mobile application hosting, data analysis, payment
                processing, infrastructure provision, IT services, customer service, e-mail and
                direct mail delivery services, auditing services, and other services, in order to
                enable them to provide those services; and
              </Text>
            </li>
            <li>
              <Text variant="body" marginBottom="large">
                to a third party in the event of any reorganization, merger, sale, joint venture,
                assignment, transfer, or other disposition of all or any portion of our business,
                assets, or stock (including in connection with any bankruptcy or similar
                proceedings).
              </Text>
            </li>
          </ol>
        </li>
        <li>
          <Heading variant="h5" marginBottom="large">
            Third Party Social Media Platforms
          </Heading>
          <Text variant="body" marginBottom="large">
            You may engage with our content, such as video, applications, and other offerings, on or
            through social media services or other third-party platforms, such as Facebook, Twitter,
            and Pinterest. When you engage with our content on or through social media services or
            other third-party platforms, plug-ins, integrations, or applications, we may have access
            to certain information in your profile with that service or platform. This may include
            your name, e-mail address, photo, gender, birthday, location, an ID associated with the
            applicable third-party platform or social media account user files, photos and videos,
            your list of friends or connections, people you follow and who follows you, and your
            posts and “likes“. For a description on how such social media services and other
            third-party platforms, plug-ins, integrations, and applications handle your information,
            please refer to their respective privacy policies and terms of use, which may permit you
            to modify your privacy settings with that service or platform.
          </Text>
        </li>
        <li>
          <Heading variant="h5" marginBottom="large">
            Additional Use and Disclosures for Legal Purposes
          </Heading>
          <Text variant="body" marginBottom="large">
            In addition, we use and disclose Personal Information collected through the Platform as
            we believe to be necessary or appropriate:
          </Text>
          <Text variant="body" marginBottom="xs">
            (i) under applicable law, including laws outside your country of residence;
          </Text>
          <Text variant="body" marginBottom="xs">
            (ii) to comply with legal process;
          </Text>
          <Text variant="body" marginBottom="xs">
            (iii) to respond to requests from public and government authorities;
          </Text>
          <Text variant="body" marginBottom="xs">
            (iv) to enforce our terms and conditions;
          </Text>
          <Text variant="body" marginBottom="xs">
            (v) to protect our operations or those of any of our affiliates;
          </Text>
          <Text variant="body" marginBottom="xs">
            (vi) to protect our rights, privacy, safety, or property, and/or that of our affiliates,
            you, or others; and
          </Text>
          <Text variant="body" marginBottom="large">
            (vii) to allow us to pursue available remedies or limit the damages that we may sustain.
          </Text>
        </li>
        <li>
          <Heading variant="h5" marginBottom="large">
            Interest Based Advertising
          </Heading>
          <Text variant="body" marginBottom="large">
            We work with a variety of third-party business partners, including advertisers,
            advertising networks, and advertising and analytics companies that use various
            technologies to collect data about your use of the Platform, which may include location
            data. LifeBrand and our third-party business partners may use the aforementioned
            technologies to:
          </Text>

          <ol style={{ listStyleType: 'lower-roman' }}>
            <li>
              <Text variant="body" marginBottom="xs">
                track how you use the Platform, how you arrived at the Platform, and what you do
                after you leave the Platform;
              </Text>
            </li>
            <li>
              <Text variant="body" marginBottom="xs">
                record and link your devices, including your personal computer and mobile device
                (this is called cross-device linking); and
              </Text>
            </li>
            <li>
              <Text variant="body" marginBottom="large">
                provide you with advertisements relevant to your interests, taking into account your
                use of the Platform and the other websites and online services that you use. Note
                that these advertisements may be delivered to you on the Platform, on third-party
                websites and applications, and on a computer or device other than the device from
                which the information was collected. For example, we provide data about your use of
                the Platform to Facebook for such advertisement targeting purposes.
              </Text>
            </li>
          </ol>
        </li>
      </ol>
      <Text variant="body" marginBottom="large">
        This is called “Interest-Based Advertising” or “Online Behavioral Advertising.” While we
        work with our third-party business partners to improve your experiences with the Platform,
        we do not control their business practices.
      </Text>
      <Text variant="body" marginBottom="large">
        If you wish to opt-out of participating in Interest Based Advertising, you can use some or
        all of the methods below. If you use more than one device, you should renew your opt-out
        choices on each such device.
      </Text>
      <ol>
        <li>
          <Text variant="body" marginBottom="medium">
            Visit{' '}
            <Typography.Link
              href="http://www.aboutads.info/choices"
              target="_blank"
              rel="noopener noreferrer"
            >
              http://www.aboutads.info/choices
            </Typography.Link>{' '}
            (for web-based advertising), and{' '}
            <Typography.Link
              href="http://www.aboutads.info/appchoices"
              target="_blank"
              rel="noopener noreferrer"
            >
              http://www.aboutads.info/appchoices
            </Typography.Link>{' '}
            (for mobile advertising). To learn more, please visit the website operated by the
            Network Advertising Initiative and Digital Advertising Alliance at{' '}
            <Typography.Link
              href="http://www.networkadvertising.org/choices"
              target="_blank"
              rel="noopener noreferrer"
            >
              www.networkadvertising.org/choices
            </Typography.Link>
            ;
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="medium">
            For mobile advertising, use your phone operating system’s opt-out setting. For
            instructions on how to “Limit Ad Tracking” on iOS, please visit{' '}
            <Typography.Link>https://support.apple.com/en-us/HT202074</Typography.Link>. For
            instructions on how to opt out of interest-based ads on Android, please visit{' '}
            <Typography.Link
              href="https://support.google.com/ads/answer/2662922?hl=en"
              target="_blank"
              rel="noopener noreferrer"
            >
              https://support.google.com/ads/answer/2662922?hl=en
            </Typography.Link>
            ; and
          </Text>
        </li>
        <li>
          <Text variant="body" marginBottom="large">
            In accordance with industry self-regulatory principles, you should see an active link in
            or around LifeBrand advertisements that are delivered on other sites using information
            collected on the Platform, and in or around third-party advertisements that are
            delivered on the Platform using Interest Based Advertising programs. Clicking on this
            link will provide information about the companies and data practices that were used to
            deliver the ad and will also describe how you may opt-out of these advertising programs.
          </Text>
        </li>
      </ol>
      <Text variant="body" marginBottom="large">
        The Platform does not process Do-Not-Track (DNT) headers transmitted by Web browsers. Our
        third-party web analytics companies collect information about your online activities over
        time. These third parties do not change their tracking practices in response to DNT settings
        in your web browser and we do not obligate these parties to honor DNT settings.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        3. Information Related to Minors
      </Heading>
      <Text variant="body" marginBottom="large">
        Unless otherwise specified, the Services are designed for a general audience and are not
        directed at children. In connection with the Services, we do not knowingly solicit or
        collect personal information from children under the age of 13 without parental consent. If
        we learn that we have collected personal information from a child under age 13 without
        parental consent, we will either seek parental consent or promptly delete that information.
        If you believe that a child under age 13 may have provided us with personal information
        without parental consent, please contact us as specified in the How To Contact Us section of
        this Privacy Policy.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        4. Third-Party Websites and Services
      </Heading>
      <Text variant="body" marginBottom="large">
        The Platform may also contain links to or utilize the features of third-party websites and
        other online services, including third-party payment processors, for your convenience with
        locating information, products, or services that may be of interest. If you access a
        third-party service from a link on the Platform, any information you disclose to that third
        party is not subject to this Privacy Policy. In addition, it is possible that these links
        may be used by third parties or others to collect personal or other information about you.
      </Text>

      <Text variant="body" marginBottom="large">
        Some aspects of the Platform may also allow you to interface with other websites, social
        media, and other online services, such as Facebook. We will diligently work to identify
        these aspects of the Platform to you, for example, by identifying them with the applicable
        third-party logos or trade names. By using these interfaces, you will allow us to access
        information about you from those other online services, including information and other
        content that you submit to those online services, as described in more detail in in Section
        1(e) of this Policy. If you interface with the Platform through your social media account,
        we may contact you or enable you to share your experience and content via your social media
        account, which information may be publicly viewed by other users of those services.
      </Text>

      <Text variant="body" marginBottom="large">
        We are not responsible for the privacy practices of other online services, including other
        websites, advertisers, payment processors, and social media. It is your sole obligation to
        review and understand the privacy practices and policies of third parties. We do not control
        the use of cookies or the collection of information by these third parties, nor how they
        manage such information. The availability of, or inclusion of a link to or interface with,
        any third-party service on the Platform does not imply endorsement of it by us or by our
        affiliates. Your use of those other sites and services is subject to the privacy policies of
        those sites and services, and not this Privacy Policy.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        5. Security
      </Heading>
      <Text variant="body" marginBottom="large">
        The security of your Personal Information is important to us and we are committed to
        handling that information carefully. We use reasonable and appropriate organizational,
        technical, and administrative measures to protect Personal Information under our control.
        Unfortunately, no data transmission over the Internet or data storage system can be
        guaranteed to be 100% secure. If you have reason to believe that your interaction with us is
        no longer secure (for example, if you feel that the security of any account you have with us
        has been compromised), please immediately notify us of the problem.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        6. Data Retention
      </Heading>
      <Text variant="body" marginBottom="large">
        We generally retain Personal Information for so long as it may be relevant for the purposes
        identified in this Privacy Policy or at the time the information is collected, unless a
        longer period of time is required by law.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        7. Your Data Rights and Choices
      </Heading>
      <Text variant="body" marginBottom="large">
        Registered users can update their profile information on the Platform.
      </Text>
      <Text variant="body" marginBottom="large">
        We want to communicate with you only if you want to hear from us. If you have signed up to
        receive electronic newsletters or promotional emails from LifeBrand, including new ideas,
        special offers, and event information, or to otherwise receive communications about our
        services, you will have the right at any time to opt out of receiving marketing emails or to
        specify which, if any, communications you would like to receive from us. Should you ever
        decide to delete your account, you may do so via the Platform or by emailing {''}
        <Typography.Link href="mailto: info@lifebrand.life">info@lifebrand.life</Typography.Link>.
        You can opt-out of the use of certain cookie-related processing by following the
        instructions above (Passive Information Collection, Use, and Choices).
      </Text>

      <Text variant="body" marginBottom="large">
        If you would like to opt-out of receiving marketing via email, click the unsubscribe link on
        the footer of marketing emails. If you would like to opt-out of receiving communication via
        postal mail, contact {''}
        <Typography.Link href="mailto: info@lifebrand.life">info@lifebrand.life</Typography.Link>.
        LifeBrand will continue to send you non-promotional, service emails concerning your account,
        such as emails relating to available upgrades, billing and payment information, outstanding
        balance on your account, and other emails relating to your account and/or your use of the
        Platform.
      </Text>

      <Text variant="body" marginBottom="large">
        At your request, LifeBrand will confirm what Personal Information it collects or holds about
        you, and will correct, update and/or remove such information. You may contact LifeBrand for
        any of the foregoing at {''}
        <Typography.Link href="mailto: info@lifebrand.life">info@lifebrand.life</Typography.Link>.
        You are solely responsible for maintaining your account with updated and accurate
        information. If you ask that LifeBrand stops using or sharing your Personal Information, we
        will honor that request. However, LifeBrand may retain records of your Personal Information
        for a period of time; for example, to follow-up on a request, resolve a dispute or for
        similar reasons or in order to comply with applicable federal, state, or local law. In
        addition, some personal information may also continue to be stored on back-up files for
        financial, legal, or technical reasons.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        8. Right To Change Privacy Statement
      </Heading>
      <Text variant="body" marginBottom="large">
        LifeBrand reserves the right at any time to modify, alter, or update this Privacy Policy.
        Your use of the Platform following any changes means that you agree to follow and be bound
        by the Privacy Policy as changed, subject to limitations under applicable law. Any change to
        this Privacy Policy shall be effective as to any user who has visited the Platform before
        the change was made. Please review this policy periodically, and especially before you
        provide any Personal Information to us. The Privacy Policy was last updated on the date
        indicated above.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        9. California
      </Heading>
      <Text variant="body" marginBottom="large">
        California Civil Code Section 1798.83 (also known as the “Shine The Light” law) permits
        users who are California residents to request and obtain from us once a year, free of
        charge, information about the Personal Information (if any) we disclosed to third parties
        for direct marketing purposes in the preceding calendar year. If applicable, this
        information would include a list of the categories of personal information that was shared
        and the names and addresses of all third parties with which we shared information in the
        immediately preceding calendar year. If you are a California resident and would like to make
        such a request, please submit your request to the email address identified above.
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        10. Do Not Track
      </Heading>
      <Text variant="body" marginBottom="large">
        The Platform does not currently take any action when it receives a Do Not Track request. Do
        Not Track is a privacy preference that you can set in your web browser to indicate that you
        do not want certain information about your webpage visits collected across websites when you
        have not interacted with that service on the page. For details, including how to turn on Do
        Not Track, visit{' '}
        <Typography.Link href="http://www.donottrack.us/" target="_blank" rel="noopener noreferrer">
          www.donottrack.us
        </Typography.Link>
        .
      </Text>

      <Heading variant="h4" marginBottom="large" fontWeight={700}>
        11. How To Contact Us
      </Heading>
      <Text variant="body" marginBottom="xs">
        If you have any questions, concerns or comments about our Privacy Policy, you may contact us
        using the information below:
      </Text>

      <Text variant="body" marginBottom="large">
        By e-mail:{' '}
        <Typography.Link href="mailto: info@lifebrand.life">info@lifebrand.life</Typography.Link>
      </Text>

      <Text variant="body" marginBottom="xl">
        By written correspondence: <br />
        158 W. Gay Street, Suite 300 <br />
        West Chester PA 19380
        <br />
        United States of America
      </Text>

      {/* <Text variant="body" marginBottom="large">
        Last Updated: <strong>December 23, 2021</strong>
      </Text> */}
    </>
  );
};

export default PrivacyPolicy;
