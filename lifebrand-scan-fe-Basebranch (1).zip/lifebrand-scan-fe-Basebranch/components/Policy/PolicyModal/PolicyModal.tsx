import React, { useCallback } from 'react';

import { Button, Heading, Text } from '@UI/meeseeks';

import { POLICY_VERSION } from '../Policy.constants';

import { useAcceptPolicyMutation } from '@Generated/graphql';
import { ROUTES } from '@Utils/helper/routes';

import * as S from './Policy.styles';

type Props = {
  isVisible: boolean;
  onDecline?: () => void;
  onAgree?: () => void;
};

const PolicyModal = ({ isVisible, onAgree }: Props) => {
  const [acceptPolicy, { loading }] = useAcceptPolicyMutation();

  const handleAgree = useCallback(async () => {
    await acceptPolicy({ variables: { policyVersion: POLICY_VERSION } });
    onAgree?.();
  }, [acceptPolicy, onAgree]);

  return (
    <S.Modal visible={isVisible} closable={false} footer={null} width={680}>
      <S.Header>
        <Heading variant="h3" textAlign="center" marginBottom="small">
          We have updated our{' '}
          <a href={ROUTES.PRIVACY} target="_blank" rel="noreferrer">
            Privacy Policy
          </a>
          <br />
          and{' '}
          <a href={ROUTES.TERMS_OF_USE} target="_blank" rel="noreferrer">
            Terms of Use
          </a>
          .
        </Heading>
        <Text variant="regular" textAlign="center" fontWeight={600}>
          Please agree to confirm that you have read and understand these updates.
        </Text>
      </S.Header>
      <S.Actions>
        <Button
          variant="primary"
          size="medium"
          onClick={handleAgree}
          loading={loading}
          disabled={loading}
        >
          Agree
        </Button>
      </S.Actions>
    </S.Modal>
  );
};

export default PolicyModal;
