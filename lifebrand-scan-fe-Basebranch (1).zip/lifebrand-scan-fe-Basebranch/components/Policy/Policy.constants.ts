/**
 * Increment this value whenever the PP or T&C content is updated to make sure
 * all users agree to the new version. Typically this will be the date of last update.
 */
export const POLICY_VERSION = 'v2022-01-19';
