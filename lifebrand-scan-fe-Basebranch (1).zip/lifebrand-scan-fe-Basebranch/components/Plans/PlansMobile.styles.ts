import styled from 'styled-components';
import { Swiper as SwiperBase } from 'swiper/react';

export const Container = styled.div`
  margin: ${({ theme }) => theme.spacing.medium}px 0px;
`;

export const SwiperContainer = styled.div`
  // If anywhere up in the tree Css grids are used,
  // the Swiper parent must be also a grid for correct sizing.
  // See https://github.com/nolimits4web/swiper/issues/3599#issuecomment-731753681
  display: grid;

  width: calc(100% + 32px);
  margin: 0px -16px;
  position: relative;
`;

export const Swiper = styled(SwiperBase)`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  padding-top: ${({ theme }) => theme.spacing.small}px;

  .swiper-slide {
    width: 90%;
    max-width: 360px;
  }

  .swiper-slide-active > div:first-child {
    border: 4px solid ${({ theme }) => theme.meeseeks.color['primary.900']};
    border-radius: 8px;
  }

  .swiper-slide-shadow-left {
    background-image: linear-gradient(to left, rgba(255, 255, 255, 0.5), rgba(255, 255, 255, 0));
  }

  .swiper-slide-shadow-right {
    background-image: linear-gradient(to right, rgba(255, 255, 255, 0.5), rgba(255, 255, 255, 0));
  }

  .swiper-pagination {
    position: static;
    order: 1;
    padding: ${({ theme }) => theme.spacing.small}px 0px;

    .swiper-pagination-bullet {
      width: 12px;
      height: 12px;
      line-height: 6px;
      vertical-align: middle;
      background-color: ${({ theme }) => theme.color.primary};
      opacity: 0.35;
    }

    .swiper-pagination-bullet-active {
      opacity: 1;
    }
  }
`;
