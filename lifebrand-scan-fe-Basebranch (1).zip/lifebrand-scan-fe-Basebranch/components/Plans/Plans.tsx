import React from 'react';

import PlansDesktop from './PlansDesktop';
import PlansMobile from './PlansMobile';

import Loading from '@UI/Loading';

import { useAuthContext } from '@Utils/AuthContext';
import { plansByKey, getPlanKey, PlanKey, getPlanByKey } from '@Utils/plans';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { usePlansQuery } from '@Generated/graphql';

const IndividualPlans = () => {
  const { userData } = useAuthContext();
  const { isMobile, isTablet, isDesktop } = useBreakpoints();
  const { data: plansData, loading } = usePlansQuery();

  const currentPlanKey = userData?.Plan ? getPlanKey(userData?.Plan) : undefined;

  const basicPlan = plansData && getPlanByKey(PlanKey.Basic, plansData.plans);
  const individualPlans =
    plansData &&
    [PlanKey.Free, PlanKey.Basic, PlanKey.Unlimited].map((planKey) => {
      const plan = getPlanByKey(planKey, plansData.plans)!;
      const extraInfo = plansByKey[planKey];

      return {
        id: plan.id,
        key: planKey,
        name: plan.name,
        description: extraInfo.description,
        type: plan.type,
        price: planKey === PlanKey.Unlimited ? basicPlan!.price : plan.price,
        monthlyPrice: planKey === PlanKey.Unlimited ? plan.price : null,
        isRecommended: extraInfo.isRecommended,
        isActive: currentPlanKey === planKey,
        /**
         * Free plan will be counted as used
         * if it's current plan it's active and used
         * if current plan is unlimited every other plan are used
         */
        isUsed:
          planKey === PlanKey.Free ||
          userData?.planId === plan.id ||
          currentPlanKey === PlanKey.Unlimited,
      };
    });

  if (loading) {
    return <Loading />;
  }

  if (isMobile || isTablet) {
    return <PlansMobile plans={individualPlans || []} />;
  }

  if (isDesktop) {
    return <PlansDesktop plans={individualPlans || []} />;
  }

  return null;
};

export default IndividualPlans;
