import React from 'react';
import { useRouter } from 'next/router';
import { ThemeProvider } from 'styled-components';

import { fireEvent, render, waitFor } from '@testing-library/react';
import { MockedProvider, MockedResponse } from '@apollo/client/testing';

import { theme } from 'theme/theme';

import Plans from './Plans';

import { BreakpointProvider } from '@Utils/hooks/useBreakpoints';
import { ContextProps as AuthContextProps, useAuthContext } from '@Utils/AuthContext';
import { PlanDataFragment, PlansDocument, PlansQuery, UserDataFragment } from '@Generated/graphql';

jest.mock('next/router', () => ({
  useRouter: jest.fn().mockReturnValue({
    route: '/',
    pathname: '',
    query: '',
    asPath: '',
    push: jest.fn(),
  }),
}));

jest.mock('@Utils/AuthContext', () => ({
  ...jest.requireActual('@Utils/AuthContext'),
  useAuthContext: jest.fn(),
}));

const mockUseAuth = (userData: AuthContextProps['userData']) => {
  (useAuthContext as jest.Mock).mockReturnValue({
    userData,
    triggerRefetch: (() => {}) as AuthContextProps['triggerRefetch'],
    loading: false,
    isLoggedIn: true,
    isInvited: false,
    invitedBy: [],
  });
};

const renderPlans = (mocks: MockedResponse[]) => {
  return render(
    <ThemeProvider theme={theme}>
      <BreakpointProvider>
        <MockedProvider mocks={mocks} addTypename>
          <Plans />
        </MockedProvider>
      </BreakpointProvider>
    </ThemeProvider>,
  );
};

const generateTestData = () => {
  const plans = {
    business: {
      __typename: 'Plan',
      id: 'ckrd5tivs00072jymnmygx6gz',
      name: 'Monthly Subscription',
      type: 'Business',
      numberOfScans: -1,
      isRecurring: true,
      price: -1,
    },
    free: {
      __typename: 'Plan',
      id: 'FREE_PLAN',
      name: 'Free',
      type: 'Individual',
      numberOfScans: 1,
      isRecurring: false,
      price: 0,
    },
    basic: {
      __typename: 'Plan',
      id: 'ckrd5tilh00002jym62ozxvcw',
      name: 'Basic Access',
      type: 'Individual',
      numberOfScans: 1,
      isRecurring: false,
      price: 997,
    },
    unlimited: {
      __typename: 'Plan',
      id: 'ckrd5tj3600212jym75wtlnj7',
      name: 'Unlimited Access',
      type: 'Individual',
      numberOfScans: -1,
      isRecurring: true,
      price: 397,
    },
  } as Record<string, PlanDataFragment>;

  const user = {
    __typename: 'User',
    id: 'ckzia9ypd119760js6uvsy7mbv',
    name: 'Erica Lumley',
    email: 'erica_lumley@mail.com',
    photo:
      'https://scontent-sea1-1.xx.fbcdn.net/v/t1.30497-1/cp0/c15.0.50.50a/p50x50/84628273_176159830277856_972693363922829312_n.jpg?_nc_cat=1&ccb=1-5&_nc_sid=12b3be&_nc_ohc=PI_YeJrsSWYAX9u02Qg&_nc_ht=scontent-sea1-1.xx&edm=AP4hL3IEAAAA&oh=00_AT85A1vMKWa_K5piZbc8DzxYKRRzmZMmnWHlChBC2H6n9w&oe=622D72B8',
    scanAmount: 1,
    authId: 'facebook|107403778058630',
    stripeId: null,
    planId: plans.free.id,
    Plan: plans.free,
    createdAt: '2022-02-11T10:45:15.889Z',
    updatedAt: '2022-02-11T10:45:15.890Z',
    lastRefresh: null,
    acceptedFcraVersion: null,
    acceptedPolicyVersion: 'v2022-01-19',
    hasPassword: false,
    BusinessCustomer: [],
  } as UserDataFragment;

  return {
    user,
    plans,
    apollo: {
      plans: {
        request: {
          query: PlansDocument,
        },
        result: {
          data: {
            plans: Object.values(plans),
          } as PlansQuery,
        },
      },
    },
  };
};

const testData = generateTestData();

describe('Plans', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('displays free plan as current and upgrade to basic or unlimited', async () => {
    mockUseAuth(testData.user);

    const { findByTestId, getByRole, getAllByRole } = renderPlans([testData.apollo.plans]);

    const freePlanCard = await findByTestId(testData.plans.free.id);
    const freePlanButton = getByRole('button', { name: 'Cannot Downgrade' });

    expect(freePlanButton).toBeDisabled();
    expect(freePlanCard).toContainElement(freePlanButton);
    expect(freePlanCard).toHaveTextContent('0.00');

    expect(getAllByRole('button', { name: 'Select' })).toHaveLength(2);
  });

  it('displays basic plan as current and upgrade to unlimited', async () => {
    mockUseAuth({
      ...testData.user,
      planId: testData.plans.basic.id,
      Plan: testData.plans.basic,
    });

    const { findByTestId, getByTestId, getByRole } = renderPlans([testData.apollo.plans]);

    const basicPlanCard = await findByTestId(testData.plans.basic.id);
    const basicPlanButton = getByRole('button', { name: 'Current Plan' });

    expect(basicPlanButton).toBeDisabled();
    expect(basicPlanCard).toContainElement(basicPlanButton);
    expect(basicPlanCard).toHaveTextContent(String(testData.plans.basic.price / 100));

    expect(getByTestId(testData.plans.free.id)).toContainElement(
      getByRole('button', { name: 'Cannot Downgrade' }),
    );
    expect(getByTestId(testData.plans.unlimited.id)).toContainElement(
      getByRole('button', { name: 'Select' }),
    );
  });

  it('displays unlimited plan as current with no upgrade options', async () => {
    mockUseAuth({
      ...testData.user,
      planId: testData.plans.unlimited.id,
      Plan: testData.plans.unlimited,
    });

    const { findByTestId, getByRole, getAllByRole } = renderPlans([testData.apollo.plans]);

    const unlimitedPlanCard = await findByTestId(testData.plans.unlimited.id);
    const unlimitedPlanButton = getByRole('button', { name: 'Current Plan' });

    expect(unlimitedPlanButton).toBeDisabled();
    expect(unlimitedPlanCard).toContainElement(unlimitedPlanButton);

    expect(unlimitedPlanCard).toHaveTextContent(String(testData.plans.basic.price / 100));
    expect(unlimitedPlanCard).toHaveTextContent(`${testData.plans.unlimited.price / 100} monthly`);

    expect(getAllByRole('button', { name: 'Cannot Downgrade' })).toHaveLength(2);
  });

  it('redirects to the checkout page if can upgrade', async () => {
    mockUseAuth({
      ...testData.user,
      planId: testData.plans.basic.id,
      Plan: testData.plans.basic,
    });

    const { findByTestId, getByRole } = renderPlans([testData.apollo.plans]);

    const unlimitedPlanCard = await findByTestId(testData.plans.unlimited.id);
    const upgradeButton = getByRole('button', { name: 'Select' });

    expect(unlimitedPlanCard).toContainElement(upgradeButton);

    fireEvent.click(upgradeButton);

    await waitFor(() => {
      expect((useRouter as jest.Mock).mock.results[0].value.push).toBeCalledWith(
        expect.objectContaining({
          pathname: '/payment',
          query: expect.objectContaining({
            planKey: 'individual-unlimited',
          }),
        }),
      );
    });
  });

  // TODO: Test after confirmed and fixed.
  it.todo('displays basic as current if unlimited is cancelled');
});
