import React, { useState, useMemo } from 'react';
import SwiperCore, { Pagination, EffectCoverflow } from 'swiper/core';
import { SwiperSlide } from 'swiper/react';

import PlanCard from './PlanCard';
import FeatureTable from './FeatureTable';

import { Plan } from '@Utils/plans';

import 'swiper/swiper.min.css';
import 'swiper/components/pagination/pagination.min.css';
import 'swiper/components/effect-coverflow/effect-coverflow.min.css';
import * as S from './PlansMobile.styles';

SwiperCore.use([Pagination, EffectCoverflow]);

type Props = {
  plans: Plan[];
};

const IndividualPlansMobile = ({ plans }: Props) => {
  const initialIndex = useMemo(() => plans.findIndex((plan) => plan.isRecommended) || 0, [plans]);
  const [activeIndex, setActiveIndex] = useState(initialIndex);

  return (
    <S.Container>
      <S.SwiperContainer>
        <S.Swiper
          pagination
          slidesPerView="auto"
          centeredSlides
          initialSlide={initialIndex}
          onActiveIndexChange={(swiper) => setActiveIndex(swiper.activeIndex)}
          effect="coverflow"
          grabCursor
          coverflowEffect={{ rotate: 0, depth: 50 }}
        >
          {plans.map((plan) => (
            <SwiperSlide key={plan.key}>
              <PlanCard plan={plan} />
            </SwiperSlide>
          ))}
        </S.Swiper>
      </S.SwiperContainer>
      <FeatureTable planKey={plans[activeIndex].key} individualPlans={plans} />
    </S.Container>
  );
};

export default IndividualPlansMobile;
