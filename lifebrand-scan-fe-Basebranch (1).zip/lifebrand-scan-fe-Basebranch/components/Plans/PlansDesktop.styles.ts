import styled from 'styled-components';

import { gap } from '@Utils/style/gap';

export const List = styled.div`
  display: flex;
  flex-wrap: wrap;
  margin: ${({ theme }) => theme.spacing.small}px 0px;
  ${({ theme }) => gap(`${theme.spacing.medium}px`)}
`;

export const Actions = styled.div`
  display: flex;
  justify-content: center;
  margin-top: ${({ theme }) => theme.spacing.large * 2}px;
  margin-bottom: ${({ theme }) => theme.spacing.large + theme.spacing.medium}px;
`;
