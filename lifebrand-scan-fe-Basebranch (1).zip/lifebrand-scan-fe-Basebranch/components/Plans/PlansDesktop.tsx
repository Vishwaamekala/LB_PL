import React, { useState, useCallback } from 'react';

import PlanCard from './PlanCard';
import FeatureTable from './FeatureTable';

import { Button } from '@UI/meeseeks';

import { ExtendedPlan } from '@Utils/plans';

import * as S from './PlansDesktop.styles';

type Props = {
  plans: ExtendedPlan[];
};

// TODO: features table hidden due to inconsistencies in plans / pricing - revisit
const IndividualPlansDesktop = ({ plans }: Props) => {
  const [isTableOpen, setIsTableOpen] = useState(false);
  const handleTableToggle = useCallback(() => {
    setIsTableOpen((isOpen) => !isOpen);
  }, []);

  return (
    <>
      <S.List>
        {plans.map((plan) => (
          <PlanCard plan={plan} key={plan.key} />
        ))}
      </S.List>
      <S.Actions>
        <Button variant="secondary" size="large" onClick={handleTableToggle}>
          {isTableOpen ? 'Hide' : 'View'} Full Comparison
        </Button>
      </S.Actions>
      {isTableOpen && <FeatureTable individualPlans={plans} />}
    </>
  );
};

export default IndividualPlansDesktop;
