import React, { Fragment } from 'react';

import { Heading, Icon, Text } from '@UI/meeseeks';

import { plansByGroupedFeature, PlanKey, Plan } from '@Utils/plans';

import * as S from './FeatureTable.styles';

type Props = {
  planKey?: PlanKey;
  individualPlans: Plan[];
};

const FeatureTable = ({ planKey, individualPlans }: Props) => {
  return (
    <S.Table>
      {!planKey && (
        <thead>
          <tr>
            <th />
            {individualPlans.map((plan) => (
              <th key={plan.key}>
                <Heading variant="h5" textAlign="center">
                  {plan.name}
                </Heading>
              </th>
            ))}
          </tr>
        </thead>
      )}
      <tbody>
        {Object.entries(plansByGroupedFeature).map(([group, plansByFeature]) => (
          <Fragment key={group}>
            <tr>
              <th colSpan={planKey ? 2 : individualPlans.length + 1}>
                <Heading variant="h5">{group}</Heading>
              </th>
            </tr>
            {Object.entries(plansByFeature).map(([feature, planKeys]) => (
              <tr key={feature}>
                <td>
                  <Text variant="regular">{feature}</Text>
                </td>
                {individualPlans.map(
                  (plan) =>
                    (!planKey || planKey === plan.key) && (
                      <td key={plan.key}>
                        {planKeys.includes(plan.key) && (
                          <Icon name="Success" size={21} color="primary" />
                        )}
                      </td>
                    ),
                )}
              </tr>
            ))}
          </Fragment>
        ))}
      </tbody>
    </S.Table>
  );
};

export default FeatureTable;
