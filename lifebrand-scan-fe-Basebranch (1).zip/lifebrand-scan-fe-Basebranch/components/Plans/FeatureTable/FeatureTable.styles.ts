import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Table = styled.table`
  table-layout: fixed;
  width: 100%;

  tr {
    height: 56px;
  }

  tbody tr th,
  tbody tr td {
    border-bottom: ${({ theme }) => theme.border.card};
    min-width: 60px;

    > svg {
      display: block;
      margin: auto;
    }
  }

  tbody tr:last-of-type th,
  tbody tr:last-of-type td {
    border-bottom: none;
  }

  ${useBreakpoint.tablet`
    table-layout: auto;
  `}
`;
