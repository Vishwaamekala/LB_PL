import React, { useCallback, useMemo } from 'react';
import { useRouter } from 'next/router';

import { Button, Heading, Icon, Text } from '@UI/meeseeks';

import {
  pinnedFeaturesByPlan,
  ExtendedPlan,
  PlanKey,
  stripePriceToCurrencyFormatter,
} from '@Utils/plans';
import { ROUTES } from '@Utils/helper/routes';

import * as S from './PlanCard.styles';

type Props = {
  plan: ExtendedPlan;
};

const PlanCard = ({ plan }: Props) => {
  const router = useRouter();

  const handleSelect = useCallback(() => {
    router.push({
      pathname: ROUTES.PAYMENT,
      query: { planKey: plan.key },
    });
  }, [router, plan.key]);

  const action = useMemo(() => {
    if (plan.isActive && plan.key !== PlanKey.Free) {
      return (
        <Button variant="primary" size="large" iconLeft={<Icon name="Success" />} disabled fluid>
          Current Plan
        </Button>
      );
    }
    if (plan.isUsed) {
      return (
        <Button variant="primary" size="large" iconLeft={<Icon name="Error" />} disabled fluid>
          Cannot Downgrade
        </Button>
      );
    }
    return (
      <Button variant="primary" size="large" onClick={handleSelect} fluid>
        Select
      </Button>
    );
  }, [plan, handleSelect]);

  return (
    <S.Card isRecommended={plan.isRecommended} data-testid={plan.id} key={plan.key}>
      {plan.isRecommended && <S.RecommendedBadge src="/images/png/recommended-badge.png" />}
      <div>
        <Heading variant="h2" marginBottom="xxs">
          {stripePriceToCurrencyFormatter(plan.price)}
        </Heading>
        <Heading variant="h3" marginBottom="medium">
          {plan.name}
        </Heading>
        <Text variant="regular">
          {plan.monthlyPrice
            ? `+ ${stripePriceToCurrencyFormatter(plan.monthlyPrice)} monthly`
            : plan.description}
        </Text>
        <S.Features>
          {pinnedFeaturesByPlan[plan.key]?.map(([name, isEnabled]) => (
            <S.Feature isEnabled={isEnabled} key={name}>
              <Icon name="Success" size={16} />
              <Heading variant="h6">{name}</Heading>
            </S.Feature>
          ))}
        </S.Features>
      </div>
      {action}
    </S.Card>
  );
};

export default PlanCard;
