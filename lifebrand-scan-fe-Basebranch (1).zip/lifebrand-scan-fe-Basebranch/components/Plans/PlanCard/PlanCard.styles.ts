import styled from 'styled-components';

export const Card = styled.div<{ isRecommended?: boolean }>`
  position: relative;
  display: flex;
  flex: 1 0 290px;
  flex-direction: column;
  justify-content: space-between;
  gap: ${({ theme }) => theme.spacing.extraLarge}px;
  border: ${({ theme }) => theme.border.card};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  padding: ${({ theme }) => `${theme.spacing.extraLarge}px ${theme.spacing.large}px`};
  background: ${({ theme }) => theme.meeseeks.color.white};
  min-height: 460px;

  ${({ isRecommended, theme }) =>
    isRecommended &&
    `
    background: linear-gradient(202.11deg,  ${theme.meeseeks.color['primary.800']}  3.26%,  ${theme.meeseeks.color['primary.900']} 99.36%);
    border: none;

    * {
      color: ${theme.meeseeks.color.white}!important;
    }

    svg * {
      fill: ${theme.meeseeks.color.white}!important;
    }
  `}

  button:disabled svg * {
    fill: ${({ theme }) => theme.meeseeks.color.white}!important;
  }
`;

export const RecommendedBadge = styled.img`
  position: absolute;
  top: -58px;
  right: -57px;
  width: 210px;
`;

export const Features = styled.div``;

export const Feature = styled.div<{ isEnabled?: boolean }>`
  display: flex;
  align-items: center;
  margin: ${({ theme }) => theme.spacing.medium}px 0px;

  h6 {
    flex-shrink: 1;
    color: ${({ theme, isEnabled }) =>
      isEnabled ? theme.meeseeks.color.body : theme.meeseeks.color['neutrals.300']};
  }

  svg {
    flex-shrink: 0;
    margin-right: ${({ theme }) => theme.spacing.small}px;
  }
  svg * {
    fill: ${({ theme, isEnabled }) =>
      isEnabled ? theme.color.primary : theme.meeseeks.color['neutrals.300']};
  }

  ${({ isEnabled, theme }) =>
    !isEnabled &&
    `
    svg,
    h6 {
      color: ${theme.meeseeks.color.tertiary} !important;
    }
  `}
`;
