export { default } from './FAQ';
export * from './FAQ';
