import React from 'react';
import Skeleton from 'react-loading-skeleton';

import { QUESTIONS } from './content';

import { Heading, Text } from '@UI/meeseeks';
import Collapse from '@UI/Collapse';

type Props = {
  loading?: boolean;
};

const FAQ = ({ loading }: Props) => {
  return (
    <Collapse>
      {QUESTIONS.map(({ id, question, answer }) => (
        <Collapse.Panel
          key={id}
          header={loading ? <Skeleton width="100%" /> : <Heading variant="h5">{question}</Heading>}
        >
          <Text variant="regular" marginBottom="large" textColor="body">
            {answer}
          </Text>
        </Collapse.Panel>
      ))}
    </Collapse>
  );
};

export default FAQ;
