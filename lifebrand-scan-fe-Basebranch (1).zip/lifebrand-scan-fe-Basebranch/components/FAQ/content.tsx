import React from 'react';

import { Text } from '@UI/meeseeks';

type ContentProps = {
  id: string;
  question: string;
  answer: string | React.ReactNode;
};

export const QUESTIONS: ContentProps[] = [
  {
    id: 'Criteria used to flag posts',
    question: 'What are the criteria used to flag the posts?',
    answer:
      'We have a large dataset of profanities that helps us flag potentially harmful posts. Our AI is looking for these words in your posts and once it finds one, the whole post is marked as harmful. We are also considering typos to make sure we catch everything.',
  },
  {
    id: 'Account Safety',
    question: 'Is my account information safe?',
    answer:
      'At LifeBrand, security is built into our design. We never share any sensitive information with third parties or store your credentials.',
  },
  {
    id: 'Payment Security',
    question: 'What type of payment security does LifeBrand offer?',
    answer: 'We offer a secure payment method through Stripe.',
  },
  {
    id: 'Data Security',
    question: 'What type of data security does LifeBrand use?',
    answer:
      'Our server uses 256-bit Advanced Encryption Standard (AES) for encryption, TLS to protect data in transit, and SSL for data transfer.',
  },
  {
    id: 'Account Deletion',
    question: 'How do I delete my account if needed?',
    answer:
      'You can delete your LifeBrand account in the "My Account" section (top-right dropdown menu).',
  },
  {
    id: 'Subscription Cancellation',
    question: 'How can I cancel my subscription?',
    answer:
      'You can cancel your monthly subscription by going to your account and clicking on the "Downgrade" button.',
  },
  {
    id: 'Product Updates',
    question: 'How frequently is the product updated or bugs fixed?',
    answer: (
      <Text variant="small" marginBottom="medium" textColor="secondary">
        Fixes and improvements happen routinely. We value client feedback and encourage feature
        suggestions and improvements <a href="https://www.lifebrand.life/contact-support">here.</a>
      </Text>
    ),
  },
  {
    id: 'One-Time Scan',
    question: 'What is included in the one-time scan?',
    answer:
      'The One Time Scan includes the ability to connect your Twitter, Instagram, and Facebook accounts to be scanned. The ability to delete or ignore all flagged posts. The ability to view your social impact score and learn tips to improve it.',
  },
  {
    id: 'Private Messages Access',
    question: 'Can LifeBraned see my private messages in messenger/DM’s?',
    answer:
      "No. LifeBrand is only able to see your posts that you shared. We won't have access to your private messages or direct messages.",
  },
  {
    id: 'Report Sharing',
    question: 'Am I able to send a report to my employer or future employer?',
    answer: 'Yes. You are able to easily send your LifeBrand report back to your employer.',
  },
  {
    id: 'Name Change',
    question:
      'I am not using my real name on my social media, can I change it somehow in the LifeBrand platform?',
    answer:
      'Yes, you can do it by opening your Profile Sidebar and clicking "Edit My Profile" button.',
  },
  {
    id: 'Posts Storing',
    question: 'Do you store my deleted posts?',
    answer: 'No. We do not store any posts that were deleted through our Platform.',
  },
  {
    id: 'Deletion of Ignored Posts',
    question: 'What if I want to delete a post that I marked as ignored earlier?',
    answer:
      'You can find all your ignored posts in the Ignored folder on when you open a scan from your dashboard. If you want to delete one, just click on the trash bin icon next to it.',
  },
  {
    id: "Employers' Access to View Posts",
    question: 'Can my employer / future employer see my posts?',
    answer:
      'No. Your employer will not be able to see your posts. If you share a summary report with them, they will be able to see the categories that your posts fall into, how many posts were ignored, and which social media platforms you are most active on.',
  },
];
