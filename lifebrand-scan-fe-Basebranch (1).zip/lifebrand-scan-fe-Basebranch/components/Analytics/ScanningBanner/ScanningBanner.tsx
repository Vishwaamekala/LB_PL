import React from 'react';

import { Heading } from '@UI/meeseeks';

import Steps, { Animation } from 'components/Auth/Intro/Steps';

import * as S from './ScanningBanner.styles';

const ScanningBanner = () => {
  return (
    <S.Card>
      <S.Content>
        <Heading variant="h3" textColor="heading" textAlign="center" marginBottom="medium">
          Scan In Progress
        </Heading>
        <Heading variant="h5" textColor="body" textAlign="center" marginBottom="medium">
          Please wait until it’s finished to review analytics and create report.
        </Heading>
      </S.Content>
      <S.ScanningAnimation>
        <Steps animation={Animation.StepTwo} infiniteLoop={true} />
      </S.ScanningAnimation>
    </S.Card>
  );
};

export default ScanningBanner;
