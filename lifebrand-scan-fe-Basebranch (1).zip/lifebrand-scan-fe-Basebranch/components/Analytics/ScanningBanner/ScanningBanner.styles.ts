import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const ScanningAnimation = styled.div`
  position: absolute;
  bottom: 0;
  width: 80%;

  ${useBreakpoint.mobile`
    width: 100%;
  `}
`;

export const Card = styled.div`
  position: relative;
  display: flex;
  flex-direction: row;
  justify-content: center;
  background-color: ${({ theme }) => theme.meeseeks.color['primary.200']};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  z-index: 1;
  height: 480px;

  ${useBreakpoint.mobile`
    padding: ${({ theme }) => theme.spacing.medium}px;
    height: 454px;
  `}
`;

export const Content = styled.div`
  margin-top: 10%;
`;
