import React from 'react';
import { Row, Col } from 'antd';
import { useTheme } from 'styled-components';

import { format } from 'date-fns';

import { Text } from '@UI/meeseeks';
import ProgressCard from '@UI/ProgressCard';

import OverallPostsCard from 'components/Analytics/Report/ReportDetails/OverallPostsCard';
import FlaggedByOriginsCard from 'components/Analytics/Report/ReportDetails/FlaggedByOriginsCard';
import FlaggedByLabelsCard from 'components/Analytics/Report/ReportDetails/FlaggedByLabelsCard';
import OverviewCard from 'components/Analytics/Report/ReportDetails/OverviewCard';

import { OverviewContentBreakdownsDataFragment } from '@Generated/graphql';
import { ROUTES } from '@Utils/helper/routes';
import { getAnalyticsInfo } from '@Utils/analytics/helper';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

const FORMAT = 'yyyy-MM-dd';
const TODAY = new Date();

interface Props {
  data: OverviewContentBreakdownsDataFragment;
  isFCRACompliant?: boolean;
}

const OverviewDetails = ({ data, isFCRACompliant }: Props) => {
  const theme = useTheme();
  const { isMobile } = useBreakpoints();

  const {
    flaggedContentsPercentage,
    hasFlaggedContents,
    hasDeletedFlaggedContents,
    flaggedIncludingDeletedCount,
    deletedPercentage,
  } = getAnalyticsInfo(data);

  return (
    <Row gutter={[theme.spacing.large, theme.spacing.large]}>
      {(hasFlaggedContents || hasDeletedFlaggedContents) && (
        <>
          <Col span={isMobile ? 24 : 12}>
            <ProgressCard
              title={`${data.deletedFlaggedContentsCount} out of ${flaggedIncludingDeletedCount}`}
              description="Flagged Posts Deleted"
              progress={deletedPercentage}
              color="primary.600"
            />
          </Col>
          <Col span={isMobile ? 24 : 12}>
            <ProgressCard
              title={`${flaggedContentsPercentage}%`}
              description="Flagged Posts Overall"
              progress={flaggedContentsPercentage}
              color="highlight.300"
            />
          </Col>
          <Col span={24} lg={hasFlaggedContents ? 12 : 24}>
            <OverallPostsCard
              nonFlaggedContentsCount={data.nonFlaggedContentsCount}
              flaggedContentsCount={data.flaggedContentsCount}
              deletedFlaggedContentsCount={data.deletedFlaggedContentsCount}
            />
          </Col>
        </>
      )}

      {hasFlaggedContents && (
        <>
          <Col span={24} lg={12}>
            <FlaggedByOriginsCard originsBreakdownData={data.flaggedByOriginsBreakdown} />
          </Col>
          <Col span={24}>
            <FlaggedByLabelsCard labelsBreakdownData={data.flaggedByLabelsBreakdown} />
          </Col>
          <Col span={24}>
            <OverviewCard
              timelineBreakdown={data.flaggedByTimelineBreakdown}
              endDateAt={format(TODAY, FORMAT)}
            />
          </Col>
        </>
      )}

      {isFCRACompliant && (
        <Col span={24}>
          <Text variant="caption">
            Thanks for choosing LifeBrand for your social media screening! By accessing, viewing, or
            using the platform or services, you certify that you have read, understand and agree to
            be legally bound by the <a href={ROUTES.TERMS_OF_USE}>Terms of Service</a> and{' '}
            <a href={ROUTES.PRIVACY}>Privacy Policy</a>. You further certify that you are at least
            18 years of age or older. You understand and agree that we do not guarantee the results
            are accurate, correct, or universally accepted. You understand that the services are
            based on various criteria, value judgments and other factors and the information
            provided by LifeBrand may not capture all items that may be considered problematic by
            everyone and that the information may not be considered problematic by everyone.
            LifeBrand does not guarantee the information provided and hereby disclaims any and all
            representations to that effect. If the platform or services are made available to you by
            an employer or potential employer, you acknowledge and agree that the conclusions or
            other information from the platform and services may be shared with such employer or
            potential employer. If you have any questions, please feel free to contact us through
            our website.
          </Text>
        </Col>
      )}
    </Row>
  );
};

export default OverviewDetails;
