export { default } from './OverviewDetails';
export * from './OverviewDetails';
