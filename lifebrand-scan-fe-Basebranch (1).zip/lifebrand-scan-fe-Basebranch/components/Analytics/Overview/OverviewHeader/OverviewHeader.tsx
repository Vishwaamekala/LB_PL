import React from 'react';

import HeaderCard from '@UI/HeaderCard';

import NoFlaggedPostsBanner from 'components/Analytics/NoFlaggedPostsBanner';

import { OverviewContentBreakdownsDataFragment } from '@Generated/graphql';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';
import { getAnalyticsInfo } from '@Utils/analytics/helper';

import { useAuthContext } from '@Utils/AuthContext';

import * as S from './OverviewHeader.styles';

type Props = {
  data: OverviewContentBreakdownsDataFragment;
  loading?: boolean;
  isFCRACompliant: boolean;
};

const OverviewHeader = ({ data, loading = false, isFCRACompliant }: Props) => {
  const { isMobile, isTablet } = useBreakpoints();
  const { hasBusinessDictionary } = useAuthContext();

  const { businessDictionaryContentsCount } = data;

  const { totalCount, hasFlaggedContents, hasDeletedFlaggedContents } = getAnalyticsInfo(data);

  const showDictionary =
    isFCRACompliant && hasBusinessDictionary && businessDictionaryContentsCount !== null;

  return (
    <S.Wrapper>
      {!hasFlaggedContents && (
        <NoFlaggedPostsBanner
          allFlaggedDeleted={hasDeletedFlaggedContents}
          isFCRACompliant={isFCRACompliant}
        />
      )}
      <S.CountersWrapper>
        <HeaderCard
          title={isMobile || isTablet ? 'Flagged' : 'Flagged Posts'}
          isSelected={false}
          count={data.flaggedContentsCount}
          loading={loading}
        />
        <HeaderCard
          title={isMobile || isTablet ? 'All' : 'All Posts'}
          isSelected={false}
          count={totalCount}
          loading={loading}
        />
        {showDictionary && (
          <HeaderCard
            title={isMobile ? 'Dictionary' : 'Custom Dictionary'}
            isSelected={false}
            count={businessDictionaryContentsCount || 0}
            loading={loading}
          />
        )}
      </S.CountersWrapper>
    </S.Wrapper>
  );
};

export default OverviewHeader;
