import styled from 'styled-components';
import { Row } from 'antd';

import { useBreakpoint } from '@Utils/style/breakpoint';
import { inlineGap } from '@Utils/style/gap';

export const Wrapper = styled(Row)`
  width: 100%;

  & > * {
    margin-bottom: ${({ theme }) => theme.spacing.large}px;

    ${useBreakpoint.mobile`
      margin-bottom: ${({ theme }) => theme.spacing.large + theme.spacing.medium}px;
    `}
  }
`;

export const CountersWrapper = styled.div`
  display: flex;
  width: 100%;
  ${({ theme }) => inlineGap(`${theme.spacing.large}px`)};

  ${useBreakpoint.mobile`
    ${({ theme }) => inlineGap(`${theme.spacing.medium}px`)};
  `}
`;
