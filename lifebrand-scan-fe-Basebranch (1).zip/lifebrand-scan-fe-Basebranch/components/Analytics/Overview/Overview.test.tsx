import React from 'react';

import { fireEvent, render, within } from '@testing-library/react';
import 'jest-canvas-mock';

import { theme } from 'theme/theme';
import { ThemeProvider } from 'styled-components';
import { MockedProvider, MockedResponse } from '@apollo/client/testing';

import Overview from './Overview';

import {
  mockOverviewContentBreakdownsFCRA,
  mockOverviewContentBreakdownsOverall,
} from '../mocks/constants';

import { SubscriptionContext, SubscriptionContextProps } from '@Utils/SubscriptionContext';

import { ReportType } from '@Generated/graphql';

const intersectionObserverMock = () => ({
  observe: () => null,
});
window.IntersectionObserver = jest.fn().mockImplementation(intersectionObserverMock);

type RenderProps = {
  subscriptionValue: SubscriptionContextProps;
  hasScanRunning?: boolean;
  finishedScansCount?: number;
  currentTab: ReportType;
  mocks: MockedResponse[];
};

const renderComponent = ({
  subscriptionValue,
  hasScanRunning = false,
  finishedScansCount = 5,
  currentTab,
  mocks,
}: RenderProps) => {
  return render(
    <ThemeProvider theme={theme}>
      <MockedProvider mocks={mocks} addTypename={false}>
        <SubscriptionContext.Provider value={subscriptionValue}>
          <Overview
            hasScanRunning={hasScanRunning}
            finishedScansCountData={{ finishedScansCount }}
            loadingCount={false}
            currentTab={currentTab}
            setCurrentTab={jest.fn()}
            setLoadingChildren={jest.fn()}
          />
        </SubscriptionContext.Provider>
      </MockedProvider>
    </ThemeProvider>,
  );
};

const generateTestData = () => {
  const subscriptions = {
    free: {
      features: {
        canScan: true,
        canUpgrade: true,
        canAccessAnalytics: false,
        canUseAdvancedDashboard: false,
      },
      plan: {
        name: 'Free',
        isCancellable: false,
        isCancelled: false,
        currentPeriodEnds: null,
      },
    },
    basic: {
      features: {
        canScan: false,
        canUpgrade: true,
        canAccessAnalytics: true,
        canUseAdvancedDashboard: true,
      },
      plan: {
        name: 'Basic',
        isCancellable: false,
        isCancelled: false,
        currentPeriodEnds: null,
      },
    },
    unlimited: {
      features: {
        canScan: true,
        canUpgrade: true,
        canAccessAnalytics: true,
        canUseAdvancedDashboard: true,
      },
      plan: {
        name: 'Unlimited',
        isCancellable: true,
        isCancelled: false,
        currentPeriodEnds: null,
      },
    },
  } as Record<string, Omit<SubscriptionContextProps, 'loading'>>;

  return {
    subscriptions,
  };
};

const testData = generateTestData();

// to avoid error TypeError: window.matchMedia is not a function
window.matchMedia =
  window.matchMedia ||
  function () {
    return {
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  };

describe('Overview', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders FCRA Banner when tab is FCRA Compliant', async () => {
    const { getByTestId, getByText } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.basic, loading: false },
      hasScanRunning: false,
      finishedScansCount: 5,
      currentTab: ReportType.Employer,
      mocks: [mockOverviewContentBreakdownsFCRA],
    });

    const TabsContainer = getByTestId('tabs');
    const FCRAToggle = within(TabsContainer).getByText(/FCRA Compliant/gi);
    const OverallDataToggle = within(TabsContainer).getByText(/Overall Data/gi);
    fireEvent.click(FCRAToggle);

    expect(FCRAToggle).toHaveStyle('background-color: rgb(255, 255, 255)');
    expect(OverallDataToggle).toHaveStyle('background-color: transparent');

    const FCRABanner = getByText(/What is FCRA Compliant Data/gi);
    expect(FCRABanner).toBeInTheDocument();
  });

  it('doesnt render FCRA Banner when tab is OverallData', async () => {
    const { getByTestId, queryByText } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.basic, loading: false },
      hasScanRunning: false,
      finishedScansCount: 5,
      currentTab: ReportType.Personal,
      mocks: [mockOverviewContentBreakdownsOverall],
    });

    const TabsContainer = getByTestId('tabs');
    const OverallDataToggle = within(TabsContainer).getByText(/Overall Data/gi);
    const FCRAToggle = within(TabsContainer).getByText(/FCRA Compliant/gi);
    fireEvent.click(OverallDataToggle);

    expect(OverallDataToggle).toHaveStyle('background-color: rgb(255, 255, 255)');
    expect(FCRAToggle).toHaveStyle('background-color: transparent');

    expect(queryByText(/What is FCRA Compliant Data/gi)).not.toBeInTheDocument();
  });
});
