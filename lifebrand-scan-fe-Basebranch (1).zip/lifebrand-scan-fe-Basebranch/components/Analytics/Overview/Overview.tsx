import React, { useEffect } from 'react';

import OverviewDetails from './OverviewDetails';
import OverviewHeader from './OverviewHeader';
import { TABS_OPTIONS } from './constants';
import FCRAInfoBanner from './FCRAInfoBanner';

import OverviewSkeleton from '../GridSkeleton';

import AnalyticsUpgradeBanner from '../AnalyticsUpgradeBanner';
import NoAnalyticsBanner from '../NoAnalyticsBanner';

import { Tabs } from '@UI/meeseeks';
import { Spacing } from '@UI/Spacing';
import ScanButton from 'components/ScanButton';

import ScanningBanner from '../ScanningBanner';

import { TriggerClass } from '@Utils/google-tag-manager';

import { useAnalyticsDataForBanners } from '@Utils/analytics/useAnalyticsDataForBanners';
import { useSubscriptionContext } from '@Utils/SubscriptionContext/useSubscriptionContext';

import {
  FinishedScansCountQuery,
  ReportType,
  useOverviewContentBreakdownsQuery,
} from '@Generated/graphql';

interface Props {
  hasScanRunning?: boolean;
  finishedScansCountData?: FinishedScansCountQuery;
  loadingCount: boolean;
  currentTab: ReportType;
  setCurrentTab: (tab: ReportType) => void;
  setLoadingChildren: (state: boolean) => void;
}

const Overview = ({
  hasScanRunning,
  finishedScansCountData,
  loadingCount,
  currentTab,
  setCurrentTab,
  setLoadingChildren,
}: Props) => {
  const { features } = useSubscriptionContext();
  const isFCRA = currentTab === ReportType.Employer;
  const { data: contentsBreakdown, loading } = useOverviewContentBreakdownsQuery({
    variables: {
      input: {
        FCRACompliant: isFCRA,
      },
    },
  });

  const { noFinishedScan } = useAnalyticsDataForBanners(finishedScansCountData?.finishedScansCount);
  const isLoading = loading || loadingCount;

  useEffect(() => {
    setLoadingChildren(isLoading);
  }, [isLoading]);

  if (hasScanRunning) {
    return <ScanningBanner />;
  }

  if (features?.canAccessAnalytics === false) {
    return (
      <AnalyticsUpgradeBanner
        title={
          <>
            Want to see detailed analysis
            <br />
            of your social media?
          </>
        }
      />
    );
  }

  if (noFinishedScan) {
    return (
      <NoAnalyticsBanner
        title="No posts were scanned yet."
        description="To view analytics we need to scan some posts first."
        actionButton={
          <ScanButton
            variant="primary"
            size="medium"
            triggerClassName={TriggerClass.RunScanOverview}
          />
        }
      />
    );
  }

  return (
    <>
      <div data-testid="tabs">
        <Tabs
          tabs={TABS_OPTIONS}
          activeTab={currentTab}
          onTabChange={(tab) => tab && setCurrentTab(tab.key as ReportType)}
        />
      </div>
      <Spacing size="large" />
      {isFCRA && <FCRAInfoBanner />}
      {isLoading || !contentsBreakdown ? (
        <OverviewSkeleton />
      ) : (
        <>
          <OverviewHeader
            data={contentsBreakdown.overviewContentBreakdowns}
            loading={loading}
            isFCRACompliant={isFCRA}
          />
          <OverviewDetails
            data={contentsBreakdown.overviewContentBreakdowns}
            isFCRACompliant={isFCRA}
          />
        </>
      )}
    </>
  );
};

export default Overview;
