export { default } from './FCRAInfoBanner';
export * from './FCRAInfoBanner';
