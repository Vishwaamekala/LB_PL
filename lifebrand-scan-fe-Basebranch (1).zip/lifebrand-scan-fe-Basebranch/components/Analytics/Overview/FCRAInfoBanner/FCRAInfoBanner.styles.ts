import styled from 'styled-components';

import { Text as TextBase, Icon as IconBase } from '@UI/meeseeks';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Card = styled.div`
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  background-color: ${({ theme }) => theme.meeseeks.color['primary.200']};
  padding: ${({ theme }) => theme.spacing.extraLarge}px
    ${({ theme }) => theme.spacing.extraLarge + theme.spacing.small}px;
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  z-index: 1;
  height: 200px;
  overflow: hidden;
  margin-bottom: ${({ theme }) => theme.spacing.extraLarge}px;

  ${useBreakpoint.tablet`
    height: 260px;
  `}

  ${useBreakpoint.mobile`
    padding: ${({ theme }) => `${theme.spacing.medium * 2}px ${theme.spacing.large}px`};
    height: 420px;
    flex-direction: column;
  `}
`;

export const Content = styled.div``;

export const CheckBoxWrapper = styled.div`
  display: flex;
  align-items: center;
`;

export const Image = styled.img`
  width: 250px;
  z-index: -1;

  ${useBreakpoint.tablet`
    width: 174px;
  `}
`;

export const Text = styled(TextBase)`
  padding-left: ${({ theme }) => theme.spacing.small}px;
`;

export const Icon = styled(IconBase)`
  position: absolute;
  right: ${({ theme }) => theme.spacing.medium}px;
  top: ${({ theme }) => theme.spacing.medium}px;
  cursor: pointer;
`;
