import React, { useCallback, useEffect, useState } from 'react';

import { Checkbox, Heading, Text } from '@UI/meeseeks';

import useLocalStorage from '@Utils/storage/useLocalStorage';
import { userAcknowledgesFCRA } from '@Utils/storage/localStorageKeys';
import { useAuthContext } from '@Utils/AuthContext';

import * as S from './FCRAInfoBanner.styles';

const FCRAInfoBanner = () => {
  const { userData } = useAuthContext();
  const [visible, setVisible] = useState(true);
  const [checked, setChecked] = useState(false);
  const [acknowledgeFCRA, setAcknowledgeFCRA] = useLocalStorage<boolean>(
    userAcknowledgesFCRA(userData?.id),
    false,
  );

  useEffect(() => setVisible(!acknowledgeFCRA), [acknowledgeFCRA]);

  const handleDoNotShow = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      setChecked(event.target.checked);
    },
    [setChecked],
  );

  const handleDoNeverShow = useCallback(() => {
    if (checked) {
      setAcknowledgeFCRA(true);
    }
    setVisible(false);
  }, [checked, setAcknowledgeFCRA]);

  if (!visible) {
    return null;
  }

  return (
    <S.Card>
      <S.Content>
        <Heading variant="h5" marginBottom="medium" textColor="heading">
          What is FCRA Compliant Data?
        </Heading>
        <Text variant="regular" textColor="body" marginBottom="medium">
          The numbers shown in Overall Data might differ from the
          <br />
          FCRA Compliant Data. That’s because FCRA compliant data is
          <br />
          only available for the previous seven years.
        </Text>
        <S.CheckBoxWrapper>
          <Checkbox onChange={handleDoNotShow} checked={checked} />
          <S.Text variant="regular">Don’t show this again</S.Text>
        </S.CheckBoxWrapper>
      </S.Content>
      <S.Image src="/images/png/deletion-confirmation-img.png" alt="confirm" />
      <S.Icon name="X" color="secondary" size={24} onClick={handleDoNeverShow} />
    </S.Card>
  );
};

export default FCRAInfoBanner;
