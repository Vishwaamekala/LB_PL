import { ReportType } from '@Generated/graphql';

export enum TabsValue {
  OverallData = 'Overall Data',
  FCRAData = 'FCRA Compliant',
}

export const TABS_OPTIONS = [
  { key: ReportType.Personal, title: TabsValue.OverallData },
  { key: ReportType.Employer, title: TabsValue.FCRAData },
];
