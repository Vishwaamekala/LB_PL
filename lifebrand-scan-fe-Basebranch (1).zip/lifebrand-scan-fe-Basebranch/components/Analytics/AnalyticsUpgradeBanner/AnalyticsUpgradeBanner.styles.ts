import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Card = styled.div`
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  background-color: ${({ theme }) => theme.meeseeks.color['primary.200']};
  padding-left: ${({ theme }) => theme.spacing.extraLarge + theme.spacing.small}px;
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  z-index: 1;
  height: 480px;

  ${useBreakpoint.mobile`
    padding: ${({ theme }) => theme.spacing.medium}px;
  `}
`;

export const Content = styled.div``;

export const Image = styled.img`
  width: 500px;
  position: absolute;
  right: 0;
  z-index: -1;

  ${useBreakpoint.mobile`
    width: 300px;
    bottom: 0;
  `}
`;
