import React from 'react';
import { useRouter } from 'next/router';

import { Button, Icon, Heading, Text } from '@UI/meeseeks';

import { ROUTES } from '@Utils/helper/routes';

import * as S from './AnalyticsUpgradeBanner.styles';

type Props = {
  title: string | React.ReactNode;
};

const AnalyticsUpgradeBanner = ({ title }: Props) => {
  const router = useRouter();

  return (
    <S.Card>
      <S.Content>
        <Heading variant="h3" textColor="heading" marginBottom="medium">
          {title}
        </Heading>
        <Text variant="regular" textColor="body" marginBottom="medium">
          To view and delete all of your
          <br />
          flagged posts, send reports and more
          <br />
          please upgrade!
        </Text>
        <Button
          iconLeft={<Icon name="Bolt" size={16} color="#fff" />}
          variant="secondary"
          size="medium"
          onClick={() => router.push(ROUTES.PLANS)}
        >
          Upgrade
        </Button>
      </S.Content>
      <S.Image src="/images/png/upgrade-overview-image.png" alt="upgrade" />
    </S.Card>
  );
};

export default AnalyticsUpgradeBanner;
