import React from 'react';

import LegacyReportMobile from './LegacyReportMobile';

import ReportDetails from 'components/Analytics/LegacyReport/ReportDetails';
import ReportHeader from 'components/Analytics/LegacyReport/UI/ReportHeader';

import { ReportOldDataFragment } from '@Generated/graphql';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

type Props = {
  reportData: ReportOldDataFragment;
  loading: boolean;
};

const LegacyReport = ({ reportData, loading }: Props) => {
  const { isMobile } = useBreakpoints();

  if (isMobile) {
    return <LegacyReportMobile reportData={reportData} loading={loading} />;
  }

  return (
    <>
      <ReportHeader reportData={reportData} loading={loading} />
      <ReportDetails reportData={reportData} />
    </>
  );
};

export default LegacyReport;
