import React from 'react';
import { Row, Col } from 'antd';
import { useTheme } from 'styled-components';

import OverviewCard from './OverviewCard';
import FlaggedWordsCard from './FlaggedWordsCard';
import FlaggedPostsCard from './FlaggedPostsCard';

import { Text } from '@UI/meeseeks';

import NoFlaggedPostsBanner from 'components/Analytics/NoFlaggedPostsBanner';

import { ROUTES } from '@Utils/helper/routes';

import { ReportOldDataFragment } from '@Generated/graphql';

interface Props {
  reportData: ReportOldDataFragment;
}

const ReportDetails = ({ reportData }: Props) => {
  const theme = useTheme();
  const noData = Object.keys(reportData.timelineBreakdown).length === 0;

  return (
    <Row gutter={[theme.spacing.large, theme.spacing.large]}>
      {noData ? (
        <Col span={24}>
          <NoFlaggedPostsBanner />
        </Col>
      ) : (
        <>
          <Col span={24} lg={12}>
            <FlaggedWordsCard profanitiesBreakdown={reportData.profanitiesBreakdown} />
          </Col>
          <Col span={24} lg={12}>
            <FlaggedPostsCard harmfulPostBreakdown={reportData.harmfulBreakdown} />
          </Col>
          <Col span={24}>
            <OverviewCard
              timelineBreakdown={reportData.timelineBreakdown}
              scanCreatedAt={reportData.createdAt}
            />
          </Col>
        </>
      )}
      <Col span={24}>
        <Text variant="small" marginBottom="large">
          To make sure all the reports are FCRA compliant, we display data only up to seven years
          back from the moment the scan was conducted.
        </Text>
        <Text variant="small">
          Thanks for choosing LifeBrand for your social media screening! By accessing, viewing, or
          using the platform or services, you certify that you have read, understand and agree to be
          legally bound by the <a href={ROUTES.TERMS_OF_USE}>Terms of Service</a> and{' '}
          <a href={ROUTES.PRIVACY}>Privacy Policy</a>. You further certify that you are at least 18
          years of age or older. You understand and agree that we do not guarantee the results are
          accurate, correct, or universally accepted. You understand that the services are based on
          various criteria, value judgments and other factors and the information provided by
          LifeBrand may not capture all items that may be considered problematic by everyone and
          that the information may not be considered problematic by everyone. LifeBrand does not
          guarantee the information provided and hereby disclaims any and all representations to
          that effect. If the platform or services are made available to you by an employer or
          potential employer, you acknowledge and agree that the conclusions or other information
          from the platform and services may be shared with such employer or potential employer. If
          you have any questions, please feel free to contact us through our website.
        </Text>
      </Col>
    </Row>
  );
};

export default ReportDetails;
