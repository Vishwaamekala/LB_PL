import React, { useMemo } from 'react';

import DonutGraph from '@UI/Graphs/DonutGraph';
import ReportCard from 'components/Analytics/Report/UI/ReportCard';

import { getTooltipConfig, getLegendConfig } from '../donutGraphConfig';
import { DonutGraphData } from '../types';
import { formatProfanitiesData } from '../utils';

import { ProfanitiesBreakdown } from '@Generated/graphql';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';
import { getProfanityColors } from '@Utils/profanityConfigOld/profanityTagsConfig';

type Props = {
  profanitiesBreakdown?: ProfanitiesBreakdown;
};

const FlaggedWordsCard = ({ profanitiesBreakdown }: Props) => {
  const { isMobile } = useBreakpoints();

  const formattedProfanitiesBreakdown = useMemo(() => {
    if (!profanitiesBreakdown) {
      return [];
    }
    return formatProfanitiesData(profanitiesBreakdown);
  }, [profanitiesBreakdown]);

  if (!profanitiesBreakdown) {
    return <div>{'No data'}</div>;
  }

  return (
    <ReportCard headerText="Flagged Posts Breakdown" headerVariant={isMobile ? 'h5' : 'h3'}>
      <DonutGraph<DonutGraphData>
        data={formattedProfanitiesBreakdown}
        angleField="value"
        colorField="type"
        color={getProfanityColors}
        height={isMobile ? 120 : 196}
        legend={getLegendConfig(formattedProfanitiesBreakdown)}
        tooltip={getTooltipConfig(formattedProfanitiesBreakdown)}
      />
    </ReportCard>
  );
};

export default FlaggedWordsCard;
