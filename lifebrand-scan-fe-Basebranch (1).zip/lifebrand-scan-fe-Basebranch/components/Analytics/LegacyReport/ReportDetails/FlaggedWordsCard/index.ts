export { default } from './FlaggedWordsCard';
export * from './FlaggedWordsCard';
