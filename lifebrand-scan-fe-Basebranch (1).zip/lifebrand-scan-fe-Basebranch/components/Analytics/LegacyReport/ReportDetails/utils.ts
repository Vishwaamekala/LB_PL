import { DonutGraphData } from './types';

import { PROFANITY_DETAILS } from '@Utils/profanityConfigOld/constants';

import {
  HarmfulBreakdown,
  Profanities,
  ProfanitiesBreakdown,
  SocialMedia,
} from '@Generated/graphql';

const SocialMedias = [SocialMedia.Facebook, SocialMedia.Twitter, SocialMedia.Instagram];

export const sanitizeHarmfulPostBreakdown = (breakdown: HarmfulBreakdown) =>
  SocialMedias.reduce(
    (prev, socialMedia) => ({
      ...prev,
      [socialMedia]: breakdown[socialMedia],
    }),
    {
      [SocialMedia.Facebook]: 0,
      [SocialMedia.Twitter]: 0,
      [SocialMedia.Instagram]: 0,
    },
  );

export const formatHarmfulData = (data: HarmfulBreakdown): DonutGraphData[] =>
  Object.entries(sanitizeHarmfulPostBreakdown(data))
    .map(([type, value]) => ({
      type,
      value,
    }))
    .filter((profanity) => profanity.value !== 0);

export const formatProfanitiesData = (data: ProfanitiesBreakdown): DonutGraphData[] =>
  Object.values(Profanities)
    .map((key) => ({
      type: PROFANITY_DETAILS[key].title,
      value: data[key],
    }))
    .filter((profanity) => profanity.value !== 0);
