import { theme } from 'theme/theme';

export enum TabsValue {
  Months = 'Months',
  Years = 'Years',
}

export const TABS_OPTIONS = [
  { key: TabsValue.Months, title: TabsValue.Months, disabled: false },
  { key: TabsValue.Years, title: TabsValue.Years, disabled: false },
];

export const FONT_FAMILY = 'Poppins';
export const FONT_SIZE = 14;
export const FONT_SIZE_LABEL = 12;
export const COLOR_AXIS_LINE = theme.meeseeks.color['primary.100'];
export const COLOR_LABEL = theme.meeseeks.color.caption;
export const COLOR_TEXT = theme.meeseeks.color.body;

export const GRAPH_STYLES = {
  fontFamily: FONT_FAMILY,
  fontSize: FONT_SIZE,
  fontSizeLabel: FONT_SIZE_LABEL,
  colorAxisLine: COLOR_AXIS_LINE,
  colorLabel: COLOR_LABEL,
  colorText: COLOR_TEXT,
};
