export { default } from './FlaggedPostsCard';
export * from './FlaggedPostsCard';
