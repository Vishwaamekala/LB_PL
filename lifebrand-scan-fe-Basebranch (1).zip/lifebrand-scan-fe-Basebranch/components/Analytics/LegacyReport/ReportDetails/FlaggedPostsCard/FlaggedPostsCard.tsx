import React, { useMemo } from 'react';

import { DonutGraphData } from '../types';

import ReportCard from 'components/Analytics/Report/UI/ReportCard';
import DonutGraph from '@UI/Graphs/DonutGraph';
import { getColors } from '@UI/Graphs/utils/socialMediaConfig';

import { getLegendConfig, getTooltipConfig } from '../donutGraphConfig';
import { formatHarmfulData } from '../utils';

import { HarmfulBreakdown } from '@Generated/graphql';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

type Props = {
  harmfulPostBreakdown?: HarmfulBreakdown;
};

const FlaggedPostsCard = ({ harmfulPostBreakdown }: Props) => {
  const { isMobile } = useBreakpoints();

  const formattedHarmfulPostBreakdown = useMemo(() => {
    if (!harmfulPostBreakdown) {
      return [];
    }
    return formatHarmfulData(harmfulPostBreakdown);
  }, [harmfulPostBreakdown]);

  if (!harmfulPostBreakdown) {
    return <div>{'No data'}</div>;
  }

  return (
    <ReportCard headerText="Flagged Posts by Social Media" headerVariant={isMobile ? 'h5' : 'h3'}>
      <DonutGraph<DonutGraphData>
        data={formattedHarmfulPostBreakdown}
        angleField="value"
        colorField="type"
        color={getColors}
        height={isMobile ? 120 : 196}
        legend={getLegendConfig(formattedHarmfulPostBreakdown)}
        tooltip={getTooltipConfig(formattedHarmfulPostBreakdown)}
      />
    </ReportCard>
  );
};

export default FlaggedPostsCard;
