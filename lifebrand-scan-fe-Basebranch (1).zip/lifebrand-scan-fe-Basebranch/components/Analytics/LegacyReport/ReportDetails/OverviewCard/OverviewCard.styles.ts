import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Wrapper = styled.div<{ onlyToggle: boolean }>`
  display: grid;
  align-items: center;

  ${({ onlyToggle, theme }) =>
    !onlyToggle &&
    `
    display: grid;
    grid-template-columns: auto 1fr;
    gap: ${theme.spacing.small}px;
  `}
`;

export const Header = styled.div`
  display: flex;
  justify-content: space-between;
  width: 100%;
  margin-bottom: ${({ theme }) => theme.spacing.medium * 2}px;

  ${useBreakpoint.mobile`
    flex-direction: column;
    margin-bottom: ${({ theme }) => theme.spacing.large}px;
  `}
`;

export const WrapperToggle = styled.div`
  margin-bottom: ${({ theme }) => theme.spacing.large}px;
`;
