import React, { useState, useMemo, useEffect } from 'react';

import { formatYearlyBreakDown, aggregateOverviewYearData } from './utils';

import ReportCard from 'components/Analytics/Report/UI/ReportCard';
import ValuePicker from 'components/Analytics/Report/UI/ReportCard/ValuePicker';
import ColumnGraph from '@UI/Graphs/ColumnGraph';

import { Heading, Tabs } from '@UI/meeseeks';
import { getColors } from '@UI/Graphs/utils/socialMediaConfig';

import {
  ColumnGraphLegendConfig,
  ColumnGraphTooltipConfig,
  ColumnGraphXAxisConfig,
  ColumnGraphYAxisConfig,
} from '../columnGraphConfig';
import { ColumnGraphData, TimelineBreakdown, YearlyData } from '../types';
import { TabsValue, TABS_OPTIONS } from '../constants';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import * as S from './OverviewCard.styles';

type Props = {
  timelineBreakdown?: TimelineBreakdown;
  scanCreatedAt: string;
};

const OverviewCardIndividual = ({ timelineBreakdown, scanCreatedAt }: Props) => {
  const [selectedIndex, setSelectedIndex] = useState<number>(0);
  const [currentView, setCurrentView] = useState<string>(TabsValue.Months);
  const yearOfScan = scanCreatedAt.split('-')[0];

  const { isMobile } = useBreakpoints();

  const columnData = useMemo(
    () => (timelineBreakdown ? formatYearlyBreakDown(timelineBreakdown) : []),
    [timelineBreakdown],
  );

  useEffect(() => {
    setSelectedIndex(columnData.length - 1);
  }, [columnData]);

  const [selectedYear, previousYear, nextYear] = useMemo(() => {
    const selected = columnData[selectedIndex];
    if (!selected) return [undefined, undefined, undefined];

    const previous = columnData[selectedIndex - 1];
    const next = columnData[selectedIndex + 1];

    return [selected, previous ?? undefined, next ?? undefined];
  }, [selectedIndex]);

  const changeYear = (year: YearlyData) => {
    const selectedYearIndex = columnData.findIndex((data) => data.year === year.year);
    if (selectedYearIndex >= 0) {
      setSelectedIndex(selectedYearIndex);
    }
  };

  if (!timelineBreakdown) {
    return <div>{'No data'}</div>;
  }

  return (
    <ReportCard
      headerComponent={
        <S.Header>
          <Heading variant={isMobile ? 'h5' : 'h3'} marginBottom={isMobile ? 'medium' : 'large'}>
            Overview of Flagged Posts
          </Heading>
          <S.Wrapper onlyToggle={currentView === TabsValue.Years}>
            {currentView === TabsValue.Months && (
              <ValuePicker<YearlyData>
                value={`${selectedYear?.year}`}
                prev={previousYear}
                next={nextYear}
                onChange={changeYear}
              />
            )}
            <Tabs
              tabs={TABS_OPTIONS}
              activeTab={currentView}
              onTabChange={(tab) => tab && setCurrentView(tab.key)}
            />
          </S.Wrapper>
        </S.Header>
      }
    >
      {columnData && (
        <ColumnGraph<ColumnGraphData>
          data={
            currentView === TabsValue.Years
              ? aggregateOverviewYearData(timelineBreakdown, yearOfScan)
              : selectedYear!.data
          }
          xField="date"
          yField="value"
          seriesField="type"
          color={getColors}
          legend={ColumnGraphLegendConfig}
          xAxis={ColumnGraphXAxisConfig}
          yAxis={ColumnGraphYAxisConfig}
          tooltip={ColumnGraphTooltipConfig}
          minColumnWidth={20}
          interactions={[
            {
              type: 'active-region',
              enable: false,
            },
          ]}
        />
      )}
    </ReportCard>
  );
};

export default OverviewCardIndividual;
