import { ColumnGraphData } from './types';
import { GRAPH_STYLES } from './constants';

import { ColumnGraphProps } from '@UI/Graphs/ColumnGraph/ColumnGraph';

export const ColumnGraphLegendConfig: ColumnGraphProps<ColumnGraphData>['legend'] = {
  offsetY: 7,
  position: 'bottom',
  marker: {
    symbol: 'circle',
  },
  itemName: {
    style: {
      fontSize: GRAPH_STYLES.fontSize,
      lineHeight: 18,
      fontFamily: GRAPH_STYLES.fontFamily,
      fill: GRAPH_STYLES.colorText,
    },
  },
};

export const ColumnGraphXAxisConfig: ColumnGraphProps<ColumnGraphData>['xAxis'] = {
  label: {
    offset: 16,
    style: {
      fontFamily: GRAPH_STYLES.fontFamily,
      fill: GRAPH_STYLES.colorLabel,
      fontSize: GRAPH_STYLES.fontSizeLabel,
      lineHeight: 17,
    },
  },

  tickLine: null,
  line: {
    style: {
      opacity: 0,
    },
  },
};

export const ColumnGraphYAxisConfig: ColumnGraphProps<ColumnGraphData>['yAxis'] = {
  label: {
    offset: 16,
    style: {
      fontFamily: GRAPH_STYLES.fontFamily,
      fill: GRAPH_STYLES.colorLabel,
      fontSize: GRAPH_STYLES.fontSizeLabel,
      lineHeight: 17,
    },
  },
  line: {
    style: {
      stroke: GRAPH_STYLES.colorAxisLine,
      lineDash: [1, 4],
      opacity: 0,
    },
  },
  grid: {
    line: {
      style: {
        lineWidth: 3,
        stroke: GRAPH_STYLES.colorAxisLine,
        lineDash: [1, 4],
      },
    },
  },
};

export const ColumnGraphTooltipConfig: ColumnGraphProps<ColumnGraphData>['tooltip'] = {
  domStyles: {
    'g2-tooltip': {
      opacity: 1,
      fontFamily: GRAPH_STYLES.fontFamily,
      fontSize: GRAPH_STYLES.fontSize,
      lineHeight: '18px',
      color: GRAPH_STYLES.colorText,
      borderRadius: '4px',
      boxShadow:
        '0px 2px 4px rgba(0, 0, 0, 0.04), 0px 4px 5px rgba(0, 0, 0, 0.02), 0px 1px 10px rgba(0, 0, 0, 0.1)',
    },
  },
};
