export { default } from './ReportDetails';
export * from './ReportDetails';
