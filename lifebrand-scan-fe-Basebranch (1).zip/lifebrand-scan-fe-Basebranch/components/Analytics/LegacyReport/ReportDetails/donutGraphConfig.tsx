import { DonutGraphData } from './types';
import { GRAPH_STYLES } from './constants';

import { DonutGraphProps } from '@UI/Graphs/DonutGraph';

export const getLegendConfig: (
  data: DonutGraphData[],
) => DonutGraphProps<DonutGraphData>['legend'] = (data) => ({
  offsetX: -25,
  itemName: {
    style: {
      fontSize: GRAPH_STYLES.fontSize,
      fontFamily: GRAPH_STYLES.fontFamily,
      fill: GRAPH_STYLES.colorText,
    },
  },
  itemValue: {
    formatter: (text, item) => {
      const items = data.filter((d) => d.type === item.value);
      return `${items.length && text ? items.map((a) => a.value) : '0'}`;
    },
    style: {
      fontSize: GRAPH_STYLES.fontSize,
      fontFamily: GRAPH_STYLES.fontFamily,
      fill: GRAPH_STYLES.colorText,
      fontWeight: 'bold',
    },
  },
  marker: {
    symbol: 'circle',
  },
});

export const getTooltipConfig = (data: DonutGraphData[]) => {
  const tooltip: DonutGraphProps<DonutGraphData>['tooltip'] = {
    domStyles: {
      'g2-tooltip': {
        opacity: 1,
        fontFamily: GRAPH_STYLES.fontFamily,
        fontSize: GRAPH_STYLES.fontSize,
        lineHeight: '18px',
        color: GRAPH_STYLES.colorText,
        borderRadius: '4px',
        boxShadow:
          '0px 2px 4px rgba(0, 0, 0, 0.04), 0px 4px 5px rgba(0, 0, 0, 0.02), 0px 1px 10px rgba(0, 0, 0, 0.1)',
      },
    },
    formatter: (datum) => {
      const total = data.reduce((a, { value }) => a + value, 0);
      const percentageFromTotal = (datum.value * 100) / total;
      return { name: datum.type, value: `${percentageFromTotal.toFixed(1)} %` };
    },
  };
  return tooltip;
};
