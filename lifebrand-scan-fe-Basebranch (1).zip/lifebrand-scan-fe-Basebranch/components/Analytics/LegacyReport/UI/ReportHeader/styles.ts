import styled from 'styled-components';

import { Heading as HeadingBase } from '@UI/meeseeks';

import { useBreakpoint } from '@Utils/style/breakpoint';
import { breakpointSizes } from '@Utils/hooks/useBreakpoints';

export const Icon = styled.img`
  height: 40px;
  width: 40px;
`;

export const Counter = styled.span`
  font-family: Poppins;
  font-weight: 600;
  font-size: 32px;
  line-height: 32px;
  color: ${({ theme }) => theme.color.primary};
  margin-left: ${({ theme }) => theme.spacing.small}px;
`;

export const Heading = styled(HeadingBase)`
  line-height: 40px;
`;

// Styled components for Individual Report updates

export const Wrapper = styled.div`
  & > * {
    margin-bottom: ${({ theme }) => theme.spacing.large}px;
  }
`;

export const HeaderCard = styled.div`
  padding: ${({ theme }) => theme.spacing.medium}px;
  border-bottom: 1px solid ${({ theme }) => theme.meeseeks.color.tertiary};
  display: flex;

  justify-content: space-between;
  align-items: center;

  ${useBreakpoint.mdDesktop`
    justify-content:unset;
    align-items: unset;
  `}
`;

export const Actions = styled.div`
  display: flex;
  align-items: center;

  & > * {
    margin-left: ${({ theme }) => theme.spacing.medium}px;

    ${useBreakpoint.smDesktop`
      margin-left: ${({ theme }) => theme.spacing.medium / 2}px;
    `}
  }
`;

export const DateCounters = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  background-color: ${({ theme }) => theme.meeseeks.color['neutrals.100']};
  min-width: 300px;
  padding: ${({ theme }) => theme.spacing.medium}px;

  @media screen and (max-width: ${breakpointSizes.isDesktop[0]}px) {
    justify-content: space-between;
    & > *:first-child {
      margin-left: 0px;
    }
  }
`;

export const CountersWrapper = styled.div`
  display: flex;
`;
