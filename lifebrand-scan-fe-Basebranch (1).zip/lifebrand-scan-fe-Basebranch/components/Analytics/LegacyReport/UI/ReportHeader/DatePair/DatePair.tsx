import React, { useMemo } from 'react';

import { format, parseISO } from 'date-fns';

import { Heading, HeadingElements } from '@UI/meeseeks';

import * as S from './DatePair.styles';

type DatePairProps = {
  title: string;
  value?: string;
  variant?: HeadingElements[number];
};

const DatePair = ({ title, value, variant = 'h6' }: DatePairProps) => {
  const date = useMemo(() => (value ? format(parseISO(value), 'MMM d, y') : 'N/A'), [value]);

  return (
    <S.DateContainer>
      <Heading variant={variant} fontWeight={400} marginBottom="xxs" color="secondary">
        {title}
      </Heading>
      <S.StyledHeading variant={variant} fontWeight={600}>
        {date}
      </S.StyledHeading>
    </S.DateContainer>
  );
};

export default DatePair;
