import styled from 'styled-components';

import { Heading } from '@UI/meeseeks';

export const DateContainer = styled.div`
  display: flex;
  margin-bottom: ${({ theme }) => theme.spacing.small}px;
`;

export const StyledHeading = styled(Heading)`
  margin-left: ${({ theme }) => theme.spacing.small}px !important;
`;
