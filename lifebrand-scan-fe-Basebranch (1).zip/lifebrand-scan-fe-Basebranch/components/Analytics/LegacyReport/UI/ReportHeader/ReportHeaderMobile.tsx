import React from 'react';

import DatePair from './DatePair';
import CounterPair from './CounterPair';

import { Heading } from '@UI/meeseeks';

import { ReportOldDataFragment } from '@Generated/graphql';

import * as S from './ReportHeaderMobile.styles';

type Props = {
  reportData: ReportOldDataFragment;
  loading: boolean;
};

const ReportHeaderMobile = ({ reportData, loading }: Props) => {
  const noData = Object.keys(reportData.timelineBreakdown).length === 0;

  return (
    <S.Wrapper>
      <Heading variant="h3" fontWeight={600} textColor="heading">
        {reportData.User?.name || ''}
      </Heading>
      <S.Counters>
        <S.DateCounters>
          <DatePair title="Showing Data Back to:" value={reportData.startDate} />
          <DatePair title="Report Sent:" value={reportData.sentAt} />
        </S.DateCounters>
        {!noData && (
          <S.CounterPairWrapper>
            <CounterPair title="Flagged" value={reportData.harmfulPostCount} loading={loading} />
            <CounterPair title="Deleted" value={reportData.deletedPostCount} loading={loading} />
            <CounterPair title="Ignored" value={reportData.ignoredPostCount} loading={loading} />
          </S.CounterPairWrapper>
        )}
      </S.Counters>
    </S.Wrapper>
  );
};

export default ReportHeaderMobile;
