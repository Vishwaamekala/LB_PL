import styled from 'styled-components';

export const Wrapper = styled.div`
  & > * {
    margin-bottom: ${({ theme }) => theme.spacing.large}px;
  }

  // override parent padding so that the box shadow takes full width
  box-shadow: 0px 12px 12px -6px rgba(${({ theme }) => theme.color.primaryRgb}, 0.08);
  margin: 0px ${({ theme }) => -theme.spacing.medium}px ${({ theme }) => theme.spacing.medium}px;
  padding: 0px ${({ theme }) => theme.spacing.medium}px;
`;

export const Counters = styled.div`
  display: flex;
  flex-direction: column;

  & > * + * {
    margin-left: ${({ theme }) => theme.spacing.small}px;
  }
`;

export const DateCounters = styled.div`
  display: flex;
  width: 100%;
  padding-bottom: ${({ theme }) => theme.spacing.medium}px;
  flex-direction: column;
  padding: ${({ theme }) => theme.spacing.medium}px;
  background-color: ${({ theme }) => theme.meeseeks.color['neutrals.100']};
`;

export const CounterPairWrapper = styled.div`
  display: flex;
`;
