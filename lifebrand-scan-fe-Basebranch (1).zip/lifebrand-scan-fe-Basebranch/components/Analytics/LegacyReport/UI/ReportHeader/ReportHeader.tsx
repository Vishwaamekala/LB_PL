import React from 'react';

import CounterPair from './CounterPair';
import DatePair from './DatePair';

import { Heading } from '@UI/meeseeks';

import { ReportOldDataFragment } from '@Generated/graphql';

import * as S from './styles';

type Props = {
  reportData: ReportOldDataFragment;
  loading?: boolean;
};

const ReportHeader = ({ reportData, loading = false }: Props) => {
  return (
    <S.Wrapper>
      <S.HeaderCard>
        <Heading variant="h1" fontWeight={600} textColor="secondary">
          {reportData.User?.name || ''}
        </Heading>
      </S.HeaderCard>
      <S.CountersWrapper>
        <CounterPair
          title="All Flagged Posts"
          value={reportData.harmfulPostCount}
          loading={loading}
        />
        <CounterPair
          title="All Deleted Posts"
          value={reportData.deletedPostCount}
          loading={loading}
        />
        <CounterPair
          title="All Ignored Posts"
          value={reportData.ignoredPostCount}
          loading={loading}
        />
        <S.DateCounters>
          <DatePair title="Showing Data Back to:" value={reportData.startDate} />
          <DatePair title="Report Sent:" value={reportData.sentAt} />
        </S.DateCounters>
      </S.CountersWrapper>
    </S.Wrapper>
  );
};

export default ReportHeader;
