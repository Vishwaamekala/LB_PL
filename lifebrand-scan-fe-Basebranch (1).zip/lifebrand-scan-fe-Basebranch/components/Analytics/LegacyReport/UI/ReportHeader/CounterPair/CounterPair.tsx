import React from 'react';
import Skeleton from 'react-loading-skeleton';

import { Heading, HeadingElements } from '@UI/meeseeks';

import * as S from './CounterPair.styles';

type CounterPairProps = {
  title: string;
  value: number;
  loading: boolean;
  textSize?: HeadingElements[number];
  valueSize?: HeadingElements[number];
};

const CounterPair = ({
  title,
  value,
  textSize = 'h6',
  valueSize = 'h1',
  loading,
}: CounterPairProps) => {
  return (
    <S.Counter>
      <Heading variant={textSize} fontWeight={600} textColor="heading">
        {title}
      </Heading>
      <Heading variant={valueSize} fontWeight={600} marginBottom="xxs" textColor="secondary">
        {loading ? <Skeleton width={20} /> : value}
      </Heading>
    </S.Counter>
  );
};

export default CounterPair;
