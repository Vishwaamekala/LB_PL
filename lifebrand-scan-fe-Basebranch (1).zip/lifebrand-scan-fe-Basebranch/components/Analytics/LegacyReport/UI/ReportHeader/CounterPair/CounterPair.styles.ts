import styled from 'styled-components';

export const Counter = styled.div`
  position: relative;
  display: flex;
  height: 102px;
  flex-direction: column;
  flex: 2;
  padding: ${({ theme }) => `${theme.spacing.large}px ${theme.spacing.medium}px`};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
`;
