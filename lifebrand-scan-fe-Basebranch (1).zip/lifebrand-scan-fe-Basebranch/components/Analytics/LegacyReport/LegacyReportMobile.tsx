import React from 'react';

import ReportDetails from 'components/Analytics/LegacyReport/ReportDetails';
import ReportHeaderMobile from 'components/Analytics/LegacyReport/UI/ReportHeader/ReportHeaderMobile';

import { ReportOldDataFragment } from '@Generated/graphql';

type Props = {
  reportData: ReportOldDataFragment;
  loading: boolean;
};

const ReportIndividualMobile = ({ reportData, loading }: Props) => {
  return (
    <>
      <ReportHeaderMobile reportData={reportData} loading={loading} />
      <ReportDetails reportData={reportData} />
    </>
  );
};

export default ReportIndividualMobile;
