import React from 'react';
import Skeleton from 'react-loading-skeleton';

import * as S from './SkeletonGroup.styles';

type Props = {
  count: number;
};

const SkeletonGroup = ({ count }: Props) => {
  const placeHolderArray = new Array(count).fill('');

  const skeletonList = placeHolderArray.map((_, i) => (
    <S.SkeletonGroup key={i}>
      <Skeleton width="70%" height={40} />
      <div>
        <Skeleton width="40%" />
        <Skeleton width="90%" />
        <Skeleton width="30%" />
      </div>
      <Skeleton width="100%" />
    </S.SkeletonGroup>
  ));

  return <>{skeletonList}</>;
};

export default SkeletonGroup;
