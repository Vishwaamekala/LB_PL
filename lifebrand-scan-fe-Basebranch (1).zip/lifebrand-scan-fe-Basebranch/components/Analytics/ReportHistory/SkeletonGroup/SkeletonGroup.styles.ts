import styled from 'styled-components';

export const SkeletonGroup = styled.div`
  margin-top: ${({ theme }) => theme.spacing.medium}px;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  flex-direction: row;

  > div {
    display: flex;
    flex-direction: column;
    width: 80%;
  }

  > span {
    width: 10%;
  }
`;
