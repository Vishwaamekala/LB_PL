import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';
import { inlineGap } from '@Utils/style/gap';

export const Footer = styled.div`
  display: flex;
  align-items: center;
  ${({ theme }) => inlineGap(`${theme.spacing.small}px`)}
  position: fixed;
  bottom: ${({ theme }) => theme.spacing.large}px;

  @media screen and (max-height: 690px) {
    bottom: 0;
  }

  ${useBreakpoint.tablet`
    flex-direction: column;
    align-items: flex-start;
    z-index: 1;

    & > button {
      margin-bottom: ${({ theme }) => theme.spacing.medium}px;
    }
  `}
`;
