import React, { useEffect } from 'react';

import { useRouter } from 'next/router';

import ReportHistoryContent from './ReportHistoryContent';

import { Button, Icon, Text } from '@UI/meeseeks';

import { useAuthContext } from '@Utils/AuthContext';
import { ROUTES } from '@Utils/helper/routes';
import { signedQueryOptions } from '@Utils/reports/constants';

import { useHasLegacyReportsLazyQuery, useIndividualReportsQuery } from '@Generated/graphql';

import * as S from './ReportHistory.styles';

const ReportHistory = () => {
  const { userData } = useAuthContext();
  const userId = userData?.id;
  const router = useRouter();

  const { data, loading } = useIndividualReportsQuery(signedQueryOptions);

  const [fetchHasLegacyReports, { data: legacyData }] = useHasLegacyReportsLazyQuery();

  useEffect(() => {
    if (userId) {
      fetchHasLegacyReports({ variables: { userId } });
    }
  }, [fetchHasLegacyReports, userId]);

  return (
    <>
      <ReportHistoryContent reports={data?.individualReports} loading={loading} />
      {legacyData?.hasLegacyReports && (
        <S.Footer>
          <Button
            variant="tertiary"
            size="medium"
            iconLeft={<Icon name="Archive" color="neutrals.700" />}
            onClick={() => router.push(ROUTES.LEGACY_REPORTS)}
          >
            View Legacy Reports
          </Button>
          <Text variant="caption" textColor="caption">
            As we recently upgraded our AI, older reports could be found here.
          </Text>
        </S.Footer>
      )}
    </>
  );
};

export default ReportHistory;
