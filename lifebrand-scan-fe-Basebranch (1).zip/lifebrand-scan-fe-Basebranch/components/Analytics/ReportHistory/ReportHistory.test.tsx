import React from 'react';
import { useRouter } from 'next/router';

import { fireEvent, render, waitFor } from '@testing-library/react';
import 'jest-canvas-mock';

import { ThemeProvider } from 'styled-components';

import { MockedProvider, MockedResponse } from '@apollo/client/testing';

import { theme } from 'theme/theme';

import ReportHistory from './ReportHistory';

import {
  mockFinishedScansEqualZero,
  mockFinishedScansGreaterThanZero,
  mockIndividual0Report,
  mockIndividual2Report,
  mockIndividualFCRAReport,
  mockIndividualPersonalReport,
  TestReportInfo,
} from '../mocks/constants';

import { SubscriptionContext, SubscriptionContextProps } from '@Utils/SubscriptionContext';
import { ContextProps as AuthContextProps, useAuthContext } from '@Utils/AuthContext';
import { useScanContext } from '@Utils/ScanContext';
import { ROUTES } from '@Utils/helper/routes';
import { UserDataFragment } from '@Generated/graphql';

const intersectionObserverMock = () => ({
  observe: () => null,
});

jest.mock('next/router', () => ({
  useRouter: jest.fn().mockReturnValue({
    route: '/',
    pathname: '',
    query: '',
    asPath: '',
    push: jest.fn(),
  }),
}));

window.IntersectionObserver = jest.fn().mockImplementation(intersectionObserverMock);

jest.mock('@Utils/hooks/useConnections', () => ({
  ...jest.requireActual('@Utils/hooks/useConnections'),
  useConnections() {
    return {
      ...jest.requireActual('@Utils/hooks/useConnections'),
      isActionsDisabled: false,
      isAnySocialMediaConnected: true,
      isAuthenticated: true,
      socialMediaConnection: [
        {
          isConnected: true,
          isMainIdentity: false,
          socialMedia: 'Facebook',
          userName: 'Erica Lumley',
        },
      ],
    };
  },
}));

jest.mock('@Utils/AuthContext', () => ({
  ...jest.requireActual('@Utils/AuthContext'),
  useAuthContext: jest.fn(),
}));

jest.mock('@Utils/ScanContext', () => ({
  ...jest.requireActual('@Utils/ScanContext'),
  useScanContext: jest.fn(),
}));

const mockUseScan = (hasScanRunning = false) => {
  (useScanContext as jest.Mock).mockReturnValue({
    hasScanRunning,
  });
};

const mockUseAuth = (userData: AuthContextProps['userData'], isInvited = false) => {
  (useAuthContext as jest.Mock).mockReturnValue({
    userData,
    isInvited,
    triggerRefetch: (() => {}) as AuthContextProps['triggerRefetch'],
    loading: false,
    isLoggedIn: true,
    invitedBy: userData?.BusinessCustomer.filter((one) => one.isActive),
  });
};

type RenderProps = {
  subscriptionValue: SubscriptionContextProps;
  mockFinishedScansData?: MockedResponse;
  mockIndividualReportsData?: MockedResponse;
};

const renderComponent = ({
  subscriptionValue,
  mockFinishedScansData = mockFinishedScansEqualZero,
  mockIndividualReportsData = mockIndividual0Report,
}: RenderProps) => {
  return render(
    <ThemeProvider theme={theme}>
      <MockedProvider
        mocks={[mockFinishedScansData, mockIndividualReportsData]}
        addTypename={false}
      >
        <SubscriptionContext.Provider value={subscriptionValue}>
          <ReportHistory />
        </SubscriptionContext.Provider>
      </MockedProvider>
    </ThemeProvider>,
  );
};

const generateTestData = () => {
  const user = ({
    id: 'ckzoaok6312090ks6yvptlsyp',
    name: 'Erica Lumley',
    email: 'erica_lumley@mail.com',
    photo:
      'https://scontent-sea1-1.xx.fbcdn.net/v/t1.30497-1/cp0/c15.0.50.50a/p50x50/84628273_176159830277856_972693363922829312_n.jpg?_nc_cat=1&ccb=1-5&_nc_sid=12b3be&_nc_ohc=BIVkKoTaVNgAX-TqIzy&_nc_ht=scontent-sea1-1.xx&edm=AP4hL3IEAAAA&oh=00_AT8evaGQNy4bMH2P7o4O56jiboovC8eBO9VqukZEePIq-g&oe=62316738',
    scanAmount: -1,
    authId: 'facebook|107403778058630',
    stripeId: 'cus_LA9n0FjaUMm5R9',
    planId: null,
    createdAt: '2022-02-15T15:43:13.947Z',
    updatedAt: '2022-02-17T15:07:24.154Z',
    lastRefresh: null,
    acceptedFcraVersion: 'v1-2022',
    acceptedPolicyVersion: 'v2022-01-19',
    hasPassword: false,
    BusinessCustomer: [
      {
        id: 'ckzoaolhd12740ks6q4wldyxt',
        type: 'PotentialEmployee',
        isActive: false,
        Business: {
          id: 'cks0899i200071cs69vsucf88',
          name: 'qacoakslab1',
          contactEmail: 'qa1oaks@gmail.com',
          __typename: 'PublicBusiness',
        },
        __typename: 'BusinessCustomer',
      },
    ],
    __typename: 'User',
    Plan: null,
  } as unknown) as UserDataFragment;

  const subscriptions = {
    free: {
      features: {
        canScan: true,
        canUpgrade: true,
        canAccessAnalytics: false,
        canUseAdvancedDashboard: false,
      },
      plan: {
        name: 'Free',
        isCancellable: false,
        isCancelled: false,
        currentPeriodEnds: null,
      },
    },
    basic: {
      features: {
        canScan: false,
        canUpgrade: true,
        canAccessAnalytics: true,
        canUseAdvancedDashboard: true,
      },
      plan: {
        name: 'Basic',
        isCancellable: false,
        isCancelled: false,
        currentPeriodEnds: null,
      },
    },
    unlimited: {
      features: {
        canScan: true,
        canUpgrade: true,
        canAccessAnalytics: true,
        canUseAdvancedDashboard: true,
      },
      plan: {
        name: 'Unlimited',
        isCancellable: true,
        isCancelled: false,
        currentPeriodEnds: null,
      },
    },
  } as Record<string, Omit<SubscriptionContextProps, 'loading'>>;

  return {
    user,
    subscriptions,
  };
};

const testData = generateTestData();

describe('Report History', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders Banner for No posts scanned', async () => {
    mockUseAuth({ ...testData.user }, false);
    mockUseScan(false);
    const { findByText, getByRole } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      mockFinishedScansData: mockFinishedScansEqualZero,
    });

    expect(await findByText(/No posts/gi)).toBeInTheDocument();

    const scanButton = getByRole('button', { name: /Scan/gi });
    expect(scanButton).toBeEnabled();
  });

  it('renders Banner for No reports created', async () => {
    mockUseAuth({ ...testData.user }, false);
    mockUseScan(false);
    const { findByText, getByRole } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      mockFinishedScansData: mockFinishedScansGreaterThanZero,
    });

    expect(await findByText(/No reports/gi)).toBeInTheDocument();

    const redirectButton = getByRole('button', { name: /Overview/gi });
    expect(redirectButton).toBeEnabled();
  });

  it('renders Upgrade Banner for Free User', async () => {
    mockUseAuth({ ...testData.user }, false);
    mockUseScan(false);
    const { findByRole } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.free, loading: false },
      mockFinishedScansData: mockFinishedScansGreaterThanZero,
    });

    const upgradeButton = await findByRole('button', { name: /Upgrade/gi });
    expect(upgradeButton).toBeEnabled();
  });

  it('renders Scan In Progress Banner when running scan', async () => {
    mockUseAuth({ ...testData.user }, false);
    mockUseScan(true);
    const { findByText } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.free, loading: true },
      mockFinishedScansData: mockFinishedScansEqualZero,
    });

    expect(await findByText(/Scan In Progress/i)).toBeInTheDocument();
  });

  it('renders report logs and their buttons', async () => {
    mockUseAuth({ ...testData.user }, false);
    mockUseScan(false);
    const { findAllByTestId, getAllByRole } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      mockFinishedScansData: mockFinishedScansGreaterThanZero,
      mockIndividualReportsData: mockIndividual2Report,
    });

    expect(await findAllByTestId(/reportLog/)).toHaveLength(2);
    expect(getAllByRole('button', { name: /View/i })).toHaveLength(2);
    expect(getAllByRole('link', { current: false })).toHaveLength(2);
  });

  it('renders elements for FCRA Reports - invited', async () => {
    mockUseAuth({ ...testData.user }, true);
    mockUseScan(false);
    const { findByTestId, getByRole, getByText } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      mockFinishedScansData: mockFinishedScansGreaterThanZero,
      mockIndividualReportsData: mockIndividualFCRAReport,
    });

    const reportLogFCRA = await findByTestId(`reportLog-${TestReportInfo.Employer.reportId}`);

    const viewButton = getByRole('button', { name: /View/i });
    const downloadButton = getByRole('link', { current: false }); // Behaviour covered in Report Individual
    const reportIcon = getByText(/💼/);

    expect(reportLogFCRA).toContainElement(viewButton);
    expect(reportLogFCRA).toContainElement(downloadButton);
    expect(reportLogFCRA).toContainElement(reportIcon);

    fireEvent.click(viewButton);
    await waitFor(() => {
      expect((useRouter as jest.Mock).mock.results[0].value.push).toBeCalledWith({
        pathname: ROUTES.REPORT,
        query: { id: TestReportInfo.Employer.reportId },
      });
    });

    const reportStatusTag = getByText(/Inviter/i);
    expect(reportStatusTag).toBeInTheDocument();

    expect(reportLogFCRA).toContainElement(reportStatusTag);
  });

  it('renders elements for Personal Reports - invited', async () => {
    mockUseAuth({ ...testData.user }, true);
    mockUseScan(false);

    const { findByTestId, getByRole, getByText, queryByRole } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      mockFinishedScansData: mockFinishedScansGreaterThanZero,
      mockIndividualReportsData: mockIndividualPersonalReport,
    });

    const reportLogFCRA = await findByTestId(`reportLog-${TestReportInfo.Personal.reportId}`);

    const viewButton = getByRole('button', { name: /View/i }); // Behaviour covered in previous test
    const downloadButton = getByRole('link', { current: false }); // Behaviour covered in Report Individual
    const reportIcon = getByText(/👨/);

    expect(queryByRole('tag', { name: /Inviter/i })).toBeNull();

    expect(reportLogFCRA).toContainElement(viewButton);
    expect(reportLogFCRA).toContainElement(downloadButton);
    expect(reportLogFCRA).toContainElement(reportIcon);
  });
});
