import styled from 'styled-components';

import { Text, Heading } from '@UI/meeseeks';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Wrapper = styled.div<{ isSelected?: boolean; isCursorEnabled?: boolean }>`
  position: relative;
  display: inline-flex;
  gap: ${({ theme }) => theme.spacing.medium}px;
  flex-direction: row;
  align-items: center;
  width: 100%;
  padding: ${({ theme }) => theme.spacing.medium}px;
  box-shadow: ${({ theme }) => theme.shadow.card};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;

  ${({ isCursorEnabled }) => isCursorEnabled && 'cursor: pointer;'}
  ${({ isSelected, theme }) => isSelected && `background-color: ${theme.color.primary};`}
`;

export const HeaderInfo = styled.div`
  position: absolute;
  top: ${({ theme }) => theme.spacing.medium}px;
  display: inline-flex;
  gap: ${({ theme }) => theme.spacing.small / 2}px;
  flex-direction: row;
`;

export const Content = styled.div`
  display: flex;
  flex: 1;
  flex-direction: column;
  margin-top: ${({ theme }) => theme.spacing.medium}px; // to keep the absolute HeaderInfo visible
`;

export const Caption = styled(Text)`
  line-height: 19px;
`;

export const Name = styled(Heading).attrs({
  variant: 'h6',
  textColor: 'heading',
  marginBottom: 'xxs',
})`
  margin-top: ${({ theme }) => theme.spacing.small / 2}px;
`;

export const Tags = styled.div`
  margin-right: ${({ theme }) => theme.spacing.extraLarge}px;

  ${useBreakpoint.tablet`
    margin-right: ${({ theme }) => theme.spacing.small}px;
  `}

  ${useBreakpoint.mobile`
    margin-top: ${({ theme }) => theme.spacing.small}px;

    & > div {
      display: inline-flex;
      margin: 0;
    }
  `}
`;

export const ActionButtons = styled.div`
  display: inline-flex;
  align-items: center;
  gap: ${({ theme }) => theme.spacing.medium}px;
`;
