import React, { useCallback, useMemo } from 'react';

import { Icon, Tag } from '@UI/meeseeks';
import SocialMediaIcon from '@UI/SocialMediaIcon';
import ViewReportButton from 'components/Analytics/ViewReportButton';
import ReportIcon from 'components/Analytics/Report/UI/ReportIcon';

import { formatDateDistance } from '@Utils/formatters/date';
import { calculatePercentage } from '@Utils/calculatePercentage';

import { ReportDataFragment, ReportType, SocialMedia } from '@Generated/graphql';

import { useAuthContext } from '@Utils/AuthContext';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import * as S from './ReportLog.styles';

type Props = {
  data: ReportDataFragment;
  hideActions?: boolean;
  isSelected?: boolean;
  onClick?: (id: string) => void;
};

const ReportLog = ({ data, hideActions, isSelected, onClick }: Props) => {
  const { isInvited } = useAuthContext();
  const { isMobile } = useBreakpoints();
  const allContentsCount = data.nonFlaggedContentsCount + data.flaggedContentsCount; // Deleted Posts are not counted
  const overallFlagged = calculatePercentage(data.flaggedContentsCount, allContentsCount);

  const isReportForEmployer = isInvited && data.type === ReportType.Employer;

  const handleOnClick = useCallback(() => {
    if (!hideActions) {
      return;
    }
    onClick?.(data.id);
  }, [onClick, data.id, hideActions]);

  const SentToInviterTag = useMemo(
    () =>
      isReportForEmployer && (
        <S.Tags>
          {data.isShared ? (
            <Tag variant="success">Sent to Inviter</Tag>
          ) : (
            <Tag variant="warning">Not Sent to Inviter</Tag>
          )}
        </S.Tags>
      ),
    [isReportForEmployer, data.isShared],
  );

  return (
    <S.Wrapper
      isSelected={isSelected}
      isCursorEnabled={hideActions}
      onClick={handleOnClick}
      data-testid={`reportLog-${data.id}`}
    >
      <ReportIcon reportType={data.type} />
      <S.Content>
        <S.HeaderInfo>
          <S.Caption variant="small" textColor="caption">
            {formatDateDistance(new Date(data.createdAt))}
          </S.Caption>
          <S.Caption variant="body" textColor="caption">
            ·
          </S.Caption>
          {Object.keys(SocialMedia).map((origin) => {
            const lastScanDate = data.originsLastScannedBreakdown[origin as SocialMedia];
            if (!lastScanDate) return <></>;
            return (
              <SocialMediaIcon
                socialMedia={origin as SocialMedia}
                size={16}
                color="caption"
                key={origin}
              />
            );
          })}
        </S.HeaderInfo>
        <S.Name>{data.name}</S.Name>
        <S.Caption variant="small" textColor="body">
          <b>{overallFlagged}% </b>
          flagged posts
        </S.Caption>
        {!hideActions && isMobile && SentToInviterTag}
      </S.Content>
      {!hideActions && !isMobile && SentToInviterTag}
      {!hideActions && (
        <S.ActionButtons>
          <a href={data.pdfUrl} target="_blank" rel="noreferrer" download>
            <Icon name="Download" size={16} color="neutrals.700" />
          </a>
          <ViewReportButton reportId={data.id} />
        </S.ActionButtons>
      )}
    </S.Wrapper>
  );
};

export default ReportLog;
