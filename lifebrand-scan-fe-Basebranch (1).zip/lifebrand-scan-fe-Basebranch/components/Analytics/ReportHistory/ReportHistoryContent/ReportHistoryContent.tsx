import React from 'react';

import ReportLog from './ReportLog';

import AnalyticsUpgradeBanner from 'components/Analytics/AnalyticsUpgradeBanner';
import NoAnalyticsBanner from 'components/Analytics/NoAnalyticsBanner';
import ScanningBanner from 'components/Analytics/ScanningBanner';
import ScanButton from 'components/ScanButton';
import AnalyticsOverviewButton from 'components/ActionButtons/AnalyticsOverviewButton';

import SkeletonGroup from '../SkeletonGroup';

import { TriggerClass } from '@Utils/google-tag-manager';

import { IndividualReportsQuery, useFinishedScansCountQuery } from '@Generated/graphql';
import { useAnalyticsDataForBanners } from '@Utils/analytics/useAnalyticsDataForBanners';
import { useScanContext } from '@Utils/ScanContext';
import { useSubscriptionContext } from '@Utils/SubscriptionContext/useSubscriptionContext';

import * as S from './ReportHistoryContent.styles';

type Props = {
  loading?: boolean;
  reports?: IndividualReportsQuery['individualReports'];
};

const ReportHistoryContent = ({ loading, reports }: Props) => {
  const { features } = useSubscriptionContext();

  const { data: finishedScansCountData, loading: loadingCount } = useFinishedScansCountQuery();

  const { hasReports, noScanOrReport, noFinishedScan } = useAnalyticsDataForBanners(
    finishedScansCountData?.finishedScansCount,
    reports,
  );
  const { hasScanRunning } = useScanContext();

  if ((loading && !reports) || loadingCount || !features) {
    return <SkeletonGroup count={5} />;
  }

  if (noFinishedScan && hasScanRunning) {
    return <ScanningBanner />;
  }

  if (!features?.canAccessAnalytics) {
    return (
      <AnalyticsUpgradeBanner
        title={
          <>
            Want to see export and share
            <br />
            reports?
          </>
        }
      />
    );
  }

  if (!hasReports) {
    return (
      <NoAnalyticsBanner
        title={noScanOrReport ? 'No posts were scanned yet.' : 'No reports were created yet.'}
        description={
          noScanOrReport
            ? 'To create report you need to scan your social media accounts first.'
            : 'First check your Analytics Overview, then you can Create Report from there. '
        }
        actionButton={
          noScanOrReport ? (
            <ScanButton
              variant="primary"
              size="medium"
              triggerClassName={TriggerClass.RunScanReportHistory}
            />
          ) : (
            <AnalyticsOverviewButton />
          )
        }
      />
    );
  }

  return (
    <S.Container>
      {reports?.map((report) => (
        <ReportLog key={report.id} data={report} />
      ))}
    </S.Container>
  );
};

export default ReportHistoryContent;
