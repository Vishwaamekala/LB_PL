import { GraphQLError } from 'graphql';

import {
  CreateReportDocument,
  FinishedScansCountDocument,
  IndividualReportsDocument,
  OverviewContentBreakdownsDocument,
  ReportType,
  SendReportPdfDocument,
  ShareReportDocument,
} from '@Generated/graphql';

export const mockFinishedScansEqualZero = {
  request: {
    query: FinishedScansCountDocument,
    variables: {},
  },
  result: {
    data: {
      finishedScansCount: 0,
    },
  },
};

export const mockFinishedScansGreaterThanZero = {
  request: {
    query: FinishedScansCountDocument,
    variables: {},
  },
  result: {
    data: {
      finishedScansCount: 1,
    },
  },
};

const mockOverviewContentBreakdownsData = {
  overviewContentBreakdowns: {
    flaggedContentsCount: 10,
    nonFlaggedContentsCount: 20,
    deletedFlaggedContentsCount: 5,
    flaggedByTimelineBreakdown: {
      '2021': {
        '0': { Facebook: 1, Twitter: 0, Instagram: 0 },
        '1': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '2': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '3': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '4': { Facebook: 0, Twitter: 1, Instagram: 0 },
        '5': { Facebook: 0, Twitter: 0, Instagram: 1 },
        '6': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '7': { Facebook: 0, Twitter: 1, Instagram: 2 },
        '8': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '9': { Facebook: 2, Twitter: 0, Instagram: 0 },
        '10': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '11': { Facebook: 0, Twitter: 1, Instagram: 0 },
      },
      '2022': {
        '0': { Facebook: 1, Twitter: 0, Instagram: 0 },
        '1': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '2': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '3': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '4': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '5': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '6': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '7': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '8': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '9': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '10': { Facebook: 0, Twitter: 0, Instagram: 0 },
        '11': { Facebook: 0, Twitter: 0, Instagram: 0 },
      },
    },
    flaggedByOriginsBreakdown: {
      Facebook: 4,
      Twitter: 3,
      Instagram: 3,
      __typename: 'OriginsBreakdown',
    },
    flaggedByLabelsBreakdown: {
      identity_attack: 0,
      insult: 3,
      obscene: 3,
      threat: 0,
      sexual_explicit: 2,
      sexual: 5,
      severe_toxicity: 0,
      toxicity: 0,
      inappropriate: 0,
      blasphemy: 0,
      discriminatory: 0,
      __typename: 'FlaggedPostLabelsBreakdownResponse',
    },
    __typename: 'OverviewContentBreakdownsResponse',
  },
};

export const mockOverviewContentBreakdownsFCRA = {
  request: {
    query: OverviewContentBreakdownsDocument,
    variables: {
      input: {
        FCRACompliant: true,
      },
    },
  },
  result: {
    data: {
      mockOverviewContentBreakdownsData,
    },
  },
};

export const mockOverviewContentBreakdownsOverallZero = {
  request: {
    query: OverviewContentBreakdownsDocument,
    variables: {
      input: {
        FCRACompliant: false,
      },
    },
  },
  result: {
    data: {
      overviewContentBreakdowns: {
        flaggedContentsCount: 0,
        nonFlaggedContentsCount: 0,
        deletedFlaggedContentsCount: 0,
        businessDictionaryContentsCount: 0,
        countByBusinessDictionaryBreakdown: { 0: 0 },
        flaggedByTimelineBreakdown: {
          '2021': {
            '0': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '1': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '2': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '3': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '4': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '5': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '6': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '7': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '8': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '9': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '10': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '11': { Facebook: 0, Twitter: 0, Instagram: 0 },
          },
          '2022': {
            '0': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '1': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '2': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '3': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '4': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '5': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '6': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '7': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '8': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '9': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '10': { Facebook: 0, Twitter: 0, Instagram: 0 },
            '11': { Facebook: 0, Twitter: 0, Instagram: 0 },
          },
        },
        flaggedByOriginsBreakdown: {
          Facebook: 0,
          Twitter: 0,
          Instagram: 0,
          __typename: 'OriginsBreakdown',
        },
        flaggedByLabelsBreakdown: {
          identity_attack: 0,
          insult: 0,
          obscene: 0,
          threat: 0,
          sexual_explicit: 0,
          sexual: 0,
          severe_toxicity: 0,
          toxicity: 0,
          inappropriate: 0,
          blasphemy: 0,
          discriminatory: 0,
          __typename: 'FlaggedPostLabelsBreakdownResponse',
        },
        __typename: 'OverviewContentBreakdownsResponse',
      },
    },
  },
};

export const mockOverviewContentBreakdownsOverall = {
  request: {
    query: OverviewContentBreakdownsDocument,
    variables: {
      input: {
        FCRACompliant: false,
      },
    },
  },
  result: {
    data: {
      mockOverviewContentBreakdownsData,
    },
  },
};

export const mockIndividual0Report = {
  request: {
    query: IndividualReportsDocument,
    variables: {},
  },
  result: {
    data: {
      individualReports: [],
    },
  },
};

export const TestReportInfo = {
  Employer: {
    reportId: 'ckyykddot07322uoeqr3ejy40',
    reportURL:
      'https://storage.googleapis.com/lifebrand-social-bff-develop.appspot.com/report-v2Pdf/1643383940215.pdf?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=github-ci-cd%40lifebrand-social-bff-develop.iam.gserviceaccount.com%2F20220224%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20220224T135415Z&X-Goog-Expires=901&X-Goog-SignedHeaders=host&X-Goog-Signature=00216e6fb91803d88bdd60ee1443a8ed4fe5149f80d9bae320070cab2c058cdcd6a2b36565ddfe257ccff1d33c646ebbe7aea45853d3fff67d566291222f8d8fd4f085698ece864e7a026eae64d8a6ef7e6411541d32f3e84b9b2f9a07c498288b6f4c56545179f20f765979c6c247eda6f1e5979b08ff2722314443edc2d31a19eba6e0c23791784ce08188ed2666f53a44aa02b0a42d49ced91ffd042b6f47395fdbb06dbdee616700ab7e6b163a3b1067ce23cc3e952fd715b343471f1fb426e37fbdfab9e65f91d3a213537d32c19622558d09772610efea224c18626e2696435825bae75093cde5769815af5b9196daf44905bfedf00d6c06c9ceaf7456',
    reportName: 'FCRA My Report',
  },
  Personal: {
    reportId: 'cttttddot07322uoeqr3ejy40',
    reportURL:
      'https://storage.googleapis.com/lifebrand-social-bff-develop.appspot.com/report-v2Pdf/1643383940215.pdf?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=github-ci-cd%40lifebrand-social-bff-develop.iam.gserviceaccount.com%2F20220224%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20220224T135415Z&X-Goog-Expires=901&X-Goog-SignedHeaders=host&X-Goog-Signature=00216e6fb91803d88bdd60ee1443a8ed4fe5149f80d9bae320070cab2c058cdcd6a2b36565ddfe257ccff1d33c646ebbe7aea45853d3fff67d566291222f8d8fd4f085698ece864e7a026eae64d8a6ef7e6411541d32f3e84b9b2f9a07c498288b6f4c56545179f20f765979c6c247eda6f1e5979b08ff2722314443edc2d31a19eba6e0c23791784ce08188ed2666f53a44aa02b0a42d49ced91ffd042b6f47395fdbb06dbdee616700ab7e6b163a3b1067ce23cc3e952fd715b343471f1fb426e37fbdfab9e65f91d3a213537d32c19622558d09772610efea224c18626e2696435825bae75093cde5769815af5b9196daf44905bfedf00d6c06c9ceaf7456',
    reportName: 'Personal Testing Report',
  },
};

export const mockCreateReportPersonal = {
  request: {
    query: CreateReportDocument,
    variables: {
      type: ReportType.Personal,
      name: TestReportInfo.Personal.reportName,
    },
  },
  result: {
    data: {
      createReport: {
        id: TestReportInfo.Personal.reportId,
        __typename: 'Report',
      },
    },
  },
};

export const mockCreateReportPersonalError = {
  request: {
    query: CreateReportDocument,
    variables: {
      type: ReportType.Personal,
      name: TestReportInfo.Personal.reportName,
    },
  },
  result: {
    errors: [new GraphQLError('Some backend error!')],
  },
};

export const individualReportEmployerDataShared = {
  __typename: 'Report',
  id: TestReportInfo.Employer.reportId,
  userId: 'ckwlyh99l06610ks6llxqvbee',
  type: ReportType.Employer,
  name: TestReportInfo.Employer.reportName,
  isFCRACompliant: true,
  createdAt: '2022-01-28T15:32:19.981Z',
  startDate: '2015-01-28T15:32:19.582Z',
  endDate: '2022-01-28T15:32:19.581Z',
  isShared: true,
  pdfUrl: TestReportInfo.Employer.reportURL,
  flaggedContentsCount: 2,
  nonFlaggedContentsCount: 5,
  deletedFlaggedContentsCount: 0,
  businessDictionaryContentsCount: 1,
  countByBusinessDictionaryBreakdown: { dictionaryId: 1 },
  allByTimelineBreakdown: {
    2015: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 1,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
    2017: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 1,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
    2018: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 1,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
    2020: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 1,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
    2021: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 2,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
    2022: {
      0: {
        Twitter: 0,
        Facebook: 1,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
  },
  flaggedByTimelineBreakdown: {
    2021: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 2,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
  },
  originsLastScannedBreakdown: {
    __typename: 'ScanDateOriginsBreakdown',
    Facebook: '2022-01-20T10:45:52.195Z',
    Twitter: null,
    Instagram: null,
  },
  flaggedByOriginsBreakdown: {
    __typename: 'OriginsBreakdown',
    Facebook: 2,
    Twitter: 0,
    Instagram: 0,
  },
  flaggedByLabelsBreakdown: {
    __typename: 'FlaggedPostLabelsBreakdownResponse',
    identity_attack: 0,
    insult: 1,
    obscene: 0,
    threat: 0,
    sexual_explicit: 2,
    sexual: 0,
    severe_toxicity: 0,
    toxicity: 0,
    inappropriate: 0,
    blasphemy: 0,
    discriminatory: 0,
  },
  allByOriginsBreakdown: {
    __typename: 'OriginsBreakdown',
    Facebook: 7,
    Twitter: 0,
    Instagram: 0,
  },
};

export const individualReportEmployerData = {
  __typename: 'Report',
  id: TestReportInfo.Employer.reportId,
  userId: 'ckwlyh99l06610ks6llxqvbee',
  type: ReportType.Employer,
  name: TestReportInfo.Employer.reportName,
  isFCRACompliant: true,
  createdAt: '2022-01-28T15:32:19.981Z',
  startDate: '2015-01-28T15:32:19.582Z',
  endDate: '2022-01-28T15:32:19.581Z',
  isShared: false,
  pdfUrl: TestReportInfo.Employer.reportURL,
  flaggedContentsCount: 2,
  nonFlaggedContentsCount: 5,
  deletedFlaggedContentsCount: 0,
  businessDictionaryContentsCount: 1,
  countByBusinessDictionaryBreakdown: { dictionaryId: 1 },
  allByTimelineBreakdown: {
    2015: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 1,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
    2017: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 1,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
    2018: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 1,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
    2020: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 1,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
    2021: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 2,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
    2022: {
      0: {
        Twitter: 0,
        Facebook: 1,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
  },
  flaggedByTimelineBreakdown: {
    2021: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 2,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
  },
  originsLastScannedBreakdown: {
    __typename: 'ScanDateOriginsBreakdown',
    Facebook: '2022-01-20T10:45:52.195Z',
    Twitter: null,
    Instagram: null,
  },
  flaggedByOriginsBreakdown: {
    __typename: 'OriginsBreakdown',
    Facebook: 2,
    Twitter: 0,
    Instagram: 0,
  },
  flaggedByLabelsBreakdown: {
    __typename: 'FlaggedPostLabelsBreakdownResponse',
    identity_attack: 0,
    insult: 1,
    obscene: 0,
    threat: 0,
    sexual_explicit: 2,
    sexual: 0,
    severe_toxicity: 0,
    toxicity: 0,
    inappropriate: 0,
    blasphemy: 0,
    discriminatory: 0,
  },
  allByOriginsBreakdown: {
    __typename: 'OriginsBreakdown',
    Facebook: 7,
    Twitter: 0,
    Instagram: 0,
  },
};

export const individualReportPersonalData = {
  __typename: 'Report',
  id: TestReportInfo.Personal.reportId,
  userId: 'ckwlyh99l06610ks6llxqvbee',
  type: ReportType.Personal,
  name: TestReportInfo.Personal.reportName,
  isFCRACompliant: false,
  createdAt: '2021-12-28T15:32:19.981Z',
  startDate: '2010-09-15T15:32:19.582Z',
  endDate: '2021-11-28T15:32:19.581Z',
  isShared: false,
  pdfUrl: TestReportInfo.Personal.reportURL,
  flaggedContentsCount: 2,
  nonFlaggedContentsCount: 5,
  deletedFlaggedContentsCount: 0,
  businessDictionaryContentsCount: 0,
  countByBusinessDictionaryBreakdown: { 0: 0 },
  allByTimelineBreakdown: {
    2010: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 1,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
    2017: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 1,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
    2018: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 1,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
    2020: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 1,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
    2021: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 2,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
    2022: {
      0: {
        Twitter: 0,
        Facebook: 1,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
  },
  flaggedByTimelineBreakdown: {
    2021: {
      0: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      1: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      2: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      3: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      4: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      5: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      6: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      7: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      8: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      9: {
        Twitter: 0,
        Facebook: 2,
        Instagram: 0,
      },
      10: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
      11: {
        Twitter: 0,
        Facebook: 0,
        Instagram: 0,
      },
    },
  },
  originsLastScannedBreakdown: {
    __typename: 'ScanDateOriginsBreakdown',
    Facebook: '2022-01-20T10:45:52.195Z',
    Twitter: null,
    Instagram: null,
  },
  flaggedByOriginsBreakdown: {
    __typename: 'OriginsBreakdown',
    Facebook: 2,
    Twitter: 0,
    Instagram: 0,
  },
  flaggedByLabelsBreakdown: {
    __typename: 'FlaggedPostLabelsBreakdownResponse',
    identity_attack: 0,
    insult: 1,
    obscene: 0,
    threat: 0,
    sexual_explicit: 2,
    sexual: 0,
    severe_toxicity: 0,
    toxicity: 0,
    inappropriate: 0,
    blasphemy: 0,
    discriminatory: 0,
  },
  allByOriginsBreakdown: {
    __typename: 'OriginsBreakdown',
    Facebook: 7,
    Twitter: 0,
    Instagram: 0,
  },
};

export const mockIndividual2Report = {
  request: {
    query: IndividualReportsDocument,
    variables: {},
  },
  result: {
    data: {
      individualReports: [individualReportEmployerData, individualReportPersonalData],
    },
  },
};

export const mockIndividualFCRAReport = {
  request: {
    query: IndividualReportsDocument,
    variables: {},
  },
  result: {
    data: {
      individualReports: [individualReportEmployerData],
    },
  },
};

export const mockIndividualPersonalReport = {
  request: {
    query: IndividualReportsDocument,
    variables: {},
  },
  result: {
    data: {
      individualReports: [individualReportPersonalData],
    },
  },
};

export const mockSharedReportError = {
  request: {
    query: ShareReportDocument,
    variables: {
      reportId: TestReportInfo.Employer.reportId,
    },
  },
  result: {
    errors: [new GraphQLError('Some backend error!')],
  },
};

export const mockSharedReport = {
  request: {
    query: ShareReportDocument,
    variables: {
      reportId: TestReportInfo.Employer.reportId,
    },
  },
  result: {
    data: {
      shareReport: {
        id: 'ckyykddot07322uoeqr3ejy40',
        isShared: true,
        __typename: 'Report',
      },
    },
  },
};

export const mockNotSharedReport = {
  request: {
    query: ShareReportDocument,
    variables: {
      reportId: TestReportInfo.Employer.reportId,
    },
  },
  result: {
    data: {
      shareReport: {
        id: 'ckyykddot07322uoeqr3ejy40',
        isShared: false,
        __typename: 'Report',
      },
    },
  },
};

export const mocksendReportPDF = {
  request: {
    query: SendReportPdfDocument,
    variables: {
      reportId: TestReportInfo.Employer.reportId,
      emails: ['alba@mail.com'],
    },
  },
  result: {
    data: {},
  },
};

export const mocksendReportPDFError = {
  request: {
    query: SendReportPdfDocument,
    variables: {
      reportId: TestReportInfo.Employer.reportId,
      emails: ['alba@mail.com'],
    },
  },
  result: {
    errors: [new GraphQLError('Some backend error!')],
  },
};
