import React from 'react';
import Skeleton from 'react-loading-skeleton';

import * as S from './GridSkeleton.styles';

type Props = {
  secondRowCount?: number;
};

const OverviewSkeleton = ({ secondRowCount = 2 }: Props) => {
  return (
    <S.Wrapper data-testid="skeleton">
      <div>
        <Skeleton height={90} width="32%" count={3} />
      </div>
      <S.LineTwo>
        <Skeleton
          height={120}
          width={secondRowCount === 2 ? '49%' : '100%'}
          count={secondRowCount}
          data-testid="skeleton"
        />
      </S.LineTwo>
      <S.LineThree>
        <Skeleton height={200} width="49%" count={2} />
      </S.LineThree>
      <div>
        <Skeleton height={170} width="100%" />
      </div>
      <div>
        <Skeleton height={300} width="100%" />
      </div>
    </S.Wrapper>
  );
};

export default OverviewSkeleton;
