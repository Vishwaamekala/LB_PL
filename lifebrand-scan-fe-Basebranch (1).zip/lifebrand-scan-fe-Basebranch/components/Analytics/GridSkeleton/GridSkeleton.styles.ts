import styled from 'styled-components';
import { Row } from 'antd';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Wrapper = styled(Row)`
  width: 100%;
  > div > span {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
  }

  & > * {
    margin-bottom: ${({ theme }) => theme.spacing.large}px;
    width: 100%;

    ${useBreakpoint.mobile`
      margin-bottom: ${({ theme }) => theme.spacing.medium}px;
    `}
  }
`;

export const LineTwo = styled.div`
  ${useBreakpoint.mobile`
  > span span {
    width: 100% !important;
  }
  > span > span:first-child {
    margin-bottom: ${({ theme }) => theme.spacing.medium}px;
  }
  `}
`;

export const LineThree = styled.div`
  ${useBreakpoint.smDesktop`
  > span span {
    width: 100% !important;
  }
  > span > span:first-child {
    margin-bottom: ${({ theme }) => theme.spacing.medium}px;
  }
  `}
`;
