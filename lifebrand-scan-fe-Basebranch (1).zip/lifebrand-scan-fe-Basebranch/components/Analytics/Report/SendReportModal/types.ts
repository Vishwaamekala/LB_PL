export type ModalContentProps = {
  reportId: string;
  onSuccess: () => void;
  onFailure: () => void;
  onClose: () => void;
};

export enum Content {
  Business = 'business',
  Others = 'others',
}
