import React from 'react';

import { fireEvent, render, waitFor, within } from '@testing-library/react';
import 'jest-canvas-mock';

import { ThemeProvider } from 'styled-components';

import { MockedProvider, MockedResponse } from '@apollo/client/testing';

import { theme } from 'theme/theme';

import SendReportModal from './SendReportModal';

import {
  individualReportEmployerData,
  individualReportEmployerDataShared,
  individualReportPersonalData,
  mockIndividual0Report,
  mockNotSharedReport,
  mocksendReportPDF,
  mocksendReportPDFError,
  mockSharedReportError,
} from '../../mocks/constants';

import { SubscriptionContext, SubscriptionContextProps } from '@Utils/SubscriptionContext';
import { ContextProps as AuthContextProps, useAuthContext } from '@Utils/AuthContext';
import { ReportDataFragment, UserDataFragment } from '@Generated/graphql';

const intersectionObserverMock = () => ({
  observe: () => null,
});

jest.mock('next/router', () => ({
  useRouter: jest.fn().mockReturnValue({
    route: '/',
    pathname: '',
    query: '',
    asPath: '',
    push: jest.fn(),
  }),
}));

window.IntersectionObserver = jest.fn().mockImplementation(intersectionObserverMock);

jest.mock('@Utils/AuthContext', () => ({
  ...jest.requireActual('@Utils/AuthContext'),
  useAuthContext: jest.fn(),
}));

const mockUseAuth = (userData: AuthContextProps['userData'], isInvited = false) => {
  (useAuthContext as jest.Mock).mockReturnValue({
    userData,
    isInvited,
    triggerRefetch: (() => {}) as AuthContextProps['triggerRefetch'],
    loading: false,
    isLoggedIn: true,
    invitedBy: userData?.BusinessCustomer.filter((one) => one.isActive),
  });
};

// to avoid error TypeError: window.matchMedia is not a function
window.matchMedia =
  window.matchMedia ||
  function () {
    return {
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  };

type RenderProps = {
  subscriptionValue: SubscriptionContextProps;
  mockIndividualReportsData?: MockedResponse;
  mockSharedReportData?: MockedResponse;
  mockSendReportPDFData?: MockedResponse;
  reportData: ReportDataFragment;
  isInvited?: boolean;
  isSentToB2B?: boolean;
  loading?: boolean;
};

const renderComponent = ({
  subscriptionValue,
  mockIndividualReportsData = mockIndividual0Report,
  mockSharedReportData = mockNotSharedReport,
  mockSendReportPDFData = mocksendReportPDF,
  reportData,
  isInvited = false,
  isSentToB2B = false,
}: RenderProps) => {
  return render(
    <ThemeProvider theme={theme}>
      <MockedProvider
        mocks={[mockIndividualReportsData, mockSharedReportData, mockSendReportPDFData]}
        addTypename={false}
      >
        <SubscriptionContext.Provider value={subscriptionValue}>
          <SendReportModal
            reportData={reportData}
            isSentToB2B={isSentToB2B}
            isInvited={isInvited}
          />
        </SubscriptionContext.Provider>
      </MockedProvider>
    </ThemeProvider>,
  );
};

const generateTestData = () => {
  const user = ({
    notInvited: {
      id: 'ckwlyh99l06610ks6llxqvbee',
      name: 'Erica Lumley',
      email: 'erica_lumley@mail.com',
      photo:
        'https://scontent-sea1-1.xx.fbcdn.net/v/t1.30497-1/cp0/c15.0.50.50a/p50x50/84628273_176159830277856_972693363922829312_n.jpg?_nc_cat=1&ccb=1-5&_nc_sid=12b3be&_nc_ohc=BIVkKoTaVNgAX-TqIzy&_nc_ht=scontent-sea1-1.xx&edm=AP4hL3IEAAAA&oh=00_AT8evaGQNy4bMH2P7o4O56jiboovC8eBO9VqukZEePIq-g&oe=62316738',
      scanAmount: -1,
      authId: 'facebook|107403778058630',
      stripeId: 'cus_LA9n0FjaUMm5R9',
      planId: null,
      createdAt: '2022-02-15T15:43:13.947Z',
      updatedAt: '2022-02-17T15:07:24.154Z',
      lastRefresh: null,
      acceptedFcraVersion: 'v1-2022',
      acceptedPolicyVersion: 'v2022-01-19',
      hasPassword: false,
      BusinessCustomer: [
        {
          id: 'ckzoaolhd12740ks6q4wldyxt',
          type: 'PotentialEmployee',
          isActive: false,
          Business: {
            id: 'cks0899i200071cs69vsucf88',
            name: 'qacoakslab1',
            contactEmail: 'qa1oaks@gmail.com',
            __typename: 'PublicBusiness',
          },
          __typename: 'BusinessCustomer',
        },
      ],
      __typename: 'User',
      Plan: null,
    },
    invited: {
      id: 'ckwlyh99l06610ks6llxqvbee',
      name: 'Romulo Ganuza',
      email: 'romulo_ganuza@mail.com',
      photo:
        'https://scontent-sea1-1.xx.fbcdn.net/v/t1.30497-1/cp0/c15.0.50.50a/p50x50/84628273_176159830277856_972693363922829312_n.jpg?_nc_cat=1&ccb=1-5&_nc_sid=12b3be&_nc_ohc=BIVkKoTaVNgAX-TqIzy&_nc_ht=scontent-sea1-1.xx&edm=AP4hL3IEAAAA&oh=00_AT8evaGQNy4bMH2P7o4O56jiboovC8eBO9VqukZEePIq-g&oe=62316738',
      scanAmount: -1,
      authId: 'twitter|127403778058630',
      stripeId: 'cus_LA9n0FjaUMm6TY',
      planId: null,
      createdAt: '2021-12-15T12:03:13.947Z',
      updatedAt: '2021-12-17T15:07:24.154Z',
      lastRefresh: null,
      acceptedFcraVersion: 'v1-2022',
      acceptedPolicyVersion: 'v2022-01-19',
      hasPassword: false,
      BusinessCustomer: [
        {
          id: 'ckzoaolhd12740ks6q4wlllxt',
          type: 'CurrentEmployee',
          isActive: true,
          Business: {
            id: 'cks0899i200071cs69vsucf88',
            name: 'qacoakslab1',
            contactEmail: 'qa1oaks@gmail.com',
            __typename: 'PublicBusiness',
          },
          __typename: 'BusinessCustomer',
        },
      ],
      __typename: 'User',
      Plan: null,
    },
  } as unknown) as Record<string, UserDataFragment>;

  const subscriptions = {
    free: {
      features: {
        canScan: true,
        canUpgrade: true,
        canAccessAnalytics: false,
        canUseAdvancedDashboard: false,
      },
      plan: {
        name: 'Free',
        isCancellable: false,
        isCancelled: false,
        currentPeriodEnds: null,
      },
    },
    basic: {
      features: {
        canScan: false,
        canUpgrade: true,
        canAccessAnalytics: true,
        canUseAdvancedDashboard: true,
      },
      plan: {
        name: 'Basic',
        isCancellable: true,
        isCancelled: false,
        currentPeriodEnds: null,
      },
    },
    unlimited: {
      features: {
        canScan: true,
        canUpgrade: true,
        canAccessAnalytics: true,
        canUseAdvancedDashboard: true,
      },
      plan: {
        name: 'Unlimited',
        isCancellable: true,
        isCancelled: false,
        currentPeriodEnds: null,
      },
    },
  } as Record<string, Omit<SubscriptionContextProps, 'loading'>>;

  const individualReportPersonal = individualReportPersonalData as ReportDataFragment;
  const individualReportEmployer = individualReportEmployerData as ReportDataFragment;
  const individualReportEmployerShared = individualReportEmployerDataShared as ReportDataFragment;

  return {
    user,
    subscriptions,
    individualReportPersonal,
    individualReportEmployer,
    individualReportEmployerShared,
  };
};

const testData = generateTestData();
window.open = jest.fn();

describe('Send Report Modal - Share With Others', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders the correct initial DOM - empty', async () => {
    mockUseAuth({ ...testData.user.notInvited }, false);
    const { findByText, findByTestId, queryAllByTestId, getByLabelText } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      reportData: testData.individualReportEmployer,
    });

    const sendButton = await findByTestId('send-report-button');
    expect(sendButton).toBeEnabled();

    fireEvent.click(sendButton);
    const sendReportModal = await findByTestId('send-report-modal');
    expect(sendReportModal).toBeInTheDocument();

    expect(await findByText(/Sending the Report/)).toBeInTheDocument();

    const confirmSendButton = within(sendReportModal).getByRole('button', {
      name: /Send Report/gi,
    });
    expect(confirmSendButton).toBeDisabled();

    const cancelSendButton = within(sendReportModal).getByRole('button', {
      name: /Cancel/gi,
    });
    expect(cancelSendButton).toBeEnabled();

    const emailsInput = getByLabelText('send-report-emails-input') as HTMLInputElement;
    const emails = queryAllByTestId('email');

    // Initially
    expect(emailsInput.getAttribute('value')).toBe('');
    expect(emails.length).toBe(0);
  });

  it('creates wrong email tag', async () => {
    mockUseAuth({ ...testData.user.notInvited }, false);
    const { findByTestId, getByLabelText, getByTestId, findAllByTestId } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      reportData: testData.individualReportEmployer,
    });

    const sendButton = await findByTestId('send-report-button');
    expect(sendButton).toBeEnabled();

    fireEvent.click(sendButton);
    const sendReportModal = await findByTestId('send-report-modal');
    const emailsInput = getByLabelText('send-report-emails-input') as HTMLInputElement;

    // Create wrong email tag
    fireEvent.input(emailsInput, { target: { value: 'alba@mail ' } });

    const emailList = await findByTestId('email-list');
    await waitFor(() => expect(emailList.childElementCount).toBeGreaterThan(1));

    const emails = await findAllByTestId('email');
    const email = getByTestId('email');
    const emailNameElement = email.firstChild;

    expect(emailNameElement?.textContent).toBe('alba@mail');

    // The input field should be blank
    expect(emailsInput.value).toBe('');

    // alba@mail exists
    expect(email).toBeInTheDocument();
    expect(emails.length).toBe(1);

    const confirmSendButton = within(sendReportModal).getByRole('button', {
      name: /Send Report/gi,
    });
    expect(confirmSendButton).toBeDisabled();
  });

  it('creates correct email tag and send report', async () => {
    mockUseAuth({ ...testData.user.notInvited }, false);
    const {
      findByText,
      findByTestId,
      getByLabelText,
      getByTestId,
      findAllByTestId,
    } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      reportData: testData.individualReportEmployer,
    });

    const sendButton = await findByTestId('send-report-button');
    expect(sendButton).toBeEnabled();

    fireEvent.click(sendButton);
    const sendReportModal = await findByTestId('send-report-modal');
    const emailsInput = getByLabelText('send-report-emails-input') as HTMLInputElement;

    // Create correct email tag
    fireEvent.input(emailsInput, { target: { value: 'alba@mail.com ' } });

    const emailList = await findByTestId('email-list');
    await waitFor(() => expect(emailList.childElementCount).toBeGreaterThan(1));

    const emails = await findAllByTestId('email');
    const email = getByTestId('email');
    const emailNameElement = email.firstChild;

    expect(emailNameElement?.textContent).toBe('alba@mail.com');

    // The input field should be blank
    expect(emailsInput.value).toBe('');

    // alba@mail.com exists
    expect(email).toBeInTheDocument();
    expect(emails.length).toBe(1);

    const confirmSendButton = within(sendReportModal).getByRole('button', {
      name: /Send Report/gi,
    });
    expect(confirmSendButton).toBeEnabled();

    fireEvent.click(confirmSendButton);
    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    expect(await findByText('Your report was successfully sent.')).toBeInTheDocument();
  });

  it('creates correct email tag and has error on sending', async () => {
    mockUseAuth({ ...testData.user.notInvited }, false);
    const {
      findByText,
      findByTestId,
      getByLabelText,
      getByTestId,
      findAllByTestId,
    } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      reportData: testData.individualReportEmployer,
      mockSendReportPDFData: mocksendReportPDFError,
    });

    const sendButton = await findByTestId('send-report-button');
    expect(sendButton).toBeEnabled();

    fireEvent.click(sendButton);
    const sendReportModal = await findByTestId('send-report-modal');
    const emailsInput = getByLabelText('send-report-emails-input') as HTMLInputElement;

    // Create correct email tag
    fireEvent.input(emailsInput, { target: { value: 'alba@mail.com ' } });

    const emailList = await findByTestId('email-list');
    await waitFor(() => expect(emailList.childElementCount).toBeGreaterThan(1));

    const emails = await findAllByTestId('email');
    const email = getByTestId('email');
    const emailNameElement = email.firstChild;

    expect(emailNameElement?.textContent).toBe('alba@mail.com');

    // The input field should be blank
    expect(emailsInput.value).toBe('');

    // alba@mail.com exists
    expect(email).toBeInTheDocument();
    expect(emails.length).toBe(1);

    const confirmSendButton = within(sendReportModal).getByRole('button', {
      name: /Send Report/gi,
    });
    expect(confirmSendButton).toBeEnabled();

    fireEvent.click(confirmSendButton);
    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    expect(await findByText(/Failed to send report. Please try again./gi)).toBeInTheDocument();
  });
});

describe('Send Report Modal - Send To Business Content', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('sends FCRA Report successfully - Invited employee', async () => {
    const { findByText, findByTestId } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      reportData: testData.individualReportEmployer,
      isInvited: true,
    });

    const sendButton = await findByTestId('send-report-button');
    expect(sendButton).toBeEnabled();

    fireEvent.click(sendButton);
    const sendReportModal = await findByTestId('send-report-modal');
    expect(sendReportModal).toBeInTheDocument();

    const InviterToggle = await findByText(/Send Back to Inviter/);
    const OtherToggle = await findByText(/Share with Others/gi);

    expect(InviterToggle).toBeInTheDocument();
    expect(OtherToggle).toBeInTheDocument();

    expect(InviterToggle).toHaveStyle('background-color: rgb(255, 255, 255)'); // it is selected

    const cancelSendButton = within(sendReportModal).getByRole('button', { name: /Cancel/i });
    expect(cancelSendButton).toBeEnabled();

    const confirmSendButton = within(sendReportModal).getByRole('button', {
      name: /Send Report/gi,
    });

    fireEvent.click(confirmSendButton);
    expect(await findByText(/Your report was successfully sent./gi)).toBeInTheDocument();
  });
  it('renders error while sending FCRA Report - Invited employee', async () => {
    mockUseAuth({ ...testData.user.invited }, true);
    const { findByText, findByTestId } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      reportData: testData.individualReportEmployer,
      mockSharedReportData: mockSharedReportError,
      isInvited: true,
    });

    const sendButton = await findByTestId('send-report-button');
    expect(sendButton).toBeEnabled();

    fireEvent.click(sendButton);
    const sendReportModal = await findByTestId('send-report-modal');
    expect(sendReportModal).toBeInTheDocument();

    const InviterToggle = await findByText(/Send Back to Inviter/);
    expect(InviterToggle).toHaveStyle('background-color: rgb(255, 255, 255)'); // it is selected

    const confirmSendButton = within(sendReportModal).getByRole('button', {
      name: /Send Report/gi,
    });

    fireEvent.click(confirmSendButton);
    expect(await findByText(/Sending report failed. Please try again./gi)).toBeInTheDocument();
  });
});
