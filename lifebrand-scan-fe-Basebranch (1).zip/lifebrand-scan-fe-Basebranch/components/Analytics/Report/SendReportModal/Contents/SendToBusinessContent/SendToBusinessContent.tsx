import React from 'react';

import { Button, Heading, Icon } from '@UI/meeseeks';

import { ModalContentProps } from '../../types';
import * as S from '../../SendReportModal.styles';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { TriggerClass } from '@Utils/google-tag-manager';

import { useShareReportMutation } from '@Generated/graphql';

const SendToBusinessContent = ({ reportId, onSuccess, onFailure, onClose }: ModalContentProps) => {
  const { isMobile } = useBreakpoints();

  const [shareReport, { loading }] = useShareReportMutation();

  const onSendReport = async () => {
    try {
      await shareReport({
        variables: { reportId },
      });
      onSuccess();
    } catch (e) {
      onFailure();
    }
  };

  return (
    <>
      <Heading
        variant={isMobile ? 'h4' : 'h3'}
        textColor="heading"
        textAlign="center"
        marginBottom="small"
        letterSpacing={0}
      >
        Sending the Report
      </Heading>
      <Heading variant="h6" textColor="neutrals.700" textAlign="center" marginBottom="large">
        You are about to send a report summary link back to your inviter.
      </Heading>
      <S.ImageWrapper>
        <img src="/images/png/plane-large.png" width={200} height={118} alt="send" />
      </S.ImageWrapper>
      <S.ActionButtons>
        <Button variant="tertiary" size="medium" onClick={onClose}>
          Cancel
        </Button>
        <Button
          className={TriggerClass.SendReport}
          variant="secondary"
          size="medium"
          iconLeft={<Icon name="Send" size={16} color="#fff" />}
          onClick={onSendReport}
          loading={loading}
          disabled={loading}
          fluid={isMobile}
        >
          Send Report
        </Button>
      </S.ActionButtons>
    </>
  );
};

export default SendToBusinessContent;
