import React, { useCallback, useState } from 'react';

import { Button, Heading, Icon, message } from '@UI/meeseeks';

import FCRAModal, { VERSION as FCRA_VERSION } from 'components/Analytics/Report/FCRAModal';
import EmailsInput from 'components/Analytics/Report/EmailsInput';
import { ModalContentProps } from '../../types';
import * as S from '../../SendReportModal.styles';

import { useAuthContext } from '@Utils/AuthContext';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { TriggerClass } from '@Utils/google-tag-manager';

import { useSendReportPdfMutation } from '@Generated/graphql';

const ShareWithOthersContent = ({ reportId, onSuccess, onFailure, onClose }: ModalContentProps) => {
  const { userData } = useAuthContext();
  const { isMobile } = useBreakpoints();

  const [emails, setEmails] = useState<{ email: string; valid: boolean }[]>([]);

  const [sendReportPDF, { loading }] = useSendReportPdfMutation();

  const shouldBeDisabled = () => {
    const notValidEmails = emails.some((el) => !el.valid);
    return loading || !emails.length || notValidEmails;
  };

  const handleSuccess = useCallback(() => {
    onSuccess();
    setEmails([]);
  }, [onSuccess]);

  const handleClose = useCallback(() => {
    onClose();
    setEmails([]);
  }, [onClose]);

  const handleReportShare = useCallback(async () => {
    const emailsList = emails.map((el) => el.email);
    try {
      await sendReportPDF({ variables: { reportId, emails: emailsList } });
      handleSuccess();
    } catch (e) {
      message.error({
        title: 'Failed to send report. Please try again.',
      });
      onFailure();
    }
  }, [reportId, emails, sendReportPDF, handleSuccess, onFailure]);

  const [isFcraModalVisible, setIsFcraModalVisible] = useState(false);

  const handleFcraAgree = () => {
    setIsFcraModalVisible(false);
    handleReportShare();
  };

  const handleFcraDecline = () => {
    setIsFcraModalVisible(false);
  };

  const handleFcraCheck = useCallback(() => {
    if (userData?.acceptedFcraVersion === FCRA_VERSION) {
      handleReportShare();
    } else {
      setIsFcraModalVisible(true);
    }
  }, [userData, handleReportShare]);

  return (
    <>
      <Heading
        variant={isMobile ? 'h4' : 'h3'}
        textColor="heading"
        textAlign="center"
        marginBottom="small"
        letterSpacing={0}
      >
        Sending the Report
      </Heading>
      <Heading variant="h6" textColor="neutrals.700" textAlign="center" marginBottom="large">
        Please, make sure you validate each email by pressing space.
      </Heading>
      <S.EmailsInputWrapper>
        <EmailsInput emails={emails} setEmails={setEmails} />
      </S.EmailsInputWrapper>
      <S.ActionButtons>
        <Button variant="tertiary" size="medium" onClick={handleClose}>
          Cancel
        </Button>
        <Button
          className={TriggerClass.ShareReport}
          variant="secondary"
          size="medium"
          iconLeft={<Icon name="Send" size={16} color="#fff" />}
          onClick={handleFcraCheck}
          loading={loading}
          disabled={shouldBeDisabled()}
          fluid={isMobile}
        >
          Send Report
        </Button>
      </S.ActionButtons>

      <FCRAModal
        description="Please read and agree to the terms before sending your report."
        isVisible={isFcraModalVisible}
        onAgree={handleFcraAgree}
        onDecline={handleFcraDecline}
      />
    </>
  );
};

export default ShareWithOthersContent;
