import styled from 'styled-components';

import { Tabs as TabsBase } from '@UI/meeseeks';

export const Tabs = styled(TabsBase)`
  max-width: 360px;
  margin: 0 auto ${({ theme }) => theme.spacing.large}px;

  // TODO: This might be up for alignment in designs - design system has different size than actual platform design
  & > * {
    font-size: ${({ theme }) => theme.typography.text.xs}px;
    line-height: 140%;
  }
`;

export const ImageWrapper = styled.div`
  display: grid;
  place-content: center;
  background: ${({ theme }) => theme.meeseeks.color['neutrals.100']};
  margin-bottom: ${({ theme }) => theme.spacing.large}px;
  height: 280px;
`;

export const EmailsInputWrapper = styled.div`
  margin-bottom: ${({ theme }) => theme.spacing.large}px;
`;

export const ActionButtons = styled.div`
  display: flex;
  justify-content: flex-end;

  & > * + * {
    margin-left: ${({ theme }) => theme.spacing.medium}px;
  }
`;
