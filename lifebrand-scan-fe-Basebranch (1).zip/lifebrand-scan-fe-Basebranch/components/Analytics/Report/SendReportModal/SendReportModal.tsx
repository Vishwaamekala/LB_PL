import React, { useCallback, useMemo, useState } from 'react';

import SendToBusinessContent from './Contents/SendToBusinessContent';
import ShareWithOthersContent from './Contents/ShareWithOthersContent';
import { Content } from './types';

import { Button, Icon, message } from '@UI/meeseeks';
import Modal from '@UI/Modal';

import { ReportDataFragment } from '@Generated/graphql';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import * as S from './SendReportModal.styles';

type Props = {
  reportData: ReportDataFragment;
  isSentToB2B?: boolean;
  isInvited?: boolean;
};

const SendReportModal = ({ reportData, isSentToB2B, isInvited }: Props) => {
  const { isMobile } = useBreakpoints();

  const [visible, setVisible] = useState(false);
  const [content, setContent] = useState<Content>();

  const isSendingMode = content === Content.Business || content === Content.Others;
  const showButtons = isInvited && isSendingMode && !isSentToB2B;

  const handleSuccess = useCallback(() => {
    setVisible(false);
    message.success({
      title: 'Your report was successfully sent.',
    });
  }, []);

  const handleFailure = useCallback(() => {
    message.error({
      title: 'Sending report failed. Please try again.',
    });
  }, []);

  const handleOpen = useCallback(async () => {
    if (isInvited && !isSentToB2B) {
      setContent(Content.Business);
    } else {
      setContent(Content.Others);
    }
    setVisible(true);
  }, [isInvited, isSentToB2B]);

  const handleClose = useCallback(() => {
    setVisible(false);
    setContent(undefined);
  }, []);

  const buttonText = useMemo((): string => {
    switch (true) {
      case !!isSentToB2B:
        return 'Resend Report';
      default:
        return 'Send Report';
    }
  }, [isSentToB2B]);

  return (
    <>
      <Button
        variant="secondary"
        size="medium"
        iconLeft={<Icon name="Send" size={16} color="#fff" />}
        onClick={handleOpen}
        fluid={isMobile}
        data-testid="send-report-button"
      >
        {buttonText}
      </Button>
      <Modal
        visible={visible}
        width={628}
        footer={null}
        onCancel={handleClose}
        centered
        wrapProps={{ 'data-testid': 'send-report-modal' }}
      >
        {showButtons && (
          <S.Tabs
            activeTab={content}
            onTabChange={(tab) => setContent(tab?.key as Content)}
            tabs={[
              {
                key: Content.Business,
                title: 'Send Back to Inviter',
                isDisabled: isSentToB2B,
              },
              {
                key: Content.Others,
                title: 'Share with Others',
                isDisabled: isSentToB2B,
              },
            ]}
          />
        )}
        {content === Content.Business && (
          <SendToBusinessContent
            reportId={reportData.id}
            onSuccess={handleSuccess}
            onFailure={handleFailure}
            onClose={handleClose}
          />
        )}
        {content === Content.Others && (
          <ShareWithOthersContent
            reportId={reportData.id}
            onSuccess={handleSuccess}
            onFailure={handleFailure}
            onClose={handleClose}
          />
        )}
      </Modal>
    </>
  );
};

export default SendReportModal;
