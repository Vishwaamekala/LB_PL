import React from 'react';

import ReportDetails from 'components/Analytics/Report/ReportDetails';
import ReportHeader from 'components/Analytics/Report/UI/ReportHeader';

import { ReportDataFragment } from '@Generated/graphql';

type Props = {
  reportData: ReportDataFragment;
  loading: boolean;
};

const ReportIndividual = ({ reportData, loading }: Props) => (
  <>
    <ReportHeader reportData={reportData} loading={loading} />
    <ReportDetails reportData={reportData} />
  </>
);

export default ReportIndividual;
