import React from 'react';

import { Tag } from '@UI/meeseeks';

import HeaderCard from '@UI/HeaderCard';

import SendReportModal from 'components/Analytics/Report/SendReportModal';
import ExportToPdf from 'components/Analytics/Report/ExportToPdf';
import ReportIcon from 'components/Analytics/Report/UI/ReportIcon';
import EllipsisTooltip from '@UI/EllipsisTooltip';

import { ReportDataFragment, ReportType } from '@Generated/graphql';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';
import { useAuthContext } from '@Utils/AuthContext';

import * as S from './styles';

type Props = {
  reportData: ReportDataFragment;
  loading?: boolean;
};

// TODO : Manage Access Button/Send Report Modal
// TODO : Empty state/loading ? For the moment, Loading in ReportIndividual level

const ReportHeader = ({ reportData, loading = false }: Props) => {
  const { isMobile, isTablet } = useBreakpoints();
  const { isInvited } = useAuthContext();
  const isFCRACompliant = reportData.type === ReportType.Employer;
  const isReportForEmployer = isInvited && isFCRACompliant;

  return (
    <S.Wrapper>
      {isReportForEmployer &&
        (reportData.isShared ? (
          <Tag variant="success">Sent to Inviter</Tag>
        ) : (
          <Tag variant="warning">Not Sent to Inviter</Tag>
        ))}
      <S.HeaderInfo>
        <S.Title>
          <ReportIcon reportType={reportData.type} />
          <S.Heading variant="h4" textColor="secondary">
            <EllipsisTooltip>{reportData.name}</EllipsisTooltip>
          </S.Heading>
        </S.Title>
        <S.Actions>
          <ExportToPdf pdfUrl={reportData.pdfUrl} />
          {isFCRACompliant && (
            <SendReportModal
              isInvited={isInvited}
              isSentToB2B={isReportForEmployer && reportData.isShared}
              reportData={reportData}
            />
          )}
        </S.Actions>
      </S.HeaderInfo>
      <S.CountersWrapper>
        <HeaderCard
          title={isMobile || isTablet ? 'Flagged' : 'Flagged Posts'}
          isSelected={false}
          count={reportData.flaggedContentsCount}
          loading={loading}
        />
        <HeaderCard
          title={isMobile || isTablet ? 'All' : 'All Posts'}
          isSelected={false}
          count={reportData.flaggedContentsCount + reportData.nonFlaggedContentsCount}
          loading={loading}
        />
        {isFCRACompliant && reportData?.businessDictionaryContentsCount && (
          <HeaderCard
            title={isMobile ? 'Dictionary' : 'Custom Dictionary'}
            isSelected={false}
            count={reportData.businessDictionaryContentsCount}
            loading={loading}
          />
        )}
      </S.CountersWrapper>
    </S.Wrapper>
  );
};

export default ReportHeader;
