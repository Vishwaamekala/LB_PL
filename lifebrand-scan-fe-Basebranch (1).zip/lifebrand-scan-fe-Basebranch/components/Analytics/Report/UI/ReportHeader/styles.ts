import styled from 'styled-components';

import { Row } from 'antd';

import { Heading as HeadingBase } from '@UI/meeseeks';

import { useBreakpoint } from '@Utils/style/breakpoint';
import { inlineGap } from '@Utils/style/gap';

export const Wrapper = styled(Row)`
  width: 100%;

  & > * {
    margin-bottom: ${({ theme }) => theme.spacing.large}px;
  }
`;

export const HeaderInfo = styled.div`
  display: flex;
  position: relative;
  width: 100%;

  justify-content: space-between;
  align-items: center;

  & > :last-child {
    margin-left: auto;
  }

  ${useBreakpoint.mdDesktop`
    justify-content:unset;
    align-items: unset;
  `}

  ${useBreakpoint.mobile`
    flex-direction: column;
  `}
`;

export const Title = styled.div`
  display: flex;
  flex: 1;
  align-items: center;
  overflow-x: hidden;
`;

export const Actions = styled.div`
  display: flex;
  align-items: center;
  flex-direction: flex-end;
  ${({ theme }) => inlineGap(`${theme.spacing.medium}px`)};

  ${useBreakpoint.mobile`
    width: 100%;
    margin-top: ${({ theme }) => theme.spacing.medium}px;
    ${({ theme }) => inlineGap(`${theme.spacing.small}px`)};
  `}

  & button {
    ${useBreakpoint.mobile`
      padding: ${({ theme }) => theme.spacing.small}px;
    `}
  }
`;

export const CountersWrapper = styled.div`
  display: flex;
  width: 100%;
  ${({ theme }) => inlineGap(`${theme.spacing.large}px`)};

  ${useBreakpoint.mobile`
    ${({ theme }) => inlineGap(`${theme.spacing.medium}px`)};
  `}
`;

export const Heading = styled(HeadingBase).attrs({
  variant: 'h4',
  textColor: 'secondary',
})`
  margin-left: ${({ theme }) => theme.spacing.small}px;
  overflow: hidden;
`;
