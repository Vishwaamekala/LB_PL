import React from 'react';

import { Heading, HeadingElements, MarginBottomSizes } from '@UI/meeseeks';

import * as S from './styles';

interface Props {
  headerText?: string;
  headerComponent?: React.ReactNode;
  children: React.ReactNode;
  headerVariant?: HeadingElements[number];
  headerMarginBottom?: MarginBottomSizes[number];
}

const ReportCard = ({
  headerText,
  headerComponent,
  children,
  headerVariant = 'h5',
  headerMarginBottom = 'large',
}: Props) => {
  return (
    <S.Wrapper>
      {(headerText || headerComponent) && (
        <S.Header>
          {headerText && (
            <Heading variant={headerVariant} marginBottom={headerMarginBottom}>
              {headerText}
            </Heading>
          )}
          {headerComponent}
        </S.Header>
      )}
      {children}
    </S.Wrapper>
  );
};

export default ReportCard;
