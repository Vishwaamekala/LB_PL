import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Wrapper = styled.div`
  color: ${({ theme }) => theme.meeseeks.color.secondary};
  padding: ${({ theme }) => theme.spacing.extraLarge}px;
  border: 1px solid ${({ theme }) => theme.meeseeks.color.tertiary};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  min-height: 100%;

  ${useBreakpoint.mobile`
    padding: ${({ theme }) => theme.spacing.large}px ${({ theme }) => theme.spacing.medium}px;
  `}
`;

export const Header = styled.div`
  display: flex;
  justify-content: space-between;
  width: 100%;
`;
