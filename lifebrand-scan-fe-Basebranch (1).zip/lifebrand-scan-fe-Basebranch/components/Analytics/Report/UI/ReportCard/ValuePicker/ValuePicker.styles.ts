import styled from 'styled-components';

export const Button = styled.div`
  padding: 0 ${({ theme }) => theme.spacing.medium}px;
  cursor: pointer;
`;

export const Wrapper = styled.div`
  display: flex;
  direction: row;
  justify-content: center;
`;
