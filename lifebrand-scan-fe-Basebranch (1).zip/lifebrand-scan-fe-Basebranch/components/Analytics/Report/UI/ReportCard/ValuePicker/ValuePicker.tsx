import React from 'react';

import { Text } from '@UI/meeseeks';

import * as S from './ValuePicker.styles';

type Props<T> = {
  prev?: T;
  next?: T;
  value: string;
  onChange: (value: T) => void;
};

const ValuePicker = <T extends Record<string, any>>({ prev, next, onChange, value }: Props<T>) => {
  return (
    <S.Wrapper>
      {prev && (
        <S.Button onClick={() => onChange(prev)}>
          <img src="/images/svg/chevron-left.svg" alt="prev" />
        </S.Button>
      )}
      <Text variant="body" textColor="secondary">
        {value}
      </Text>
      {next && (
        <S.Button onClick={() => onChange(next)}>
          <img src="/images/svg/chevron-right.svg" alt="next" />
        </S.Button>
      )}
    </S.Wrapper>
  );
};

export default ValuePicker;
