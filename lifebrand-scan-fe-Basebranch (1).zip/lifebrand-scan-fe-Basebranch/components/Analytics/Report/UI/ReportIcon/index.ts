export { default } from './ReportIcon';
export * from './ReportIcon';
