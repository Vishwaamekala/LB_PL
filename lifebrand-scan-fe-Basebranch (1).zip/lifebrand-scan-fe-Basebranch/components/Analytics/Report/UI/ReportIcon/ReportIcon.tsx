import React from 'react';
import { theme } from 'theme/theme';

import { ReportType } from '@Generated/graphql';

import * as S from './styles';

type Props = {
  reportType: ReportType;
  size?: number;
};

const REPORT_ICON = {
  [ReportType.Employer]: {
    symbol: '💼',
    label: 'FCRA Compliant Report',
    backgroundColor: theme.meeseeks.color['primary.200'],
  },
  [ReportType.Personal]: {
    symbol: '👨',
    label: 'Personal Report',
    backgroundColor: theme.meeseeks.color['highlight.100'],
  },
};

const ReportIcon = ({ reportType, size = 24 }: Props) => (
  <S.Wrapper backgroundColor={REPORT_ICON[reportType].backgroundColor}>
    <span
      className="emoji"
      role="img"
      style={{ fontSize: `${size}px` }}
      aria-label={REPORT_ICON[reportType].label}
    >
      {REPORT_ICON[reportType].symbol}
    </span>
  </S.Wrapper>
);

export default ReportIcon;
