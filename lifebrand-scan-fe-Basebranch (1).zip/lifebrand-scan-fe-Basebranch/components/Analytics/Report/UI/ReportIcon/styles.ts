import styled from 'styled-components';

export const Wrapper = styled.div<{ backgroundColor: string }>`
  display: flex;
  align-items: center;
  justify-content: center;

  width: ${({ theme }) => theme.spacing.large + theme.spacing.medium}px;
  min-width: ${({ theme }) => theme.spacing.large + theme.spacing.medium}px;
  height: ${({ theme }) => theme.spacing.large + theme.spacing.medium}px;
  border-radius: ${({ theme }) => theme.borderRadius.small * 2}px;
  background-color: ${({ backgroundColor }) => backgroundColor};
`;
