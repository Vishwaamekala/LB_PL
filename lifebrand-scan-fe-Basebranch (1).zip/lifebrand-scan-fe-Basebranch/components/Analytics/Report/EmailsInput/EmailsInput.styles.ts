import styled from 'styled-components';

export const Wrapper = styled.div`
  display: flex;
  flex-flow: column;
  height: 118px;
  overflow: auto;
  padding: ${({ theme }) => theme.spacing.small}px;
  border: 1px solid ${({ theme }) => theme.meeseeks.color.tertiary};
  border-radius: ${({ theme }) => theme.borderRadius.small * 2}px;
  background: ${({ theme }) => theme.meeseeks.color.white};
  transition: all 0.3s;
  cursor: text;
`;

export const List = styled.div`
  display: flex;
  flex-wrap: wrap;
  padding: 0;
  list-style: none;
  margin: ${({ theme }) => theme.spacing.small / 2}px;
`;

export const Input = styled.input`
  padding: ${({ theme }) => `${theme.spacing.small / 2 + 1}px ${theme.spacing.small}px`};
  margin: ${({ theme }) => theme.spacing.small / 2}px;
  background: none;
  border: none;
  outline: none;
  box-shadow: none !important;
  line-height: 140%;
`;

export const ListItem = styled.div`
  max-height: 35px;
`;
