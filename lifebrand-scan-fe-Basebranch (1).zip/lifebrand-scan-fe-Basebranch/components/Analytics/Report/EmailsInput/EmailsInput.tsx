import React, { useState, useRef } from 'react';

import { Tag } from '@UI/meeseeks';
import { isEmailValid } from '@UI/Modal/utils';

import * as S from './EmailsInput.styles';

type Email = {
  email: string;
  valid: boolean;
};

type Props = {
  placeholder?: string;
  emails: Email[];
  setEmails: (emails: Email[]) => void;
};

const SPACE_KEYCODE = 32;

const EmailsInput = ({ placeholder, emails, setEmails }: Props) => {
  const [valueInput, setValueInput] = useState('');

  const inputRef = useRef<HTMLInputElement>(null);

  const removeEmailFromList = (email: string) => {
    setEmails(emails.filter((item) => item.email !== email));
  };

  const handleClick = () => inputRef.current && inputRef.current.focus();

  const onInput = (e: React.KeyboardEvent<HTMLInputElement>) => {
    const target = e.target as HTMLInputElement;
    if (target.value === ' ') return;
    setValueInput(target.value);

    const charCodeAt = target.value.substr(-1).charCodeAt(0);

    if (
      e.key === ' ' ||
      e.key === 'Space' ||
      e.key === 'Spacebar' ||
      e.keyCode === SPACE_KEYCODE ||
      e.which === SPACE_KEYCODE ||
      charCodeAt === SPACE_KEYCODE
    ) {
      if (
        target.value &&
        !emails.some((el) => el.email === target.value && target.value.length !== 1)
      ) {
        setEmails([
          ...emails,
          {
            email: target.value.trim(),
            valid: isEmailValid(target.value.trim()),
          },
        ]);
      }
      setValueInput('');
    }
  };

  return (
    <S.Wrapper onClick={handleClick}>
      <S.List data-testid="email-list">
        {emails &&
          emails.map((item) => (
            <S.ListItem key={item.email} data-testid="email">
              <Tag
                isDismissible
                onClose={() => removeEmailFromList(item.email)}
                variant={item.valid ? 'primary' : 'danger'}
              >
                {item.email}
              </Tag>
            </S.ListItem>
          ))}
        <S.ListItem>
          <S.Input
            ref={inputRef}
            value={valueInput}
            onInput={onInput}
            placeholder={placeholder}
            size={Math.max(10, valueInput.length + 1)}
            tabIndex={-1}
            aria-label="send-report-emails-input"
          />
        </S.ListItem>
      </S.List>
    </S.Wrapper>
  );
};

export default EmailsInput;
