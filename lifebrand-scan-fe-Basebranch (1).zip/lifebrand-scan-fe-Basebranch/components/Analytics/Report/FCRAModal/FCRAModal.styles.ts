import styled from 'styled-components';

import ModalBase from '@UI/Modal';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Modal = styled(ModalBase)`
  .ant-modal-content {
    background-color: ${({ theme }) => theme.meeseeks.color['neutrals.100']};
  }

  ${useBreakpoint.mobile`
    .ant-modal-body {
      padding-left: ${({ theme }) => theme.spacing.medium}px;
      padding-right: ${({ theme }) => theme.spacing.medium}px;
    }
  `}
`;

export const Header = styled.div`
  max-width: 460px;
  margin: 0px auto;
`;

export const Body = styled.div`
  border: ${({ theme }) => theme.border.card};
  border-radius: ${({ theme }) => theme.borderRadius.medium}px;
  padding: ${({ theme }) => theme.spacing.medium}px;
  max-height: 300px;
  overflow: auto;
  background-color: ${({ theme }) => theme.meeseeks.color.white};

  ${useBreakpoint.mobile`
    max-height: 360px;
  `}
`;

export const List = styled.ul`
  margin-top: ${({ theme }) => theme.spacing.small}px;
  padding-left: ${({ theme }) => theme.spacing.medium}px;

  li {
    font-family: 'Open Sans';
    font-size: ${({ theme }) => theme.typography.text.xs}px;
    line-height: 120%;
    margin-bottom: ${({ theme }) => theme.spacing.small}px;
  }
`;

export const TableContainer = styled.div`
  width: 100%;
  overflow: auto;
`;

export const Table = styled.table`
  table-layout: fixed;
  width: 100%;
  min-width: 400px;

  th,
  td {
    padding: ${({ theme }) => theme.spacing.small}px;
    border-bottom: ${({ theme }) => theme.border.card};
  }

  th {
    font-family: Poppins;
    font-size: ${({ theme }) => theme.typography.text.xs}px;
    line-height: 120%;
    font-weight: 600;
  }

  td {
    font-family: 'Open Sans';
    font-size: ${({ theme }) => theme.typography.text.xs}px;
    line-height: 120%;
    margin-bottom: ${({ theme }) => theme.spacing.small}px;
  }
`;

export const Actions = styled.div`
  display: flex;
  justify-content: flex-end;
  margin-top: ${({ theme }) => theme.spacing.large}px;

  & > * + * {
    margin-left: ${({ theme }) => theme.spacing.medium}px;
  }
`;
