import React, { useCallback, useEffect, useState } from 'react';
import { useInView } from 'react-intersection-observer';

import { Button, Heading, Text } from '@UI/meeseeks';

import { useAcceptFcraMutation } from '@Generated/graphql';

import * as S from './FCRAModal.styles';

/**
 * Increment this value whenever the FCRA content is updated to make sure
 * all users agree to the new version. Append the current year to make users
 * review the document every year.
 */
export const VERSION = `v1-${new Date().getFullYear()}`;

type Props = {
  description: string;
  isVisible: boolean;
  onDecline?: () => void;
  onAgree?: () => void;
};

const FCRAModal = ({ description, isVisible, onAgree, onDecline }: Props) => {
  const [acceptFcra, { loading }] = useAcceptFcraMutation();

  const handleAgree = useCallback(async () => {
    await acceptFcra({ variables: { fcraVersion: VERSION } });
    onAgree?.();
  }, [acceptFcra, onAgree]);

  const [bottomLine, inView] = useInView({
    threshold: 0,
  });

  const [isRead, setIsRead] = useState(false);

  useEffect(() => {
    if (inView) setIsRead(true);
  }, [inView]);

  return (
    <S.Modal visible={isVisible} onCancel={onDecline} footer={null} width={680}>
      <S.Header>
        <Heading variant="h3" textAlign="center" marginBottom="small">
          Fair Credit Reporting Act
        </Heading>
        <Heading variant="h6" textColor="body" textAlign="center" marginBottom="large">
          {description}
        </Heading>
      </S.Header>
      <S.Body>
        <Text marginBottom="medium" variant="small">
          Para información en español, visite{' '}
          <a target="_blank" rel="noreferrer" href="https://www.consumerfinance.gov/learnmore/">
            www.consumerfinance.gov/learnmore
          </a>{' '}
          o escribe a la Consumer Financial Protection Bureau, 1700 G Street N.W., Washington, DC
          20552.
        </Text>
        <Heading variant="h6" marginBottom="medium" textAlign="center">
          A Summary of Your Rights Under the Fair Credit Reporting Act
        </Heading>
        <Text marginBottom="small" variant="small">
          The federal Fair Credit Reporting Act (FCRA) promotes the accuracy, fairness, and privacy
          of information in the files of consumer reporting agencies. There are many types of
          consumer reporting agencies, including credit bureaus and specialty agencies (such as
          agencies that sell information about check writing histories, medical records, and rental
          history records). Here is a summary of your major rights under FCRA.{' '}
          <b>
            For more information, including information about additional rights, go to{' '}
            <a target="_blank" rel="noreferrer" href="https://www.consumerfinance.gov/learnmore/">
              www.consumerfinance.gov/learnmore
            </a>{' '}
            or write to: Consumer Financial Protection Bureau, 1700 G Street N.W., Washington, DC
            20552.
          </b>
        </Text>
        <S.List>
          <li>
            <b>You must be told if information in your file has been used against you.</b> Anyone
            who uses a credit report or another type of consumer report to deny your application for
            credit, insurance, or employment – or to take another adverse action against you – must
            tell you, and must give you the name, address, and phone number of the agency that
            provided the information.
          </li>
          <li>
            <b>You have the right to know what is in your file.</b> You may request and obtain all
            the information about you in the files of a consumer reporting agency (your “file
            disclosure”). You will be required to provide proper identification, which may include
            your Social Security number. In many cases, the disclosure will be free. You are
            entitled to a free file disclosure if:
            <S.List>
              <li>
                a person has taken adverse action against you because of information in your credit
                report;
              </li>
              <li>you are the victim of identity theft and place a fraud alert in your file;</li>
              <li>your file contains inaccurate information as a result of fraud;</li>
              <li>you are on public assistance;</li>
              <li>you are unemployed but expect to apply for employment within 60 days.</li>
            </S.List>
            In addition, all consumers are entitled to one free disclosure every 12 months upon
            request from each nationwide credit bureau and from nationwide specialty consumer
            reporting agencies. See{' '}
            <a target="_blank" rel="noreferrer" href="https://www.consumerfinance.gov/learnmore/">
              www.consumerfinance.gov/learnmore
            </a>{' '}
            for additional information.
          </li>
          <li>
            <b>You have the right to ask for a credit score.</b> Credit scores are numerical
            summaries of your credit-worthiness based on information from credit bureaus. You may
            request a credit score from consumer reporting agencies that create scores or distribute
            scores used in residential real property loans, but you will have to pay for it. In some
            mortgage transactions, you will receive credit score information for free from the
            mortgage lender.
          </li>
          <li>
            <b>You have the right to dispute incomplete or inaccurate information.</b> If you
            identify information in your file that is incomplete or inaccurate, and report it to the
            consumer reporting agency, the agency must investigate unless your dispute is frivolous.
            See{' '}
            <a target="_blank" rel="noreferrer" href="https://www.consumerfinance.gov/learnmore/">
              www.consumerfinance.gov/learnmore
            </a>{' '}
            for an explanation of dispute procedures.
          </li>
          <li>
            <b>
              Consumer reporting agencies must correct or delete inaccurate, incomplete, or
              unverifiable information.
            </b>{' '}
            Inaccurate, incomplete, or unverifiable information must be removed or corrected,
            usually within 30 days. However, a consumer reporting agency may continue to report
            information it has verified as accurate.
          </li>
          <li>
            <b>Consumer reporting agencies may not report outdated negative information.</b> In most
            cases, a consumer reporting agency may not report negative information that is more than
            seven years old, or bankruptcies that are more than 10 years old.
          </li>
          <li>
            <b>Access to your file is limited.</b> A consumer reporting agency may provide
            information about you only to people with a valid need – usually to consider an
            application with a creditor, insurer, employer, landlord, or other business. The FCRA
            specifies those with a valid need for access.
          </li>
          <li>
            <b>You must give your consent for reports to be provided to employers.</b> A consumer
            reporting agency may not give out information about you to your employer, or a potential
            employer, without your written consent given to the employer. Written consent generally
            is not required in the trucking industry. For more information, go to{' '}
            <a target="_blank" rel="noreferrer" href="https://www.consumerfinance.gov/learnmore/">
              www.consumerfinance.gov/learnmore
            </a>
            .
          </li>
          <li>
            <b>
              You may limit “prescreened” offers of credit and insurance you get based on
              information in your credit report.
            </b>{' '}
            Unsolicited “prescreened” offers for credit and insurance must include a toll-free phone
            number you can call if you choose to remove your name and address form the lists these
            offers are based on. You may opt out with the nationwide credit bureaus at
            1-888-5-OPTOUT (1-888-567-8688).
          </li>
          <li>
            The following FCRA right applies with respect to nationwide consumer reporting agencies:
          </li>
        </S.List>
        <Heading variant="h6" marginBottom="medium">
          Consumers Have the Right to Obtain a Security Freeze
        </Heading>
        <Text marginBottom="small" variant="small">
          You have a right to place a “security freeze” on your credit report, which will prohibit a
          consumer reporting agency from releasing information in your credit report without your
          express authorization. The security freeze is designed to prevent credit, loans, and
          services from being approved in your name without your consent. However, you should be
          aware that using a security freeze to take control over who gets access to the personal
          and financial information in your credit report may delay, interfere with, or prohibit the
          timely approval of any subsequent request or application you make regarding a new loan,
          credit, mortgage, or any other account involving the extension of credit.
        </Text>
        <Text marginBottom="small" variant="small">
          As an alternative to a security freeze, you have the right to place an initial or extended
          fraud alert on your credit file at no cost. An initial fraud alert is a 1-year alert that
          is placed on a consumer’s credit file. Upon seeing a fraud alert display on a consumer’s
          credit file, a business is required to take steps to verify the consumer’s identity before
          extending new credit. If you are a victim of identity theft, you are entitled to an
          extended fraud alert, which is a fraud alert lasting 7 years.
        </Text>
        <Text marginBottom="small" variant="small">
          A security freeze does not apply to a person or entity, or its affiliates, or collection
          agencies acting on behalf of the person or entity, with which you have an existing account
          that requests information in your credit report for the purposes of reviewing or
          collecting the account. Reviewing the account includes activities related to account
          maintenance, monitoring, credit line increases, and account upgrades and enhancements.
        </Text>
        <S.List>
          <li>
            <b>You may seek damages from violators.</b> If a consumer reporting agency, or, in some
            cases, a user of consumer reports or a furnisher of information to a consumer reporting
            agency violates the FCRA, you may be able to sue in state or federal court.
          </li>
          <li>
            <b>Identity theft victims and active duty military personnel have additional rights.</b>{' '}
            For more information, visit{' '}
            <a target="_blank" rel="noreferrer" href="https://www.consumerfinance.gov/learnmore/">
              www.consumerfinance.gov/learnmore
            </a>
            .
          </li>
        </S.List>
        <Text marginBottom="small" variant="small">
          <b>
            States may enforce the FCRA, and many states have their own consumer reporting laws. In
            some cases, you may have more rights under state law. For more information, contact your
            state or local consumer protection agency or your state Attorney General. For
            information about your federal rights, contact:
          </b>
        </Text>
        <S.TableContainer>
          <S.Table>
            <thead>
              <tr>
                <th>Type of Business</th>
                <th>Contact</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  1.a. Banks, savings associations, and credit unions with total assets of over $10
                  billion and their affiliates
                  <br />
                  <br /> b. Such affiliates that are not banks, savings assosiations, or credit
                  unions also should list, in addition to the CFPB:
                </td>
                <td>
                  a. Consumer Financial Brotection Bureau
                  <br /> 1700 G Street, N.W.
                  <br /> Washington, DC 20552
                  <br />
                  <br /> b. Federal Trade Commission
                  <br /> Consumer Response Center
                  <br /> 600 Pennsylvania Avenue, N.W.
                  <br /> Washington, DC 20580
                  <br /> (877) 382-4357
                </td>
              </tr>
              <tr>
                <td>
                  2. To the c.o. not included in item 1 above:
                  <br />
                  <br /> a. National banks, federal savings associations, and federal branches and
                  federal agencies of foreign banks
                  <br />
                  <br /> b. State member beaks, branches and agencies of foreign banks (other than
                  federal branches, federal agencies, and Insured State Branches of Foreign Banks),
                  commercial lending companies owned or controlled by foreign banks, and
                  organizations operating under section 25 or 25A of the Federal Reserve Act.
                  <br />
                  <br /> c. Nonmember Insured Banks, Insured State Branches of Foreign Banks, and
                  insured state savings associations
                  <br />
                  <br /> d. Federal Credit Unions
                </td>
                <td>
                  a. Office of the Comptroller of the Currency
                  <br /> Customer Assistance Group
                  <br /> 1301 McKinney Street, Suite 3450
                  <br /> Houston, TX 77010-9050
                  <br />
                  <br /> b. Federal Reserve Consumer Help Center
                  <br /> P.O. Box 1200
                  <br /> Minneapolis, MN 55480
                  <br />
                  <br /> c. FDIC Consumer Response Center
                  <br /> 1100 Walnut Street, Box #11
                  <br /> Kansas City, MO 64106
                  <br />
                  <br /> d. National Credit Union Administration Office of Consumer Financial
                  Protection (OCFP)
                  <br /> Division of Consumer Compliance Policy and Outreach
                  <br /> 1775 Duke Street
                  <br /> Alexandria, VA 22314
                </td>
              </tr>
              <tr>
                <td>3. Air carriers</td>
                <td>
                  Asst. General Counsel for Aviation Enforcement & Proceedings
                  <br /> Aviation VConsumer Protection Division
                  <br /> Department of Transportation
                  <br /> 1200 New Jersey Avenue, S.E.
                  <br /> Washington, DC 20423
                </td>
              </tr>
              <tr>
                <td>4. Creditors Subject to the Surface Transportation Board</td>
                <td>
                  Office of Proceedings, Surface Transportation Board Department of Transportation
                  <br /> 395E Street, S.W.
                  <br /> Washington, DC 20423
                </td>
              </tr>
              <tr>
                <td>5. Creditors Subject to the Packers and Stockyards Act, 1921</td>
                <td>Nearest Packers and Stockyards Administration area supervisor</td>
              </tr>
              <tr>
                <td>6. Small Business Investment Companies</td>
                <td>
                  Associate Deputy Administrator for Capital Access United States Small Business
                  <br /> Administration 409 Third Street, SM., Suite 8200
                  <br /> Washington, DC 20416
                </td>
              </tr>
              <tr>
                <td>7. Brokers and Dealers</td>
                <td>
                  Securities and Exchange Commission
                  <br /> 100 F Street, N.E.
                  <br /> Washington, DC 20549
                </td>
              </tr>
              <tr>
                <td>
                  8. Federal Land Banks, Federal Land Bank Associations, Federal Intermediate Credit
                  Banks, and Production Credit Associations
                </td>
                <td>
                  Farm Credit Administration
                  <br /> 1501 Farm Credit Drive
                  <br /> McLean, VA 22102-5090
                </td>
              </tr>
              <tr>
                <td>9. Retailers, Finance Companies, and All Other Creditors Not Listed Above</td>
                <td>
                  Federal Trade Commission
                  <br /> Consumer Response Center
                  <br /> 600 Pennsylvania Avenue, N.M.
                  <br /> Washington, DC 20580
                  <br /> (877) 382-9357
                </td>
              </tr>
            </tbody>
          </S.Table>
        </S.TableContainer>
        <div ref={bottomLine} />
      </S.Body>
      <S.Actions>
        <Button variant="secondary" size="medium" onClick={onDecline} disabled={!isRead || loading}>
          Decline
        </Button>
        <Button
          variant="primary"
          size="medium"
          onClick={handleAgree}
          loading={loading}
          disabled={!isRead || loading}
        >
          Agree
        </Button>
      </S.Actions>
    </S.Modal>
  );
};

export default FCRAModal;
