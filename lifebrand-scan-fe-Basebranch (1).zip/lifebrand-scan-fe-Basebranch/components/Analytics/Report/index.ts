export { default } from './ReportIndividual';
export * from './ReportIndividual';
