import React, { useCallback } from 'react';

import { Button, Icon } from '@UI/meeseeks';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

interface Props {
  pdfUrl: string;
}

const ExportToPdf = ({ pdfUrl }: Props) => {
  const { isMobile } = useBreakpoints();

  const handleClick = useCallback(() => {
    window.open(pdfUrl, '_blank');
  }, [pdfUrl]);

  return (
    <Button
      variant="tertiary"
      size="medium"
      iconLeft={<Icon name="File" size={16} color="secondary" />}
      onClick={handleClick}
      fluid={isMobile}
    >
      Export As PDF
    </Button>
  );
};
export default ExportToPdf;
