import React, { useCallback } from 'react';
import { useRouter } from 'next/router';

import { Button, Heading, Icon, Text, message } from '@UI/meeseeks';

import RejectReportRequestButton from 'components/ActionButtons/RejectReportRequestButton';

import {
  PendingReportRequestsDocument,
  ReportRequestDataFragment,
  useFulfillReportRequestMutation,
} from '@Generated/graphql';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { ROUTES } from '@Utils/helper/routes';

import * as S from './SubmitReportBanner.styles';

type Props = {
  reportRequest: ReportRequestDataFragment;
  reportId: string;
};

const SubmitReportBanner = ({ reportRequest, reportId }: Props) => {
  const { isDesktop } = useBreakpoints();
  const router = useRouter();
  const inviterName = reportRequest.Business.name || reportRequest.Business.contactEmail;
  const trimmedInviterName =
    inviterName.length > 26 ? `${inviterName.substring(0, 24)}...` : inviterName;

  const [fulfillReportRequest] = useFulfillReportRequestMutation({
    refetchQueries: [{ query: PendingReportRequestsDocument }],
  });

  const handleSuccess = useCallback(() => {
    message.success({
      title: 'Your report was successfully sent.',
    });
    router.push(ROUTES.DASHBOARD);
  }, []);

  const handleFailure = useCallback(() => {
    message.error({
      title: 'Failed to send report. Please try again.',
    });
  }, []);

  const onSubmitReport = useCallback(async () => {
    try {
      await fulfillReportRequest({
        variables: {
          reportRequestId: reportRequest.id,
          reportId,
        },
      });
      handleSuccess();
    } catch {
      handleFailure();
    }
  }, [reportRequest, reportId]);

  return (
    <S.Card>
      <S.Content>
        <Heading variant="h4" marginBottom="medium">
          Submit Report to {isDesktop ? inviterName : trimmedInviterName}
        </Heading>
        <Text variant="regular" marginBottom="medium">
          After you have reviewed your report, please press the “Submit {isDesktop && <br />}{' '}
          Report” button to share it with your employer.
        </Text>
        <S.ActionButtons>
          <RejectReportRequestButton reportRequest={reportRequest} buttonVariant="tertiary" />
          <Button
            variant="primary"
            size="medium"
            iconLeft={<Icon name="CheckCircle" size={16} color="#fff" />}
            onClick={onSubmitReport}
          >
            Submit Report
          </Button>
        </S.ActionButtons>
      </S.Content>
      {isDesktop && (
        <S.Image src="/images/png/banner-b2c-report-request.png" alt="Submit Report Request" />
      )}
    </S.Card>
  );
};

export default SubmitReportBanner;
