import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Card = styled.div`
  position: relative;
  display: flex;
  flex: 1;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  background-color: ${({ theme }) => theme.meeseeks.color['primary.200']};
  padding: ${({ theme }) => theme.spacing.extraLarge}px
    ${({ theme }) => theme.spacing.extraLarge + theme.spacing.small}px;
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  margin-top: ${({ theme }) => theme.spacing.large}px;
  z-index: 1;
  max-height: 200px;
  overflow: hidden;

  ${useBreakpoint.mobile`
    padding: ${({ theme }) => theme.spacing.large}px
    ${({ theme }) => theme.spacing.medium + theme.spacing.small / 2}px;
    justify-content: center;
    flex-direction: column;
    max-height: 300px;
  `}
`;

export const Content = styled.div``;
export const ActionButtons = styled.div`
  display: flex;
  direction: flex-start;
  gap: ${({ theme }) => theme.spacing.medium}px;
  align-items: center;

  ${useBreakpoint.mobile`
      & > * {
        flex: 1;
      }
  `}
`;

export const Image = styled.img`
  position: absolute;
  right: 32px;
  width: 250px;
  bottom: -10px;
  transform: rotate(10deg);
  z-index: -1;
`;
