import React from 'react';

import { fireEvent, render } from '@testing-library/react';
import 'jest-canvas-mock';

import { ThemeProvider } from 'styled-components';

import { MockedProvider, MockedResponse } from '@apollo/client/testing';

import { theme } from 'theme/theme';

import ReportIndividual from './ReportIndividual';

import {
  individualReportEmployerData,
  individualReportEmployerDataShared,
  individualReportPersonalData,
  mockIndividual0Report,
  mockNotSharedReport,
  mocksendReportPDF,
  mockSharedReport,
  TestReportInfo,
} from '../mocks/constants';

import { SubscriptionContext, SubscriptionContextProps } from '@Utils/SubscriptionContext';
import { ContextProps as AuthContextProps, useAuthContext } from '@Utils/AuthContext';
import { ReportDataFragment, UserDataFragment } from '@Generated/graphql';

const intersectionObserverMock = () => ({
  observe: () => null,
});

jest.mock('next/router', () => ({
  useRouter: jest.fn().mockReturnValue({
    route: '/',
    pathname: '',
    query: '',
    asPath: '',
    push: jest.fn(),
  }),
}));

window.IntersectionObserver = jest.fn().mockImplementation(intersectionObserverMock);

jest.mock('@Utils/hooks/useConnections', () => ({
  ...jest.requireActual('@Utils/hooks/useConnections'),
  useConnections() {
    return {
      ...jest.requireActual('@Utils/hooks/useConnections'),
      isActionsDisabled: false,
      isAnySocialMediaConnected: true,
      isAuthenticated: true,
      socialMediaConnection: [
        {
          isConnected: true,
          isMainIdentity: false,
          socialMedia: 'Facebook',
          userName: 'Erica Lumley',
        },
      ],
    };
  },
}));

jest.mock('@Utils/AuthContext', () => ({
  ...jest.requireActual('@Utils/AuthContext'),
  useAuthContext: jest.fn(),
}));

const mockUseAuth = (userData: AuthContextProps['userData'], isInvited = false) => {
  (useAuthContext as jest.Mock).mockReturnValue({
    userData,
    isInvited,
    triggerRefetch: (() => {}) as AuthContextProps['triggerRefetch'],
    loading: false,
    isLoggedIn: true,
    invitedBy: userData?.BusinessCustomer.filter((one) => one.isActive),
  });
};

// to avoid error TypeError: window.matchMedia is not a function
window.matchMedia =
  window.matchMedia ||
  function () {
    return {
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  };

type RenderProps = {
  subscriptionValue: SubscriptionContextProps;
  mockIndividualReportsData?: MockedResponse;
  mockSharedReportData?: MockedResponse;
  mockSendReportPDFData?: MockedResponse;
  reportData: ReportDataFragment;
  loading?: boolean;
};

const renderComponent = ({
  subscriptionValue,
  mockIndividualReportsData = mockIndividual0Report,
  mockSharedReportData = mockNotSharedReport,
  mockSendReportPDFData = mocksendReportPDF,
  reportData,
  loading = false,
}: RenderProps) => {
  return render(
    <ThemeProvider theme={theme}>
      <MockedProvider
        mocks={[mockIndividualReportsData, mockSharedReportData, mockSendReportPDFData]}
        addTypename={false}
      >
        <SubscriptionContext.Provider value={subscriptionValue}>
          <ReportIndividual reportData={reportData} loading={loading} />
        </SubscriptionContext.Provider>
      </MockedProvider>
    </ThemeProvider>,
  );
};

const generateTestData = () => {
  const user = ({
    notInvited: {
      id: 'ckwlyh99l06610ks6llxqvbee',
      name: 'Erica Lumley',
      email: 'erica_lumley@mail.com',
      photo:
        'https://scontent-sea1-1.xx.fbcdn.net/v/t1.30497-1/cp0/c15.0.50.50a/p50x50/84628273_176159830277856_972693363922829312_n.jpg?_nc_cat=1&ccb=1-5&_nc_sid=12b3be&_nc_ohc=BIVkKoTaVNgAX-TqIzy&_nc_ht=scontent-sea1-1.xx&edm=AP4hL3IEAAAA&oh=00_AT8evaGQNy4bMH2P7o4O56jiboovC8eBO9VqukZEePIq-g&oe=62316738',
      scanAmount: -1,
      authId: 'facebook|107403778058630',
      stripeId: 'cus_LA9n0FjaUMm5R9',
      planId: null,
      createdAt: '2022-02-15T15:43:13.947Z',
      updatedAt: '2022-02-17T15:07:24.154Z',
      lastRefresh: null,
      acceptedFcraVersion: 'v1-2022',
      acceptedPolicyVersion: 'v2022-01-19',
      hasPassword: false,
      BusinessCustomer: [
        {
          id: 'ckzoaolhd12740ks6q4wldyxt',
          type: 'PotentialEmployee',
          isActive: false,
          Business: {
            id: 'cks0899i200071cs69vsucf88',
            name: 'qacoakslab1',
            contactEmail: 'qa1oaks@gmail.com',
            __typename: 'PublicBusiness',
          },
          __typename: 'BusinessCustomer',
        },
      ],
      __typename: 'User',
      Plan: null,
    },
    invited: {
      id: 'ckwlyh99l06610ks6llxqvbee',
      name: 'Romulo Ganuza',
      email: 'romulo_ganuza@mail.com',
      photo:
        'https://scontent-sea1-1.xx.fbcdn.net/v/t1.30497-1/cp0/c15.0.50.50a/p50x50/84628273_176159830277856_972693363922829312_n.jpg?_nc_cat=1&ccb=1-5&_nc_sid=12b3be&_nc_ohc=BIVkKoTaVNgAX-TqIzy&_nc_ht=scontent-sea1-1.xx&edm=AP4hL3IEAAAA&oh=00_AT8evaGQNy4bMH2P7o4O56jiboovC8eBO9VqukZEePIq-g&oe=62316738',
      scanAmount: -1,
      authId: 'twitter|127403778058630',
      stripeId: 'cus_LA9n0FjaUMm6TY',
      planId: null,
      createdAt: '2021-12-15T12:03:13.947Z',
      updatedAt: '2021-12-17T15:07:24.154Z',
      lastRefresh: null,
      acceptedFcraVersion: 'v1-2022',
      acceptedPolicyVersion: 'v2022-01-19',
      hasPassword: false,
      BusinessCustomer: [
        {
          id: 'ckzoaolhd12740ks6q4wlllxt',
          type: 'CurrentEmployee',
          isActive: true,
          Business: {
            id: 'cks0899i200071cs69vsucf88',
            name: 'qacoakslab1',
            contactEmail: 'qa1oaks@gmail.com',
            __typename: 'PublicBusiness',
          },
          __typename: 'BusinessCustomer',
        },
      ],
      __typename: 'User',
      Plan: null,
    },
  } as unknown) as Record<string, UserDataFragment>;

  const subscriptions = {
    free: {
      features: {
        canScan: true,
        canUpgrade: true,
        canAccessAnalytics: false,
        canUseAdvancedDashboard: false,
      },
      plan: {
        name: 'Free',
        isCancellable: false,
        isCancelled: false,
        currentPeriodEnds: null,
      },
    },
    basic: {
      features: {
        canScan: false,
        canUpgrade: true,
        canAccessAnalytics: true,
        canUseAdvancedDashboard: true,
      },
      plan: {
        name: 'Basic',
        isCancellable: true,
        isCancelled: false,
        currentPeriodEnds: null,
      },
    },
    unlimited: {
      features: {
        canScan: true,
        canUpgrade: true,
        canAccessAnalytics: true,
        canUseAdvancedDashboard: true,
      },
      plan: {
        name: 'Unlimited',
        isCancellable: true,
        isCancelled: false,
        currentPeriodEnds: null,
      },
    },
  } as Record<string, Omit<SubscriptionContextProps, 'loading'>>;

  const individualReportPersonal = individualReportPersonalData as ReportDataFragment;
  const individualReportEmployer = individualReportEmployerData as ReportDataFragment;
  const individualReportEmployerShared = individualReportEmployerDataShared as ReportDataFragment;

  return {
    user,
    subscriptions,
    individualReportPersonal,
    individualReportEmployer,
    individualReportEmployerShared,
  };
};

const testData = generateTestData();
window.open = jest.fn();

describe('Report Individual', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('downloads Personal Report', async () => {
    mockUseAuth({ ...testData.user.notInvited }, false);
    const { findByText, getByText, getByRole, queryByRole } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      reportData: testData.individualReportPersonal,
    });

    expect(await findByText(TestReportInfo.Personal.reportName)).toBeInTheDocument();
    expect(getByText(/👨/)).toBeInTheDocument();

    const downloadButton = getByRole('button', { name: /Export as PDF/gi });
    expect(downloadButton).toBeEnabled();

    expect(queryByRole('button', { name: /Send Report/i })).not.toBeInTheDocument();

    expect(downloadButton).toBeEnabled();
    fireEvent.click(downloadButton);

    expect(window.open).toHaveBeenCalledTimes(1);
    expect(window.open).toHaveBeenCalledWith(`${TestReportInfo.Personal.reportURL}`, '_blank');
  });

  it('shows FCRA Report with Custom Dictionary tab - Invited employee', async () => {
    mockUseAuth({ ...testData.user.invited }, true);
    const { getByText } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      reportData: testData.individualReportEmployerShared,
      mockSharedReportData: mockSharedReport,
    });

    expect(getByText(/Custom Dictionary/gi)).toBeInTheDocument();
  });

  it('shows FCRA Report - not Invited', async () => {
    mockUseAuth({ ...testData.user.notInvited }, false);
    const { findByText, getByText, getByRole, queryByText } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      reportData: testData.individualReportEmployer,
    });

    expect(await findByText(TestReportInfo.Employer.reportName)).toBeInTheDocument();
    expect(getByText(/💼/)).toBeInTheDocument();

    expect(queryByText(/Inviter/gi)).not.toBeInTheDocument();

    const downloadButton = getByRole('button', { name: /Export as PDF/i });
    expect(downloadButton).toBeEnabled();

    const sendButton = getByRole('button', { name: /Send Report/i });
    expect(sendButton).toBeEnabled();

    // Even if is not Invited, Custom Dictionary will show if there was data
    expect(getByText(/Custom Dictionary/gi)).toBeInTheDocument();
  });

  it('shows FCRA Report with No Sent Flagged - Invited employee', async () => {
    mockUseAuth({ ...testData.user.invited }, true);
    const { findByText, getByText, getByRole } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      reportData: testData.individualReportEmployer,
    });

    expect(await findByText(TestReportInfo.Employer.reportName)).toBeInTheDocument();
    expect(getByText(/💼/)).toBeInTheDocument();
    expect(getByText('Not Sent to Inviter')).toBeInTheDocument();

    const downloadButton = getByRole('button', { name: /Export as PDF/i });
    expect(downloadButton).toBeEnabled();

    const sendButton = getByRole('button', { name: /Send Report/i });
    expect(sendButton).toBeEnabled();
  });

  it('shows FCRA Report with Sent Flagged - Invited employee', async () => {
    mockUseAuth({ ...testData.user.invited }, true);
    const { findByText, getByText, getByRole } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      reportData: testData.individualReportEmployerShared,
      mockSharedReportData: mockSharedReport,
    });

    expect(await findByText(TestReportInfo.Employer.reportName)).toBeInTheDocument();
    expect(getByText(/💼/)).toBeInTheDocument();
    expect(getByText('Sent to Inviter')).toBeInTheDocument();

    const downloadButton = getByRole('button', { name: /Export as PDF/i });
    expect(downloadButton).toBeEnabled();

    const sendButton = getByRole('button', { name: /ReSend Report/i });
    expect(sendButton).toBeEnabled();
  });
});
