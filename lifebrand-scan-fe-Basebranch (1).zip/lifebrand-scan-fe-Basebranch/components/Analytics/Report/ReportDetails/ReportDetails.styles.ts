import styled from 'styled-components';

export const EmptyWrapper = styled.div`
  height: 330px;
  width: 100%;
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: center;
`;

export const WatermarkImage = styled.img`
  position: absolute;
  top: 0;
  right: 0;
  width: 480px;
  z-index: -1;
`;
