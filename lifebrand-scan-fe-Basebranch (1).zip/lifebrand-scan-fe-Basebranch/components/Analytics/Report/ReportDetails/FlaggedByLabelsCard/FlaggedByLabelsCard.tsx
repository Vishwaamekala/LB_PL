import React, { useMemo } from 'react';

import DonutGraph from '@UI/Graphs/DonutGraph';
import { getFlaggedPostLabelColors } from '@UI/Graphs/utils/flaggedLabelsConfig';
import ReportCard from 'components/Analytics/Report/UI/ReportCard';

import { getLegendConfig, tooltip } from '../donutGraphConfig';
import { DonutGraphData } from '../types';
import { formatLabelsBreakdownData } from '../utils';
import { GRAPH_STYLES } from '../constants';

import { FlaggedPostLabelsBreakdownResponse } from '@Generated/graphql';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

type Props = {
  labelsBreakdownData?: FlaggedPostLabelsBreakdownResponse;
};

const FlaggedByLabelsCard = ({ labelsBreakdownData }: Props) => {
  const { isMobile } = useBreakpoints();

  const formattedProfanitiesBreakdown = useMemo(() => {
    if (!labelsBreakdownData) {
      return [];
    }
    return formatLabelsBreakdownData(labelsBreakdownData);
  }, [labelsBreakdownData]);

  if (!labelsBreakdownData) {
    return <div>{'No data'}</div>;
  }

  return (
    <ReportCard headerText="Flagged Posts Breakdown" headerVariant="h5">
      <DonutGraph<DonutGraphData>
        data={formattedProfanitiesBreakdown}
        angleField="value"
        colorField="type"
        color={getFlaggedPostLabelColors}
        height={isMobile ? GRAPH_STYLES.height.small : GRAPH_STYLES.height.normal}
        legend={getLegendConfig(formattedProfanitiesBreakdown)}
        tooltip={tooltip}
      />
    </ReportCard>
  );
};

export default FlaggedByLabelsCard;
