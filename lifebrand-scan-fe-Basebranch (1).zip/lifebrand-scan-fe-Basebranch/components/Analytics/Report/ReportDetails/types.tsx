import { OriginsBreakdown } from '@Generated/graphql';

export type ColumnGraphData = {
  date: string;
  value: number;
  type: string;
};

export type DonutGraphData = {
  value: number;
  type: string;
};

// Database JSON Year Breakdown
export type TimelineBreakdown = {
  // Year as key and months are child
  [key: string]: MonthlyBreakdown;
};

// Month Breakdown
export type MonthlyBreakdown = {
  [key: string]: OriginsBreakdown;
};

export type YearlyData = { year: number; data: ColumnGraphData[] };
export type YearlyAggregatedData = { data: ColumnGraphData[] };
