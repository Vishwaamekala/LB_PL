import React, { useMemo } from 'react';

import { DonutGraphData } from '../types';

import ReportCard from 'components/Analytics/Report/UI/ReportCard';
import DonutGraph from '@UI/Graphs/DonutGraph';
import { getOverallColors } from '@UI/Graphs/utils/overallConfig';

import { getLegendConfig, tooltip } from '../donutGraphConfig';
import { GRAPH_STYLES } from '../constants';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

type Props = {
  nonFlaggedContentsCount: number;
  flaggedContentsCount: number;
  deletedFlaggedContentsCount: number;
};

const OverallPostsCard = ({
  nonFlaggedContentsCount,
  flaggedContentsCount,
  deletedFlaggedContentsCount,
}: Props) => {
  const { isMobile } = useBreakpoints();

  const graphData: DonutGraphData[] = useMemo(
    () => [
      {
        type: 'non-Flagged',
        value: nonFlaggedContentsCount,
      },
      {
        type: 'Flagged',
        value: flaggedContentsCount,
      },
      {
        type: 'Deleted',
        value: deletedFlaggedContentsCount,
      },
    ],
    [nonFlaggedContentsCount, flaggedContentsCount, deletedFlaggedContentsCount],
  );

  return (
    <ReportCard headerText="Overall Posts" headerVariant="h5">
      <DonutGraph<DonutGraphData>
        data={graphData}
        angleField="value"
        colorField="type"
        color={getOverallColors}
        height={isMobile ? GRAPH_STYLES.height.small : GRAPH_STYLES.height.normal}
        legend={getLegendConfig(graphData)}
        tooltip={tooltip}
      />
    </ReportCard>
  );
};

export default OverallPostsCard;
