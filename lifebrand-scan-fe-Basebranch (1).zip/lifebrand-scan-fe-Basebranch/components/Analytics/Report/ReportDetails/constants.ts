import { theme } from 'theme/theme';

export enum TabsValue {
  Months = 'Months',
  Years = 'Years',
}

export const TABS_OPTIONS = [
  { key: TabsValue.Months, title: TabsValue.Months, disabled: false },
  { key: TabsValue.Years, title: TabsValue.Years, disabled: false },
];

export const GRAPH_STYLES = {
  fontFamily: 'Poppins',
  fontSize: 12,
  fontSizeLabel: 12,
  colorAxisLine: '#E5E7EB',
  colorLabel: theme.meeseeks.color.caption,
  colorText: theme.meeseeks.color.body,
  height: {
    small: 120,
    normal: 150,
  },
};
