export { default } from './FlaggedByOriginsCard';
export * from './FlaggedByOriginsCard';
