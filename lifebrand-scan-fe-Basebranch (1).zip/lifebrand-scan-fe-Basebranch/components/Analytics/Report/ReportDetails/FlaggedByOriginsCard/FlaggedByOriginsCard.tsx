import React, { useMemo } from 'react';

import { DonutGraphData } from '../types';

import ReportCard from 'components/Analytics/Report/UI/ReportCard';
import DonutGraph from '@UI/Graphs/DonutGraph';
import { getColors } from '@UI/Graphs/utils/socialMediaConfig';

import { getLegendConfig, tooltip } from '../donutGraphConfig';
import { formatOriginsBreakdownCount } from '../utils';
import { GRAPH_STYLES } from '../constants';

import { OriginsBreakdown } from '@Generated/graphql';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

type Props = {
  originsBreakdownData?: OriginsBreakdown;
};

const FlaggedByOriginsCard = ({ originsBreakdownData }: Props) => {
  const { isMobile } = useBreakpoints();

  const formattedOriginsBreakdownData = useMemo(() => {
    if (!originsBreakdownData) {
      return [];
    }
    return formatOriginsBreakdownCount(originsBreakdownData);
  }, [originsBreakdownData]);

  if (!originsBreakdownData) {
    return <div>{'No data'}</div>;
  }

  return (
    <ReportCard headerText="Flagged by Social Media" headerVariant="h5">
      <DonutGraph<DonutGraphData>
        data={formattedOriginsBreakdownData}
        angleField="value"
        colorField="type"
        color={getColors}
        height={isMobile ? GRAPH_STYLES.height.small : GRAPH_STYLES.height.normal}
        legend={getLegendConfig(formattedOriginsBreakdownData)}
        tooltip={tooltip}
      />
    </ReportCard>
  );
};

export default FlaggedByOriginsCard;
