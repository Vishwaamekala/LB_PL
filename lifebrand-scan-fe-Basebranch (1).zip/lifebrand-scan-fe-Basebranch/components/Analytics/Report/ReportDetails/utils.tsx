import { DonutGraphData } from './types';

import {
  FlaggedPostLabelsBreakdownResponse,
  OriginsBreakdown,
  SocialMedia,
} from '@Generated/graphql';
import { toxicityLabelsByKey } from '@Utils/toxicityLabels/constants';
import { ToxicityLabelKey } from '@Utils/toxicityLabels/types';

const SocialMedias = [SocialMedia.Facebook, SocialMedia.Twitter, SocialMedia.Instagram];

export const sanitizeOriginsBreakdownData = (breakdown: OriginsBreakdown) =>
  SocialMedias.reduce(
    (prev, socialMedia) => ({
      ...prev,
      [socialMedia]: breakdown[socialMedia],
    }),
    {
      [SocialMedia.Facebook]: 0,
      [SocialMedia.Twitter]: 0,
      [SocialMedia.Instagram]: 0,
    },
  );

export const formatOriginsBreakdownCount = (data: OriginsBreakdown): DonutGraphData[] =>
  Object.entries(sanitizeOriginsBreakdownData(data))
    .map(([type, value]) => ({
      type,
      value,
    }))
    .filter((origin) => origin.value !== 0);

export const formatLabelsBreakdownData = (
  labelBreakdown: FlaggedPostLabelsBreakdownResponse,
): DonutGraphData[] => {
  return Object.entries(toxicityLabelsByKey)
    .map(([key, data]) => {
      const count = labelBreakdown[key as ToxicityLabelKey] ?? 0;
      return {
        type: data.title,
        value: count,
      };
    })
    .filter((label) => label.value !== 0);
};
