import { sanitizeOriginsBreakdownData } from '../utils';
import { ColumnGraphData, MonthlyBreakdown, TimelineBreakdown, YearlyData } from '../types';

import { OriginsBreakdown, SocialMedia } from '@Generated/graphql';

export const formatFlaggedData = (date: string, data: OriginsBreakdown): ColumnGraphData[] =>
  Object.entries(sanitizeOriginsBreakdownData(data)).map(([type, value]) => ({
    date,
    type,
    value,
  }));

export const MONTH_NAMES = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

export const formatMonthlyBreakdown = (data: MonthlyBreakdown) =>
  Object.keys(data).reduce<ColumnGraphData[]>((acc, month) => {
    return [...acc, ...formatFlaggedData(MONTH_NAMES[Number(month)], data[month])];
  }, []);

export const formatYearlyBreakDown = (data: TimelineBreakdown): YearlyData[] =>
  Object.keys(data)
    .reduce<YearlyData[]>(
      (acc, year) => [...acc, { year: Number(year), data: formatMonthlyBreakdown(data[year]) }],
      [],
    )
    .sort((a, b) => a.year - b.year);

export const aggregateMonthlySocialMedia = (monthsOfTheYearData: MonthlyBreakdown) => {
  return Object.entries(monthsOfTheYearData).reduce(
    (state, [, value]) => {
      return {
        [SocialMedia.Facebook]: state[SocialMedia.Facebook] + value[SocialMedia.Facebook],
        [SocialMedia.Twitter]: state[SocialMedia.Twitter] + value[SocialMedia.Twitter],
        [SocialMedia.Instagram]: state[SocialMedia.Instagram] + value[SocialMedia.Instagram],
      };
    },
    {
      [SocialMedia.Facebook]: 0,
      [SocialMedia.Twitter]: 0,
      [SocialMedia.Instagram]: 0,
    },
  );
};

const COMPLIANCE_FCRA_INTERVAL = 7;
const createEmptyForYear = (year: string): ColumnGraphData[] => {
  return Object.values(SocialMedia).map((type) => ({ date: year, type, value: 0 }));
};

export const completeOverviewYearData = (
  yearOfScan: string,
  yearTimelineKeys: string[],
  aggregatedOverview: ColumnGraphData[],
) => {
  const yearsToDisplay = [];
  const startYear = Number(yearOfScan) - COMPLIANCE_FCRA_INTERVAL;
  for (let i = 1; i < COMPLIANCE_FCRA_INTERVAL; i += 1) {
    yearsToDisplay.push(`${startYear + i}`.toString());
  }

  yearsToDisplay.forEach((year) => {
    if (!yearTimelineKeys.includes(year)) {
      aggregatedOverview.push(...createEmptyForYear(year));
    }
  });
  return aggregatedOverview.sort(
    (a: ColumnGraphData, b: ColumnGraphData): number => Number(a.date) - Number(b.date),
  );
};

export const aggregateOverviewYearData = (yearTimeline: TimelineBreakdown, yearOfScan: string) => {
  const some = Object.entries(yearTimeline).reduce<ColumnGraphData[]>((state, [key, value]) => {
    const socialMediaAggregation = aggregateMonthlySocialMedia(value);

    const aggregatedMonths = Object.entries(socialMediaAggregation).map(
      ([socialMediaKey, val]) => ({
        date: key,
        type: socialMediaKey as SocialMedia,
        value: val,
      }),
    );
    return [...state, ...aggregatedMonths];
  }, []);

  return completeOverviewYearData(yearOfScan, Object.keys(yearTimeline), some);
};
