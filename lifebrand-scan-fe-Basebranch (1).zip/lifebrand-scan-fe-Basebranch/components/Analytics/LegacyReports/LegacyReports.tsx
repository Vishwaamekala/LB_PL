import React, { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/router';
import { Col, Row } from 'antd';
import { useTheme } from 'styled-components';

import GoBack from '@UI/GoBack';
import List from 'components/Analytics/LegacyReports/List';
import ReportOldItem from 'components/Analytics/LegacyReports/List/LegacyReportItem';
import LegacyReport from 'components/Analytics/LegacyReport';

import { ROUTES } from '@Utils/helper/routes';
import { useIndividualLegacyReportsQuery } from '@Generated/graphql';

import * as S from './LegacyReports.styles';

const LegacyReports = () => {
  const theme = useTheme();
  const router = useRouter();

  const { data } = useIndividualLegacyReportsQuery();

  const [selectedReportId, setSelectedReportId] = useState<string>();

  useEffect(() => {
    if (!selectedReportId && data?.individualLegacyReports[0]) {
      setSelectedReportId(data?.individualLegacyReports[0].id);
    }
  }, [data, selectedReportId]);

  const selectedReport = useMemo(() => {
    if (!selectedReportId) return undefined;
    return data?.individualLegacyReports.find((one) => one.id === selectedReportId);
  }, [data, selectedReportId]);

  return (
    <S.Container>
      <S.BackWrap>
        <GoBack title="Report History" action={() => router.push(ROUTES.REPORT_HISTORY)} />
      </S.BackWrap>
      <Row gutter={[theme.spacing.large, theme.spacing.large]}>
        <Col span={24} lg={6}>
          <List
            title={
              !data?.individualLegacyReports.length
                ? 'No Reports Yet'
                : `${data?.individualLegacyReports.length} Total Reports`
            }
          >
            {data?.individualLegacyReports.map((reportOld) => (
              <ReportOldItem
                reportOld={reportOld}
                isSelected={reportOld.id === selectedReportId}
                onClick={() => setSelectedReportId(reportOld.id)}
                key={reportOld.id}
              />
            ))}
          </List>
        </Col>
        <Col span={24} lg={18}>
          {selectedReport && <LegacyReport reportData={selectedReport} loading={false} />}
        </Col>
      </Row>
    </S.Container>
  );
};

export default LegacyReports;
