import styled from 'styled-components';

export const Container = styled.div`
  max-width: 1200px;
  margin-left: auto;
  margin-right: auto;
  display: flex;
  flex-direction: column;
  padding: ${({ theme }) => `${theme.spacing.large}px ${theme.spacing.medium}px 0`};
`;

export const BackWrap = styled.div`
  margin: ${({ theme }) =>
    `${theme.spacing.large + theme.spacing.medium}px 0  ${theme.spacing.large}px`};
`;
