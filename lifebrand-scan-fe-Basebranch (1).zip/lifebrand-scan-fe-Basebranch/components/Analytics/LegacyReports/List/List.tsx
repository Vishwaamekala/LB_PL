import React, { useState } from 'react';
import Skeleton from 'react-loading-skeleton';

import SkeletonItem from './SkeletonItem';

import { IconButton, Heading, Text } from '@UI/meeseeks';

import * as S from './List.styles';

const LIMIT = 20;

const skeletonItems = Array(6).fill(0);

type Props = {
  title: string;
  loading?: boolean;
  children: React.ReactNode;
};

const ListOfScansDesktop = ({ title, loading, children }: Props) => {
  const [page, setPage] = useState(0);

  const items = React.Children.toArray(children);
  const isEmpty = items.length === 0;

  const startIndex = page * LIMIT;
  const endIndex = Math.min(startIndex + LIMIT, items.length || 0);
  const visibleItems = items.slice(startIndex, endIndex);

  return (
    <S.List id="scans-list">
      <S.Header>
        {loading ? <Skeleton width={100} /> : <Heading variant="h6">{title}</Heading>}
      </S.Header>
      <S.Content>
        {loading ? skeletonItems.map((_, index) => <SkeletonItem key={index} />) : visibleItems}
      </S.Content>
      <S.Footer isEmpty={isEmpty || loading}>
        <IconButton name="ChevronsLeft" onClick={() => setPage(0)} disabled={startIndex === 0} />
        <IconButton
          name="ChevronLeft"
          onClick={() => setPage(page - 1)}
          disabled={startIndex === 0}
        />
        <Text variant="small">
          {startIndex + 1}-{endIndex} of {items.length}
        </Text>
        <IconButton
          name="ChevronRight"
          onClick={() => setPage(page + 1)}
          disabled={endIndex === items.length}
        />
        <IconButton
          name="ChevronsRight"
          onClick={() => setPage(Math.floor((items.length || 0) / LIMIT))}
          disabled={endIndex === items.length}
        />
      </S.Footer>
    </S.List>
  );
};

export default ListOfScansDesktop;
