import React from 'react';

import { Heading, Text } from '@UI/meeseeks';

import { formatDateDistance } from '@Utils/formatters/date';
import { ReportOldDataFragment } from '@Generated/graphql';

import * as S from '../List.styles';

type Props = {
  reportOld: ReportOldDataFragment;
  isSelected?: boolean;
  onClick?: () => void;
};

const LegacyReportItem = ({ reportOld, isSelected, onClick }: Props) => {
  return (
    <S.Item role="button" isSelected={isSelected} onClick={onClick}>
      <Text variant="small" marginBottom="xs" textColor="caption">
        {formatDateDistance(new Date(reportOld.createdAt))}
      </Text>

      <Heading variant="h6" textColor="heading" marginBottom="xxs">
        {reportOld.harmfulPostCount === 0
          ? 'No flagged posts'
          : `${reportOld.harmfulPostCount} flagged posts`}
      </Heading>

      <Text variant="small" textColor="body">
        {reportOld.deletedPostCount === 0 && reportOld.ignoredPostCount === 0 ? (
          'no actions'
        ) : (
          <>
            you deleted <b>{reportOld.deletedPostCount}</b> and ignored{' '}
            <b>{reportOld.ignoredPostCount}</b> posts
          </>
        )}
      </Text>
    </S.Item>
  );
};

export default LegacyReportItem;
