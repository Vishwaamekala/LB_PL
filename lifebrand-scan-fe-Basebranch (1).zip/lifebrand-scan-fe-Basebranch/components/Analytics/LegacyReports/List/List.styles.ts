import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

const NEGATIVE_SPACE_LIST_SCANS_SIZE = '202px';
const ONE_VISUALIZED_SCAN_SIZE = '242px';

export const List = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1;
  width: 100%;
  height: calc(100vh - ${NEGATIVE_SPACE_LIST_SCANS_SIZE});
  // minim visualization of 1 scan
  min-height: ${ONE_VISUALIZED_SCAN_SIZE};
  box-shadow: 0px 4px 8px rgba(78, 76, 140, 0.04);
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  background: ${({ theme }) => theme.meeseeks.color['neutrals.100']};

  ${useBreakpoint.mobile`
    max-height: 400px;
  `}
`;

export const Header = styled.div`
  min-height: 64px;
  display: flex;
  justify-content: center;
  align-items: center;
`;

export const Content = styled.div`
  flex: 1;
  margin: 0px ${({ theme }) => theme.spacing.medium}px;
  border: 1px solid rgba(221, 221, 221, 0.8);
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  background: ${({ theme }) => theme.meeseeks.color.white};
  overflow: auto;
`;

export const SkeletonItem = styled.div`
  padding: ${({ theme }) => theme.spacing.medium}px;

  & :not(:last-child) {
    border-bottom: ${({ theme }) => theme.border.cardLight};
  }

  & > * {
    display: block;
  }
`;

export const Item = styled.div<{ isSelected?: boolean }>`
  position: relative;
  padding: ${({ theme }) => theme.spacing.medium}px;
  cursor: pointer;

  & :not(:last-child) {
    border-bottom: 1px solid rgba(221, 221, 221, 0.4);
  }

  ${({ isSelected, theme }) =>
    isSelected
      ? `background: rgba(${theme.color.primaryRgb}, 0.16);`
      : `:hover { background: rgba(${theme.color.primaryRgb}, 0.08); }`}
`;

export const Icons = styled.div`
  display: flex;
  opacity: 0.8;
  margin: 0px ${({ theme }) => -theme.spacing.small / 2}px;

  & > * {
    width: 16px;
    height: 16px;
  }
`;

export const Footer = styled.div<{ isEmpty?: boolean }>`
  min-height: 64px;
  display: flex;
  justify-content: center;
  align-items: center;

  & > * {
    margin: 0px 6px;
  }

  ${({ isEmpty }) =>
    isEmpty &&
    `
    height: 42px;
    & > * {
      display: none;
    }
  `}
`;
