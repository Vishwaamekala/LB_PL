import React from 'react';

import SkeletonItemDesktop from './SkeletonItemDesktop';
import SkeletonItemMobile from './SkeletonItemMobile';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

const SkeletonItem = () => {
  const { isMobile, isTablet, isDesktop } = useBreakpoints();

  if (isMobile || isTablet) {
    return <SkeletonItemMobile />;
  }
  if (isDesktop) {
    return <SkeletonItemDesktop />;
  }

  // do not render anything if cannot find a breakpoint yet
  return null;
};

export default SkeletonItem;
