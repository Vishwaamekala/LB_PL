import React from 'react';
import Skeleton from 'react-loading-skeleton';

import * as S from '../List.styles';

const SkeletonItemDesktop = () => {
  return (
    <S.SkeletonItem>
      <Skeleton width="35%" />
      <Skeleton width="50%" />
      <Skeleton width="75%" />
      <Skeleton width="25%" />
    </S.SkeletonItem>
  );
};

export default SkeletonItemDesktop;
