import React from 'react';
import Skeleton from 'react-loading-skeleton';

import * as S from '../List.styles';

const SkeletonItemMobile = () => {
  return (
    <S.SkeletonItem>
      <Skeleton width="35%" />
      <Skeleton width="50%" />
    </S.SkeletonItem>
  );
};

export default SkeletonItemMobile;
