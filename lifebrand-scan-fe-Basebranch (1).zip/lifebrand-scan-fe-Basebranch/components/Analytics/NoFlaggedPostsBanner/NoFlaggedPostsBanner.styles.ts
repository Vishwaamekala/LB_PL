import styled from 'styled-components';

import { Text as TextBase } from '@UI/meeseeks';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Banner = styled.div`
  background-color: ${({ theme }) => theme.meeseeks.color['primary.800']};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  position: relative;
  display: flex;
  width: 100%;

  ${useBreakpoint.tablet`
    flex-direction: column;
    align-items: center;
  `}
`;

export const CopyWrapper = styled.div`
  padding: ${({ theme }) => `${theme.spacing.medium * 4}px ${theme.spacing.small * 5}px`};
  position: relative;
  z-index: 1;

  ${useBreakpoint.tablet`
    text-align: center;
    padding: ${({ theme }) => `${theme.spacing.medium * 4}px ${theme.spacing.small * 5}px 0`};
  `}
`;

export const Image = styled.img`
  position: absolute;
  top: 0;
  right: 40px;
  width: 460px;
  height: 100%;
  object-fit: cover;
  overflow: hidden;

  ${useBreakpoint.tablet`
    position: initial;
    width: 340px;
  `}

  ${useBreakpoint.mobile`
    width: 320px;
  `}
`;

export const Text = styled(TextBase)`
  width: 290px;
`;
