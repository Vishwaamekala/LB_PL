import React from 'react';

import { Heading } from '@UI/meeseeks';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import * as S from './NoFlaggedPostsBanner.styles';

interface Props {
  allFlaggedDeleted?: boolean;
  isFCRACompliant?: boolean;
}

const NoFlaggedPostsBanner = ({ allFlaggedDeleted, isFCRACompliant }: Props) => {
  const { isMdDesktop, isDesktop } = useBreakpoints();

  return (
    <S.Banner>
      <S.CopyWrapper>
        <Heading variant="h3" textColor="#fff" marginBottom="medium">
          You Blow Our Mind!
        </Heading>
        <S.Text variant="regular" textColor="neutrals.100">
          {`No Flagged Posts Found. ${
            (allFlaggedDeleted &&
              !isFCRACompliant &&
              'Seems like you deleted everything that could have been flagged.') ||
            ''
          }`}
        </S.Text>
      </S.CopyWrapper>
      <S.Image
        src={
          isMdDesktop || isDesktop
            ? '/images/png/no-flagged-posts.png'
            : '/images/png/no-flagged-posts-mobile.png'
        }
        alt="No Flagged Posts"
      />
    </S.Banner>
  );
};

export default NoFlaggedPostsBanner;
