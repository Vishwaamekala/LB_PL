import { format } from 'date-fns';

import { ReportType } from '@Generated/graphql';

const FORMAT = 'yyyy-MM-dd';
const TODAY = new Date();

const defaultReportNames = {
  [ReportType.Personal]: 'My Report',
  [ReportType.Employer]: 'FCRA Compliant Report',
} as const;

export const generateReportName = (reportType: ReportType) => {
  const templateName = defaultReportNames[reportType];
  return `${templateName} ${format(TODAY, FORMAT)}`;
};

export const reportOptions = [
  {
    label: 'FCRA Compliant Report',
    value: ReportType.Employer,
  },
  {
    label: 'General Report (Personal Use Only)',
    value: ReportType.Personal,
  },
];
