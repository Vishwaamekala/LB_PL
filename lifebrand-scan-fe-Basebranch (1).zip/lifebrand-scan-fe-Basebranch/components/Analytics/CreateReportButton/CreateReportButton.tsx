import React, { useCallback, useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { ButtonProps } from '@lifebrand/meeseeks/build/src/latest/component/Atom/Button';

import { generateReportName, reportOptions } from './utils';

import { Button, Heading, Icon, Input, message, Select, Text } from '@UI/meeseeks';
import Modal from '@UI/Modal';

import { ROUTES } from '@Utils/helper/routes';
import { TriggerClass } from '@Utils/google-tag-manager';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';
import { useSubscriptionContext } from '@Utils/SubscriptionContext/useSubscriptionContext';

import { IndividualReportsDocument, ReportType, useCreateReportMutation } from '@Generated/graphql';
import { MAX_REPORT_NAME } from '@Utils/reports/constants';

import * as S from './CreateReportButton.styles';

interface Props extends Partial<ButtonProps> {
  currentTab: ReportType;
}

const CreateReportButton = ({ size = 'large', disabled, currentTab }: Props) => {
  const router = useRouter();
  const { features } = useSubscriptionContext();
  const { isMobile } = useBreakpoints();
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [selectedReportType, setSelectedReportType] = useState<ReportType>(currentTab);
  const [reportName, setReportName] = useState('');
  const [isDefaultName, setIsDefaultName] = useState(true);

  const defaultOption = reportOptions.find((option) => option.value === selectedReportType);

  const [createReport, { loading }] = useCreateReportMutation({
    refetchQueries: [{ query: IndividualReportsDocument }],
  });

  useEffect(() => {
    if (currentTab) {
      setSelectedReportType(currentTab);
      if (isDefaultName) {
        setReportName(generateReportName(currentTab));
      }
    }
  }, [currentTab, isDefaultName]);

  const handleReportTemplate = useCallback(
    (value) => {
      if (value) {
        setSelectedReportType(value?.value);
        if (isDefaultName) {
          setReportName(generateReportName(value?.value));
        }
      }
    },
    [isDefaultName],
  );

  const handleCancel = () => {
    setIsDefaultName(true);
    setIsModalOpen(false);
  };

  const handleCreateReport = useCallback(async () => {
    message.info({
      title: 'Creating report...',
    });

    try {
      const report = await createReport({
        variables: {
          type: selectedReportType,
          name: reportName,
        },
      });

      const createdReportId = report.data?.createReport.id;

      if (createdReportId) {
        message.success({
          title: 'Report successfully created.',
        });

        setIsModalOpen(false);

        router.push({
          pathname: ROUTES.REPORT,
          query: { id: createdReportId },
        });
      }
    } catch (e) {
      message.error({
        title: 'Failed to load report. Please try again.',
      });
    }
  }, [reportName, router]);

  return (
    <>
      <Button
        variant="secondary"
        size={size}
        onClick={() => setIsModalOpen(true)}
        iconLeft={<Icon name="FilePlus" color="#fff" />}
        disabled={!features?.canAccessAnalytics || loading || disabled} // TODO : add condition !reportRequestId
        loading={loading}
        fluid={isMobile}
      >
        Create Report
      </Button>
      <Modal
        visible={isModalOpen}
        onCancel={handleCancel}
        footer={null}
        width={630}
        wrapProps={{ 'data-testid': 'create-report-modal' }}
      >
        <S.HeadingWrap>
          <Heading
            variant={isMobile ? 'h4' : 'h3'}
            marginBottom={isMobile ? 'small' : 'large'}
            textAlign={isMobile ? 'left' : 'center'}
          >
            Create Report
          </Heading>
          <Text variant="regular" textAlign="center">
            Make sure to select an FCRA compliant report if you are sharing it with anybody, for
            personal use create a General Report that contains overall data.
          </Text>
        </S.HeadingWrap>
        {selectedReportType === ReportType.Employer && (
          <S.Alert>
            <Icon name="Warning" size={32} color="highlight.300" />
            <Text variant="regular" textColor="body">
              To make sure all the reports are FCRA compliant, we display data only up to seven
              years back from the moment the scan was conducted.
            </Text>
          </S.Alert>
        )}
        <S.SelectWrap>
          <Select
            fluid
            options={reportOptions}
            value={defaultOption}
            placeholder={'Select Report Template'}
            onChange={handleReportTemplate}
          />
        </S.SelectWrap>
        <S.InputWrap>
          <Input
            value={reportName}
            onChange={(e) => {
              if (isDefaultName) {
                setIsDefaultName(false);
              }
              setReportName(e.currentTarget.value);
            }}
            label="Report Name"
            aria-label="report-name"
            hint={{ message: 'Name your report to easily find it in the future.' }}
            fluid
            maxLength={MAX_REPORT_NAME}
          />
        </S.InputWrap>

        <S.ActionButtons>
          <Button variant="tertiary" size="medium" onClick={handleCancel} disabled={loading}>
            Cancel
          </Button>
          <Button
            variant="primary"
            size="medium"
            onClick={handleCreateReport}
            className={TriggerClass.CreateReport}
            loading={loading}
            fluid={isMobile}
            data-testid="create-report-confirm"
          >
            Create Report
          </Button>
        </S.ActionButtons>
      </Modal>
    </>
  );
};

export default CreateReportButton;
