import styled from 'styled-components';

import { inlineGap } from '@Utils/style/gap';

export const HeadingWrap = styled.div`
  margin-bottom: ${({ theme }) => theme.spacing.large}px;
`;

export const Alert = styled.div`
  background-color: ${({ theme }) => theme.meeseeks.color['highlight.100']};
  width: 100%;
  display: flex;
  align-items: center;
  padding: ${({ theme }) => theme.spacing.medium}px;
  margin-bottom: ${({ theme }) => theme.spacing.large}px;

  ${({ theme }) => inlineGap(`${theme.spacing.small}px`)}
`;

export const ActionButtons = styled.div`
  display: flex;
  justify-content: flex-end;
  margin-top: ${({ theme }) => theme.spacing.large}px;

  & > * + * {
    margin-left: ${({ theme }) => theme.spacing.medium}px;
  }
`;

export const SelectWrap = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: ${({ theme }) => theme.spacing.large}px;
  max-width: 400px;

  & > * + * {
    margin-left: ${({ theme }) => theme.spacing.medium}px;
  }
`;

export const InputWrap = styled.div`
  max-width: 400px;
`;
