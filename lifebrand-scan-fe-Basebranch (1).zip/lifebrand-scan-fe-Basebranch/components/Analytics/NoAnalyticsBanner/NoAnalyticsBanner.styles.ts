import styled from 'styled-components';

export const NoData = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  background-image: url('/images/png/no-data-clouds.png');
  background-size: 100% auto;
  background-repeat: no-repeat;
  width: 100%;
  min-height: 480px;
  padding-top: 104px;
  align-items: center;

  & > * {
    align-content: center;
    text-align: center;
    max-width: 550px;
  }
`;
