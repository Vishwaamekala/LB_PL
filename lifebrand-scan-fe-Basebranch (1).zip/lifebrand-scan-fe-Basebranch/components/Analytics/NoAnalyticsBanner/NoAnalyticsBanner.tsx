import React from 'react';

import { Heading } from '@UI/meeseeks';

import * as S from './NoAnalyticsBanner.styles';

type Props = {
  title: string;
  description: string;
  actionButton: React.ReactNode;
};
const NoAnalyticsBanner = ({ title, description, actionButton }: Props) => {
  return (
    <S.NoData>
      <Heading variant="h4" marginBottom="xs" textColor="heading">
        {title}
      </Heading>
      <Heading variant="h5" textColor="body" marginBottom="medium">
        {description}
      </Heading>
      {actionButton}
    </S.NoData>
  );
};

export default NoAnalyticsBanner;
