export { default } from './ViewReportButton';
export * from './ViewReportButton';
