import React, { useCallback } from 'react';
import { useRouter } from 'next/router';

import { Button, ButtonProps } from '@UI/meeseeks';

import { ROUTES } from '@Utils/helper/routes';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

type ViewReportButtonProps = {
  reportId: string;
  disabled?: ButtonProps['disabled'];
  variant?: ButtonProps['variant'];
  size?: ButtonProps['size'];
  text?: string;
};

const ViewReportButton = ({
  reportId,
  disabled = false,
  variant = 'tertiary',
  size = 'small',
  text = 'View',
}: ViewReportButtonProps) => {
  const router = useRouter();

  const { isMobile } = useBreakpoints();

  const handleView = useCallback(() => {
    router.push({
      pathname: ROUTES.REPORT,
      query: { id: reportId },
    });
  }, [router, reportId]);

  return (
    <Button variant={variant} size={size} onClick={handleView} disabled={disabled} fluid={isMobile}>
      {text}
    </Button>
  );
};

export default ViewReportButton;
