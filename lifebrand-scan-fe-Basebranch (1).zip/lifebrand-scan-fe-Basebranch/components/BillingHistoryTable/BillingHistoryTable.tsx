import React from 'react';
import { Table } from 'antd';
import { ColumnProps } from 'antd/lib/table';
import { format, fromUnixTime } from 'date-fns';

import { Heading } from '@UI/meeseeks';

import formatPrice from '@Utils/formatters/price';
import { ChargeDataFragment } from '@Generated/graphql';

import * as S from './BillingHistoryTable.styles';

const EmptyContent = () => {
  return (
    <S.EmptyWrap>
      <Heading variant="h4" textColor="neutrals.400" marginBottom="small">
        No history of payments.
      </Heading>
      <img src="/images/png/stickers.png" alt="No Data" width={82} />
    </S.EmptyWrap>
  );
};

const columns: ColumnProps<ChargeDataFragment>[] = [
  {
    title: 'Date',
    dataIndex: 'date',
    render: (value) => format(fromUnixTime(value), 'MMMM d, yyyy'),
  },
  {
    title: 'Description',
    dataIndex: 'description',
  },
  {
    title: 'Amount',
    dataIndex: 'amount',
    render: (_, { amount, currency, receiptUrl }) => {
      if (!amount || !currency) {
        return '0';
      }
      return (
        <S.Anchor href={receiptUrl ?? ''} target="_blank">
          {formatPrice(amount, currency, 100)}
        </S.Anchor>
      );
    },
  } as ColumnProps<ChargeDataFragment>,
];

interface Props {
  charges?: ChargeDataFragment[];
  loading?: boolean;
}

const BillingHistoryTable = ({ charges = [], loading }: Props) => {
  if (!loading && charges.length < 1) {
    return <EmptyContent />;
  }
  // TODO: implement infinite scroll
  return (
    <Table<ChargeDataFragment>
      rowKey="id"
      dataSource={charges}
      columns={columns}
      pagination={false}
      scroll={{ x: '100%' }}
      loading={loading}
    />
  );
};

export default BillingHistoryTable;
