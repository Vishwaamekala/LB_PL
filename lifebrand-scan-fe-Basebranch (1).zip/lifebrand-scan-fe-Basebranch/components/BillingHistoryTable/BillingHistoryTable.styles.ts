import styled from 'styled-components';

export const Anchor = styled.a`
  font-family: 'Poppins';
  font-weight: ${({ theme }) => theme.typography.fontWeight.semiBold};
  color: ${({ theme }) => theme.meeseeks.color.secondary};
`;

export const EmptyWrap = styled.div`
  display: grid;
  place-items: center;
  padding: ${({ theme }) => theme.spacing.large + theme.spacing.large / 2}px;
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  background-color: ${({ theme }) => theme.meeseeks.color['neutrals.100']};
`;
