import styled from 'styled-components';

const HEIGHT_WHOLE_CONTENT = 642;
const PADDING_TOP_BOTTOM = 16;

export const Side = styled.div<{ hideIntro?: boolean }>`
  width: ${({ hideIntro }) => (hideIntro ? 100 : 50)}%;
  min-height: ${HEIGHT_WHOLE_CONTENT + 2 * PADDING_TOP_BOTTOM}px;
`;
