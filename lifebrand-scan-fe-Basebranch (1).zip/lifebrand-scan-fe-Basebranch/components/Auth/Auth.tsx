import React from 'react';

import Intro from 'components/Auth/Intro';
import Authentication from 'components/Authentication/Authentication';

import * as S from './styles';

type Props = {
  hideIntro?: boolean;
};

const Auth = ({ hideIntro }: Props) => {
  return (
    <>
      {!hideIntro && (
        <S.Side>
          <Intro />
        </S.Side>
      )}

      <S.Side hideIntro={hideIntro}>
        <Authentication />
      </S.Side>
    </>
  );
};

export default Auth;
