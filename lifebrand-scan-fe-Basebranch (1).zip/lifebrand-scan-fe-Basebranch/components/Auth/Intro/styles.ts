import styled, { createGlobalStyle } from 'styled-components';

import { transparentise } from '@Utils/style/transparentise';
import { useBreakpoint } from '@Utils/style/breakpoint';

export const Wrapper = styled.div`
  position: relative;
  width: 100%;
  height: 100%;
  display: inline-flex;
  flex: 1;
`;

export const SlideWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  z-index: 1;
  padding: ${({ theme }) => theme.spacing.large * 3}px;

  ${useBreakpoint.mdDesktop`
    justify-content: space-around;
  `}

  ${useBreakpoint.mobile`
    padding: ${({ theme }) => theme.spacing.extraLarge}px;
  `}
`;

export const Background = styled.div<{ backgroundColor: string }>`
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  z-index: -1;
  background-color: ${({ backgroundColor }) => backgroundColor};

  ${useBreakpoint.mdDesktop`
      clip-path: ellipse(100% 60% at center 0px);
    `}

  ${useBreakpoint.mobile`
      clip-path: ellipse(100% 50% at center 0px);
    `}
`;

export const GlobalStyledCarousel = createGlobalStyle`
  .swiper-container-horizontal {

    .swiper-pagination-bullets {
        left: ${({ theme }) => theme.spacing.large * 3}px;
        bottom: ${({ theme }) => theme.spacing.large * 3}px;
        width: auto;

        ${useBreakpoint.mdDesktop`
          width: 100%;
          left: 0;
          right: 0;
          bottom: 35%;
        `}

        ${useBreakpoint.mobile`
          width: 100%;
          left: 0;
          right: 0;
          bottom: 45%;
        `}

        .swiper-pagination-bullet {
          margin: 0 3px;
        }
      }
  }

  .swiper-container {
    width: 100%;

    & .swiper-pagination {
        & .swiper-pagination-bullet {
          background-color: ${({ theme }) => theme.meeseeks.color.white};
          opacity: 0.35;
          ${useBreakpoint.mdDesktop`
            background-color: ${({ theme }) => theme.color.primary};
          `}
        }

        & .swiper-pagination-bullet-active {
          background-color: ${({ theme }) => theme.meeseeks.color.white};
          opacity: 1;
          ${useBreakpoint.mdDesktop`
            background-color: ${({ theme }) => theme.color.primary};
          `}
        }
    }
  }

   &.swiper-arrow-prev,
   &.swiper-arrow-next {

    ${useBreakpoint.mdDesktop`
      display: none;
    `}

    position: absolute;
    width: 40px;
    height: 40px;
    border-radius: 100%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 3;
    bottom: ${({ theme }) => theme.spacing.large * 3}px;
    background-color: ${({ theme }) => transparentise(theme.meeseeks.color.secondary, 0.2)};
  }

  &.swiper-arrow-prev {
    color: ${({ theme }) => theme.meeseeks.color.white};
    right: ${({ theme }) => theme.spacing.large * 3 + theme.spacing.large * 2}px;
  }

  &.swiper-arrow-next {
    color: ${({ theme }) => theme.meeseeks.color.white};
    right: ${({ theme }) => theme.spacing.large * 3}px;
  }
`;

export const LogoWrapper = styled.div`
  ${useBreakpoint.mdDesktop`
      display: none;
  `}
  position: absolute;
  padding: ${({ theme }) => theme.spacing.large * 3}px;
  padding-bottom: 0;
  z-index: 3;

  img {
    height: 25px;
  }
`;
