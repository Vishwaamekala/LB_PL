import React, { useCallback, useRef } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';

import SwiperCore, { Navigation, Pagination, SwiperOptions, Autoplay } from 'swiper';

import { CarouselAnimations } from './Steps/content';

import { Icon, Heading } from '@UI/meeseeks';
import Logo from '@UI/Logo';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';
import { ROUTES } from '@Utils/helper/routes';

import * as S from './styles';

SwiperCore.use([Navigation, Pagination, Autoplay]);

enum NavigationClassName {
  Prev = 'swiper-arrow-prev',
  Next = 'swiper-arrow-next',
}

const componentId = 'swiper-carousel';

const options: SwiperOptions = {
  navigation: {
    prevEl: `#${componentId} .${NavigationClassName.Prev}`,
    nextEl: `#${componentId} .${NavigationClassName.Next}`,
  },
  slidesPerView: 1,
  slidesPerGroup: 1,
  autoplay: {
    delay: 7000,
  },
  loop: true,
  pagination: true,
  initialSlide: 0,
};

const Intro = () => {
  const { isDesktop } = useBreakpoints();
  const swiperRef = useRef<SwiperCore | undefined>();

  const nextSlide = useCallback(() => {
    try {
      if (swiperRef?.current) {
        swiperRef?.current?.slideNext();
      }
    } catch {
      // empty catch
    }
  }, [swiperRef]);

  const prevSlide = useCallback(() => {
    try {
      if (swiperRef?.current) {
        swiperRef?.current?.slidePrev();
      }
    } catch {
      // empty catch
    }
  }, [swiperRef]);

  return (
    <S.Wrapper>
      <S.GlobalStyledCarousel />
      <S.LogoWrapper>
        <Logo isWhite href={ROUTES.WEBSITE} />
      </S.LogoWrapper>
      <Swiper
        {...options}
        onSwiper={(ref) => {
          swiperRef.current = ref;
        }}
      >
        {CarouselAnimations.map(({ content, id, text, backgroundColor, title }) => (
          <SwiperSlide key={id}>
            <S.SlideWrapper>
              {content}
              <div>
                <Heading
                  variant={isDesktop ? 'h2' : 'h3'}
                  textAlign={isDesktop ? 'left' : 'center'}
                  textColor={isDesktop ? '#fff' : 'secondary'}
                  marginBottom="small"
                >
                  {title}
                </Heading>
                <Heading
                  variant={isDesktop ? 'h3' : 'h5'}
                  fontWeight={isDesktop ? 500 : 400}
                  textAlign={isDesktop ? 'left' : 'center'}
                  textColor={isDesktop ? '#fff' : 'secondary'}
                >
                  {text}
                </Heading>
              </div>
            </S.SlideWrapper>
            <S.Background backgroundColor={backgroundColor} />
          </SwiperSlide>
        ))}
        <div className={NavigationClassName.Prev} onClick={prevSlide}>
          <Icon name="ChevronLeft" size={24} color="#fff" />
        </div>
        <div className={NavigationClassName.Next} onClick={nextSlide}>
          <Icon name="ChevronRight" size={24} color="#fff" />
        </div>
      </Swiper>
    </S.Wrapper>
  );
};

export default Intro;
