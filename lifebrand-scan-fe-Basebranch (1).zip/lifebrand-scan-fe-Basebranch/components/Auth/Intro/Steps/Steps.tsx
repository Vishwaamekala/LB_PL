import React, { useEffect, useRef } from 'react';
import Lottie, { AnimationItem } from 'lottie-web';

import { useOnScreen } from '@Utils/hooks/onScreen';

import animationStepOneMobile from 'public/animations/step-one.json';
import animationStepTwoMobile from 'public/animations/step-two.json';
import animationStepThreeMobile from 'public/animations/step-three.json';
import animationStepFourMobile from 'public/animations/step-four.json';

export enum Animation {
  StepOne,
  StepTwo,
  StepThree,
  StepFour,
}

const ANIMATION_LIST = {
  [Animation.StepOne]: animationStepOneMobile,
  [Animation.StepTwo]: animationStepTwoMobile,
  [Animation.StepThree]: animationStepThreeMobile,
  [Animation.StepFour]: animationStepFourMobile,
};

interface Props {
  animation: Animation;
  infiniteLoop?: boolean;
}

const Steps = ({ animation, infiniteLoop = false }: Props) => {
  const container = useRef<HTMLDivElement | null>(null);
  const lottie = useRef<AnimationItem | null>();
  const onScreen = useOnScreen(container);

  useEffect(() => {
    if (container.current) {
      // while is loading and page changes throws an error
      try {
        lottie.current = Lottie.loadAnimation({
          container: container.current,
          renderer: 'svg',
          loop: infiniteLoop,
          autoplay: false,
          animationData: ANIMATION_LIST[animation],
        });
      } catch {
        // empty-catch
      }
    }
  }, [animation, container]);

  useEffect(() => {
    if (lottie.current) {
      // on development on page change before loaded throwing error
      try {
        if (onScreen && lottie.current.isLoaded) {
          lottie.current.play();
        } else {
          lottie.current.goToAndStop(0);
        }
      } catch {
        // empty-catch
      }
    }
  }, [onScreen, lottie]);

  return <div ref={container} />;
};

export default Steps;
