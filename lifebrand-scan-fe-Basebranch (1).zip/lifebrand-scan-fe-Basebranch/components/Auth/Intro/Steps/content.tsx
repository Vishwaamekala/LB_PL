import React from 'react';
import { theme } from 'theme/theme';

import Steps, { Animation } from './Steps';

import { CarouselContentProps } from '@UI/Carousel';

export const CarouselAnimations: CarouselContentProps[] = [
  {
    content: <Steps animation={Animation.StepOne} />,
    id: 'Step One',
    title: 'Connect',
    text: 'First, connect one or multiple social media accounts you would like to scan and clean.',
    backgroundColor: theme.meeseeks.color['socialMedia.twitter'],
  },
  {
    content: <Steps animation={Animation.StepTwo} />,
    id: 'Step Two',
    title: 'Scan',
    text:
      'With one click our AI-technology scans your page and identifies potentially harmful posts by their category.',
    backgroundColor: theme.meeseeks.color['socialMedia.facebook'],
  },
  {
    content: <Steps animation={Animation.StepThree} />,
    id: 'Step Three',
    title: 'Delete',
    text: 'Delete selected posts and get a confirmation report when your scrub is complete.',
    backgroundColor: theme.meeseeks.color['highlight.300'],
  },
  {
    content: <Steps animation={Animation.StepFour} />,
    id: 'Step Four',
    title: 'Security & Privacy',
    text:
      'We value your privacy, and therefore we never scan your private messages or collect your data!',
    backgroundColor: theme.meeseeks.color['danger.500'],
  },
];
