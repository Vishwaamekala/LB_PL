import styled from 'styled-components';

export const ContentWrapper = styled.div`
  display: flex;
  margin: auto;
  text-align: center;
`;
