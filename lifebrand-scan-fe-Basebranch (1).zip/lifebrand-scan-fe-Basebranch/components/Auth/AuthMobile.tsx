import React, { useState } from 'react';

import Intro from './Intro';

import LayoutWithoutHeader from '@Layout/LayoutWithoutHeader';
import IndividualAuth from 'components/Auth';

import * as S from './AuthMobile.styles';

interface Props {
  onClick: () => void;
  isLoggedIn?: boolean;
}

const AuthMobile = ({ onClick, isLoggedIn }: Props) => {
  const [visualizeAuthPage, setVisualizeAuthPage] = useState(false);

  if (!visualizeAuthPage) {
    return (
      <LayoutWithoutHeader
        isLogoWhite
        withFooter={false}
        buttonText={'Get Started'}
        onClick={() => setVisualizeAuthPage(true)}
      >
        <Intro />
      </LayoutWithoutHeader>
    );
  }
  return (
    <LayoutWithoutHeader
      withFooter={false}
      buttonText={!visualizeAuthPage ? "Let's Go" : undefined}
      onClick={onClick}
      disabledButton={!isLoggedIn}
    >
      <S.ContentWrapper>
        <IndividualAuth hideIntro />
      </S.ContentWrapper>
    </LayoutWithoutHeader>
  );
};

export default AuthMobile;
