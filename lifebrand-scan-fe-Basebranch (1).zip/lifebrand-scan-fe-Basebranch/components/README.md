## Folder Structure

#### /Components

- @UI

UI Elements or utils for individual user's page.

- @Layout

Basic layout elements goes here.

- @WhiteLabel

Whitelabel context and changes for whitelabel css / context.

- @Util

Utilization functionms that are used on anywhere in the app belongs here.
