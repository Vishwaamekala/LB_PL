export { default } from './SuccessfulOnboardingModal';
export * from './SuccessfulOnboardingModal';
