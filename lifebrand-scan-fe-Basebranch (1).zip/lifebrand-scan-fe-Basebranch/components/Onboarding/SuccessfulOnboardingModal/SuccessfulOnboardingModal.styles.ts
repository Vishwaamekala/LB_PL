import styled from 'styled-components';

import ModalBase from '@UI/Modal';

// TODO-COLOR: Review use of theme color.yellow

export const Container = styled.div`
  display: flex;
  justify-content: center;
  background-color: ${({ theme }) => theme.meeseeks.color['highlight.300']};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  height: 280px;
  margin-bottom: ${({ theme }) => theme.spacing.large}px;
  overflow: hidden;
`;

export const ButtonsWrap = styled.div`
  display: flex;
  justify-content: flex-end;

  & > * + * {
    margin-left: ${({ theme }) => theme.spacing.medium}px;
  }
`;

export const Modal = styled(ModalBase)`
  .ant-modal-close {
    display: none;
  }
`;
