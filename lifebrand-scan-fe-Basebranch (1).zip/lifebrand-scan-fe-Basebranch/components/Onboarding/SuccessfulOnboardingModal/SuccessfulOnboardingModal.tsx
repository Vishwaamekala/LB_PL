import React from 'react';

import { Button, Heading } from '@UI/meeseeks';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import * as S from './SuccessfulOnboardingModal.styles';

type Props = {
  visible: boolean;
  onOk: () => void;
};

const SuccessfulOnboardingModal = ({ visible, onOk }: Props) => {
  const { isMobile } = useBreakpoints();

  return (
    <S.Modal visible={visible} onOk={onOk} footer={false} width={630}>
      <Heading variant={isMobile ? 'h4' : 'h3'} marginBottom="large" textAlign="center">
        Tour successfully completed!
      </Heading>
      <S.Container>
        <img src="/images/png/tour-completed.png" alt="tour completed" />
      </S.Container>
      <S.ButtonsWrap>
        <Button variant="primary" size="medium" onClick={onOk} fluid={isMobile}>
          Done
        </Button>
      </S.ButtonsWrap>
    </S.Modal>
  );
};

export default SuccessfulOnboardingModal;
