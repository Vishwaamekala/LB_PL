import React from 'react';
import { theme } from 'theme/theme';
import { StepType } from '@reactour/tour';

import OnboardingStepContent from './custom/OnboardingStepContent';

import { Text } from '@UI/meeseeks';

const popoverPadding = `${theme.spacing.medium}px`;
const borderRadius = `${theme.borderRadius.small}px`;

export const OnboardingCustomStyles = {
  popover: {
    borderRadius,
    padding: popoverPadding,
    width: '326px',
  },
  close: {
    width: '12px',
    height: '12px',
    top: popoverPadding,
    right: popoverPadding,
  },
  maskArea: {
    rx: borderRadius,
  },
};

export enum OnboardingStepKeys {
  Menu = 'menu',
  ScanButton = 'scan-button',
  DashboardHeader = 'dashboard-header',
  SortingPanel = 'sorting-panel',
  DashboardContent = 'dashboard-content',
  DashboardToolbar = 'dashboard-toolbar',
  Analytics = 'analytics',
}

const CommonStepConfig: { [key in OnboardingStepKeys]: StepType } = {
  [OnboardingStepKeys.Menu]: {
    selector: `#${OnboardingStepKeys.Menu}`,
    content: (
      <OnboardingStepContent
        content="Click here to open your profile menu. This is where you can link more social media
      accounts, edit your profile and subscription settings."
      />
    ),
  },
  [OnboardingStepKeys.ScanButton]: {
    selector: `#${OnboardingStepKeys.ScanButton}`,
    content: <OnboardingStepContent content="To start a new social media scan, click here 🙌 ." />,
  },
  [OnboardingStepKeys.DashboardHeader]: {
    selector: `#${OnboardingStepKeys.DashboardHeader}`,
    content: (
      <OnboardingStepContent
        content={
          <Text variant="body" textColor="neutrals.700">
            Switch between Flagged and
            <br />
            non-Flagged posts here.
          </Text>
        }
      />
    ),
  },
  [OnboardingStepKeys.SortingPanel]: {
    selector: `#${OnboardingStepKeys.SortingPanel}`,
    content: <OnboardingStepContent content="Sort by oldest and newest here." />,
  },
  [OnboardingStepKeys.DashboardContent]: {
    selector: `#${OnboardingStepKeys.DashboardContent}`,
    content: (
      <OnboardingStepContent content="All posts are listed here, and if there are flagged posts they are shown in the categories our AI identified them as. You can delete posts, so they don’t harm your personal brand, or view them directly on your social media pages." />
    ),
    styles: {
      // position of the popover on this step is different from designs
      // this way we can always keep the step centred at the top
      // and it doesn't break on different resolutions
      popover: (base) => ({
        ...base,
        ...OnboardingCustomStyles.popover,
        top: 0,
        left: 0,
        right: 0,
        margin: '0 auto',
      }),
      maskArea: (base) => ({
        ...base,
        y: '250px',
        rx: OnboardingCustomStyles.maskArea.rx,
      }),
      close: (base) => ({ ...base, ...OnboardingCustomStyles.close }),
    },
  },
  [OnboardingStepKeys.DashboardToolbar]: {
    selector: `#${OnboardingStepKeys.DashboardToolbar}`,
    content: (
      <OnboardingStepContent
        content="Preview overall statistics, filter posts by category, or search by keywords in this panel
      here."
      />
    ),
  },
  [OnboardingStepKeys.Analytics]: {
    selector: `#${OnboardingStepKeys.Analytics}`,
    content: (
      <OnboardingStepContent
        content="When you finish reviewing flagged posts, view your Analytics page here. Later you can
      export the report as a PDF or email it to your current or potential employer."
      />
    ),
    styles: {
      popover: (base) => ({ ...base, ...OnboardingCustomStyles.popover }),
      maskArea: (base) => ({
        ...base,
        width: '300px',
        rx: OnboardingCustomStyles.maskArea.rx,
      }),
      close: (base) => ({ ...base, ...OnboardingCustomStyles.close }),
    },
  },
};

export const StepsDesktop: StepType[] = [
  { ...CommonStepConfig[OnboardingStepKeys.Menu], position: 'bottom' },
  {
    ...CommonStepConfig[OnboardingStepKeys.ScanButton],
    position: 'bottom',
  },
  {
    ...CommonStepConfig[OnboardingStepKeys.DashboardHeader],
    position: 'bottom',
  },
  {
    ...CommonStepConfig[OnboardingStepKeys.SortingPanel],
    position: 'bottom',
  },
  {
    ...CommonStepConfig[OnboardingStepKeys.DashboardContent],
    position: [0, 0],
  },
  {
    ...CommonStepConfig[OnboardingStepKeys.DashboardToolbar],
    position: 'left',
  },
  {
    ...CommonStepConfig[OnboardingStepKeys.Analytics],
    position: 'right',
  },
];

export const StepsMobile: StepType[] = [
  { ...CommonStepConfig[OnboardingStepKeys.Menu], position: 'bottom' },
  {
    ...CommonStepConfig[OnboardingStepKeys.ScanButton],
    position: 'bottom',
  },
  {
    ...CommonStepConfig[OnboardingStepKeys.DashboardHeader],
    position: 'bottom',
  },
  {
    ...CommonStepConfig[OnboardingStepKeys.SortingPanel],
    position: 'bottom',
  },
  {
    ...CommonStepConfig[OnboardingStepKeys.DashboardContent],
    position: [0, 0],
  },
  {
    ...CommonStepConfig[OnboardingStepKeys.DashboardToolbar],
    position: 'top',
    resizeObservables: [`#${OnboardingStepKeys.DashboardToolbar}`],
    mutationObservables: [`#${OnboardingStepKeys.DashboardToolbar}`],
  },
  {
    ...CommonStepConfig[OnboardingStepKeys.Analytics],
    position: 'bottom',
    resizeObservables: [`#${OnboardingStepKeys.Analytics}`],
    mutationObservables: [`#${OnboardingStepKeys.Analytics}`],
  },
];
