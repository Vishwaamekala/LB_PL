import React from 'react';
import styled from 'styled-components';

import { useTour } from '@reactour/tour';

import { Icon } from '@UI/meeseeks';

const IconWrap = styled.div<{ disabled?: boolean }>`
  cursor: pointer;
  pointer-events: ${({ disabled }) => (disabled ? 'none' : 'initial')};
  height: 24px;

  &:hover {
    svg {
      stroke: ${({ theme }) => theme.meeseeks.color['neutrals.800']};
    }
  }
`;

const PrevButton = () => {
  const { setCurrentStep, currentStep } = useTour();

  const firstStep = currentStep === 0;

  return (
    <IconWrap role="button" onClick={() => setCurrentStep((step) => step - 1)} disabled={firstStep}>
      <Icon name="ArrowLeft" size={24} color={firstStep ? 'tertiary' : 'neutrals.700'} />
    </IconWrap>
  );
};

export default PrevButton;
