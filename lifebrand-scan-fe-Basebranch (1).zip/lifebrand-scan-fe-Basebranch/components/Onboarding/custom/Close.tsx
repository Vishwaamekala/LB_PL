import React from 'react';
import styled from 'styled-components';
import { useTour } from '@reactour/tour';

import { Icon } from '@UI/meeseeks';

import { OnboardingCustomStyles } from '../Onboarding.config';

import { useOnboarding } from '@Utils/hooks/useOnboarding';

const IconWrap = styled.div`
  position: absolute;
  right: ${OnboardingCustomStyles.popover.padding};

  &:hover {
    svg {
      stroke: ${({ theme }) => theme.meeseeks.color['neutrals.800']};
    }
  }
`;

const Close = () => {
  const { setIsOpen } = useTour();
  const { handleSkipOnboarding } = useOnboarding();

  const handleClose = () => {
    setIsOpen(false);
    handleSkipOnboarding();
  };
  return (
    <IconWrap role="button" onClick={handleClose}>
      <Icon name="X" size={24} color="neutrals.700" />
    </IconWrap>
  );
};

export default Close;
