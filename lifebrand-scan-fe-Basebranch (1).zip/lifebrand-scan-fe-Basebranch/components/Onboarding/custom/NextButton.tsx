import React from 'react';
import { useTour } from '@reactour/tour';

import styled from 'styled-components';

import { Button, Icon } from '@UI/meeseeks';

import { useOnboarding } from '@Utils/hooks/useOnboarding';

const IconWrap = styled.div`
  cursor: pointer;
  height: 24px;

  &:hover {
    svg {
      stroke: ${({ theme }) => theme.meeseeks.color['neutrals.800']};
    }
  }
`;

const NextButton = () => {
  const { setIsOpen: setIsOnboardingOn, currentStep, steps, setCurrentStep } = useTour();
  const { setIsOnboarded, setShowSuccessfulOnboardingModal } = useOnboarding();

  const lastStep = currentStep === steps.length - 1;

  const handleNextStep = () => {
    setCurrentStep((step) => step + 1);
  };

  const handleLastStep = () => {
    setIsOnboarded(true);
    setShowSuccessfulOnboardingModal(true);
    setIsOnboardingOn(false);
  };

  return lastStep ? (
    <Button variant="primary" size="small" onClick={handleLastStep}>
      Done!
    </Button>
  ) : (
    <IconWrap role="button" onClick={handleNextStep}>
      <Icon name="ArrowRight" size={24} color="neutrals.700" />
    </IconWrap>
  );
};

export default NextButton;
