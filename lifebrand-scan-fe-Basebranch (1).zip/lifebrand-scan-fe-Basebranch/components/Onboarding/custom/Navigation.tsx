import React, { Key, PropsWithChildren } from 'react';
import styled from 'styled-components';
import { NavigationProps } from '@reactour/tour/dist/components/Navigation';
import { useTour } from '@reactour/tour';

import NextButton from './NextButton';
import PrevButton from './PrevButton';

const Container = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: ${({ theme }) => theme.spacing.extraLarge}px;
  align-items: center;
`;

const Dot = styled.button<{ isActive?: boolean }>`
  cursor: pointer;
  outline: none;
  border: none;
  min-width: 8px;
  min-height: 8px;
  padding: 0;
  border-radius: 50%;
  background: ${({ theme, isActive }) =>
    isActive ? theme.color.primary : `rgba(${theme.color.primaryRgb}, 0.2)`};
`;

const DotsWrapper = styled.div`
  display: flex;

  & > * + * {
    margin-left: ${({ theme }) => theme.spacing.small}px;
  }
`;

const Navigation = ({ steps }: PropsWithChildren<NavigationProps>) => {
  const { setCurrentStep, currentStep } = useTour();

  return (
    <Container>
      <PrevButton />
      <DotsWrapper>
        {steps.map((step, i) => {
          return (
            <Dot
              key={step.selector as Key}
              isActive={i === currentStep}
              onClick={() => setCurrentStep(i)}
            />
          );
        })}
      </DotsWrapper>
      <NextButton />
    </Container>
  );
};

export default Navigation;
