import React from 'react';
import styled from 'styled-components';

import { Text } from '@UI/meeseeks';

export const ContentWrapper = styled.div`
  max-width: 260px;
`;

type Props = {
  content: string | React.ReactNode;
};

const OnboardingStepContent = ({ content }: Props) => {
  return (
    <ContentWrapper>
      {typeof content === 'string' ? (
        <Text variant="body" textColor="neutrals.700">
          {content}
        </Text>
      ) : (
        content
      )}
    </ContentWrapper>
  );
};

export default OnboardingStepContent;
