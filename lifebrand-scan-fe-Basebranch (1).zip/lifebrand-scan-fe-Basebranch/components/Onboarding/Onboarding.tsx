import React from 'react';
import { TourProvider } from '@reactour/tour';
import { disableBodyScroll, enableBodyScroll } from 'body-scroll-lock';

import { OnboardingCustomStyles, StepsDesktop, StepsMobile } from './Onboarding.config';
import Navigation from './custom/Navigation';
import Close from './custom/Close';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

type Props = {
  children: React.ReactNode;
};

const Onboarding = ({ children }: Props) => {
  const { isMdDesktop, isDesktop } = useBreakpoints();

  // disable scroll when onboarding is on in order to prevent unwanted behavior
  const disableBody = (target: Element | null) => target && disableBodyScroll(target);
  const enableBody = (target: Element | null) => target && enableBodyScroll(target);

  const isDesktopResolution = isMdDesktop || isDesktop;
  const steps = isDesktopResolution ? StepsDesktop : StepsMobile;

  return (
    <TourProvider
      showBadge={false}
      onClickMask={({ setIsOpen }) => setIsOpen(true)}
      afterOpen={disableBody}
      beforeClose={enableBody}
      components={{ Close, Navigation }}
      steps={steps}
      styles={{
        popover: (base) => ({
          ...base,
          ...OnboardingCustomStyles.popover,
        }),
        maskArea: (base) => ({ ...base, ...OnboardingCustomStyles.maskArea }),
        close: (base) => ({
          ...base,
          ...OnboardingCustomStyles.close,
        }),
      }}
    >
      {children}
    </TourProvider>
  );
};

export default Onboarding;
