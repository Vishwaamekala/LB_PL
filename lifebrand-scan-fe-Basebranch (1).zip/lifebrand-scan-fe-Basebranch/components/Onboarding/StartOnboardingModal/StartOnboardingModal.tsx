import React from 'react';

import { useTour } from '@reactour/tour';

import { Button, Checkbox, Heading } from '@UI/meeseeks';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';
import { useOnboarding } from '@Utils/hooks/useOnboarding';

import * as S from './StartOnboardingModal.styles';

type Props = {
  visible: boolean;
  checked?: boolean;
  onCheckboxChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onSkip: () => void;
};

const StartOnboardingModal = ({ visible, checked, onCheckboxChange, onSkip }: Props) => {
  const { isMobile } = useBreakpoints();
  const { setIsOpen: setIsOnboardingOn } = useTour();
  const { setShowStartOnboardingModal } = useOnboarding();

  const handleStartOnboarding = () => {
    setIsOnboardingOn(true);
    setShowStartOnboardingModal(false);
  };

  return (
    <S.Modal visible={visible} onOk={handleStartOnboarding} footer={false} width={630}>
      <Heading variant="h3" marginBottom="xs" textAlign="center">
        Let us show you around!
      </Heading>
      <Heading variant="h6" textAlign="center" textColor="body" marginBottom="large">
        We want to make you feel comfortable here, so let’s go through the basics 🎓
      </Heading>
      <S.ImageContainer>
        <S.Image src="/images/png/person_climbing.png" alt="first scan completed" />
      </S.ImageContainer>
      <S.Footer>
        <S.CheckBoxWrapper>
          <Checkbox id="onBoardingCheckbox" onChange={onCheckboxChange} checked={checked} />
          <S.StyledText variant="regular">
            <label htmlFor="onBoardingCheckbox">Ok, do not show this again.</label>
          </S.StyledText>
        </S.CheckBoxWrapper>
        <S.ButtonsWrap>
          <Button variant="tertiary" size="medium" onClick={onSkip} fluid={isMobile}>
            Skip
          </Button>
          <Button variant="primary" size="medium" onClick={handleStartOnboarding} fluid={isMobile}>
            Start Tour
          </Button>
        </S.ButtonsWrap>
      </S.Footer>
    </S.Modal>
  );
};

export default StartOnboardingModal;
