import styled from 'styled-components';

import { Text } from '@UI/meeseeks';
import ModalBase from '@UI/Modal';

import { useBreakpoint } from '@Utils/style/breakpoint';

// TODO-COLOR: Review use of theme color.yellow

export const ImageContainer = styled.div`
  display: flex;
  justify-content: center;
  background-color: ${({ theme }) => theme.meeseeks.color['highlight.300']};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  height: 280px;
  margin-bottom: ${({ theme }) => theme.spacing.large}px;
  overflow: hidden;
`;

export const Image = styled.img`
  height: 280px;
`;

export const Footer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;

  ${useBreakpoint.mobile`
    flex-direction: column-reverse;
    align-items: flex-start;

    & > * + * {
      margin-bottom: ${({ theme }) => theme.spacing.large}px;
    }
  `}
`;

export const ButtonsWrap = styled.div`
  display: flex;
  justify-content: flex-end;

  & > * + * {
    margin-left: ${({ theme }) => theme.spacing.medium}px;
  }

  ${useBreakpoint.mobile`
    width: 100%;
  `}
`;

export const Modal = styled(ModalBase)`
  .ant-modal-close {
    display: none;
  }
`;

export const CheckBoxWrapper = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: ${({ theme }) => theme.spacing.small}px;
`;

export const StyledText = styled(Text)`
  margin-left: ${({ theme }) => theme.spacing.small}px;
  line-height: 1;
`;
