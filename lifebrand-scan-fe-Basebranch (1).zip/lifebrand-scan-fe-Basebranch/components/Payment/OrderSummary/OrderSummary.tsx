import React, { useEffect } from 'react';
import Skeleton from 'react-loading-skeleton';
import { FormInstance } from 'antd';

import { Heading, Text } from '@UI/meeseeks';

import PurchaseButton from '../PurchaseButton';

import { Promo, stripePriceToCurrencyFormatter } from '@Utils/plans';

import {
  TaxRateDataFragment,
  useSearchIndividualPurchaseAmountLazyQuery,
} from '@Generated/graphql';

import { JSVariable } from '@Utils/google-tag-manager';

import * as S from '../OrderSummary.styles';

type Props = {
  form: FormInstance;
  planId?: string;
  promo?: Promo;
  taxRate?: TaxRateDataFragment;
};

const OrderSummary = ({ form, planId, promo, taxRate }: Props) => {
  const [
    getPurchaseAmount,
    { data: purchaseData, loading },
  ] = useSearchIndividualPurchaseAmountLazyQuery({
    fetchPolicy: 'network-only',
  });

  useEffect(() => {
    if (planId) {
      getPurchaseAmount({
        variables: {
          input: {
            promoCode: promo?.code,
            planId,
            taxRateId: taxRate?.id,
          },
        },
      });
    }
  }, [getPurchaseAmount, planId, promo?.code, taxRate?.id]);

  return (
    <>
      <Heading variant="h3" marginBottom="large">
        Order Summary
      </Heading>
      <S.List>
        <S.ListItem>
          <Text variant="regular">Item</Text>
          {loading || purchaseData?.individualPurchaseAmount.planName === undefined ? (
            <Skeleton width={100} height={20} />
          ) : (
            <Heading variant="h6">{purchaseData?.individualPurchaseAmount.planName}</Heading>
          )}
        </S.ListItem>
        <S.ListItem>
          <Text variant="regular">Price</Text>
          {loading || purchaseData?.individualPurchaseAmount.price === undefined ? (
            <Skeleton width={40} height={20} />
          ) : (
            <Heading variant="h6">
              {stripePriceToCurrencyFormatter(purchaseData?.individualPurchaseAmount.price)}
              {purchaseData?.individualPurchaseAmount.recurringPrice &&
                purchaseData?.individualPurchaseAmount.recurringPrice >= 0 &&
                `+ ${stripePriceToCurrencyFormatter(
                  purchaseData?.individualPurchaseAmount.recurringPrice,
                )} / monthly`}
            </Heading>
          )}
        </S.ListItem>
        {promo && (
          <S.ListItem>
            <Text variant="regular">{promo?.code}</Text>
            {loading || purchaseData?.individualPurchaseAmount.promoAmountOff === undefined ? (
              <Skeleton width={40} height={20} />
            ) : (
              <Heading variant="h6">
                -{' '}
                {stripePriceToCurrencyFormatter(
                  purchaseData?.individualPurchaseAmount.promoAmountOff || 0,
                )}
              </Heading>
            )}
          </S.ListItem>
        )}
        {taxRate && (
          <S.ListItem>
            <Text variant="regular">
              Tax (
              {loading ? (
                <Skeleton width={20} height={20} />
              ) : (
                purchaseData?.individualPurchaseAmount.taxPercentage
              )}
              %)
            </Text>
            {loading || purchaseData?.individualPurchaseAmount.taxAmount === undefined ? (
              <Skeleton width={40} height={20} />
            ) : (
              <Heading variant="h6">
                {stripePriceToCurrencyFormatter(
                  purchaseData?.individualPurchaseAmount.taxAmount || 0,
                )}
              </Heading>
            )}
          </S.ListItem>
        )}
        <S.ListItem id={JSVariable.TotalAmount}>
          <Text variant="regular">Total</Text>
          {loading || purchaseData?.individualPurchaseAmount.totalPrice === undefined ? (
            <Skeleton width={40} height={20} />
          ) : (
            <Heading variant="h6">
              {stripePriceToCurrencyFormatter(
                purchaseData?.individualPurchaseAmount.totalPrice || 0,
              )}
            </Heading>
          )}
        </S.ListItem>
      </S.List>

      <PurchaseButton form={form} planId={planId} promoCode={promo?.code} taxRateId={taxRate?.id} />
    </>
  );
};

export default OrderSummary;
