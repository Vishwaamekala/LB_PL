import React, { useEffect, useMemo, useState } from 'react';

import { Input, Text } from '@UI/meeseeks';

import { useSearchPromoLazyQuery } from '@Generated/graphql';
import { isPromoValid, getPromoError, Promo } from '@Utils/plans';

import * as S from './PromoForm.styles';

type Props = {
  onSubmit: (promo?: Promo) => void;
};

const PromoCodeForm = ({ onSubmit }: Props) => {
  const [inputValue, setInputValue] = useState('');
  const [errorMessage, setErrorMessage] = useState<string>();
  const [isApplied, setIsApplied] = useState(false);

  const [getPromo, { loading, data, error }] = useSearchPromoLazyQuery({
    fetchPolicy: 'network-only',
  });

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(event.target.value);
    setErrorMessage(undefined);
  };

  const handleApply = () => {
    getPromo({ variables: { input: { code: inputValue } } });
  };

  useEffect(() => {
    if (error || (data?.promoCode && !isPromoValid(data?.promoCode))) {
      setInputValue('');
      setErrorMessage(getPromoError(data?.promoCode, error));
    }
  }, [data?.promoCode, error]);

  useEffect(() => {
    if (!error && data?.promoCode && isPromoValid(data?.promoCode)) {
      onSubmit({
        code: inputValue,
        ...data?.promoCode,
      });
      setIsApplied(true);
    }
  }, [onSubmit, inputValue, data?.promoCode, error]);

  const validation = useMemo(() => {
    if (isApplied) return { success: { message: ' Promo code was successfully applied.' } };
    if (errorMessage) return { error: { message: errorMessage } };
    return {};
  }, [isApplied, errorMessage]);

  return (
    <>
      <Text marginBottom="large" variant="regular">
        Enter promo code (Optional)
      </Text>
      <Input
        label="Promo Code"
        placeholder="Write your promo code here"
        value={inputValue}
        onChange={handleChange}
        {...validation}
        disabled={isApplied}
        fluid
      />
      {inputValue && !isApplied && (
        <S.Button
          variant="secondary"
          size="medium"
          loading={loading}
          disabled={loading}
          onClick={handleApply}
        >
          Apply Promo Code
        </S.Button>
      )}
    </>
  );
};

export default PromoCodeForm;
