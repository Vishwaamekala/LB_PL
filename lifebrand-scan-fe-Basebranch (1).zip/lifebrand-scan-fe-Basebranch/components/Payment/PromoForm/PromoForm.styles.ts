import styled from 'styled-components';

import { Button as ButtonBase } from '@UI/meeseeks';

export const Button = styled(ButtonBase)`
  display: block;
  margin-top: ${({ theme }) => theme.spacing.medium}px;
  margin-left: auto;
`;

export const Message = styled.div`
  margin-top: ${({ theme }) => theme.spacing.medium}px;
  display: flex;
  align-items: center;

  svg {
    margin-right: ${({ theme }) => theme.spacing.small}px;
  }
`;
