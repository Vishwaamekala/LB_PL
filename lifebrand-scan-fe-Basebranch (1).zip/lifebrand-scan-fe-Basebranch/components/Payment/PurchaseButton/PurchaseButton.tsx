import React, { useCallback, useState } from 'react';
import { useRouter } from 'next/router';
import { CardElement, useElements, useStripe } from '@stripe/react-stripe-js';
import { FormInstance } from 'antd';

import { Button, message, Heading } from '@UI/meeseeks';
import Modal from '@UI/Modal';

import {
  AuthDocument,
  BillingHistoryDocument,
  IndividualFeatureAccessDocument,
  IndividualPaymentMethodDocument,
  LastScanDocument,
  useCreateIndividualSubscriptionMutation,
} from '@Generated/graphql';

import { ROUTES } from '@Utils/helper/routes';

import { TriggerClass, TriggerEvent } from '@Utils/google-tag-manager';

import * as S from './PurchaseButton.styles';

type Props = {
  form: FormInstance;
  planId?: string;
  promoCode?: string;
  taxRateId?: string;
};

const PurchaseButton = ({ form, planId, promoCode, taxRateId }: Props) => {
  const router = useRouter();

  const stripe = useStripe();
  const elements = useElements();

  const [createIndividualSubscription, { loading }] = useCreateIndividualSubscriptionMutation();

  const [isModalOpen, setIsModalOpen] = useState(false);

  const handlePayment = async () => {
    const cardElement = elements?.getElement(CardElement);
    if (!stripe || !cardElement || !planId) return;

    let fields;
    try {
      fields = await form.validateFields();
    } catch {
      return;
    }

    try {
      const { name, email } = fields;

      const stripeSource = await stripe.createSource(cardElement, {
        type: 'card',
        owner: { email, name },
      });
      if (stripeSource.error) {
        throw new Error(stripeSource.error.message);
      }

      const paymentCreate = await createIndividualSubscription({
        variables: {
          input: {
            stripeSource: stripeSource.source?.id,
            planId,
            promoCode,
            email,
            taxRateId,
          },
        },
        awaitRefetchQueries: true,
        refetchQueries: [
          { query: AuthDocument },
          { query: IndividualPaymentMethodDocument },
          { query: BillingHistoryDocument },
          { query: IndividualFeatureAccessDocument },
          { query: LastScanDocument },
        ],
      });
      if (paymentCreate.data?.createIndividualSubscription) {
        window.dataLayer?.push({
          event: TriggerEvent.PurchaseSuccess,
          planId,
          promoCode,
          taxRateId,
        });
        setIsModalOpen(true);
      }
    } catch (error) {
      console.error(error);
      message.error({
        title: 'Something went wrong. Please try again.',
      });
    }
  };

  const handleClose = useCallback(() => {
    message.success({
      title: 'Your subscription was successfully upgraded.',
    });
    router.push(ROUTES.DASHBOARD);
  }, [router]);

  return (
    <>
      <Button
        className={TriggerClass.ConfirmPurchase}
        variant="primary"
        size="large"
        onClick={handlePayment}
        disabled={loading || isModalOpen}
        loading={loading}
        fluid
      >
        Purchase
      </Button>

      <Modal visible={isModalOpen} onCancel={handleClose} footer={null} width={630}>
        <S.Header>
          <Heading variant="h3" textAlign="center" marginBottom="small">
            You’re all set!
          </Heading>
          <Heading variant="h6" textColor="body" textAlign="center" marginBottom="large">
            Welcome to Lifebrand! You can now clean all of your flagged posts.
          </Heading>
        </S.Header>
        <S.ImageContainer>
          <S.Image src="/images/png/like.png" alt="subscription upgraded" />
        </S.ImageContainer>
        <S.Actions>
          <Button variant="primary" size="medium" onClick={handleClose}>
            Okay
          </Button>
        </S.Actions>
      </Modal>
    </>
  );
};

export default PurchaseButton;
