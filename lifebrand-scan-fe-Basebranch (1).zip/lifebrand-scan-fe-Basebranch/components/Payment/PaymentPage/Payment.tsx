import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useTheme } from 'styled-components';
import { Col, Form, Row } from 'antd';

import PaymentDetails from '../PaymentDetails';
import type { PaymentDetailsFields, ValuesChangeHandler } from '../PaymentDetails';
import OrderSummary from '../OrderSummary';
import PromoForm from '../PromoForm';

import { ROUTES } from '@Utils/helper/routes';

import { plansByKey, PlanKey, Promo, getPlanIdByKey } from '@Utils/plans';
import { TaxRateDataFragment, usePlansQuery, useTaxRatesQuery } from '@Generated/graphql';

import * as S from '../Payment.styles';

const IndividualPayment = () => {
  const router = useRouter();

  const planKey = router.query.planKey as PlanKey;
  const plan = plansByKey[planKey];

  useEffect(() => {
    if (!plan) router.push(ROUTES.PLANS);
  }, [router, plan]);

  const { data: taxRatesData } = useTaxRatesQuery();
  const { data: plansData } = usePlansQuery();

  const planId = getPlanIdByKey(planKey, plansData?.plans);
  const [promo, setPromo] = useState<Promo>();
  const [taxRate, setTaxRate] = useState<TaxRateDataFragment>();

  const [form] = Form.useForm();

  const handleFieldsChange: ValuesChangeHandler = (_, allFields) => {
    const { country, state } = allFields as PaymentDetailsFields;
    const nextTaxRate = taxRatesData?.taxRates.find(
      (one) => one.active && one.country === country?.value && one.state === state?.value,
    );
    setTaxRate(nextTaxRate);
  };

  const theme = useTheme();

  if (!plan) return null;

  return (
    <>
      <Row gutter={[theme.spacing.large, theme.spacing.large]}>
        <Col span={24} lg={14}>
          <S.Card>
            <PaymentDetails form={form} onValuesChange={handleFieldsChange} />
          </S.Card>
        </Col>
        <Col span={24} lg={10}>
          <S.WrapRow gutter={[theme.spacing.large, theme.spacing.large]}>
            <Col span={24}>
              <S.Card>
                <OrderSummary form={form} planId={planId} promo={promo} taxRate={taxRate} />
              </S.Card>
            </Col>
            <Col span={24}>
              <S.Card>
                <PromoForm onSubmit={setPromo} />
              </S.Card>
            </Col>
          </S.WrapRow>
        </Col>
      </Row>
    </>
  );
};

export default IndividualPayment;
