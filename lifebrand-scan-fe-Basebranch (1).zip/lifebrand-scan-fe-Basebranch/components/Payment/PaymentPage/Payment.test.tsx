import React from 'react';
import { useRouter } from 'next/router';
import { ThemeProvider } from 'styled-components';
import { StripeCardElementChangeEvent } from '@stripe/stripe-js';
import { useStripe } from '@stripe/react-stripe-js';
import { fireEvent, render, waitFor } from '@testing-library/react';
import { MockedProvider, MockedResponse } from '@apollo/client/testing';

import { theme } from 'theme/theme';

import Payment from './Payment';

import { BreakpointProvider } from '@Utils/hooks/useBreakpoints';
import { ContextProps as AuthContextProps, useAuthContext } from '@Utils/AuthContext';
import { ROUTES } from '@Utils/helper/routes';
import { PlanKey } from '@Utils/plans';

import {
  PlanDataFragment,
  PlansDocument,
  PlansQuery,
  SearchIndividualPurchaseAmountDocument,
  SearchPromoDocument,
  TaxRatesDocument,
  TaxRatesQuery,
  useCreateIndividualSubscriptionMutation,
  UserDataFragment,
} from '@Generated/graphql';

window.matchMedia =
  window.matchMedia ||
  (() => ({
    addListener: jest.fn(),
    removeListener: jest.fn(),
  }));

jest.mock('next/router', () => ({
  useRouter: jest.fn(),
}));

const mockUseRouter = (planKey?: string) => {
  (useRouter as jest.Mock).mockReturnValue({
    pathname: '/payment',
    query: { planKey },
    asPath: '',
    push: jest.fn(),
  });
};

jest.mock('@stripe/react-stripe-js', () => ({
  ...jest.requireActual('@stripe/react-stripe-js'),
  Elements: ({ children }: { children: React.ReactNode }) => children,
  CardElement: ({ onChange }: { onChange: (event: StripeCardElementChangeEvent) => void }) => (
    <input
      type="number"
      name="card"
      data-testid="pseudo-card"
      onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
        if (Number.isNaN(Number(event.target.value))) {
          onChange({
            error: { message: 'Not a number.', type: 'validation_error', code: '' },
            complete: false,
          } as StripeCardElementChangeEvent);
        } else {
          onChange({ complete: true } as StripeCardElementChangeEvent);
        }
      }}
    />
  ),
  useStripe: jest.fn(),
  useElements: () => ({
    getElement: jest.fn().mockReturnValue({}),
  }),
}));

jest.mock('@Utils/AuthContext', () => ({
  ...jest.requireActual('@Utils/AuthContext'),
  useAuthContext: jest.fn(),
}));

const mockUseAuth = (userData: AuthContextProps['userData']) => {
  (useAuthContext as jest.Mock).mockReturnValue({
    userData,
    triggerRefetch: (() => {}) as AuthContextProps['triggerRefetch'],
    loading: false,
    isLoggedIn: true,
    isInvited: false,
    invitedBy: [],
  });
};

jest.mock('@Generated/graphql', () => ({
  ...jest.requireActual('@Generated/graphql'),
  useCreateIndividualSubscriptionMutation: jest
    .fn()
    .mockReturnValue([
      jest.fn().mockResolvedValue({ data: { createIndividualSubscription: true } }),
      { loading: false },
    ]),
}));

const renderPayment = (mocks: MockedResponse[]) => {
  return render(
    <ThemeProvider theme={theme}>
      <BreakpointProvider>
        <MockedProvider mocks={mocks} addTypename>
          <Payment />
        </MockedProvider>
      </BreakpointProvider>
    </ThemeProvider>,
  );
};

const generateTestData = () => {
  const plans = {
    business: {
      __typename: 'Plan',
      id: 'ckrd5tivs00072jymnmygx6gz',
      name: 'Monthly Subscription',
      type: 'Business',
      numberOfScans: -1,
      isRecurring: true,
      price: -1,
    },
    free: {
      __typename: 'Plan',
      id: 'FREE_PLAN',
      name: 'Free',
      type: 'Individual',
      numberOfScans: 1,
      isRecurring: false,
      price: 0,
    },
    basic: {
      __typename: 'Plan',
      id: 'ckrd5tilh00002jym62ozxvcw',
      name: 'Basic Access',
      type: 'Individual',
      numberOfScans: 1,
      isRecurring: false,
      price: 997,
    },
    unlimited: {
      __typename: 'Plan',
      id: 'ckrd5tj3600212jym75wtlnj7',
      name: 'Unlimited Access',
      type: 'Individual',
      numberOfScans: -1,
      isRecurring: true,
      price: 397,
    },
  } as Record<string, PlanDataFragment>;

  const taxRates = {
    Wyoming: {
      __typename: 'StripeTaxRate',
      id: 'txr_1IoAKMIBigh46ksLtKwhCun7',
      active: true,
      livemode: false,
      percentage: 4,
      country: 'US',
      state: 'WY',
    },
    Wisconsin: {
      __typename: 'StripeTaxRate',
      id: 'txr_1IoAKGIBigh46ksLBZlz3hTe',
      active: true,
      livemode: false,
      percentage: 5,
      country: 'US',
      state: 'WI',
    },
    'West Virginia': {
      __typename: 'StripeTaxRate',
      id: 'txr_1IoAKAIBigh46ksLy46d7xeZ',
      active: true,
      livemode: false,
      percentage: 6,
      country: 'US',
      state: 'WV',
    },
  };

  const user = {
    __typename: 'User',
    id: 'ckzia9ypd119760js6uvsy7mbv',
    name: 'Erica Lumley',
    email: 'erica_lumley@mail.com',
    photo:
      'https://scontent-sea1-1.xx.fbcdn.net/v/t1.30497-1/cp0/c15.0.50.50a/p50x50/84628273_176159830277856_972693363922829312_n.jpg?_nc_cat=1&ccb=1-5&_nc_sid=12b3be&_nc_ohc=PI_YeJrsSWYAX9u02Qg&_nc_ht=scontent-sea1-1.xx&edm=AP4hL3IEAAAA&oh=00_AT85A1vMKWa_K5piZbc8DzxYKRRzmZMmnWHlChBC2H6n9w&oe=622D72B8',
    scanAmount: 1,
    authId: 'facebook|107403778058630',
    stripeId: null,
    planId: plans.free.id,
    Plan: plans.free,
    createdAt: '2022-02-11T10:45:15.889Z',
    updatedAt: '2022-02-11T10:45:15.890Z',
    lastRefresh: null,
    acceptedFcraVersion: null,
    acceptedPolicyVersion: 'v2022-01-19',
    hasPassword: false,
    BusinessCustomer: [],
  } as UserDataFragment;

  const stripeSource = {
    id: 'src_1KTpU7IBigh46ksLXzEAOK4Z',
    object: 'source',
    amount: null,
    card: {
      exp_month: 4,
      exp_year: 2024,
      last4: '4242',
      country: 'US',
      brand: 'Visa',
      cvc_check: 'unchecked',
      funding: 'credit',
      three_d_secure: 'optional',
      name: null,
      address_line1_check: null,
      address_zip_check: null,
      tokenization_method: null,
      dynamic_last4: null,
    },
    client_secret: 'src_client_secret_RniUCVqhXT0PqdO1eDBzM8i8',
    created: 1645025523,
    currency: null,
    flow: 'none',
    livemode: false,
    owner: {
      address: null,
      email: 'erica_lumley@mail.com',
      name: 'Ruslan Purii',
      phone: null,
      verified_address: null,
      verified_email: null,
      verified_name: null,
      verified_phone: null,
    },
    statement_descriptor: null,
    status: 'chargeable',
    type: 'card',
    usage: 'reusable',
  };

  return {
    user,
    plans,
    taxRates,
    stripe: {
      source: stripeSource,
    },
    apollo: {
      plans: {
        request: {
          query: PlansDocument,
        },
        result: {
          data: {
            plans: Object.values(plans),
          } as PlansQuery,
        },
      },
      taxRates: {
        request: {
          query: TaxRatesDocument,
        },
        result: {
          data: {
            taxRates: Object.values(taxRates),
          } as TaxRatesQuery,
        },
      },
      promoCode: {
        request: {
          query: SearchPromoDocument,
          variables: {
            input: {
              code: 'OOO',
            },
          },
        },
        result: {
          data: {
            promoCode: {
              __typename: 'PromoResponse',
              amountOff: 499,
              percentOff: null,
              isActive: true,
              isFound: true,
            },
          },
        },
      },
      individualPlainPurchaseAmount: {
        request: {
          query: SearchIndividualPurchaseAmountDocument,
          variables: {
            input: {
              planId: plans.unlimited.id,
            },
          },
        },
        result: {
          data: {
            individualPurchaseAmount: {
              __typename: 'IndividualPurchaseAmountResponse',
              planName: 'Unlimited Access',
              price: 997,
              monthlyPrice: 397,
              promoAmountOff: 0,
              taxAmount: 0,
              taxPercentage: 0,
              totalPrice: 1394,
            },
          },
        },
      },
      individualPurchaseAmountWithPromoAndTaxes: {
        request: {
          query: SearchIndividualPurchaseAmountDocument,
          variables: {
            input: {
              planId: plans.basic.id,
              taxRateId: 'txr_1IoAKMIBigh46ksLtKwhCun7',
              promoCode: 'OOO',
            },
          },
        },
        result: {
          data: {
            individualPurchaseAmount: {
              __typename: 'IndividualPurchaseAmountResponse',
              planName: 'Basic Access',
              price: 997,
              monthlyPrice: -1,
              promoAmountOff: 499,
              taxAmount: 20,
              taxPercentage: 4,
              totalPrice: 518,
            },
          },
        },
      },
    },
  };
};

const testData = generateTestData();

describe('Payment', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('redirects to plans if no plan selected', async () => {
    mockUseRouter();
    mockUseAuth(testData.user);

    renderPayment(Object.values(testData.apollo));

    await waitFor(() => {
      expect(useRouter).toBeCalled();

      expect((useRouter as jest.Mock).mock.results[0].value.push).toBeCalledWith(ROUTES.PLANS);
    });
  });

  it('validates form fields', async () => {
    mockUseRouter(PlanKey.Unlimited);
    mockUseAuth(testData.user);

    (useStripe as jest.Mock).mockReturnValue({
      createSource: jest.fn().mockResolvedValue({ source: testData.stripe.source }),
    });

    const { findByText, getByLabelText, getByTestId, getByText, getByRole } = renderPayment(
      Object.values(testData.apollo),
    );
    expect(await findByText('Unlimited Access')).toBeInTheDocument();

    const submitButton = getByRole('button', { name: 'Purchase' });
    fireEvent.click(submitButton);

    expect(await findByText('Please enter your card details.')).toBeInTheDocument();
    fireEvent.change(getByTestId('pseudo-card'), { target: { value: '4242424242424242' } });

    fireEvent.click(submitButton);

    expect(await findByText('Please enter your name.')).toBeInTheDocument();
    fireEvent.change(getByLabelText('Name'), { target: { value: 'Erica Lumley' } });

    fireEvent.change(getByLabelText('Email'), { target: { value: 'not-an-email' } });

    fireEvent.click(submitButton);

    expect(await findByText('Enter a valid email')).toBeInTheDocument();
    fireEvent.change(getByLabelText('Email'), { target: { value: 'erica_lumley@mail.com' } });

    fireEvent.click(submitButton);

    expect(await findByText('Please select your country.')).toBeInTheDocument();
    fireEvent.mouseDown(getByText('Select Country'));
    fireEvent.click(await findByText('United States'));

    fireEvent.click(submitButton);

    expect(await findByText('Please select your state.')).toBeInTheDocument();
    fireEvent.mouseDown(getByText('Select State'));
    fireEvent.click(await findByText('Wisconsin'));

    fireEvent.click(submitButton);

    expect(await findByText('You’re all set!')).toBeInTheDocument();
  });

  it('applies promo and taxes', async () => {
    mockUseRouter(PlanKey.Basic);
    mockUseAuth(testData.user);

    (useStripe as jest.Mock).mockReturnValue({
      createSource: jest.fn().mockResolvedValue({ source: testData.stripe.source }),
    });

    const { findByRole, findByText, getByLabelText, getByTestId, getByText } = renderPayment(
      Object.values(testData.apollo),
    );

    const submitButton = await findByRole('button', { name: 'Purchase' });

    fireEvent.change(getByTestId('pseudo-card'), { target: { value: '4242424242424242' } });
    fireEvent.change(getByLabelText('Name'), { target: { value: 'Erica Lumley' } });
    fireEvent.change(getByLabelText('Email'), { target: { value: 'erica_lumley@mail.com' } });

    fireEvent.mouseDown(getByText('Select Country'));
    fireEvent.click(await findByText('United States'));

    fireEvent.mouseDown(getByText('Select State'));
    fireEvent.click(await findByText('Wyoming'));

    fireEvent.change(getByLabelText('Promo Code'), { target: { value: 'OOO' } });
    fireEvent.click(await findByRole('button', { name: 'Apply Promo Code' }));

    expect(await findByText('Promo code was successfully applied.')).toBeInTheDocument();

    const {
      individualPurchaseAmount,
    } = testData.apollo.individualPurchaseAmountWithPromoAndTaxes.result.data;

    expect(await findByText('Basic Access')).toBeInTheDocument();
    expect(getByText(`Tax (${individualPurchaseAmount.taxPercentage}%)`)).toBeInTheDocument();
    expect(getByText('OOO')).toBeInTheDocument();
    expect(getByText(`- $${individualPurchaseAmount.promoAmountOff / 100}`)).toBeInTheDocument();

    fireEvent.click(submitButton);

    expect(await findByText('You’re all set!')).toBeInTheDocument();
  });

  it('validates promo code', async () => {
    mockUseRouter(PlanKey.Basic);
    mockUseAuth(testData.user);

    (useStripe as jest.Mock).mockReturnValue({
      createSource: jest.fn().mockResolvedValue({ source: testData.stripe.source }),
    });

    const { findByRole, findByText, getByLabelText } = renderPayment(
      Object.values({
        ...testData.apollo,
        promoCode: {
          request: {
            query: SearchPromoDocument,
            variables: {
              input: {
                code: 'NON-EXISTING',
              },
            },
          },
          result: {
            data: {
              promoCode: {
                __typename: 'PromoResponse',
                amountOff: null,
                percentOff: null,
                isActive: false,
                isFound: false,
              },
            },
          },
        },
      }),
    );

    fireEvent.change(getByLabelText('Promo Code'), { target: { value: 'NON-EXISTING' } });
    fireEvent.click(await findByRole('button', { name: 'Apply Promo Code' }));

    expect(
      await findByText('This promo code does not exist, please try again.'),
    ).toBeInTheDocument();
  });

  it('notifies and redirects to dashboard after upgraded', async () => {
    mockUseRouter(PlanKey.Unlimited);
    mockUseAuth(testData.user);

    (useStripe as jest.Mock).mockReturnValue({
      createSource: jest.fn().mockResolvedValue({ source: testData.stripe.source }),
    });

    const {
      findByRole,
      findByText,
      getByLabelText,
      getByTestId,
      getByText,
      getByRole,
    } = renderPayment(Object.values(testData.apollo));

    const submitButton = await findByRole('button', { name: 'Purchase' });

    fireEvent.change(getByTestId('pseudo-card'), { target: { value: '4242424242424242' } });
    fireEvent.change(getByLabelText('Name'), { target: { value: 'Erica Lumley' } });
    fireEvent.change(getByLabelText('Email'), { target: { value: 'erica_lumley@mail.com' } });

    fireEvent.mouseDown(getByText('Select Country'));
    fireEvent.click(await findByText('Albania'));

    fireEvent.click(submitButton);

    expect(await findByText('You’re all set!')).toBeInTheDocument();

    expect(
      (useCreateIndividualSubscriptionMutation as jest.Mock).mock.results[0].value[0],
    ).toBeCalledWith(
      expect.objectContaining({
        variables: {
          input: {
            stripeSource: 'src_1KTpU7IBigh46ksLXzEAOK4Z',
            planId: 'ckrd5tj3600212jym75wtlnj7',
            email: 'erica_lumley@mail.com',
          },
        },
      }),
    );

    fireEvent.click(getByRole('button', { name: 'Okay' }));

    await waitFor(() => {
      expect(getByText('Your subscription was successfully upgraded.')).toBeInTheDocument();
    });
    expect((useRouter as jest.Mock).mock.results[0].value.push).toBeCalledWith(ROUTES.DASHBOARD);
  });
});
