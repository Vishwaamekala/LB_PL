import React, { useState, useMemo } from 'react';
import { Row, Col, Form } from 'antd';
import { FormInstance, RuleObject } from 'antd/lib/form';
import { useTheme } from 'styled-components';

import CardInput from './CardInput';

import { Input, Select, Heading, Text } from '@UI/meeseeks';

import countries from '@Utils/plans/countries';
import { useAuthContext } from '@Utils/AuthContext';

import * as S from './PaymentDetails.styles';

const countryOptions = Object.entries(countries).map(([iso2, country]) => ({
  label: country.name,
  value: iso2,
}));

export type PaymentDetailsFields = {
  email?: string;
  name?: string;
  country?: {
    label: string;
    value: string;
  };
  state?: {
    label: string;
    value: string;
  };
  isCardInfoComplete?: boolean;
};

type ValidationRules = { [key: string]: RuleObject[] };

const VALIDATION_RULES: ValidationRules = {
  isCardInfoComplete: [
    {
      validator: (_, value, callback) => {
        if (!value) {
          callback('Please enter your card details.');
        } else {
          callback();
        }
      },
    },
  ],
  email: [
    { required: true, message: 'Please enter your email.' },
    { type: 'email', message: 'Enter a valid email' },
  ],
  name: [{ required: true, message: 'Please enter your name.' }],
  country: [{ required: true, message: 'Please select your country.' }],
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type ValuesChangeHandler = (changedValues: any, values: unknown) => void;

type Props = {
  form: FormInstance;
  onValuesChange?: ValuesChangeHandler;
  title?: string;
  description?: string;
  withTaxInfo?: boolean;
};

const PaymentDetails = ({
  form,
  onValuesChange,
  title = 'Payment Details',
  description,
  withTaxInfo = true,
}: Props) => {
  const theme = useTheme();

  const { userData, loading } = useAuthContext();

  const [countryStates, setCountryStates] = useState<Record<string, string>>();

  const handleValuesChange: ValuesChangeHandler = (changedFields, allFields) => {
    const nextFields = { ...(allFields as PaymentDetailsFields) };
    if (changedFields.country) {
      nextFields.state = undefined;
      setCountryStates(countries[changedFields.country.value]?.divisions);
    }
    form.setFieldsValue(nextFields);
    onValuesChange?.(changedFields, nextFields);
  };

  const stateOptions = useMemo(() => {
    return (
      countryStates &&
      Object.entries(countryStates).map(([iso2, state]) => ({
        label: state,
        value: iso2.split('-')[1],
      }))
    );
  }, [countryStates]);

  const countryProps = {
    placeholder: 'Select Country',
    options: countryOptions,
    fluid: true,
    onChange: () => form.resetFields(['state']),
  };

  const stateProps = {
    placeholder: 'Select State',
    options: stateOptions,
    fluid: true,
  };

  if (loading) {
    // Do not render the form, if initial values cannot be provided yet.
    return null;
  }

  return (
    <>
      <Heading variant="h3" marginBottom={description ? 'xxs' : 'large'}>
        {title}
      </Heading>
      {description && (
        <Text variant="small" textColor="body" marginBottom="large">
          {description}
        </Text>
      )}

      <S.Form
        form={form}
        layout="vertical"
        requiredMark={false}
        style={{ width: '100%' }}
        initialValues={{ email: userData?.email }}
        onValuesChange={handleValuesChange}
      >
        <Form.Item label="Accepted payment types">
          <S.Image src="/images/png/payment-types.png" />
        </Form.Item>
        <Form.Item name="isCardInfoComplete" rules={VALIDATION_RULES.isCardInfoComplete}>
          <CardInput />
        </Form.Item>
        <Row gutter={[theme.spacing.medium, 0]}>
          <Col span={24} md={12}>
            <Form.Item name="name" rules={VALIDATION_RULES.name}>
              <Input label="Name" placeholder="Cardholder Name" fluid />
            </Form.Item>
          </Col>
          <Col span={24} md={12}>
            <Form.Item name="email" rules={VALIDATION_RULES.email}>
              <Input label="Email" type="email" placeholder="Email" fluid />
            </Form.Item>
          </Col>
        </Row>
        {withTaxInfo && (
          <Row gutter={[theme.spacing.medium, 0]}>
            <Col span={24} md={12}>
              <Form.Item name="country" rules={VALIDATION_RULES.country}>
                <Select {...countryProps} />
              </Form.Item>
            </Col>
            <Col span={24} md={12}>
              <Form.Item
                name="state"
                rules={[{ required: !!stateOptions, message: 'Please select your state.' }]}
              >
                <Select {...stateProps} />
              </Form.Item>
            </Col>
          </Row>
        )}
      </S.Form>
    </>
  );
};

export default PaymentDetails;
