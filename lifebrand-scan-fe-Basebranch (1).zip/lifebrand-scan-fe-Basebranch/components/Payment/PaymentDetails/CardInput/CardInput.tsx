import React, { useState } from 'react';
import { CardElement } from '@stripe/react-stripe-js';
import { StripeCardElementChangeEvent } from '@stripe/stripe-js';
import { theme } from 'theme/theme';

import * as S from './CardInput.styles';

const options = {
  hidePostalCode: true,
  iconStyle: 'solid' as const,
  style: {
    base: {
      iconColor: theme.meeseeks.color['primary.600'],
      color: theme.meeseeks.color.secondary,
      fontFamily: 'Poppins',
      fontWeight: '500',
      fontSize: '16px',
      fontSmoothing: 'antialiased',
      lineHeight: '2.2',
      ':-webkit-autofill': {
        color: theme.meeseeks.color.secondary,
      },
      '::placeholder': {
        color: theme.meeseeks.color.caption,
      },
    },
  },
};

type InputProps = {
  value?: string;
  onChange?: (value?: boolean) => void;
};

/**
 * This is a custom antd Input, however:
 * @returns `true` if the Stripe CardElement is completed, otherwise `false`.
 */
const CardInput = ({ onChange }: InputProps) => {
  const [isFocused, setIsFocused] = useState(false);
  const [isValid, setIsValid] = useState(true);

  const handleChange = (event: StripeCardElementChangeEvent): void => {
    if (event.complete) {
      onChange?.(true);
    } else {
      onChange?.(false);
    }
    if (event.error) {
      setIsValid(false);
    } else {
      setIsValid(true);
    }
  };

  return (
    <S.Container isFocused={isFocused} isValid={isValid}>
      <CardElement
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        onChange={handleChange}
        options={options}
      />
    </S.Container>
  );
};

export default CardInput;
