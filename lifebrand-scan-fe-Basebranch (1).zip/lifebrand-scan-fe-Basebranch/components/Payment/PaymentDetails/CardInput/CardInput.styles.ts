import styled from 'styled-components';

export const Container = styled.div<{ isFocused: boolean; isValid: boolean }>`
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  border: 1px solid transparent;
  padding: 1px 0px 1px ${({ theme }) => theme.spacing.small}px;

  border-color: ${({ isFocused, isValid, theme }) => {
    if (!isValid) return theme.meeseeks.color.danger;
    if (isFocused) return theme.color.primary;
    return theme.meeseeks.color.tertiary;
  }};

  box-shadow: ${({ isFocused, isValid, theme }) => {
    if (!isFocused) return 'none';
    if (!isValid) return '0 0 0 2px rgb(255 77 79 / 20%)';
    return `0 0 0 2px rgba(${theme.color.primaryRgb}, 0.2)`;
  }};
`;
