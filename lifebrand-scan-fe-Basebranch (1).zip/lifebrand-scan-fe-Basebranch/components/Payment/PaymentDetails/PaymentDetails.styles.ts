import styled from 'styled-components';
import { Form as FormBase } from 'antd';

export const Image = styled.img`
  width: 100%;
  max-width: 500px;
`;

export const Form = styled(FormBase)`
  font-family: Open Sans;
  font-style: normal;

  .ant-form-item-label > label {
    color: ${({ theme }) => theme.meeseeks.color.caption};
  }

  .ant-input::placeholder,
  .ant-select-selection-placeholder {
    color: ${({ theme }) => theme.meeseeks.color.caption};
  }

  .ant-form-item {
    margin-bottom: ${({ theme }) => theme.spacing.medium}px;
  }
`;
