import styled from 'styled-components';
import { Row as RowBase } from 'antd';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Container = styled.div`
  margin: ${({ theme }) => theme.spacing.large}px 0px;

  ${useBreakpoint.tablet`
    margin: ${({ theme }) => theme.spacing.medium}px 0px 0px;
  `}
`;

export const WrapRow = styled(RowBase)`
  margin-bottom: 0px !important;

  ${useBreakpoint.tablet`
    flex-wrap: wrap-reverse;
  `}
`;

export const Card = styled.div`
  border: ${({ theme }) => theme.border.card};
  border-radius: ${({ theme }) => theme.borderRadius.medium}px;
  padding: ${({ theme }) => theme.spacing.extraLarge}px;
  width: 100%;

  ${useBreakpoint.mobile`
    border: none;
    padding: 0;
  `}
`;
