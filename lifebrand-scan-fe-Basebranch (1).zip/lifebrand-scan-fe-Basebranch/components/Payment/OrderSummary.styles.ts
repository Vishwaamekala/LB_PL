import styled from 'styled-components';

export const ListItem = styled.div`
  display: flex;
  justify-content: space-between;
  padding: ${({ theme }) => theme.spacing.medium}px 0px;
  align-items: center;
`;

export const List = styled.div`
  margin-bottom: ${({ theme }) => theme.spacing.medium}px;

  > ${ListItem}:not(:last-child) {
    border-bottom: ${({ theme }) => theme.border.card};
  }
`;
