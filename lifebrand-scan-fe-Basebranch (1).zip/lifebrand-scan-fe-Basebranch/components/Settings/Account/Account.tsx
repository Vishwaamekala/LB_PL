import React from 'react';
import Skeleton from 'react-loading-skeleton';

import { useRouter } from 'next/router';

import { Button, Icon, Heading } from '@UI/meeseeks';
import Card from '@UI/Card';

import { useAuthContext } from '@Utils/AuthContext';
import { ROUTES } from '@Utils/helper/routes';

import * as S from './Account.styles';

const Account = () => {
  const { userData } = useAuthContext();

  const router = useRouter();

  return (
    <S.Content>
      <Card title="Basic Info">
        <S.Container>
          <S.Item name="name">
            <Heading variant="h5" marginBottom="xxs" textColor="heading">
              Name
            </Heading>
            <Heading variant="h5" textColor="caption" fontWeight={400}>
              {userData ? userData.name : <Skeleton width={200} />}
            </Heading>
          </S.Item>
          <S.Item name="email">
            <Heading variant="h5" marginBottom="xxs" textColor="heading">
              Email
            </Heading>
            <S.Email
              variant="h5"
              textColor="caption"
              fontWeight={400}
              marginBottom="large"
              breakWord={userData?.hasPassword}
            >
              {userData ? userData.email : <Skeleton width={200} />}
            </S.Email>
            <S.ButtonWrap>
              <Button
                size="medium"
                variant="primary"
                iconLeft={<Icon name="Edit" color="#fff" />}
                onClick={() => router.push(ROUTES.CHANGE_BASIC_INFO)}
              >
                Edit Info
              </Button>
            </S.ButtonWrap>
          </S.Item>
          {userData?.hasPassword && (
            <S.Item name="password">
              <Heading variant="h5" marginBottom="xxs" textColor="heading">
                Password
              </Heading>
              <Heading variant="h5" textColor="caption" fontWeight={400} marginBottom="large">
                ***************
              </Heading>
              <S.ButtonWrap>
                <Button
                  size="medium"
                  variant="primary"
                  iconLeft={<Icon name="Edit" color="#fff" />}
                  onClick={() => router.push(ROUTES.CHANGE_PASSWORD)}
                >
                  Change Password
                </Button>
              </S.ButtonWrap>
            </S.Item>
          )}
        </S.Container>
      </Card>
      <S.Footer onClick={() => router.push(ROUTES.DELETE_ACCOUNT)} data-testid="deactivate-account">
        <Heading variant="h6" textColor="danger" marginBottom="xxs">
          Deactivate Account
        </Heading>
        <S.Caption textColor="caption" fontWeight={400} variant="h6">
          All the saved data and analytics will be permanently deleted.
        </S.Caption>
      </S.Footer>
    </S.Content>
  );
};

export default Account;
