import styled from 'styled-components';

import { Heading } from '@UI/meeseeks';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Content = styled.div`
  display: flex;
  flex-direction: column;
  height: 100%;
  justify-content: space-between;
`;

export const Container = styled.div`
  display: grid;
  grid-template-columns: minmax(auto, 325px) 1fr;
  grid-column-gap: ${({ theme }) => theme.spacing.extraLarge}px;
  grid-row-gap: ${({ theme }) => theme.spacing.medium}px;
  grid-template-areas:
    ' name  . '
    ' email  password ';

  ${useBreakpoint.mobile`
      grid-template-columns: 1fr;
      grid-template-areas:
      ' name '
      ' email '
      ' password ';
  `}
`;

export const Item = styled.div<{ name: string }>`
  grid-area: ${({ name }) => name};
  display: grid;
`;

export const Caption = styled(Heading)`
  font-size: ${({ theme }) => theme.typography.text.sm}px;
`;

export const Footer = styled.div`
  position: fixed;
  bottom: ${({ theme }) => theme.spacing.large}px;
  z-index: 1;

  @media screen and (max-height: 690px) {
    bottom: 0;
  }
`;

export const Email = styled(Heading)<{ breakWord?: boolean }>`
  ${({ breakWord }) =>
    breakWord &&
    `
    word-break: break-all;
  `}
`;

export const ButtonWrap = styled.div`
  margin-top: auto;
`;
