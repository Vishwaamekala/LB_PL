import React from 'react';
import { Rule, FormInstance } from 'antd/lib/form';

import { passwordRegex } from '@Utils/formatters/regex';

import * as S from './ChangePasswordForm.styles';

export const InitialForm = { password: '', newPassword: '', reNewPassword: '' };

export type FormValues = typeof InitialForm;

const regex = new RegExp(passwordRegex);

// password check rule is from https://ant.design/components/form/
export const ValidationRules: { [key in keyof FormValues]: Rule[] } = {
  password: [
    {
      required: true,
      message: 'Please enter your current password',
    },
  ],
  newPassword: [
    {
      required: true,
      message: 'Please enter your new password',
    },
    {
      pattern: regex,
      message: (
        <div>
          Password does not match the requirements.
          <S.ListWrapper>
            <li>Needs to be at least 8 characters</li>
            <li>Contains at least 1 uppercase</li>
            <li>Contains at least 1 lowercase</li>
            <li>Contains at least 1 number</li>
          </S.ListWrapper>
        </div>
      ),
    },
  ],
  reNewPassword: [
    {
      required: true,
      message: 'Please confirm your password!',
    },
    // @ts-ignore
    ({ getFieldValue }: FormInstance) => ({
      // @ts-ignore poor type export from ant design
      validator(_, value) {
        if (!value || getFieldValue('newPassword') === value) {
          return Promise.resolve();
        }
        return Promise.reject(new Error('The two passwords that you entered do not match!'));
      },
    }),
  ],
};
