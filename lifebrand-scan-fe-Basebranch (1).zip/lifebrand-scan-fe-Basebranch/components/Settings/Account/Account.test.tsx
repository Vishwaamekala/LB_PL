import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import { theme } from 'theme/theme';
import { useRouter } from 'next/router';
import { ThemeProvider } from 'styled-components';
import { MockedProvider } from '@apollo/client/testing';

import { GraphQLError } from 'graphql';

import Account from './Account';
import EditBasicInfo from './EditBasicInfo';
import ChangePasswordForm from './ChangePasswordForm';
import DeleteAccount from './DeleteAccount';
import { REASONS } from './DeleteAccount/utils';

import { encrypt } from '@Utils/crypto';

import {
  UpdateIndividualProfileDocument,
  IndividualChangePasswordDocument,
  DeleteIndividualUserDocument,
} from '@Generated/graphql';

import { ROUTES } from '@Utils/helper/routes';

window.matchMedia =
  window.matchMedia ||
  (() => ({
    addListener: jest.fn(),
    removeListener: jest.fn(),
  }));

jest.mock('next/router', () => ({
  useRouter: jest.fn().mockReturnValue({
    route: '/settings/account',
    pathname: '',
    query: '',
    asPath: '',
    push: jest.fn(),
  }),
}));

jest.mock('@Utils/crypto', () => ({
  encrypt() {
    return 'U2FsdGVkX1+0K425b16HkhwXydsoKahYhL2JXyXafkk=';
  },
}));

jest.mock('@Utils/AuthContext', () => ({
  ...jest.requireActual('@Utils/AuthContext'),
  useAuthContext() {
    return {
      userData: {
        __typename: 'User',
        id: 'cl09eax2i128270is67jx0rfno',
        name: 'test',
        email: 'fotova3507@nitynote.com',
        photo: '',
        scanAmount: 1,
        authId: 'facebook|107403778058630',
        stripeId: null,
        planId: 'ckrd5tilh00002jym62ozxvcw',
        Plan: {
          __typename: 'Plan',
          id: 'ckrd5tilh00002jym62ozxvcw',
          name: 'Basic Access',
          type: 'Individual',
          numberOfScans: 1,
          isRecurring: false,
          price: 997,
        },
        createdAt: '2022-02-11T10:45:15.889Z',
        updatedAt: '2022-02-11T10:45:15.890Z',
        lastRefresh: null,
        acceptedFcraVersion: null,
        acceptedPolicyVersion: 'v2022-01-19',
        hasPassword: true,
        BusinessCustomer: [],
      },
      triggerRefetch: () => {},
      loading: false,
      isLoggedIn: true,
      isInvited: false,
      invitedBy: [],
    };
  },
}));

const mocks = [
  {
    request: {
      query: UpdateIndividualProfileDocument,
      variables: { input: { name: 'test user', email: 'test@gmail.com' } },
    },
    result: {
      data: {
        updateIndividualProfile: {
          __typename: 'User',
          id: 'ckwq8nqgq20210ls63vqbcgy5',
          name: 'test user',
          email: 'test@gmail.com',
        },
      },
    },
  },
  {
    request: {
      query: UpdateIndividualProfileDocument,
      variables: { input: { name: 'test', email: 'test@gmail.com' } },
    },
    result: {
      errors: [new GraphQLError('Some backend error!')],
    },
  },
  {
    request: {
      query: IndividualChangePasswordDocument,
      variables: {
        currentPassword: encrypt('Texttext1'),
        newPassword: encrypt('Password1'),
      },
    },
    result: {
      data: {
        changeIndividualPassword: true,
      },
    },
  },
  {
    request: {
      query: DeleteIndividualUserDocument,
      variables: { reasons: [REASONS.testAccount] },
    },
    result: {
      data: {
        deleteIndividualUser: true,
      },
    },
  },
  {
    request: {
      query: DeleteIndividualUserDocument,
      variables: { reasons: [REASONS.noNeed] },
    },
    result: {
      errors: [new GraphQLError('Some backend error!')],
    },
  },
];

const renderAccountComponent = () =>
  render(
    <ThemeProvider theme={theme}>
      <MockedProvider addTypename>
        <Account />
      </MockedProvider>
    </ThemeProvider>,
  );

describe('Account', () => {
  it('redirect to the Edit Info page after click', async () => {
    const { getByRole } = renderAccountComponent();
    const btn = getByRole('button', { name: 'Edit Info' });
    expect(btn).toBeInTheDocument();

    fireEvent.click(btn);

    await waitFor(() => {
      expect((useRouter as jest.Mock).mock.results[0].value.push).toBeCalledWith(
        ROUTES.CHANGE_BASIC_INFO,
      );
    });
  });

  it('redirect to the Change Password page after click', async () => {
    const { getByRole } = renderAccountComponent();
    const btn = getByRole('button', { name: 'Change Password' });
    expect(btn).toBeInTheDocument();

    fireEvent.click(btn);

    await waitFor(() => {
      expect((useRouter as jest.Mock).mock.results[0].value.push).toBeCalledWith(
        ROUTES.CHANGE_PASSWORD,
      );
    });
  });

  it('redirect to the Delete Account page after click', async () => {
    const { getByTestId } = renderAccountComponent();
    const btn = getByTestId('deactivate-account');
    expect(btn).toBeInTheDocument();

    fireEvent.click(btn);

    await waitFor(() => {
      expect((useRouter as jest.Mock).mock.results[0].value.push).toBeCalledWith(
        ROUTES.DELETE_ACCOUNT,
      );
    });
  });

  it('render success message after changing name', async () => {
    const { getByRole, getByText } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider mocks={mocks} addTypename={false}>
          <EditBasicInfo />
        </MockedProvider>
      </ThemeProvider>,
    );
    const InputName = getByRole('textbox', { name: 'Your Name' });
    const InputEmail = getByRole('textbox', { name: 'Email' });
    const btn = getByRole('button', { name: 'Save' });

    fireEvent.change(InputName, { target: { value: 'test user' } });
    fireEvent.change(InputEmail, { target: { value: 'test@gmail.com' } });

    fireEvent.click(btn);

    await waitFor(() => {
      expect(getByText('Your account details were succesfully updated.')).toBeInTheDocument();
    });
  });

  it('render error message after changing name', async () => {
    const { getByRole, getByText } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider mocks={mocks} addTypename={false}>
          <EditBasicInfo />
        </MockedProvider>
      </ThemeProvider>,
    );
    const btn = getByRole('button', { name: 'Save' });

    fireEvent.click(btn);

    await waitFor(() => {
      expect(getByText('Could’t update account details. Please try again.')).toBeInTheDocument();
    });
  });

  it('render success message after changing password ', async () => {
    const { getByRole, getByLabelText, getByText } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider mocks={mocks} addTypename={false}>
          <ChangePasswordForm />
        </MockedProvider>
      </ThemeProvider>,
    );
    const CurrentPasswordInput = getByLabelText('Current Password');
    const NewPasswordInput = getByLabelText('New Password');
    const ConfirmPassword = getByLabelText('Confirm Password');
    const btn = getByRole('button', { name: 'Change Password' });

    fireEvent.change(CurrentPasswordInput, { target: { value: 'Texttext1' } });
    fireEvent.change(NewPasswordInput, { target: { value: 'Password1' } });
    fireEvent.change(ConfirmPassword, { target: { value: 'Password1' } });

    fireEvent.click(btn);

    await waitFor(() => {
      expect(getByText('Password successfully changed.')).toBeInTheDocument();
    });
  });

  it('render error message while changing password ', async () => {
    const { getByRole, getByLabelText, getByText } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider
          mocks={[
            {
              request: {
                query: IndividualChangePasswordDocument,
                variables: {
                  currentPassword: encrypt('Password1'),
                  newPassword: encrypt('Texttext1'),
                },
              },
              result: {
                errors: [new GraphQLError('Some backend error!')],
              },
            },
          ]}
          addTypename={false}
        >
          <ChangePasswordForm />
        </MockedProvider>
      </ThemeProvider>,
    );
    const CurrentPasswordInput = getByLabelText('Current Password');
    const NewPasswordInput = getByLabelText('New Password');
    const ConfirmPassword = getByLabelText('Confirm Password');
    const btn = getByRole('button', { name: 'Change Password' });

    fireEvent.change(CurrentPasswordInput, { target: { value: 'Password1' } });
    fireEvent.change(NewPasswordInput, { target: { value: 'Texttext1' } });
    fireEvent.change(ConfirmPassword, { target: { value: 'Texttext1' } });

    fireEvent.click(btn);

    await waitFor(() => {
      expect(getByText('Some backend error!')).toBeInTheDocument();
    });
  });

  it('render success message after deleting account', async () => {
    const { getByRole, getByText, getByTestId } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider mocks={mocks} addTypename={false}>
          <DeleteAccount />
        </MockedProvider>
      </ThemeProvider>,
    );
    const SubmitButton = getByRole('button', { name: 'Submit And Delete Account' });
    const Checkbox = getByTestId(`checkbox-${REASONS.testAccount}`);

    fireEvent.click(Checkbox);

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    fireEvent.click(SubmitButton);

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    const DeleteButton = getByRole('button', { name: 'Delete' });

    fireEvent.click(DeleteButton);

    await waitFor(() => {
      expect(getByText('Your account was successfully deleted.')).toBeInTheDocument();
    });
  });

  it('render error message while deleting account', async () => {
    const { getByRole, getByText, getByTestId } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider mocks={mocks} addTypename={false}>
          <DeleteAccount />
        </MockedProvider>
      </ThemeProvider>,
    );
    const SubmitButton = getByRole('button', { name: 'Submit And Delete Account' });
    const Checkbox = getByTestId(`checkbox-${REASONS.noNeed}`);

    fireEvent.click(Checkbox);

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    fireEvent.click(SubmitButton);

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    const DeleteButton = getByRole('button', { name: 'Delete' });

    fireEvent.click(DeleteButton);

    await waitFor(() => {
      expect(getByText('Failed to delete your account. Please try again.')).toBeInTheDocument();
    });
  });
});
