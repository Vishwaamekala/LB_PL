import React, { useState } from 'react';
import { Col, Row } from 'antd';
import { useAuth0 } from '@auth0/auth0-react';

import LoginForm from './LoginForm';

import { Button, message, Heading, Text, Icon } from '@UI/meeseeks';
import Spacing from '@UI/Spacing';
import ProviderButton from '../ProviderButton';

import { useConnections, AuthProvider } from '@Utils/hooks/useConnections';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { TriggerEvent } from '@Utils/google-tag-manager';

// import { FeatureFlag, useFeatureFlags } from '@Utils/hooks/useFeatureFlags';

import * as S from './Login.styles';

type Props = {
  onChangeAuthState: () => void;
  onResetPassword: () => void;
};

const Login = ({ onChangeAuthState, onResetPassword }: Props) => {
  const { logout } = useAuth0();
  const { actions } = useConnections();
  const { isMobile } = useBreakpoints();
  const [isLoading, setIsLoading] = useState(false);

  // const {
  //   isEnabled: ENABLED_FEAT_LOGIN_TW_B2C,
  //   payload: PAYLOAD_FEAT_LOGIN_TW_B2C,
  // } = useFeatureFlags(FeatureFlag.FEAT_LOGIN_TW_B2C);

  const handleLoginWith = async (authProvider: AuthProvider) => {
    const { isSuccessful, user } = await actions.loginWith(authProvider);
    setIsLoading(true);
    if (!user) {
      logout({ localOnly: true });
      message.error({
        title: 'Please register before login.',
      });
    } else if (isSuccessful) {
      window.dataLayer?.push({ event: TriggerEvent.SignInSuccess });
    }
    setIsLoading(false);
  };

  return (
    <S.Wrapper>
      <Heading variant={isMobile ? 'h4' : 'h2'} textAlign={isMobile ? 'center' : 'left'}>
        Log Into My Account
      </Heading>
      <Spacing size="large" />
      <ProviderButton
        loading={isLoading}
        disabled={isLoading}
        onClick={() => handleLoginWith(AuthProvider.Google)}
        iconLeft={<Icon name="GoogleFilled" size={40} />}
        fluid
      >
        Log In with Google
      </ProviderButton>
      <Spacing size="medium" />
      <ProviderButton
        loading={isLoading}
        disabled={isLoading}
        onClick={() => handleLoginWith(AuthProvider.Facebook)}
        iconLeft={<Icon name="FacebookFilled" size={40} />}
        fluid
      >
        Log In with Facebook
      </ProviderButton>
      <Spacing size="medium" />
      {/* {ENABLED_FEAT_LOGIN_TW_B2C && PAYLOAD_FEAT_LOGIN_TW_B2C.isVisible ? (
        <> */}
      <ProviderButton
        loading={isLoading}
        disabled={isLoading}
        onClick={() => handleLoginWith(AuthProvider.Twitter)}
        iconLeft={<Icon name="TwitterFilled" size={40} />}
        fluid
      >
        Log In with Twitter
      </ProviderButton>
      <Spacing size="medium" />
      {/* </>
      ) : (
        ''
      )} */}
      <Text variant="body" textColor="neutrals.400" textAlign="center" marginBottom="medium">
        or
      </Text>
      <LoginForm />
      <Spacing size="medium" />
      <Text textColor="neutrals.700" variant="small">
        <S.StyledLink onClick={onResetPassword}>Forgot password?</S.StyledLink>
      </Text>
      <Spacing size="large" />
      <Row justify="space-between" align="middle">
        <Col>
          <Heading variant="h5" fontWeight={400}>
            Don&apos;t have an account?
          </Heading>
        </Col>
        <Col>
          <Button size="medium" variant="tertiary" onClick={onChangeAuthState}>
            Sign Up
          </Button>
        </Col>
      </Row>
    </S.Wrapper>
  );
};

export default Login;
