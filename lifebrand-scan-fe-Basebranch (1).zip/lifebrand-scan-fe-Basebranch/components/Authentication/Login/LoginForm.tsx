import React, { useState, useCallback } from 'react';
import { Form } from 'antd';
import { Rule } from 'antd/lib/form';

import { Button, Input } from '@UI/meeseeks';

import { useConnections } from '@Utils/hooks/useConnections';
import { encrypt } from '@Utils/crypto';

import { TriggerEvent } from '@Utils/google-tag-manager';

const initialValues = { email: '', password: '' };

type FormValues = typeof initialValues;

const VALIDATION_RULES: { [key: string]: Rule[] } = {
  email: [
    { required: true, message: 'Please enter an e-mail.' },
    { type: 'email', message: 'Enter a valid e-mail' },
  ],
  password: [{ required: true, message: 'Please fill in your password!' }],
};

const LoginForm = () => {
  const { actions } = useConnections();
  const [isLoading, setIsLoading] = useState(false);
  const [isButtonDisabled, setButtonDisabled] = useState(true);
  const [form] = Form.useForm();

  const formHasErrors = useCallback(() => {
    return form.getFieldsError().filter((item) => item.errors.length).length !== 0;
  }, [form]);

  const formHasEmptyFields = useCallback(() => {
    const formFieldsValues = form.getFieldsValue();
    return (
      Object.keys(formFieldsValues).filter((item) => formFieldsValues[item]).length !==
      Object.keys(formFieldsValues).length
    );
  }, [form]);

  const onSubmit = useCallback(
    async ({ email, password }: FormValues) => {
      setIsLoading(true);
      const { isSuccessful } = await actions.loginWithEmail({
        email,
        password: encrypt(password),
      });
      if (isSuccessful) {
        window.dataLayer?.push({ event: TriggerEvent.SignInSuccess });
      }
      setIsLoading(false);
    },
    [actions],
  );

  return (
    <Form
      form={form}
      initialValues={initialValues}
      requiredMark={false}
      onFieldsChange={() => setButtonDisabled(formHasErrors() || formHasEmptyFields())}
      onFinish={onSubmit}
    >
      <div>
        <Form.Item name="email" rules={VALIDATION_RULES.email}>
          <Input label="Email" type="email" placeholder="Email" fluid />
        </Form.Item>
        <Form.Item name="password" rules={VALIDATION_RULES.password}>
          <Input label="Password" placeholder="Password" fluid type="password" togglePassword />
        </Form.Item>
        <Button
          size="large"
          variant="primary"
          type="submit"
          disabled={isButtonDisabled || isLoading}
          loading={isLoading}
          fluid
        >
          Log In
        </Button>
      </div>
    </Form>
  );
};

export default LoginForm;
