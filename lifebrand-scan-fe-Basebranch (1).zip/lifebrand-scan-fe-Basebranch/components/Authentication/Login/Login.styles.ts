import styled from 'styled-components';

export const Wrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 370px;
`;

export const StyledLink = styled.a`
  color: inherit;
  text-decoration: underline;
`;
