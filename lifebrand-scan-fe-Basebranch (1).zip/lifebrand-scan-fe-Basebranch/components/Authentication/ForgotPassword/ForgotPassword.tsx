import React, { useCallback } from 'react';
import { Form } from 'antd';
import { Rule } from 'antd/lib/form';

import { Button, message, Input, Heading, Text } from '@UI/meeseeks';
import Spacing from '@UI/Spacing';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { useResetIndividualPasswordMutation } from '@Generated/graphql';

import * as S from './ForgotPassword.styles';

interface Props {
  onClose: () => void;
}

const VALIDATION_RULES: { [key: string]: Rule[] } = {
  email: [
    { required: true, message: 'Please enter an e-mail.' },
    { type: 'email', message: 'Enter a valid e-mail.' },
  ],
};

const ForgotPassword = ({ onClose }: Props) => {
  const { isMobile } = useBreakpoints();
  const [form] = Form.useForm();
  const [requestResetPassword, { loading }] = useResetIndividualPasswordMutation();

  const onSubmit = useCallback(
    async ({ email }: { email: string }) => {
      try {
        await requestResetPassword({
          variables: { email },
        });
        message.success({
          title: 'Mail has been sent to your email.',
        });
        onClose();
      } catch (e) {
        message.error({
          title: e.message,
        });
      }
    },
    [onClose, requestResetPassword],
  );

  return (
    <S.Wrapper>
      <Heading variant={isMobile ? 'h4' : 'h2'} marginBottom="xs">
        Forgot Password
      </Heading>
      <Text variant="paragraph">We will send you a Reset Password link via your email.</Text>
      <Spacing size="large" />
      <Form form={form} initialValues={{ email: '' }} requiredMark={false} onFinish={onSubmit}>
        <Form.Item name="email" rules={VALIDATION_RULES.password}>
          <Input label="Email" type="email" placeholder="Email" fluid />
        </Form.Item>
        <Button
          variant="primary"
          size="large"
          type="submit"
          disabled={loading}
          loading={loading}
          fluid
        >
          Reset Password
        </Button>
      </Form>
      <Spacing size="medium" />
      <Text variant="regular">
        <S.StyledLink onClick={onClose}>Return to login</S.StyledLink>
      </Text>
    </S.Wrapper>
  );
};

export default ForgotPassword;
