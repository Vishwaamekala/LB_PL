import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Wrapper = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 370px;
  margin: 0 auto;

  ${useBreakpoint.mobile`
    margin: 70px 0 0;
    padding: ${({ theme }) => `${theme.spacing.large}px ${theme.spacing.medium}px`};
    overflow: auto;
  `}
`;

export const EmailWrapper = styled.div`
  display: flex;
  flex-direction: column;
`;
