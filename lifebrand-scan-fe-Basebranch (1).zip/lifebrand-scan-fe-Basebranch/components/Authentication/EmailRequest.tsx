import React, { useCallback, useState } from 'react';
import { Form } from 'antd';
import { useForm } from 'antd/lib/form/Form';

import { Button, message, Input, Heading, Text } from '@UI/meeseeks';
import Spacing from '@UI/Spacing';

import { useUpdateIndividualProfileMutation } from '@Generated/graphql';

import * as S from './Authentication.styles';

const EmailRequest = () => {
  const [email, setEmail] = useState('');
  const [form] = useForm();

  const [updateProfile, { loading }] = useUpdateIndividualProfileMutation();

  const onSubmit = useCallback(
    async (values: { email: string }) => {
      try {
        const { errors, data } = await updateProfile({
          variables: { input: { email: values.email } },
        });
        if (errors) {
          throw new Error(errors[0].message);
        }
        if (data?.updateIndividualProfile?.email) {
          message.success({
            title: 'Your email was successfully added.',
          });
        }
      } catch {
        message.error({
          title: 'Something went wrong. Please try again.',
        });
      }
    },
    [updateProfile],
  );

  return (
    <S.EmailWrapper>
      <Heading variant="h2" textColor="secondary">
        One Last Thing....
      </Heading>
      <Spacing size="small" />
      <Text textColor="body" variant="body">
        Your email will allow us to send you valuable information about your LifeBrand account.
      </Text>
      <Spacing size="medium" />
      <Form form={form} initialValues={{ email: '' }} onFinish={onSubmit}>
        <Form.Item
          name="email"
          rules={[
            { required: true, message: 'Please enter an e-mail.' },
            { type: 'email', message: 'Enter a valid e-mail' },
          ]}
        >
          <Input
            label="Email"
            placeholder="Email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.currentTarget.value)}
            fluid
          />
        </Form.Item>
        <Spacing size="small" />
        <Button
          size="medium"
          type="submit"
          variant="primary"
          disabled={loading}
          loading={loading}
          fluid
        >
          Let&apos;s Go!
        </Button>
      </Form>
    </S.EmailWrapper>
  );
};

export default EmailRequest;
