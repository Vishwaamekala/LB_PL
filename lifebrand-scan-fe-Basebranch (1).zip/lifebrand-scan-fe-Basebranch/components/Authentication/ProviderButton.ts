import styled from 'styled-components';

import { Button, UiKitThemeExtended } from '@UI/meeseeks';

import { SocialMedia } from '@Generated/graphql';

type Colors = Pick<UiKitThemeExtended, 'color'>;

const socialMediaToColor: Record<SocialMedia, keyof Colors['color']> = {
  [SocialMedia.Facebook]: 'socialMedia.facebook',
  [SocialMedia.Twitter]: 'socialMedia.twitter',
  [SocialMedia.Instagram]: 'socialMedia.instagram',
} as const;

// no more error shows up
const ProviderButton = styled(Button).attrs({ variant: 'tertiary', size: 'large' })<{
  provider?: SocialMedia;
  connected?: boolean;
}>`
  position: relative;
  font-weight: 600;
  background-color: ${({ connected, provider, theme }) =>
    connected &&
    provider &&
    theme.meeseeks.color[socialMediaToColor[provider as SocialMedia]]} !important;
  color: ${({ connected, theme }) => connected && theme.meeseeks.color.white} !important;

  svg {
    position: absolute;
    left: ${({ theme }) => theme.spacing.medium}px;
    top: ${({ theme }) => theme.spacing.large / 2}px;
    height: 24px;
    width: 24px;
  }

  ${({ theme, connected, provider }) =>
    connected &&
    `
    background-color: ${
      provider && theme.meeseeks.color[socialMediaToColor[provider as SocialMedia]]
    } !important;
    color: ${theme.meeseeks.color.white} !important;

    svg * {
      fill: ${theme.meeseeks.color.white} !important;
    }
  `}
`;

export default ProviderButton;
