import React from 'react';

import SignupForm from './SignupForm';

import * as S from './Signup.styles';

type Props = {
  onChangeAuthState: () => void;
};

const Signup = ({ onChangeAuthState }: Props) => {
  return (
    <S.Wrapper>
      <SignupForm onChangeAuthState={onChangeAuthState} />
    </S.Wrapper>
  );
};

export default Signup;
