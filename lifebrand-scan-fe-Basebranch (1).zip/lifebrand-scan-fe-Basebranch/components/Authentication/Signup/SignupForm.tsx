import React, { useCallback, useState } from 'react';
import { Col, Form, Row } from 'antd';
import { Rule } from 'antd/lib/form';

import { Button, Input, Heading, Text, Icon } from '@UI/meeseeks';
import Spacing from '@UI/Spacing';
import ProviderButton from '../ProviderButton';
import { POLICY_VERSION } from 'components/Policy/Policy.constants';

import { ROUTES } from '@Utils/helper/routes';
import { useConnections, AuthProvider } from '@Utils/hooks/useConnections';
import { passwordRegex } from '@Utils/formatters/regex';
import { encrypt } from '@Utils/crypto';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { TriggerEvent } from '@Utils/google-tag-manager';

import * as S from './Signup.styles';

const regex = new RegExp(passwordRegex);

const initialForm = { name: '', surname: '', email: '', password: '' };

type FormValues = typeof initialForm;

const VALIDATION_RULES: { [key: string]: Rule[] } = {
  name: [{ required: true, message: 'Please enter name.' }],
  surname: [{ required: true, message: 'Please enter name.' }],
  email: [
    { required: true, message: 'Please enter an e-mail.' },
    { type: 'email', message: 'Enter a valid e-mail' },
  ],
};

interface Props {
  onChangeAuthState: () => void;
}

const SignupForm = ({ onChangeAuthState }: Props) => {
  const [isLoading, setIsLoading] = useState(false);
  const { actions } = useConnections();
  const { isMobile } = useBreakpoints();
  const [form] = Form.useForm();

  const onSubmit = useCallback(
    async ({ name, surname, ...input }: FormValues) => {
      setIsLoading(true);
      const { isSuccessful } = await actions.signupWithEmail({
        ...input,
        password: encrypt(input.password),
        name: `${name} ${surname}`,
        acceptedPolicyVersion: POLICY_VERSION,
      });
      if (isSuccessful) {
        window.dataLayer?.push({ event: TriggerEvent.SignUpSuccess });
      }
      setIsLoading(false);
    },
    [actions],
  );

  const handleSignupWith = async (authProvider: AuthProvider) => {
    setIsLoading(true);
    const { isSuccessful } = await actions.signupWith(authProvider);
    if (isSuccessful) {
      window.dataLayer?.push({ event: TriggerEvent.SignUpSuccess });
    }
    setIsLoading(false);
  };

  return (
    <>
      <Heading variant={isMobile ? 'h4' : 'h2'} textAlign={isMobile ? 'center' : 'left'}>
        Create an Account
      </Heading>
      <Spacing size="large" />

      <ProviderButton
        loading={isLoading}
        disabled={isLoading}
        onClick={() => handleSignupWith(AuthProvider.Google)}
        iconLeft={<Icon name="GoogleFilled" size={40} />}
        fluid
      >
        Continue with Google
      </ProviderButton>
      <Spacing size="medium" />
      <ProviderButton
        loading={isLoading}
        disabled={isLoading}
        onClick={() => handleSignupWith(AuthProvider.Facebook)}
        iconLeft={<Icon name="FacebookFilled" size={40} />}
        fluid
      >
        Continue with Facebook
      </ProviderButton>
      <Spacing size="medium" />
      <Text variant="body" textColor="neutrals.400" textAlign="center">
        or
      </Text>
      <Spacing size="medium" />
      <Form form={form} initialValues={initialForm} onFinish={onSubmit}>
        <S.FormGrid>
          <Form.Item name="name" rules={VALIDATION_RULES.name}>
            <Input label="First Name" placeholder="First Name" fluid />
          </Form.Item>
          <Form.Item name="surname" rules={VALIDATION_RULES.surname}>
            <Input label="Last Name" placeholder="Last Name" fluid />
          </Form.Item>
          <Form.Item name="email" rules={VALIDATION_RULES.email}>
            <Input label="Email" type="email" placeholder="Email" fluid />
          </Form.Item>
          <Form.Item
            name="password"
            rules={[
              { required: true, message: 'Please enter a password!' },
              {
                pattern: regex,
                message: (
                  <S.ListWrapper>
                    Password does not match the requirements.
                    <ul>
                      <li>Needs to be at least 8 characters</li>
                      <li>Contains at least 1 uppercase</li>
                      <li>Contains at least 1 lowercase</li>
                      <li>Contains at least 1 number</li>
                    </ul>
                  </S.ListWrapper>
                ),
              },
            ]}
          >
            <Input label="Password" placeholder="Password" fluid type="password" togglePassword />
          </Form.Item>
          <Button
            size="large"
            variant="primary"
            type="submit"
            disabled={isLoading}
            loading={isLoading}
            fluid
          >
            Create Account
          </Button>
        </S.FormGrid>
      </Form>
      <Spacing size="medium" />
      <Text variant="small" textColor="neutrals.700">
        By signing up, you agree to {"LifeBrand's "}
        <S.StyledLink target="_blank" href={ROUTES.PRIVACY}>
          Privacy Policy
        </S.StyledLink>{' '}
        and{' '}
        <S.StyledLink target="_blank" href={ROUTES.TERMS_OF_USE}>
          Terms of Use.
        </S.StyledLink>
      </Text>
      <Spacing size="large" />
      <Row justify="space-between" align="middle">
        <Col>
          <Heading variant="h5" fontWeight={400}>
            Already have an account?
          </Heading>
        </Col>
        <Col>
          <Button size="large" variant="tertiary" onClick={onChangeAuthState} fluid>
            Log In
          </Button>
        </Col>
      </Row>
    </>
  );
};

export default SignupForm;
