import styled from 'styled-components';

export const Wrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 370px;
`;

export const FormGrid = styled.div`
  display: flex;
  flex-wrap: wrap;

  > *:nth-child(1),
  > *:nth-child(2) {
    width: calc(50% - ${({ theme }) => theme.spacing.small / 2}px);
  }
  > *:nth-child(2) {
    margin-left: ${({ theme }) => theme.spacing.small}px;
  }

  > * {
    width: 100%;
  }

  > *:not(:last-child) {
    margin-bottom: ${({ theme }) => theme.spacing.medium}px;
  }
`;

export const StyledLink = styled.a`
  color: inherit;
  text-decoration: underline;
`;

export const ListWrapper = styled.div`
  ul {
    margin: 0;
    padding-left: ${({ theme }) => theme.spacing.medium}px;
  }
`;
