import React, { useCallback, useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import config from 'config';

import Signup from './Signup';
import Login from './Login';
import EmailRequest from './EmailRequest';
import ForgotPassword from './ForgotPassword';

import { message } from '@UI/meeseeks';
import Loading from '@UI/Loading';
import FCRAModal from 'components/Analytics/Report/FCRAModal';
import PolicyModal from 'components/Policy/PolicyModal/PolicyModal';

import { useConnections } from '@Utils/hooks/useConnections';
import { useAuthContext } from '@Utils/AuthContext';
import { shouldIndividualAcceptFCRA, shouldIndividualAcceptPolicy } from '@Utils/businessCustomer';
import { ROUTES } from '@Utils/helper/routes';
import { removeUrlParameter } from '@Utils/urlParam/helper';
import { unregisterAuthToken } from '@Utils/auth';

import {
  AuthDocument,
  IndividualFeatureAccessDocument,
  useAcceptInvitationMutation,
  useActivatePartnerSubscriptionMutation,
} from '@Generated/graphql';

import * as S from './Authentication.styles';

export enum AuthenticationState {
  SignUp = 'signup',
  LogIn = 'login',
  Policy = 'policy', // Only after PP or T&C change.
  FCRA = 'fcra', // Only for invited users.
  Email = 'email', // Only if could not retrieve it from the previous steps e.g. sign up with Twitter.
  ResetPassword = 'reset-password',
}

const allowedInitialStates = [AuthenticationState.SignUp, AuthenticationState.LogIn];

type RouterQuery = {
  invitationId?: string;
  subscriptionId?: string;
  targetUrl?: string;
  action?: AuthenticationState;
};

const Authentication = () => {
  const { userData, isLoggedIn, referredByNJREALTOR, usingDiscountNJREALTOR } = useAuthContext();
  const { actions } = useConnections();

  const router = useRouter();
  const { invitationId, subscriptionId, action, targetUrl } = router.query as RouterQuery;
  const [acceptInvitation] = useAcceptInvitationMutation();
  const [activatePartnerSubscription] = useActivatePartnerSubscriptionMutation();
  const successUrl = targetUrl || ROUTES.DASHBOARD;

  const [state, setState] = useState<AuthenticationState>(() => {
    if (action && allowedInitialStates.includes(action)) {
      return action;
    }
    return AuthenticationState.LogIn;
  });

  // Avoid glitch between rerenders by controlling the modal visibility separately.
  const [isFcraModalVisible, setIsFcraModalVisible] = useState(false);
  const [isPolicyModalVisible, setIsPolicyModalVisible] = useState(false);

  useEffect(() => {
    router.replace({
      query: {
        ...router.query,
        action: state,
      },
    });
    // router as dependecy is not needed it will cause loop
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  const shouldAcceptFCRA = shouldIndividualAcceptFCRA(userData, invitationId);
  const shouldAcceptPolicy = shouldIndividualAcceptPolicy(userData);
  const hasEmail = !!userData?.email;

  useEffect(() => {
    if (isLoggedIn) {
      if (invitationId) {
        acceptInvitation({
          variables: { invitationId },
          refetchQueries: [{ query: AuthDocument }, { query: IndividualFeatureAccessDocument }],
        })
          .then(() => {
            removeUrlParameter('invitationId');
          })
          .catch(() => {
            unregisterAuthToken();
          });
      } else if (subscriptionId) {
        activatePartnerSubscription({
          variables: { subscriptionId },
          refetchQueries: [{ query: AuthDocument }, { query: IndividualFeatureAccessDocument }],
        })
          .catch(() => {
            message.error({
              title: "Couldn't activate the subscription. Contact your provider.",
            });
          })
          .finally(() => {
            removeUrlParameter('subscriptionId');
          });
      } else if (shouldAcceptPolicy) {
        setState(AuthenticationState.Policy);
        setIsPolicyModalVisible(true);
      } else if (shouldAcceptFCRA) {
        setState(AuthenticationState.FCRA);
        setIsFcraModalVisible(true);
      } else if (!hasEmail) {
        setState(AuthenticationState.Email);
      } else if (referredByNJREALTOR && !usingDiscountNJREALTOR) {
        router.push({
          pathname: ROUTES.PAYMENT_SPECIAL,
          query: { planKey: 'NJREALTORS' },
        });
      } else {
        router.push(successUrl);
      }
    }
  }, [
    isLoggedIn,
    hasEmail,
    shouldAcceptFCRA,
    shouldAcceptPolicy,
    router,
    successUrl,
    acceptInvitation,
    invitationId,
    activatePartnerSubscription,
    subscriptionId,
    referredByNJREALTOR,
    usingDiscountNJREALTOR,
  ]);

  const handleFcraAgree = useCallback(() => {
    setIsFcraModalVisible(false);
  }, []);

  const handleFcraDecline = useCallback(() => {
    actions.individualLogout(config.SITE_URL);
    message.error({
      title: 'Please, agree to the terms to use the platform.',
    });
    setState(AuthenticationState.LogIn);
  }, [actions]);

  const handlePolicyAgree = useCallback(() => {
    setIsPolicyModalVisible(false);
  }, []);

  return (
    <S.Wrapper>
      {state === AuthenticationState.SignUp && (
        <Signup onChangeAuthState={() => setState(AuthenticationState.LogIn)} />
      )}
      {state === AuthenticationState.LogIn && (
        <Login
          onResetPassword={() => setState(AuthenticationState.ResetPassword)}
          onChangeAuthState={() => setState(AuthenticationState.SignUp)}
        />
      )}
      {(state === AuthenticationState.FCRA || state === AuthenticationState.Policy) && <Loading />}
      {shouldAcceptFCRA && (
        <FCRAModal
          description="Please read and agree to the terms before using the platform."
          isVisible={isFcraModalVisible}
          onAgree={handleFcraAgree}
          onDecline={handleFcraDecline}
        />
      )}
      {shouldAcceptPolicy && (
        <PolicyModal isVisible={isPolicyModalVisible} onAgree={handlePolicyAgree} />
      )}
      {state === AuthenticationState.Email && <EmailRequest />}
      {state === AuthenticationState.ResetPassword && (
        <ForgotPassword onClose={() => setState(AuthenticationState.LogIn)} />
      )}
    </S.Wrapper>
  );
};

export default Authentication;
