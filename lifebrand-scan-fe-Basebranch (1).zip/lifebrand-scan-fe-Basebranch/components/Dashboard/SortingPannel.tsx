import React from 'react';

import { SortingOption } from './types';

import { Select } from '@UI/meeseeks';

import { OnboardingStepKeys } from 'components/Onboarding/Onboarding.config';

import { ContentsSortingDirection, ContentsSortingField } from '@Generated/graphql';

import * as S from './Dashboard.styles';

type Props = {
  contentSorting: SortingOption | null;
  onChange: (value: { label: string; value: string } | null) => void;
};

const sortingOptions: SortingOption[] = [
  {
    label: 'Oldest',
    value: ContentsSortingDirection.Asc,
    field: ContentsSortingField.PostedAt,
  },
  {
    label: 'Newest',
    value: ContentsSortingDirection.Desc,
    field: ContentsSortingField.PostedAt,
  },
];

const SortingPanel = ({ contentSorting, onChange }: Props) => {
  return (
    <S.SortingTopPanel>
      {/*
        S.CheckBoxWrapper - should be there
      */}
      <S.SelectWrap id={OnboardingStepKeys.SortingPanel}>
        <Select
          width={188}
          options={sortingOptions}
          defaultValue={contentSorting || null}
          onChange={onChange}
          isDisabled={false}
          placeholder="Sort by"
        />
      </S.SelectWrap>
    </S.SortingTopPanel>
  );
};

export default SortingPanel;
