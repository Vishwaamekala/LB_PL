import { ContentsSortingDirection, ContentsSortingField } from '@Generated/graphql';

export enum ContentBreakdownCard {
  Flagged = 'Flagged Posts',
  NotFlagged = 'non-Flagged Posts',
  All = 'All Posts',
}

export type BreakdownCardProps = {
  title: string;
  count?: number;
  key: string;
  activeCard?: string;
};

export type SortingOption = {
  label: string;
  value: ContentsSortingDirection;
  field: ContentsSortingField;
};
