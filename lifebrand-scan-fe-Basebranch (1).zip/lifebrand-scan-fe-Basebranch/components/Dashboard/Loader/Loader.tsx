import React, { useEffect } from 'react';
import { useInView } from 'react-intersection-observer';

import Loading from '@UI/Loading';

import * as S from './Loader.styles';

type Props = {
  onLoad?: () => void;
};

const Loader = ({ onLoad }: Props) => {
  const [loaderRef, inView] = useInView({ threshold: 0 });

  useEffect(() => {
    if (inView) onLoad?.();
  }, [inView, onLoad]);

  return (
    <S.Container ref={loaderRef} data-testid="loader">
      <Loading />
    </S.Container>
  );
};

export default Loader;
