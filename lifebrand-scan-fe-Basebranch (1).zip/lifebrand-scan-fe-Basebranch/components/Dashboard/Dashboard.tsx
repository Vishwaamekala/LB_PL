import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { QueryLazyOptions } from '@apollo/client';
import { debounce } from 'lodash';

import DashboardHeader from './DashboardHeader';
import DashboardContent from './DashboardContent';
import DashboardReconnectProvider from './DashboardReconnectProvider';
import ToolbarPanel from './ToolbarPanel';
import ToolbarPanelMobile from './ToolbarPanel/ToolbarPanelMobile';
import SortingPanel from './SortingPannel';
import { SortingOption } from './types';

import ConnectSocialMediaBanner from 'components/Dashboard/Banners/ConnectSocialMediaBanner';
import { OnboardingStepKeys } from 'components/Onboarding/Onboarding.config';

import { useAuthContext } from '@Utils/AuthContext';
import { useContentsFilterContext } from '@Utils/ContentsFilterContext';
import { useScanContext, POLL_INTERVAL } from '@Utils/ScanContext';
import { usePreviousValue } from '@Utils/hooks/usePreviousValue';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';
import { useSubscriptionContext } from '@Utils/SubscriptionContext/useSubscriptionContext';

import {
  ContentsInput,
  SocialMedia,
  useContentsLazyQuery,
  useDashboardContentBreakdownsQuery,
  useLastScanQuery,
} from '@Generated/graphql';

import * as S from './Dashboard.styles';

const DEFAULT_LIMIT = 10;
const PREVIEW_LIMIT = 2;

type Props = {
  isScrolling: boolean;
};

const Dashboard = ({ isScrolling }: Props) => {
  const { isDesktop, isMdDesktop } = useBreakpoints();
  const isOnDesktopScreen = isMdDesktop || isDesktop;

  const { features } = useSubscriptionContext();
  const { canUseAdvancedDashboard } = features || {};

  const { data: lastScan, loading: lastScanLoading } = useLastScanQuery();
  const { hasScanRunning } = useScanContext();

  const { isInstagramTokenExpired, isFacebookTokenExpired } = useAuthContext();

  const {
    data: contentsBreakdown,
    loading: loadingBreakdowns,
    startPolling: startPollingBreakdowns,
    stopPolling: stopPollingBreakdowns,
  } = useDashboardContentBreakdownsQuery();

  const { dashboardContentBreakdowns } = contentsBreakdown || {};

  const {
    originsFilter,
    bucketLabelsFilter,
    searchFilter,
    isFlaggedFilter,
    isBusinessDictionaryFilter,
  } = useContentsFilterContext();

  const [contentSorting, setContentSorting] = useState<SortingOption | null>(null);

  const contentsInput: ContentsInput = useMemo(() => {
    return {
      socialMedia: originsFilter.length > 0 ? originsFilter : undefined,
      labels: bucketLabelsFilter.length > 0 ? bucketLabelsFilter : undefined,
      search: searchFilter,
      isDeleted: false,
      isFlagged: isFlaggedFilter,
      take: canUseAdvancedDashboard ? DEFAULT_LIMIT : PREVIEW_LIMIT,
      isBusinessDictionary: isBusinessDictionaryFilter,
      sorting: {
        field: contentSorting?.field,
        direction: contentSorting?.value,
      },
    };
  }, [
    originsFilter,
    bucketLabelsFilter,
    searchFilter,
    isFlaggedFilter,
    isBusinessDictionaryFilter,
    canUseAdvancedDashboard,
    contentSorting,
  ]);

  // default input is added due to no input and filtering done together will cause
  // all contents to be visible.
  const [
    fetchContents,
    { data: contents, loading: fetching, fetchMore, variables, startPolling, stopPolling },
  ] = useContentsLazyQuery({
    variables: {
      input: contentsInput,
    },
  });

  const previousContentsInput = usePreviousValue(contentsInput);

  // Fetch only if 500ms have passed since the last call e.g. when a user stops typing
  // to prevent extra rerenders and network requests.
  const fetchContentsDebounced = useMemo(
    () =>
      debounce(
        (options?: QueryLazyOptions<{ input: ContentsInput }>) => fetchContents(options),
        500,
      ),
    [fetchContents],
  );

  useEffect(() => {
    if (features == null) return;

    if (previousContentsInput?.search !== contentsInput?.search) {
      // only call debounced if search filter changed
      fetchContentsDebounced({ variables: { input: contentsInput } });
    } else {
      fetchContents({ variables: { input: contentsInput } });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchContents, fetchContentsDebounced, contentsInput]);

  const nextCursorId = contents?.contents.nextCursorId;

  const handleMore = useCallback(() => {
    if (fetchMore && !fetching) {
      fetchMore({ variables: { input: { ...contentsInput, cursorId: nextCursorId } } });
    }
  }, [fetchMore, fetching, contentsInput, nextCursorId]);

  const handleSorting = useCallback((value) => {
    if (value) {
      setContentSorting(value);
    }
  }, []);

  useEffect(() => {
    if (hasScanRunning) {
      startPolling?.(POLL_INTERVAL);
      startPollingBreakdowns(POLL_INTERVAL);
    } else {
      stopPolling?.();
      stopPollingBreakdowns();
    }
  }, [hasScanRunning, startPolling, stopPolling, startPollingBreakdowns, stopPollingBreakdowns]);

  if (lastScanLoading) {
    return null;
  }

  if (!lastScan?.lastScan && !hasScanRunning) {
    return <ConnectSocialMediaBanner />;
  }

  return (
    <S.Wrapper>
      <S.ResultsAndToolbarWrapper>
        <DashboardHeader
          breakdownsData={dashboardContentBreakdowns}
          loading={loadingBreakdowns}
          hasScanRunning={hasScanRunning}
          isScrolling={isScrolling}
        />
        {!isOnDesktopScreen && (
          <ToolbarPanelMobile
            breakdownsData={dashboardContentBreakdowns}
            loading={loadingBreakdowns}
          />
        )}
        {canUseAdvancedDashboard && (
          <SortingPanel contentSorting={contentSorting} onChange={handleSorting} />
        )}

        {isInstagramTokenExpired && <DashboardReconnectProvider provider={SocialMedia.Instagram} />}
        {isFacebookTokenExpired && <DashboardReconnectProvider provider={SocialMedia.Facebook} />}

        <div id={OnboardingStepKeys.DashboardContent}>
          <DashboardContent
            contentsInput={variables?.input}
            contents={contents}
            handleMore={nextCursorId && canUseAdvancedDashboard ? handleMore : undefined}
            isLoading={fetching}
            hasScanRunning={hasScanRunning}
            scanCreatedAt={lastScan?.lastScan?.createdAt}
            scanUpdatedAt={lastScan?.lastScan?.updatedAt}
          />
        </div>
      </S.ResultsAndToolbarWrapper>

      {isOnDesktopScreen && (
        <ToolbarPanel
          breakdownData={dashboardContentBreakdowns}
          loading={loadingBreakdowns}
          hasScanRunning={hasScanRunning}
        />
      )}
    </S.Wrapper>
  );
};

export default Dashboard;
