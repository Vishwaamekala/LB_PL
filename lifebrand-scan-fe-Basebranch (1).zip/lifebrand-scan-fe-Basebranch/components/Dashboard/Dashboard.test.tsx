import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import { theme } from 'theme/theme';
import { ThemeProvider } from 'styled-components';
import { MockedProvider, MockedResponse } from '@apollo/client/testing';

import Dashboard from './Dashboard';

import { ContentsFilterContext } from '@Utils/ContentsFilterContext';

import {
  LastScanDocument,
  ScanType,
  DashboardContentBreakdownsDocument,
  ContentsDocument,
  BusinessCustomerType,
  BusinessFeature,
  PlanType,
} from '@Generated/graphql';
import { BreakpointProvider } from '@Utils/hooks/useBreakpoints';
import { AuthContext, ContextProps } from '@Utils/AuthContext';

jest.mock('next/router', () => ({
  useRouter() {
    return {
      route: '/dashboard',
      pathname: '',
      query: '',
      asPath: '',
    };
  },
}));

jest.mock('@Utils/SubscriptionContext/useSubscriptionContext', () => ({
  ...jest.requireActual('@Utils/SubscriptionContext/useSubscriptionContext'),
  useSubscriptionContext() {
    return {
      features: {
        canAccessAnalytics: true,
        canScan: true,
        canUpgrade: false,
        canUseAdvancedDashboard: true,
        __typename: 'IndividualFeatureAccess',
      },
      loading: false,
      plan: {
        currentPeriodEnds: null,
        isCancelled: false,
        isCancellable: false,
        name: 'Free',
      },
    };
  },
}));

jest.mock('@Utils/hooks/useFeatureFlags', () => ({
  ...jest.requireActual('@Utils/hooks/useFeatureFlags'),
  useFeatureFlags() {
    return {
      ...jest.requireActual('@Utils/hooks/useFeatureFlags'),
      isEnabled: false,
      payload: {},
    };
  },
}));

jest.mock('react-image-lightbox/style.css', () => {});

const intersectionObserverMock = () => ({
  observe: () => null,
  unobserve: () => null,
  disconnect: () => null,
});

window.IntersectionObserver = jest.fn().mockImplementation(intersectionObserverMock);

const mock: ReadonlyArray<MockedResponse> = [
  {
    request: {
      query: ContentsDocument,
      variables: {
        input: {
          socialMedia: undefined,
          labels: undefined,
          search: '',
          isDeleted: false,
          isFlagged: true,
          isBusinessDictionary: false,
          take: 10,
          sorting: { field: undefined, direction: undefined },
        },
      },
    },
    result: {
      data: {
        contents: {
          __typename: 'ContentsResponse',
          nextCursorId: null,
          list: [
            {
              __typename: 'Content',
              id: 'ckwq93nf502330ks62hoapl71',
              text: 'text',
              type: 'Post',
              score: 30,
              origin: 'Facebook',
              url: '',
              postedAt: '2021-10-05T16:09:21.000Z',
              interactions: {
                shares: 0,
                comments: 0,
                reactions: {
                  SAD: 0,
                  WOW: 0,
                  CARE: 0,
                  HAHA: 0,
                  LIKE: 0,
                  LOVE: 0,
                  ANGRY: 0,
                },
              },
              media: [],
              isFlagged: true,
              isDeleted: false,
              createdAt: '2021-12-03T10:35:24.113Z',
              language: null,
              ContentAnalysis: [
                {
                  __typename: 'ContentAnalysis',
                  id: 'ckwq93nf502340ks6tu503m9e',
                  contentId: 'ckwq93nf502330ks62hoapl71',
                  type: 'Toxicity',
                  status: 'Finished',
                  passed: true,
                  score: 0,
                  results: [],
                  labels: [],
                  finishedAt: '2021-12-03T10:35:29.071Z',
                  createdAt: '2021-12-03T10:35:24.113Z',
                  updatedAt: '2021-12-03T10:35:29.072Z',
                },
                {
                  __typename: 'ContentAnalysis',
                  id: 'ckwq93nf502350ks66je7ejbt',
                  contentId: 'ckwq93nf502330ks62hoapl71',
                  type: 'Profanity',
                  status: 'Finished',
                  passed: false,
                  score: 30,
                  results: [
                    {
                      label: 'toxicity',
                      subject: 'text',
                      confidence: 1,
                    },
                  ],
                  labels: ['toxicity'],
                  finishedAt: '2021-12-03T10:35:23.971Z',
                  createdAt: '2021-12-03T10:35:24.113Z',
                  updatedAt: '2021-12-03T10:35:24.115Z',
                },
                {
                  __typename: 'ContentAnalysis',
                  contentId: 'cl0w6ewxy0062tzvpl0mgrdky',
                  createdAt: '2022-03-18T08:45:37.222Z',
                  finishedAt: '2022-03-18T08:45:42.549Z',
                  id: 'cl0w6ewxy0064tzvp51wmowpn',
                  labels: ['cl0v581xv000009l35x7t4ej2'],
                  passed: false,
                  score: 10,
                  results: [
                    {
                      label: 'cl0v581xv000009l35x7t4ej2',
                      subject: 'kokoko',
                      confidence: 1,
                    },
                  ],
                  status: 'Finished',
                  type: 'BusinessDictionary',
                  updatedAt: '2022-03-18T08:45:42.556Z',
                },
              ],
            },
          ],
        },
      },
    },
  },
  {
    request: {
      query: DashboardContentBreakdownsDocument,
      variables: {},
    },
    result: {
      data: {
        dashboardContentBreakdowns: {
          __typename: 'DashboardContentBreakdownsResponse',
          labelsBreakdown: {
            __typename: 'FlaggedPostLabelsBreakdownResponse',
            identity_attack: 0,
            insult: 0,
            obscene: 0,
            threat: 0,
            sexual_explicit: 9,
            sexual: 0,
            severe_toxicity: 0,
            toxicity: 3,
            inappropriate: 0,
            blasphemy: 0,
            discriminatory: 0,
          },
          originsBreakdown: {
            __typename: 'OriginsBreakdown',
            Facebook: 21,
            Twitter: 0,
            Instagram: 0,
          },
          flaggedByOriginsBreakdown: {
            __typename: 'OriginsBreakdown',
            Facebook: 9,
            Twitter: 0,
            Instagram: 0,
          },
          flaggedCount: 9,
          allContentsCount: 21,
          businessDictionaryCount: 2,
        },
      },
    },
  },
  {
    request: {
      query: LastScanDocument,
      variables: {},
    },
    result: {
      data: {
        lastScan: {
          id: 'ckzmnlmj124020js6nr70g5mn',
          type: ScanType.SyncUp,
          status: 'New',
          startedAt: '2022-02-14T12:09:19.691Z',
          createdAt: '2022-02-14T12:09:19.691Z',
          updatedAt: '2022-02-14T12:09:19.691Z',
          duration: null,
          __typename: 'Scan',
        },
      },
    },
  },
  {
    request: {
      query: ContentsDocument,
      variables: {
        input: {
          socialMedia: undefined,
          labels: undefined,
          search: 'test',
          isDeleted: false,
          isFlagged: true,
          take: 10,
          isBusinessDictionary: false,
          sorting: { field: undefined, direction: undefined },
        },
      },
    },
    result: {
      data: {
        contents: {
          __typename: 'ContentsResponse',
          nextCursorId: null,
          list: [
            {
              __typename: 'Content',
              id: 'ckwq93nf502330ks62hoapl71',
              text: 'text',
              type: 'Post',
              score: 30,
              origin: 'Facebook',
              url: '',
              postedAt: '2021-10-05T16:09:21.000Z',
              interactions: {
                shares: 0,
                comments: 0,
                reactions: {
                  SAD: 0,
                  WOW: 0,
                  CARE: 0,
                  HAHA: 0,
                  LIKE: 0,
                  LOVE: 0,
                  ANGRY: 0,
                },
              },
              media: [],
              isFlagged: true,
              isDeleted: false,
              createdAt: '2021-12-03T10:35:24.113Z',
              language: null,
              ContentAnalysis: [
                {
                  __typename: 'ContentAnalysis',
                  id: 'ckwq93nf502340ks6tu503m9e',
                  contentId: 'ckwq93nf502330ks62hoapl71',
                  type: 'Toxicity',
                  status: 'Finished',
                  passed: true,
                  score: 0,
                  results: [],
                  labels: [],
                  finishedAt: '2021-12-03T10:35:29.071Z',
                  createdAt: '2021-12-03T10:35:24.113Z',
                  updatedAt: '2021-12-03T10:35:29.072Z',
                },
                {
                  __typename: 'ContentAnalysis',
                  id: 'ckwq93nf502350ks66je7ejbt',
                  contentId: 'ckwq93nf502330ks62hoapl71',
                  type: 'Profanity',
                  status: 'Finished',
                  passed: false,
                  score: 30,
                  results: [
                    {
                      label: 'toxicity',
                      subject: 'text',
                      confidence: 1,
                    },
                  ],
                  labels: ['toxicity'],
                  finishedAt: '2021-12-03T10:35:23.971Z',
                  createdAt: '2021-12-03T10:35:24.113Z',
                  updatedAt: '2021-12-03T10:35:24.115Z',
                },
                {
                  __typename: 'ContentAnalysis',
                  contentId: 'cl0w6ewxy0062tzvpl0mgrdky',
                  createdAt: '2022-03-18T08:45:37.222Z',
                  finishedAt: '2022-03-18T08:45:42.549Z',
                  id: 'cl0w6ewxy0064tzvp51wmowpn',
                  labels: ['cl0v581xv000009l35x7t4ej2'],
                  passed: false,
                  score: 10,
                  results: [
                    {
                      label: 'cl0v581xv000009l35x7t4ej2',
                      subject: 'kokoko',
                      confidence: 1,
                    },
                  ],
                  status: 'Finished',
                  type: 'BusinessDictionary',
                  updatedAt: '2022-03-18T08:45:42.556Z',
                },
              ],
            },
            {
              __typename: 'Content',
              id: 'ckwq93nf502330ks62hoapl23',
              text: 'test',
              type: 'Post',
              score: 30,
              origin: 'Facebook',
              url: '',
              postedAt: '2020-10-05T16:10:21.000Z',
              interactions: {
                shares: 0,
                comments: 0,
                reactions: {
                  SAD: 0,
                  WOW: 0,
                  CARE: 0,
                  HAHA: 0,
                  LIKE: 0,
                  LOVE: 0,
                  ANGRY: 0,
                },
              },
              media: [],
              isFlagged: true,
              isDeleted: false,
              createdAt: '2021-12-03T10:35:24.113Z',
              language: null,
              ContentAnalysis: [
                {
                  __typename: 'ContentAnalysis',
                  id: 'ckwq93nf502340ks6tu503m9w',
                  contentId: 'ckwq93nf502330ks62hoapl23',
                  type: 'Toxicity',
                  status: 'Finished',
                  passed: true,
                  score: 0,
                  results: [],
                  labels: [],
                  finishedAt: '2020-12-03T10:35:29.071Z',
                  createdAt: '2020-12-03T10:35:24.113Z',
                  updatedAt: '2020-12-03T10:35:29.072Z',
                },
                {
                  __typename: 'ContentAnalysis',
                  id: 'ckwq93nf502350ks66je7ejbt',
                  contentId: 'ckwq93nf502330ks62hoapl71',
                  type: 'Profanity',
                  status: 'Finished',
                  passed: false,
                  score: 30,
                  results: [
                    {
                      label: 'toxicity',
                      subject: 'test',
                      confidence: 1,
                    },
                  ],
                  labels: ['toxicity'],
                  finishedAt: '2021-12-03T10:35:23.971Z',
                  createdAt: '2021-12-03T10:35:24.113Z',
                  updatedAt: '2021-12-03T10:35:24.115Z',
                },
                {
                  __typename: 'ContentAnalysis',
                  contentId: 'cl0w6ewxy0062tzvpl0mgrdky',
                  createdAt: '2022-03-18T08:45:37.222Z',
                  finishedAt: '2022-03-18T08:45:42.549Z',
                  id: 'cl0w6ewxy0064tzvp51wmowpn',
                  labels: ['cl0v581xv000009l35x7t4ej2'],
                  passed: false,
                  score: 10,
                  results: [
                    {
                      label: 'cl0v581xv000009l35x7t4ej2',
                      subject: 'kokoko',
                      confidence: 1,
                    },
                  ],
                  status: 'Finished',
                  type: 'BusinessDictionary',
                  updatedAt: '2022-03-18T08:45:42.556Z',
                },
              ],
            },
          ],
        },
      },
    },
  },
  {
    request: {
      query: ContentsDocument,
      variables: {
        input: {
          socialMedia: undefined,
          labels: ['threat'],
          search: '',
          isDeleted: false,
          isFlagged: true,
          isBusinessDictionary: false,
          take: 10,
          sorting: { field: undefined, direction: undefined },
        },
      },
    },
    result: {
      data: {
        contents: {
          __typename: 'ContentsResponse',
          nextCursorId: null,
          list: [],
        },
      },
    },
  },
  {
    request: {
      query: ContentsDocument,
      variables: {
        input: {
          socialMedia: undefined,
          labels: undefined,
          search: '',
          isDeleted: false,
          isFlagged: true,
          isBusinessDictionary: true,
          take: 10,
          sorting: { field: undefined, direction: undefined },
        },
      },
    },
    result: {
      data: {
        contents: {
          __typename: 'ContentsResponse',
          nextCursorId: null,
          list: [
            {
              __typename: 'Content',
              id: 'ckwq93nf502330ks62hoapl71',
              text: 'custom',
              type: 'Post',
              score: 30,
              origin: 'Facebook',
              url: '',
              postedAt: '2021-10-05T16:09:21.000Z',
              interactions: {
                shares: 0,
                comments: 0,
                reactions: {
                  SAD: 0,
                  WOW: 0,
                  CARE: 0,
                  HAHA: 0,
                  LIKE: 0,
                  LOVE: 0,
                  ANGRY: 0,
                },
              },
              media: [],
              isFlagged: true,
              isDeleted: false,
              createdAt: '2021-12-03T10:35:24.113Z',
              language: null,
              ContentAnalysis: [
                {
                  __typename: 'ContentAnalysis',
                  id: 'ckwq93nf502340ks6tu503m9e',
                  contentId: 'ckwq93nf502330ks62hoapl71',
                  type: 'Toxicity',
                  status: 'Finished',
                  passed: true,
                  score: 0,
                  results: [],
                  labels: [],
                  finishedAt: '2021-12-03T10:35:29.071Z',
                  createdAt: '2021-12-03T10:35:24.113Z',
                  updatedAt: '2021-12-03T10:35:29.072Z',
                },
                {
                  __typename: 'ContentAnalysis',
                  id: 'ckwq93nf502350ks66je7ejbt',
                  contentId: 'ckwq93nf502330ks62hoapl71',
                  type: 'Profanity',
                  status: 'Finished',
                  passed: false,
                  score: 30,
                  results: [
                    {
                      label: 'toxicity',
                      subject: 'text',
                      confidence: 1,
                    },
                  ],
                  labels: ['toxicity'],
                  finishedAt: '2021-12-03T10:35:23.971Z',
                  createdAt: '2021-12-03T10:35:24.113Z',
                  updatedAt: '2021-12-03T10:35:24.115Z',
                },
                {
                  __typename: 'ContentAnalysis',
                  contentId: 'cl0w6ewxy0062tzvpl0mgrdky',
                  createdAt: '2022-03-18T08:45:37.222Z',
                  finishedAt: '2022-03-18T08:45:42.549Z',
                  id: 'cl0w6ewxy0064tzvp51wmowpn',
                  labels: ['cl0v581xv000009l35x7t4ej2'],
                  passed: false,
                  score: 10,
                  results: [
                    {
                      label: 'cl0v581xv000009l35x7t4ej2',
                      subject: 'kokoko',
                      confidence: 1,
                    },
                  ],
                  status: 'Finished',
                  type: 'BusinessDictionary',
                  updatedAt: '2022-03-18T08:45:42.556Z',
                },
              ],
            },
          ],
        },
      },
    },
  },
  {
    request: {
      query: ContentsDocument,
      variables: {
        input: {
          labels: undefined,
          search: '',
          isDeleted: false,
          isFlagged: false,
          take: 10,
          isBusinessDictionary: true,
          sorting: { field: undefined, direction: undefined },
        },
      },
    },
    result: {
      data: {
        contents: {
          __typename: 'ContentsResponse',
          nextCursorId: null,
          list: [],
        },
      },
    },
  },
];

const filtersMock = {
  isFlaggedFilter: true,
  originsFilter: [],
  bucketLabelsFilter: [],
  searchFilter: '',
  isBusinessDictionaryFilter: false,
  setIsFlaggedFilter: () => null,
  setOriginsFilter: () => null,
  setBucketLabelsFilter: () => null,
  setSearchFilter: () => null,
  setIsBusinessDictionaryFilter: () => null,
  resetFilters: () => null,
  resetAllFilters: () => null,
  handleClear: () => null,
  numberOfActiveFilters: 0,
};

const authMock = {
  hasBusinessDictionary: false,
  loading: false,
  userData: undefined,
  isLoggedIn: undefined,
  socialMediaConnectionsQuery: undefined,
  isInvited: false,
  invitedBy: [],
  referredByNJREALTOR: false,
  usingDiscountNJREALTOR: false,
  triggerRefetch: (() => {
    return {};
  }) as ContextProps['triggerRefetch'],
  isInstagramTokenExpired: false,
  setIsInstagramTokenExpired: () => {},
  isFacebookTokenExpired: false,
  setIsFacebookTokenExpired: () => {},
};

describe('Dashboard', () => {
  beforeAll(() => {
    window.resizeTo = function resizeTo(width, height) {
      Object.assign(this, {
        innerWidth: width,
        innerHeight: height,
        outerWidth: width,
        outerHeight: height,
        configurable: true,
      }).dispatchEvent(new this.Event('resize'));
    };
  });

  it('renders content without filters', async () => {
    window.resizeTo(1400, 1000);
    const { findByTestId } = render(
      <ThemeProvider theme={theme}>
        <AuthContext.Provider value={authMock}>
          <BreakpointProvider>
            <ContentsFilterContext.Provider value={filtersMock}>
              <MockedProvider addTypename={false} mocks={mock}>
                <Dashboard isScrolling={false} />
              </MockedProvider>
            </ContentsFilterContext.Provider>
          </BreakpointProvider>
        </AuthContext.Provider>
      </ThemeProvider>,
    );

    expect(await findByTestId('content-log', undefined, { timeout: 3000 })).toBeInTheDocument();
  });

  it('check content is changed after clicking on filters', async () => {
    window.resizeTo(1400, 1000);
    const { getByTestId, getByText } = render(
      <ThemeProvider theme={theme}>
        <AuthContext.Provider value={authMock}>
          <BreakpointProvider>
            <ContentsFilterContext.Provider
              value={{ ...filtersMock, bucketLabelsFilter: ['threat'] }}
            >
              <MockedProvider addTypename={false} mocks={mock}>
                <Dashboard isScrolling={false} />
              </MockedProvider>
            </ContentsFilterContext.Provider>
          </BreakpointProvider>
        </AuthContext.Provider>
      </ThemeProvider>,
    );

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    const Threat = getByTestId('Threat-chip');
    fireEvent.click(Threat);

    await waitFor(() => {
      expect(getByText('Sorry, we couldn’t find any results for this filter.')).toBeInTheDocument();
    });
  });

  it('renders NoFilteredResultsBanner for search', async () => {
    window.resizeTo(1400, 1000);
    const { getByRole, getAllByTestId } = render(
      <ThemeProvider theme={theme}>
        <AuthContext.Provider value={authMock}>
          <BreakpointProvider>
            <ContentsFilterContext.Provider value={{ ...filtersMock, searchFilter: 'test' }}>
              <MockedProvider addTypename={false} mocks={mock}>
                <Dashboard isScrolling={false} />
              </MockedProvider>
            </ContentsFilterContext.Provider>
          </BreakpointProvider>
        </AuthContext.Provider>
      </ThemeProvider>,
    );

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    const Search = getByRole('searchbox');
    fireEvent.change(Search, { target: { value: 'test' } });

    await waitFor(() => {
      expect(getAllByTestId('content-log')).toHaveLength(2);
    });
  });

  it('renders Custom Dictionary tab contents', async () => {
    window.resizeTo(1400, 1000);
    const { getAllByTestId, getByText } = render(
      <ThemeProvider theme={theme}>
        <AuthContext.Provider
          value={{
            ...authMock,
            hasBusinessDictionary: true,
            userData: {
              __typename: 'User',
              Plan: {
                __typename: 'Plan',
                id: 'ckrd5tj3600212jym75wdlnj7',
                name: 'Unlimited Access',
                type: PlanType.Individual,
                numberOfScans: -1,
                isRecurring: true,
                price: 397,
              },
              id: 'ckwq8nqgq20210ls63vqbcgy5',
              name: 'name',
              email: 'test@gmaail.com',
              photo: '',
              scanAmount: -1,
              authId: 'google-oauth2|106600749954791229640',
              stripeId: 'cus_LP5MHkrf9BYujF',
              planId: 'ckrd5tj3600212jym75wtlnj7',
              createdAt: '2021-12-03T10:23:01.562Z',
              updatedAt: '2022-03-28T11:57:04.568Z',
              lastRefresh: null,
              acceptedFcraVersion: 'v1-2022',
              acceptedPolicyVersion: 'v2022-01-19',
              hasPassword: false,
              BusinessCustomer: [
                {
                  id: 'id',
                  type: BusinessCustomerType.CurrentEmployee,
                  isActive: true,
                  __typename: 'BusinessCustomer',
                  updatedAt: '2021-12-03T10:23:01.562Z',
                  Business: {
                    id: 'id',
                    name: 'name',
                    contactEmail: 'email',
                    features: [BusinessFeature.CustomDictionary],
                    BusinessDictionary: {
                      id: 'id',
                      createdAt: '2021-12-03T10:23:01.562Z',
                      updatedAt: '2021-12-03T10:23:01.562Z',
                      __typename: 'BusinessDictionary',
                    },
                  },
                },
              ],
            },
          }}
        >
          <BreakpointProvider>
            <ContentsFilterContext.Provider
              value={{ ...filtersMock, isBusinessDictionaryFilter: true }}
            >
              <MockedProvider addTypename={false} mocks={mock}>
                <Dashboard isScrolling={false} />
              </MockedProvider>
            </ContentsFilterContext.Provider>
          </BreakpointProvider>
        </AuthContext.Provider>
      </ThemeProvider>,
    );

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    const customDictionary = getByText('Custom Dictionary');
    fireEvent.click(customDictionary);

    await waitFor(() => {
      expect(getAllByTestId('content-log')).toHaveLength(1);
    });
  });

  it('renders Empty Custom Dictionary banner, before scan.', async () => {
    window.resizeTo(1400, 1000);
    const { getByTestId, getByText } = render(
      <ThemeProvider theme={theme}>
        <AuthContext.Provider value={{ ...authMock, hasBusinessDictionary: true }}>
          <BreakpointProvider>
            <ContentsFilterContext.Provider
              value={{
                ...filtersMock,
                isBusinessDictionaryFilter: true,
                isFlaggedFilter: false,
              }}
            >
              <MockedProvider addTypename={false} mocks={mock}>
                <Dashboard isScrolling={false} />
              </MockedProvider>
            </ContentsFilterContext.Provider>
          </BreakpointProvider>
        </AuthContext.Provider>
      </ThemeProvider>,
    );

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    const customDictionary = getByTestId('Custom Dictionary');
    fireEvent.click(customDictionary);

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    await waitFor(() => {
      expect(getByText('You need to scan again to see the results.')).toBeInTheDocument();
    });
  });
});
