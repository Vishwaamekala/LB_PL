import styled from 'styled-components';

import { Text as TextBase } from '@UI/meeseeks';

import { useBreakpoint } from '@Utils/style/breakpoint';
import { inlineGap } from '@Utils/style/gap';

const DASHBOARD_CONTENT_WIDTH = 600;

export const Wrapper = styled.div`
  display: flex;
  ${({ theme }) => inlineGap(`${theme.spacing.xxl}px`)};

  ${useBreakpoint.mdDesktop`
    ${({ theme }) => inlineGap(`${theme.spacing.large}px`)};
  `}

  @media screen and (max-width: 992px) {
    ${({ theme }) => inlineGap(`${theme.spacing.medium}px`)};
  }
`;

export const ResultsAndToolbarWrapper = styled.div`
  min-width: ${DASHBOARD_CONTENT_WIDTH}px;
  // Ratio of Dashboard content
  // Wrapper in ToolbarPanel.styles.ts is handling its flex too
  flex: 2;

  ${useBreakpoint.mdDesktop`
    flex: 1;
    max-width: ${DASHBOARD_CONTENT_WIDTH}px;
  `}

  ${useBreakpoint.tablet`
    max-width: 100%;
  `}

  ${useBreakpoint.mobile`
    min-width: 100%;
  `}
`;

export const ContentList = styled.div<{ isSomeFilterActive?: boolean }>`
  margin: ${({ theme, isSomeFilterActive }) =>
      isSomeFilterActive ? theme.spacing.medium : theme.spacing.large}px
    0;

  ${useBreakpoint.tablet`
    margin: 0;
  `}

  margin-bottom: ${({ theme }) => theme.spacing.medium * 5}px;

  > * + * {
    margin-top: ${({ theme }) => theme.spacing.medium}px;
  }
`;

export const FilterResults = styled.div`
  display: grid;
  grid-template-columns: 2fr 1fr;
  margin: ${({ theme }) =>
    `${theme.spacing.extraLarge}px ${theme.spacing.medium}px ${theme.spacing.medium}px`};
  gap: ${({ theme }) => theme.spacing.extraLarge * 2}px;
  align-items: center;

  ${useBreakpoint.tablet`
    margin: ${({ theme }) => `0 ${theme.spacing.medium}px ${theme.spacing.medium}px`};
  `}
`;

export const ClearFilters = styled.div`
  cursor: pointer;
`;

export const SelectWrap = styled.div`
  align-self: flex-end;
`;

export const SortingTopPanel = styled.div`
  display: flex;
  justify-content: flex-end;

  ${useBreakpoint.tablet`
    margin-bottom: ${({ theme }) => theme.spacing.medium}px;
  `}
`;

export const BannerWrap = styled.div`
  margin-top: ${({ theme }) => theme.spacing.large}px;
  max-height: 480px;
`;

export const Text = styled(TextBase)`
  .filters {
    font-weight: 600;
  }
`;
