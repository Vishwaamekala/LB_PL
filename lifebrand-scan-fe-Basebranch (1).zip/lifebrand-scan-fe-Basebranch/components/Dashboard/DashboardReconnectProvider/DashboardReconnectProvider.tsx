import React from 'react';

import { Heading, Icon, Text } from '@UI/meeseeks';

import SocialMediaIcon from '@UI/SocialMediaIcon';
import ConnectButton from 'components/ConnectionButtons/ConnectButton';

import { useConnections, SocialMediatoProviderKeys } from '@Utils/hooks/useConnections';
import { SocialMedia } from '@Generated/graphql';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import * as S from './DashboardReconnectProvider.styles';

type Props = {
  provider: SocialMedia;
};

const DashboardReconnectProvider = ({ provider }: Props) => {
  const { isMobile } = useBreakpoints();
  const { actions, isActionsDisabled, state } = useConnections();

  return (
    <S.Wrapper>
      <SocialMediaIcon socialMedia={provider} size={40} />

      <S.Text>
        <Heading variant="h5" textColor="heading">
          Ouch, your {provider} account disconnected.
        </Heading>
        <Text variant="regular" textColor="body">
          Please reconnect to see all updates.
        </Text>
      </S.Text>

      <ConnectButton
        provider={provider}
        onClick={() => actions.disconnectConnectWith(provider)}
        disabled={isActionsDisabled}
        loading={state.connectingState[SocialMediatoProviderKeys[provider]]}
        fluid={isMobile}
        iconLeft={<Icon name="RefreshCw" color="neutrals.100" />}
        title="Reconnect"
      />
    </S.Wrapper>
  );
};

export default DashboardReconnectProvider;
