import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Wrapper = styled.div`
  margin-top: ${({ theme }) => theme.spacing.xxl / 4}px;
  display: flex;
  justify-content: space-between;
  padding: ${({ theme }) => theme.spacing.xxl / 4}px ${({ theme }) => theme.spacing.xs * 3}px;
  background: ${({ theme }) => theme.meeseeks.color['neutrals.00']};
  align-items: center;

  ${useBreakpoint.mobile`
    flex-wrap:wrap;
  `}
`;

export const Text = styled.div`
  flex: 1;
  margin-left: ${({ theme }) => theme.spacing.small}px;
  margin-right: ${({ theme }) => theme.spacing.small}px;

  ${useBreakpoint.mobile`
    margin-bottom:${({ theme }) => theme.spacing.xxl / 4}px;
  `}
`;
