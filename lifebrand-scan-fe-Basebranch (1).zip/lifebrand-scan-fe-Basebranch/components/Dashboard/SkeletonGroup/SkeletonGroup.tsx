import React from 'react';
import Skeleton from 'react-loading-skeleton';

import * as S from './SkeletonGroup.styles';

type Props = {
  count: number;
};

const SkeletonGroup = ({ count }: Props) => {
  const placeHolderArray = new Array(count).fill('');

  return (
    <>
      {placeHolderArray.map((_, i) => (
        <S.SkeletonGroup key={i} data-testid="skeleton">
          <S.Header>
            <Skeleton width={70} height={20} />
            <Skeleton width={70} height={20} />
            <Skeleton width={70} height={20} />
          </S.Header>
          <S.Body>
            <Skeleton width="25%" height={15} />
            <Skeleton width="100%" height={15} />
            <Skeleton width="100%" height={15} />
            <Skeleton width="70%" height={15} />
          </S.Body>
          <S.Body>
            <Skeleton width="100%" height={200} />
          </S.Body>
        </S.SkeletonGroup>
      ))}
    </>
  );
};

export default SkeletonGroup;
