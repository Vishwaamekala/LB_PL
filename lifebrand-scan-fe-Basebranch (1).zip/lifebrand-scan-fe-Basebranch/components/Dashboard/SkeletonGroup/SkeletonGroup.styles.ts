import styled from 'styled-components';

export const SkeletonGroup = styled.div`
  background-color: ${({ theme }) => theme.meeseeks.color['neutrals.100']};
  margin-top: ${({ theme }) => theme.spacing.medium}px;
  padding: ${({ theme }) => theme.spacing.medium}px;
`;

export const Header = styled.div`
  > span {
    margin-right: ${({ theme }) => theme.spacing.small}px;
  }
`;

export const Body = styled.div`
  margin-top: ${({ theme }) => theme.spacing.medium}px;
`;
