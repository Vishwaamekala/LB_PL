import styled from 'styled-components';

import { Button as ButtonBase } from '@UI/meeseeks';

export const ChipsWrapper = styled.div`
  display: inline-flex;
  flex-wrap: wrap;
  margin: ${({ theme }) => `-${theme.spacing.medium}px 0 0 -${theme.spacing.small}px`};

  > * {
    margin: ${({ theme }) => `${theme.spacing.medium}px 0 0 ${theme.spacing.small}px`};
  }
`;

export const Button = styled(ButtonBase)`
  justify-content: center;
  margin-top: ${({ theme }) => theme.spacing.extraLarge}px;
`;
