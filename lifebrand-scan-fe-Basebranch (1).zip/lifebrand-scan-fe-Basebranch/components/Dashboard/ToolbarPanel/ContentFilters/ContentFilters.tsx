import React, { useMemo } from 'react';

import { getFlaggedContentLabelBreakdowns, getOriginBreakdowns } from './ContentFilters.utils';

import { Chip, Heading, Text, Tooltip } from '@UI/meeseeks';
import Spacing from '@UI/Spacing';

import { useContentsFilterContext } from '@Utils/ContentsFilterContext';

import { DashboardContentBreakdownsQuery, OriginsBreakdown, SocialMedia } from '@Generated/graphql';

import { useConnections } from '@Utils/hooks/useConnections';

import * as S from './ContentFilters.styles';

type Props = {
  breakdownsData?: DashboardContentBreakdownsQuery['dashboardContentBreakdowns'];
  heading?: string;
};

const ContentFilters = ({ breakdownsData, heading }: Props) => {
  const {
    bucketLabelsFilter,
    originsFilter,
    setOriginsFilter,
    setBucketLabelsFilter,
    isFlaggedFilter,
  } = useContentsFilterContext();

  const { socialMediaConnection } = useConnections();
  const {
    resetFilters,
    numberOfActiveFilters,
    isBusinessDictionaryFilter,
  } = useContentsFilterContext();

  const socialMediaConnected = socialMediaConnection
    .filter(({ isConnected }) => isConnected)
    .map((connection) => connection.socialMedia);

  const formattedFlaggedContentLabels = getFlaggedContentLabelBreakdowns(
    breakdownsData?.labelsBreakdown,
  );

  const originDataBreakdowns = useMemo((): OriginsBreakdown | undefined => {
    if (!breakdownsData) return undefined;
    const {
      flaggedByOriginsBreakdown,
      originsBreakdown,
      businessDictionaryByOriginsBreakdown,
    } = breakdownsData;

    if (isBusinessDictionaryFilter) {
      return businessDictionaryByOriginsBreakdown;
    }

    if (isFlaggedFilter) {
      return flaggedByOriginsBreakdown;
    }

    return originsBreakdown;
  }, [isFlaggedFilter, isBusinessDictionaryFilter, breakdownsData]);

  // SM Filters : connected SM or if all disconnected, those which has post in the scan.
  const formattedOriginBreakdowns = getOriginBreakdowns(originDataBreakdowns).filter(
    (origin) => socialMediaConnected.includes(origin.origin as SocialMedia) || origin.count !== 0,
  );

  const handleOriginSelect = (origin: SocialMedia) => {
    setOriginsFilter((prev) => {
      if (prev.includes(origin)) {
        return prev.filter((one) => one !== origin);
      }
      return [...prev, origin];
    });
  };

  const handleLabelSelect = (label: string) => {
    setBucketLabelsFilter((prev) => {
      if (prev.includes(label)) {
        return prev.filter((one) => one !== label);
      }
      return [...prev, label];
    });
  };

  return (
    <div>
      {heading && (
        <Heading variant="h5" marginBottom="medium" textColor="heading">
          {heading}
        </Heading>
      )}
      {formattedOriginBreakdowns.length > 0 && (
        <>
          <Text variant="regular" marginBottom="medium" textColor="body">
            Social Media
          </Text>
          <S.ChipsWrapper>
            {formattedOriginBreakdowns.map(({ origin, count }) => (
              <Chip
                key={origin}
                count={count as number}
                checked={originsFilter.includes(origin)}
                onChange={() => handleOriginSelect(origin)}
              >
                {origin}
              </Chip>
            ))}
          </S.ChipsWrapper>
        </>
      )}
      {!isBusinessDictionaryFilter && (
        <>
          <Spacing size="medium" />
          <Text variant="regular" marginBottom="medium" textColor="body">
            Flagged Posts Categories
          </Text>
          <S.ChipsWrapper>
            {formattedFlaggedContentLabels.map(({ key, count, title, description }) => (
              <Tooltip
                title={title}
                description={description}
                placement="top"
                key={title}
                mouseEnterDelay={0.8}
              >
                <Chip
                  key={key}
                  count={count as number}
                  checked={bucketLabelsFilter.includes(key)}
                  onChange={() => handleLabelSelect(key)}
                  data-testid={`${title}-chip`}
                >
                  {title}
                </Chip>
              </Tooltip>
            ))}
          </S.ChipsWrapper>
        </>
      )}
      {numberOfActiveFilters > 0 && (
        <S.Button type="button" variant="tertiary" size="medium" onClick={resetFilters} fluid>
          Clear Filters
        </S.Button>
      )}
    </div>
  );
};

export default ContentFilters;
