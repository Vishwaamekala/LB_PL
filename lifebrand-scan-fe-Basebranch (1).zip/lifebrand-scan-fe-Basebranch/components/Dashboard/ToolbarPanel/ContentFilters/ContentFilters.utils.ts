import {
  FlaggedPostLabelsBreakdownResponse,
  OriginsBreakdown,
  SocialMedia,
} from '@Generated/graphql';
import { toxicityLabelsByKey } from '@Utils/toxicityLabels/constants';

export const getFlaggedContentLabelBreakdowns = (
  labelBreakdown?: FlaggedPostLabelsBreakdownResponse,
) => {
  return Object.entries(toxicityLabelsByKey).map(([key, label]) => {
    const count = labelBreakdown?.[key as keyof typeof labelBreakdown];
    return {
      title: label.title,
      description: label.description,
      count,
      key,
    };
  });
};

export const getOriginBreakdowns = (originBreakdown?: OriginsBreakdown) => {
  return Object.entries(SocialMedia).map(([origin]) => {
    const count = originBreakdown?.[origin as keyof typeof originBreakdown];
    return {
      count,
      origin: origin as SocialMedia,
    };
  });
};
