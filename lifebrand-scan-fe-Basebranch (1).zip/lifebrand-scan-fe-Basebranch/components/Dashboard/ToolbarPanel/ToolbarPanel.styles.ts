import styled from 'styled-components';

import { HEADER_HEIGHT, SPACING_TOP_LARGE, SPACING_TOP_MEDIUM } from '@Layout/Layout.styles';

import { useBreakpoint } from '@Utils/style/breakpoint';

const SPACING_HORIZONTAL = '10px';

export const Wrapper = styled.div`
  position: sticky;
  top: 0;
  // Ratio of Dashboard content
  // ResultsAndToolbarWrapper is handling its flex too
  flex: 1;

  overflow-y: auto;
  height: calc(100vh - ${HEADER_HEIGHT} - ${SPACING_TOP_LARGE});

  // This fixes: Overflow property is cutting off children's box-shadow from sides.
  padding: 0 ${SPACING_HORIZONTAL};
  margin: 0 -${SPACING_HORIZONTAL};

  ${useBreakpoint.mobile`
    height: calc(100vh - ${HEADER_HEIGHT} - ${SPACING_TOP_MEDIUM});
  `}
`;

export const Content = styled.div`
  & > * {
    :first-child {
      margin-bottom: ${({ theme }) => theme.spacing.large}px;
    }
    :not(:first-child) {
      margin-bottom: ${({ theme }) => theme.spacing.medium}px;
    }
  }
`;

export const Card = styled.div<{ withBorder?: boolean; withBoxShadow?: boolean }>`
  padding: ${({ theme }) => theme.spacing.medium}px;
  box-shadow: ${({ withBoxShadow }) =>
    withBoxShadow && '1px 1px 1px rgba(0, 0, 0, 0.05), 0px 2px 14px rgba(51, 51, 51, 0.09)'};
  border: 1px solid
    ${({ withBorder, theme }) => (withBorder ? theme.meeseeks.color.tertiary : 'transparent')};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  background-color: ${({ theme }) => theme.meeseeks.color.white};
`;

export const ActionWrapper = styled.div`
  * + * {
    margin-top: ${({ theme }) => theme.spacing.medium}px;
  }
`;
