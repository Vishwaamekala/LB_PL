import React, { useRef } from 'react';

import ContentFilters from './ContentFilters';
import SearchContentsInput from './SearchContentsInput';

import { Heading, Text } from '@UI/meeseeks';

import AnalyticsOverviewButton from 'components/ActionButtons/AnalyticsOverviewButton';
import { OnboardingStepKeys } from 'components/Onboarding/Onboarding.config';

import ReportRequestList from '../ReportRequest/ReportRequestList';

import { useSubscriptionContext } from '@Utils/SubscriptionContext/useSubscriptionContext';
import { useAuthContext } from '@Utils/AuthContext';

import { DashboardContentBreakdownsQuery } from '@Generated/graphql';

import * as S from './ToolbarPanel.styles';

type Props = {
  breakdownData?: DashboardContentBreakdownsQuery['dashboardContentBreakdowns'];
  loading?: boolean;
  hasScanRunning?: boolean;
};

const ToolbarPanel = ({ breakdownData, loading }: Props) => {
  const { features } = useSubscriptionContext();
  const { canUseAdvancedDashboard } = features || {};

  const sidebarContentRef = useRef<HTMLDivElement>(null);

  const { isInvited } = useAuthContext();

  // TODO: in order to fix flickering on this step
  // scrolling is disabled when Onboarding is open
  // Since Toolbar is sticky, it prevents it from being visible as a whole when
  // the viewport height is smaller than this component
  // if we conditionally remove sticky, onboarding will automatically scroll at the bottom
  // of the page, which also isn't what we want.
  // if anyone has an idea how to fix it better, please, do.
  return (
    <S.Wrapper id={OnboardingStepKeys.DashboardToolbar}>
      <S.Content ref={sidebarContentRef}>
        <SearchContentsInput loading={loading} disabled={!canUseAdvancedDashboard} />
        {isInvited && (
          <S.Card withBoxShadow>
            <Heading variant="h5" marginBottom="xxs" textColor="heading">
              Want to Share Report?
            </Heading>
            <Text variant="small" textColor="body" marginBottom="medium">
              When you are done with cleaning up your Flagged posts, go to Analytics Overview. You
              can Create and Share Reports from there.
            </Text>
            <AnalyticsOverviewButton fluid />
          </S.Card>
        )}
        <ReportRequestList />
        {canUseAdvancedDashboard && (
          <S.Card withBorder>
            <ContentFilters heading="Filters" breakdownsData={breakdownData} />
          </S.Card>
        )}
      </S.Content>
    </S.Wrapper>
  );
};

export default ToolbarPanel;
