import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';

import { theme } from 'theme/theme';
import { ThemeProvider } from 'styled-components';
import { MockedProvider } from '@apollo/client/testing';

import ToolbarPanel from './ToolbarPanel';

jest.mock('next/router', () => ({
  useRouter() {
    return {
      route: '/dashboard',
      pathname: '',
      query: '',
      asPath: '',
    };
  },
}));

jest.mock('@Utils/SubscriptionContext/useSubscriptionContext', () => ({
  ...jest.requireActual('@Utils/SubscriptionContext/useSubscriptionContext'),
  useSubscriptionContext() {
    return {
      features: {
        canAccessAnalytics: true,
        canScan: true,
        canUpgrade: false,
        canUseAdvancedDashboard: true,
        __typename: 'IndividualFeatureAccess',
      },
      loading: false,
      plan: {
        currentPeriodEnds: null,
        isCancelled: false,
        isCancellable: false,
        name: 'Free',
      },
    };
  },
}));

describe('ToolbarPanel', () => {
  it('renders search input', async () => {
    const { getByRole } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider addTypename>
          <ToolbarPanel />
        </MockedProvider>
      </ThemeProvider>,
    );

    expect(getByRole('searchbox')).toBeInTheDocument();
  });

  it('renders filters', async () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider addTypename>
          <ToolbarPanel />
        </MockedProvider>
      </ThemeProvider>,
    );

    expect(getByText('Filters')).toBeInTheDocument();
  });

  it('click on filters', async () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider addTypename>
          <ToolbarPanel />
        </MockedProvider>
      </ThemeProvider>,
    );
    const Twitter = getByText('Twitter');
    fireEvent.click(Twitter);

    await waitFor(() => {
      expect(Twitter).toHaveProperty('checked');
    });
  });
});
