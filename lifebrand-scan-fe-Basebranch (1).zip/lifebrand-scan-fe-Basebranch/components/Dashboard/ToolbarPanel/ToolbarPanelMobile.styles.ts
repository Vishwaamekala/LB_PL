import styled from 'styled-components';

import CollapseBase from '@UI/Collapse';

export const Spacing = styled.div`
  height: ${({ theme }) => theme.spacing.medium}px;
`;

export const Collapse = styled(CollapseBase)`
  padding: ${({ theme }) => theme.spacing.medium}px 0;

  .ant-collapse-item {
    border-bottom: 1px solid ${({ theme }) => theme.meeseeks.color['neutrals.100']};
    border-top: 1px solid ${({ theme }) => theme.meeseeks.color['neutrals.100']};

    .ant-collapse-header > * {
      color: ${({ theme }) => theme.meeseeks.color.secondary};
      display: flex;
    }

    .ant-collapse-header {
      padding: ${({ theme }) => theme.spacing.medium}px 0;
      display: flex;

      svg {
        margin-left: ${({ theme }) => theme.spacing.small / 2}px;
      }

      .ant-collapse-arrow {
        top: ${({ theme }) => theme.spacing.medium}px;
      }
    }
  }
`;

export const CollapseContent = styled.div`
  & > *:not(:last-child) {
    margin-bottom: ${({ theme }) => theme.spacing.medium}px;
  }

  & > :last-child {
    margin-bottom: ${({ theme }) => theme.spacing.large}px;
  }
`;
