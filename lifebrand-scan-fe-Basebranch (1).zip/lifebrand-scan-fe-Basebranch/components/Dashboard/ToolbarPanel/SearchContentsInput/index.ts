export { default } from './SearchContentsInput';
export * from './SearchContentsInput';
