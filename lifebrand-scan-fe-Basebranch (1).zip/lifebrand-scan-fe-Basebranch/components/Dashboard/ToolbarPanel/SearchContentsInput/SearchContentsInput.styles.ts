import styled from 'styled-components';

export const Clear = styled.div`
  display: flex;
  justify-content: center;
  cursor: pointer;
`;
