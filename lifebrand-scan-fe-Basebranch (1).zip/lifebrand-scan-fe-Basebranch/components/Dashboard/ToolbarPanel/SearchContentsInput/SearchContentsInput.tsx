import React from 'react';

import { Icon, Input } from '@UI/meeseeks';

import { useContentsFilterContext } from '@Utils/ContentsFilterContext';

import * as S from './SearchContentsInput.styles';

type Props = {
  loading?: boolean;
  disabled?: boolean;
};

const SearchContentsInput = ({ loading, disabled }: Props) => {
  const { searchFilter, setSearchFilter, handleClear } = useContentsFilterContext();

  return (
    <Input
      disabled={loading || disabled}
      label=""
      type="search"
      placeholder="Search..."
      fluid
      value={searchFilter}
      onChange={(e) => setSearchFilter(e.currentTarget.value)}
      rightIcon={
        searchFilter && (
          <S.Clear onClick={handleClear}>
            <Icon name="X" />
          </S.Clear>
        )
      }
    />
  );
};

export default SearchContentsInput;
