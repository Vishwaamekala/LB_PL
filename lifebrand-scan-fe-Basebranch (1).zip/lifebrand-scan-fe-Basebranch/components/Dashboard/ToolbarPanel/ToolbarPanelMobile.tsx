import React, { useEffect, useState } from 'react';

import { useTour } from '@reactour/tour';

import ContentFilters from './ContentFilters';
import SearchContentsInput from './SearchContentsInput';

import { Heading, Icon } from '@UI/meeseeks';

import { OnboardingStepKeys } from 'components/Onboarding/Onboarding.config';

import { useContentsFilterContext } from '@Utils/ContentsFilterContext';
import { useSubscriptionContext } from '@Utils/SubscriptionContext/useSubscriptionContext';

import { DashboardContentBreakdownsQuery } from '@Generated/graphql';

import * as S from './ToolbarPanelMobile.styles';

type Props = {
  breakdownsData?: DashboardContentBreakdownsQuery['dashboardContentBreakdowns'];
  loading?: boolean;
};

const ToolbarPanelMobile = ({ breakdownsData, loading }: Props) => {
  const { numberOfActiveFilters } = useContentsFilterContext();
  const { features } = useSubscriptionContext();

  const { isOpen: isOnboardingOn, currentStep } = useTour();
  const [activeKey, setActiveKey] = useState<string | undefined>();

  useEffect(() => {
    if (isOnboardingOn && currentStep === 5) {
      setActiveKey('Filters');
    } else {
      setActiveKey(undefined);
    }
  }, [isOnboardingOn, currentStep]);

  const onChange = (key: string | string[]) =>
    Array.isArray(key) ? setActiveKey(key[0]) : setActiveKey(key);

  if (!features?.canUseAdvancedDashboard) {
    return <S.Spacing />;
  }

  return (
    <div id={OnboardingStepKeys.DashboardToolbar}>
      <S.Collapse
        expandIcon={({ isActive }) => (
          <Icon name={isActive ? 'ChevronUp' : 'ChevronDown'} size={22} />
        )}
        activeKey={activeKey}
        onChange={onChange}
      >
        <S.Collapse.Panel
          key="Filters"
          header={
            <Heading variant="h6" color="secondary">
              Filter {numberOfActiveFilters > 0 && <Icon name="Check" size={16} />}
            </Heading>
          }
        >
          <S.CollapseContent>
            <SearchContentsInput loading={loading} />
            <ContentFilters breakdownsData={breakdownsData} />
          </S.CollapseContent>
        </S.Collapse.Panel>
      </S.Collapse>
    </div>
  );
};

export default ToolbarPanelMobile;
