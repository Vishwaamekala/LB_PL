import React from 'react';
import { render } from '@testing-library/react';

import { theme } from 'theme/theme';
import { ThemeProvider } from 'styled-components';
import { MockedProvider } from '@apollo/client/testing';

import DashboardContent from './DashboardContent';

import {
  ContentAnalysisStatus,
  ContentAnalysisType,
  ContentType,
  SocialMedia,
} from '@Generated/graphql';

jest.mock('next/router', () => ({
  useRouter() {
    return {
      route: '/dashboard',
      pathname: '',
      query: '',
      asPath: '',
    };
  },
}));

jest.mock('@Utils/SubscriptionContext/useSubscriptionContext', () => ({
  ...jest.requireActual('@Utils/SubscriptionContext/useSubscriptionContext'),
  useSubscriptionContext() {
    return {
      features: {
        canAccessAnalytics: true,
        canScan: false,
        canUpgrade: true,
        canUseAdvancedDashboard: false,
      },
      loading: false,
      plan: {
        currentPeriodEnds: null,
        isCancelled: false,
        isCancellable: false,
        name: 'Free',
      },
    };
  },
}));

jest.mock('react-image-lightbox/style.css', () => {});

const intersectionObserverMock = () => ({
  observe: () => null,
  unobserve: () => null,
  disconnect: () => null,
});

window.IntersectionObserver = jest.fn().mockImplementation(intersectionObserverMock);

const contentMock = {
  contents: {
    list: [
      {
        id: '',
        isDeleted: false,
        isFlagged: true,
        media: [],
        origin: SocialMedia.Facebook,
        score: 20,
        text: 'text',
        type: ContentType.Post,
        url: '',
        postedAt: Date.now(),
        interactions: {
          comments: 0,
          reactions: {},
          shares: 0,
        },
        createdAt: '',
        language: null,
        ContentAnalysis: [
          {
            contentId: '',
            createdAt: '',
            finishedAt: '',
            id: '',
            labels: [],
            passed: true,
            results: [],
            score: 0,
            status: ContentAnalysisStatus.Finished,
            type: ContentAnalysisType.Profanity,
            updatedAt: '',
          },
        ],
      },
    ],
  },
};

describe('DashboardContent', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('renders NoFilteredResultsBanner for search', async () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider addTypename>
          <DashboardContent
            contents={{ contents: { list: [] } }}
            isLoading={false}
            contentsInput={{ search: 'text' }}
          />
        </MockedProvider>
      </ThemeProvider>,
    );

    expect(getByText('Sorry, we couldn’t find any results for this search.')).toBeInTheDocument();
  });

  it('renders NoFilteredResultsBanner for filters', async () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider addTypename>
          <DashboardContent
            contents={{ contents: { list: [] } }}
            isLoading={false}
            contentsInput={{ socialMedia: [SocialMedia.Facebook] }}
          />
        </MockedProvider>
      </ThemeProvider>,
    );

    expect(getByText('Sorry, we couldn’t find any results for this filter.')).toBeInTheDocument();
  });

  it('renders No posts found', async () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider addTypename>
          <DashboardContent contents={{ contents: { list: [] } }} isLoading={false} />
        </MockedProvider>
      </ThemeProvider>,
    );

    expect(getByText('No Posts here.')).toBeInTheDocument();
  });

  it('renders Upgrade banner', async () => {
    const { getByRole } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider addTypename>
          <DashboardContent contents={contentMock} isLoading={false} />
        </MockedProvider>
      </ThemeProvider>,
    );

    expect(getByRole('img', { name: 'upgrade' })).toBeInTheDocument();
  });

  it('renders filters', async () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider addTypename>
          <DashboardContent
            contents={contentMock}
            isLoading={false}
            contentsInput={{ socialMedia: [SocialMedia.Facebook] }}
          />
        </MockedProvider>
      </ThemeProvider>,
    );

    expect(getByText('Clear All Filters')).toBeInTheDocument();
  });

  it('renders Content', async () => {
    const { getByTestId } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider addTypename>
          <DashboardContent contents={contentMock} isLoading={false} />
        </MockedProvider>
      </ThemeProvider>,
    );

    expect(getByTestId('content-log')).toBeInTheDocument();
  });

  it('renders Skeleton while is loading', async () => {
    const { getAllByTestId } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider addTypename>
          <DashboardContent contents={{ contents: { list: [] } }} isLoading={true} />
        </MockedProvider>
      </ThemeProvider>,
    );

    expect(getAllByTestId('skeleton')[0]).toBeInTheDocument();
  });

  it('renders Loader on infinite scroll', async () => {
    const { getByTestId } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider addTypename>
          <DashboardContent contents={contentMock} isLoading={false} handleMore={() => {}} />
        </MockedProvider>
      </ThemeProvider>,
    );

    expect(getByTestId('loader')).toBeInTheDocument();
  });
});
