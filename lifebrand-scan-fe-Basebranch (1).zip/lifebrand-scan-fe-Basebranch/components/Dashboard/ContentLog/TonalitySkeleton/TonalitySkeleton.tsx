import React from 'react';
import Skeleton from 'react-loading-skeleton';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import * as S from './TonalitySkeleton.styles';

const TonalitySkeleton = () => {
  const { isMobile } = useBreakpoints();
  return (
    <S.Wrapper>
      <S.Row>{Array(isMobile ? 1 : 5).fill(<Skeleton height={4} width={30} />)}</S.Row>
    </S.Wrapper>
  );
};

export default TonalitySkeleton;
