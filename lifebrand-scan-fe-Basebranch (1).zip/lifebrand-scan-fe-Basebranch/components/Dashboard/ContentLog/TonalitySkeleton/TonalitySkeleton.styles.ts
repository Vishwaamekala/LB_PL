import styled from 'styled-components';

export const Wrapper = styled.div`
  margin-left: auto !important;
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  // width: 186px;
  height: 28px;
  display: flex;
  justify-content: center;
  align-items: center;
  background: ${({ theme }) => theme.meeseeks.color['neutrals.00']};
  padding: ${({ theme }) => theme.spacing.small}px;
`;

export const Row = styled.div`
  background: ${({ theme }) => theme.meeseeks.color.white};
  border: 4px solid ${({ theme }) => theme.meeseeks.color.white};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  height: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  vertical-align: middle;

  > * {
    line-height: 4px;
    font-size: 4px;

    > span {
      border-radius: 0;
    }
  }

  > * + * {
    margin-left: ${({ theme }) => theme.spacing.small / 2}px;
  }

  & > *:first-child > span {
    border-top-left-radius: ${({ theme }) => theme.borderRadius.small}px;
    border-bottom-left-radius: ${({ theme }) => theme.borderRadius.small}px;
  }

  & > *:last-child > span {
    border-top-right-radius: ${({ theme }) => theme.borderRadius.small}px;
    border-bottom-right-radius: ${({ theme }) => theme.borderRadius.small}px;
  }
`;
