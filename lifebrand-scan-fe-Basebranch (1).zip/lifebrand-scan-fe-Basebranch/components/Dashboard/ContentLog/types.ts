import { SupportedLanguage } from '@Generated/graphql';

export const SupportedLanguageFlag: Record<string, string> = {
  [SupportedLanguage.Spanish]: '/images/svg/flags/spain.svg',
};
