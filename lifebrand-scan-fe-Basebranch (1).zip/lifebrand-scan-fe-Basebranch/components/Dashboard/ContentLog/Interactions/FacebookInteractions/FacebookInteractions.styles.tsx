import styled from 'styled-components';

export const InteractionsContainer = styled.div`
  display: flex;
  align-items: center;

  > * + * {
    margin-left: ${({ theme }) => theme.spacing.small}px;
  }
`;

export const Reactions = styled.div`
  margin-right: auto;
  line-height: 100%;
`;
