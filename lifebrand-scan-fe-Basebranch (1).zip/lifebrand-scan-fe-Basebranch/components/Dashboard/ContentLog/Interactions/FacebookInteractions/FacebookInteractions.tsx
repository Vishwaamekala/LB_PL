import React from 'react';

import FacebookReaction from './FacebookReaction';

import { Tooltip, Text } from '@UI/meeseeks';

import * as S from './FacebookInteractions.styles';

enum Reactions {
  Angry = 'ANGRY',
  Care = 'CARE',
  Haha = 'HAHA',
  Like = 'LIKE',
  Love = 'LOVE',
  Sad = 'SAD',
  Wow = 'WOW',
}

type FacebookInteractionsProps = {
  interactions: {
    reactions?: { [key in Reactions]: number };
    comments?: number;
    shares?: number;
  };
};

const ReactionsDisplayOrder = [
  Reactions.Like,
  Reactions.Haha,
  Reactions.Love,
  Reactions.Angry,
  Reactions.Wow,
  Reactions.Care,
  Reactions.Sad,
];

const FacebookInteractions = ({ interactions }: FacebookInteractionsProps) => {
  if (
    !interactions.comments &&
    !interactions.shares &&
    !Object.values(interactions?.reactions || {}).some((value) => value > 0)
  ) {
    return null;
  }

  return (
    <S.InteractionsContainer>
      <S.Reactions>
        {interactions.reactions &&
          ReactionsDisplayOrder.map((reaction) =>
            interactions.reactions?.[reaction] ? (
              <Tooltip
                title={`${reaction}: ${interactions?.reactions[reaction]}`}
                placement="top"
                key={reaction}
              >
                <span>
                  <FacebookReaction type={reaction} />
                </span>
              </Tooltip>
            ) : null,
          )}
      </S.Reactions>
      {!!interactions.comments && (
        <Text variant="small" textColor="neutrals.400">
          {interactions.comments} comments
        </Text>
      )}
      {!!interactions.shares && (
        <Text variant="small" textColor="neutrals.400">
          {interactions.shares} shares
        </Text>
      )}
    </S.InteractionsContainer>
  );
};

export default FacebookInteractions;
