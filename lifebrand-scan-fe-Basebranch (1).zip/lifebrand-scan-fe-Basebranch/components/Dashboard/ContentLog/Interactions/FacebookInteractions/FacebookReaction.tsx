import React from 'react';

import { Icon, IconProps } from '@UI/meeseeks';

enum Reactions {
  Angry = 'ANGRY',
  Care = 'CARE',
  Haha = 'HAHA',
  Like = 'LIKE',
  Love = 'LOVE',
  Sad = 'SAD',
  Wow = 'WOW',
}

const iconsByReaction: Record<Reactions, IconProps['name']> = {
  [Reactions.Angry]: 'FBAngry',
  [Reactions.Care]: 'FBCare',
  [Reactions.Haha]: 'FBHaha',
  [Reactions.Like]: 'FBLike',
  [Reactions.Love]: 'FBLove',
  [Reactions.Sad]: 'FBSad',
  [Reactions.Wow]: 'FBWoW',
};

type FacebookReactionProps = {
  type: Reactions;
  size?: number;
};

const FacebookReaction = ({ type, size = 16 }: FacebookReactionProps) => {
  return <Icon name={iconsByReaction[type]} size={size} />;
};

export default FacebookReaction;
