import React from 'react';

import { Icon, IconProps } from '@UI/meeseeks';

export enum TwitterEngagementTypes {
  Comment = 'Comment',
  Like = 'Like',
  Retweet = 'Retweet',
}

const iconsByEngagement: Record<TwitterEngagementTypes, IconProps['name']> = {
  [TwitterEngagementTypes.Comment]: 'TwitterComment',
  [TwitterEngagementTypes.Like]: 'TwitterLike',
  [TwitterEngagementTypes.Retweet]: 'TwitterRetweet',
};

type TwitterEngagementProps = {
  type: TwitterEngagementTypes;
  size?: number;
};

const TwitterEngagement = ({ type, size = 16 }: TwitterEngagementProps) => {
  return <Icon name={iconsByEngagement[type]} size={size} />;
};

export default TwitterEngagement;
