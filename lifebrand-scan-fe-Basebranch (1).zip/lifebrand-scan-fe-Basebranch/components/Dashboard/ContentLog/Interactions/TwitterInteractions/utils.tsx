// https://stackoverflow.com/a/9462382
// https://www.wikiwand.com/en/International_System_of_Units

const SIUnits = [
  { value: 1, symbol: '' },
  { value: 1e3, symbol: 'k' },
  { value: 1e6, symbol: 'M' },
  { value: 1e9, symbol: 'G' },
  { value: 1e12, symbol: 'T' },
  { value: 1e15, symbol: 'P' },
  { value: 1e18, symbol: 'E' },
];

const regex = /\.0+$|(\.[0-9]*[1-9])0+$/;

export function numberWithSIUnitsFormatter(num: number, digits: number) {
  let i;
  for (i = SIUnits.length - 1; i > 0; i -= 1) {
    if (num >= SIUnits[i].value) {
      break;
    }
  }
  return (num / SIUnits[i].value).toFixed(digits).replace(regex, '$1') + SIUnits[i].symbol;
}
