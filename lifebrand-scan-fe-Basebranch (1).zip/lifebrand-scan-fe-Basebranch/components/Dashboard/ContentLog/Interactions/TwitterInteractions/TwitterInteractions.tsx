import React from 'react';

import { numberWithSIUnitsFormatter } from './utils';

import TwitterEngagement, { TwitterEngagementTypes } from './TwitterEngagement';

import { Text } from '@UI/meeseeks';

import * as S from './TwitterInteractions.styles';

type TwitterInteractionsProps = {
  interactions: {
    retweet_count?: number;
    like_count?: number; // favorite_count in API v1, like_count in API v2
    reply_count?: number; // unavailable in v1, keeping it for future consistence
    quote_count?: number; // unavailable in v1, keeping it for future consistence
  };
};

const TwitterInteractions = ({ interactions }: TwitterInteractionsProps) => {
  if (Object.values(interactions).every((count) => !count)) return null;

  return (
    <div>
      <Text variant="small" textColor="neutrals.400">
        <S.EngagementValue>
          <TwitterEngagement type={TwitterEngagementTypes.Retweet} />
          &nbsp;{numberWithSIUnitsFormatter(interactions?.retweet_count || 0, 1)}
        </S.EngagementValue>
        <S.EngagementValue>
          <TwitterEngagement type={TwitterEngagementTypes.Like} />
          &nbsp;{numberWithSIUnitsFormatter(interactions?.like_count || 0, 1)}
        </S.EngagementValue>
      </Text>
    </div>
  );
};

export default TwitterInteractions;
