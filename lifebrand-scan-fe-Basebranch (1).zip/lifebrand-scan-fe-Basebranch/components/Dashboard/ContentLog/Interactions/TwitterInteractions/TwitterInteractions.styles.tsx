import styled from 'styled-components';

export const EngagementValue = styled.span`
  display: inline-flex;
  align-items: center;
  margin-right: ${({ theme }) => theme.spacing.medium}px;
`;
