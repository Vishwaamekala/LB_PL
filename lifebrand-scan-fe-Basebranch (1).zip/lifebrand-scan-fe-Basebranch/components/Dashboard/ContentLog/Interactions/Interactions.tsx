import React from 'react';

import FacebookInteractions from './FacebookInteractions';
import TwitterInteractions from './TwitterInteractions';

import { ContentDataFragment, SocialMedia } from '@Generated/graphql';

type InteractionsProps = {
  interactions: ContentDataFragment['interactions'];
  origin: ContentDataFragment['origin'];
};

const InteractionComponents: {
  [key in SocialMedia]: React.ReactElement | null;
} = {
  [SocialMedia.Facebook]: <FacebookInteractions interactions={{}} />,
  [SocialMedia.Twitter]: <TwitterInteractions interactions={{}} />,
  [SocialMedia.Instagram]: null,
};

const Interactions = ({ interactions, origin }: InteractionsProps) => {
  const Element = InteractionComponents[origin];
  if (!Element) return null;
  return React.cloneElement(Element, {
    interactions,
  });
};
export default Interactions;
