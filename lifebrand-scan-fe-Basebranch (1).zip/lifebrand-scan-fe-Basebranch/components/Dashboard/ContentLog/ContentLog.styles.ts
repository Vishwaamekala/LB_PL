import styled from 'styled-components';

import { Text as TextBase, Tag } from '@UI/meeseeks';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Log = styled.div`
  background: ${({ theme }) => theme.meeseeks.color.white};
  box-shadow: ${({ theme }) => theme.shadow.card};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  padding: ${({ theme }) => theme.spacing.medium}px;

  ${useBreakpoint.mobile`
    margin-left: ${({ theme }) => -theme.spacing.medium}px;
    margin-right: ${({ theme }) => -theme.spacing.medium}px;
  `}
`;

export const Header = styled.div`
  display: flex;
  align-items: center;
  position: relative;

  > * + * {
    margin-left: ${({ theme }) => theme.spacing.small}px;
  }
`;

export const TagItem = styled(Tag)<{
  activeTag?: boolean;
}>`
  border: ${({ theme }) => theme.border.card};
  border-color: transparent;
  cursor: pointer;

  ${({ activeTag, theme }) =>
    activeTag &&
    `
      background-color: ${theme.meeseeks.color['highlight.100']};
      border-color: ${theme.meeseeks.color['chart.yellow']};
      color: ${theme.meeseeks.color['neutrals.800']};
    `}
`;

export const Body = styled.div`
  margin: ${({ theme }) => `${theme.spacing.large / 2}px 0 ${theme.spacing.medium}px`};
  border: ${({ theme }) => theme.border.card};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  padding: ${({ theme }) => theme.spacing.medium}px;

  > * + * {
    margin-top: ${({ theme }) => theme.spacing.medium}px;
  }
`;

export const Meta = styled.div`
  display: flex;
  align-items: center;

  > * + * {
    margin-left: ${({ theme }) => theme.spacing.small}px;
  }
`;

export const Text = styled(TextBase).attrs({ variant: 'regular', as: 'div' })`
  line-height: 160%;
`;

export const Footer = styled.div`
  display: flex;
  justify-content: flex-end;

  > * + * {
    margin-left: ${({ theme }) => theme.spacing.medium}px;
  }
`;

export const Image = styled.img`
  position: absolute;
  top: 0px;
  right: 0px;
`;
