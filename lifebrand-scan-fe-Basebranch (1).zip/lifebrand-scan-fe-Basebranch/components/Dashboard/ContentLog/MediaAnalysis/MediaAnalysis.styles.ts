import styled from 'styled-components';

import { Tag, Text } from '@UI/meeseeks';

export const Wrapper = styled.div`
  margin-bottom: ${({ theme }) => theme.spacing.medium}px;
`;

export const TagWrapper = styled.div`
  &:before {
    content: '';
    display: block;
    float: left;
  }
`;

export const StyledText = styled(Text)`
  line-height: 28px;
  margin-top: 3px;
  border: 1px solid white; //TO REVIEW: without this line it doesn't change line
`;

export const Title = styled.div`
  margin-left: ${({ theme }) => theme.spacing.small}px;
  color: ${({ theme }) => theme.meeseeks.color['highlight.800']};
`;

export const ImageTag = styled(Tag)`
  margin: 0;
  margin-right: 10px;
  background-color: ${({ theme }) => theme.meeseeks.color['highlight.100']};
  float: left;
  clear: both;
`;

export const Divider = styled.span`
  display: block;
  height: 1px;
  width: 100%;
  background: ${({ theme }) => theme.meeseeks.color['neutrals.200']};
  margin-bottom: ${({ theme }) => theme.spacing.medium}px;
`;
