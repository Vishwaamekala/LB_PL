import React from 'react';

import * as S from './MediaAnalysis.styles';

type Props = {
  text: React.ReactNode;
  imgSrc: string;
  imgAlt: string;
  title: string;
  divider: boolean;
};

const MediaAnalysis = ({ text, imgSrc, imgAlt, title, divider }: Props) => {
  return (
    <>
      <S.Wrapper>
        <S.TagWrapper>
          <S.ImageTag variant="warning">
            <img src={imgSrc} alt={imgAlt} />
            <S.Title>{title}</S.Title>
          </S.ImageTag>
        </S.TagWrapper>
        <S.StyledText variant="regular" textColor="heading">
          {text}
        </S.StyledText>
      </S.Wrapper>
      {divider && <S.Divider />}
    </>
  );
};

export default MediaAnalysis;
