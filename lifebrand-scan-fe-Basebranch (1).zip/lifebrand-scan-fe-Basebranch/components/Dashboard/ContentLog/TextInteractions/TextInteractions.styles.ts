import styled from 'styled-components';

import { Tag } from '@UI/meeseeks';

import { transparentise } from '@Utils/style/transparentise';

export const TagItem = styled(Tag)<{
  activeTag?: boolean;
  isMultiLingual?: boolean;
}>`
  border: ${({ theme }) => theme.border.card};
  border-color: transparent;
  cursor: pointer;

  ${({ activeTag, isMultiLingual, theme }) =>
    activeTag &&
    `
      background-color: ${
        isMultiLingual ? theme.meeseeks.color['primary.100'] : theme.meeseeks.color['highlight.100']
      }; 
      border-color: ${
        isMultiLingual ? theme.meeseeks.color['primary.600'] : theme.meeseeks.color['chart.yellow']
      };
      color: ${theme.meeseeks.color['neutrals.800']};
    `}
`;

export const Text = styled.span<{
  highlightedText?: boolean;
  highlightedProfanity?: boolean;
  hasMultiLingualAnalysis?: boolean;
}>`
  position: relative;
  cursor: pointer;
  text-decoration: underline;
  text-decoration-color: ${({ theme, hasMultiLingualAnalysis }) =>
    hasMultiLingualAnalysis
      ? theme.meeseeks.color['primary.500']
      : theme.meeseeks.color['highlight.300']};
  text-underline-offset: 4px;
  text-decoration-thickness: 2px;

  ${({ highlightedText, theme }) =>
    highlightedText &&
    `background: ${theme.meeseeks.color['primary.200']};
  `}

  ${({ highlightedProfanity, hasMultiLingualAnalysis, theme }) =>
    highlightedProfanity &&
    `
    background: ${transparentise(
      theme.meeseeks.color[hasMultiLingualAnalysis ? 'primary.300' : 'highlight.300'],
      0.2,
    )};
    };
  `}
  
  &:hover {
    background-color: ${({ theme, hasMultiLingualAnalysis }) =>
      transparentise(
        theme.meeseeks.color[hasMultiLingualAnalysis ? 'primary.300' : 'highlight.300'],
        0.2,
      )};
  }
`;
