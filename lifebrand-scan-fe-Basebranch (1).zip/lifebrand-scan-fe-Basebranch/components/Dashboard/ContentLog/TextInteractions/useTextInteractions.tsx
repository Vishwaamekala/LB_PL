import React, { ReactNodeArray, useCallback, useMemo, useState } from 'react';
import reactStringReplace from 'react-string-replace';

import { useTheme } from 'styled-components';

import {
  getUniqueAnalysisLabels,
  replaceSearch,
  replaceSentence,
  wordReduce,
} from './TextInteractions.utils';

import { Tag } from '@UI/meeseeks';

import {
  ContentAnalysisDataFragment,
  ContentAnalysisType,
  ContentDataFragment,
} from '@Generated/graphql';
import { useContentsFilterContext } from '@Utils/ContentsFilterContext';
import { useAuthContext } from '@Utils/AuthContext';
import { FeatureFlag, useFeatureFlags } from '@Utils/hooks/useFeatureFlags';

import * as S from './TextInteractions.styles';

type Props = {
  content: ContentDataFragment;
};

export const useTextInteractions = ({ content }: Props) => {
  const { searchFilter, isBusinessDictionaryFilter } = useContentsFilterContext();
  const { userData } = useAuthContext();

  const theme = useTheme();

  const [isClamped, setIsClamped] = useState(false);
  const [activeTag, setActiveTag] = useState('');
  const [highlightList, setHighlightList] = useState<string[]>([]);

  const {
    isEnabled: ENABLED_FEAT_MULTILINGUAL_ANALYSIS,
    payload: PAYLOAD_FEAT_MULTILINGUAL_ANALYSIS,
  } = useFeatureFlags(FeatureFlag.FEAT_MULTILINGUAL_ANALYSIS);

  const {
    isEnabled: ENABLED_FEAT_VIDEOMODERATION_ANALYSIS,
    payload: PAYLOAD_FEAT_VIDEOMODERATION_ANALYSIS,
  } = useFeatureFlags(FeatureFlag.FEAT_VIDEO_MODERATION_ANALYSIS);

  let inactiveAnalysisTypes: ContentAnalysisType[] = [
    ContentAnalysisType.VideoModeration,
    ContentAnalysisType.MultiLingual,
  ];

  let isMultiLingualEnabled = false;
  if (ENABLED_FEAT_MULTILINGUAL_ANALYSIS) {
    if (PAYLOAD_FEAT_MULTILINGUAL_ANALYSIS.ContentAnalysisType) {
      isMultiLingualEnabled = true;
      inactiveAnalysisTypes = inactiveAnalysisTypes.filter(
        (analysis) => analysis !== PAYLOAD_FEAT_MULTILINGUAL_ANALYSIS.ContentAnalysisType,
      );
    }
  }

  let isVideoModerationEnabled = false;
  if (ENABLED_FEAT_VIDEOMODERATION_ANALYSIS) {
    if (PAYLOAD_FEAT_VIDEOMODERATION_ANALYSIS.ContentAnalysisType) {
      isVideoModerationEnabled = true;
      inactiveAnalysisTypes = inactiveAnalysisTypes.filter(
        (analysis) => analysis !== PAYLOAD_FEAT_VIDEOMODERATION_ANALYSIS.ContentAnalysisType,
      );
    }
  }

  const analysesByType = useMemo(() => {
    return content.ContentAnalysis.reduce((acc, cur) => {
      acc[cur.type] = cur;
      return acc;
    }, {} as Record<ContentAnalysisType, ContentAnalysisDataFragment>);
  }, [content.ContentAnalysis]);

  const multiLingualAnalysis = content.ContentAnalysis.find(
    (analysis) =>
      analysis.type === ContentAnalysisType.MultiLingual &&
      analysis.results?.length &&
      isMultiLingualEnabled,
  );

  const tagToggle = useCallback(
    (label: Record<string, string>) => {
      if (activeTag === label.key) {
        setIsClamped(false);
        setActiveTag('');
      } else {
        setIsClamped(true);
        setActiveTag(label.key);
      }
    },
    [activeTag],
  );

  const highlightListBuckets = useCallback((labelTitles: string[]) => {
    setHighlightList(labelTitles);
    setActiveTag('');
  }, []);

  const clearHighlight = useCallback(() => {
    setHighlightList([]);
  }, []);

  // Association between sentence/words and the toxicity buckets associated to each one
  // Example : shit : ['sexual_explicit','toxicity']
  const { sentences, words } = useMemo(() => {
    return content.ContentAnalysis.reduce<{
      sentences: Record<string, string[]>;
      words: Record<string, string[]>;
    }>(
      (state, currentAnalysis) => {
        currentAnalysis.results?.forEach((result: Record<string, string>) => {
          const originalState = state;
          if (!isBusinessDictionaryFilter) {
            if (
              currentAnalysis.type === ContentAnalysisType.Toxicity ||
              (currentAnalysis.type === ContentAnalysisType.MultiLingual && isMultiLingualEnabled)
            ) {
              if (originalState.sentences[result.subject]) {
                originalState.sentences[result.subject].push(result.label);
              } else {
                originalState.sentences[result.subject] = [result.label];
              }
            } else if (currentAnalysis.type === ContentAnalysisType.Profanity) {
              if (originalState.words[result.subject]) {
                originalState.words[result.subject].push(result.label);
              } else {
                originalState.words[result.subject] = [result.label];
              }
            }
          }
          if (
            currentAnalysis.type === ContentAnalysisType.BusinessDictionary ||
            currentAnalysis.type === ContentAnalysisType.ImageModeration ||
            (currentAnalysis.type === ContentAnalysisType.VideoModeration &&
              isVideoModerationEnabled) ||
            currentAnalysis.type === ContentAnalysisType.ImageOcr
          ) {
            if (result.subject.split(' ').length > 1) {
              if (originalState.sentences[result.subject]) {
                originalState.sentences[result.subject].push(result.label);
              } else {
                originalState.sentences[result.subject] = [result.label];
              }
            } else if (originalState.words[result.subject]) {
              originalState.words[result.subject].push(result.label);
            } else {
              originalState.words[result.subject] = [result.label];
            }
          }
        });
        return state;
      },
      {
        sentences: {},
        words: {},
      },
    );
  }, [
    content.ContentAnalysis,
    isBusinessDictionaryFilter,
    isMultiLingualEnabled,
    isVideoModerationEnabled,
  ]);

  // Isolates all the toxicity labels, or labels based on inviter (for custom dictionary)
  // found in the content.Analysis
  const uniqueAnalysisLabels = useMemo(
    () =>
      getUniqueAnalysisLabels(
        content.ContentAnalysis,
        userData,
        isBusinessDictionaryFilter,
        inactiveAnalysisTypes,
      ),
    [content.ContentAnalysis, userData, isBusinessDictionaryFilter, inactiveAnalysisTypes],
  );

  const interactiveTags = uniqueAnalysisLabels.length ? (
    uniqueAnalysisLabels.map((label) => {
      if (label) {
        return (
          <S.TagItem
            key={label.title}
            variant="primary"
            activeTag={activeTag === label.key || highlightList.includes(label.key)}
            isMultiLingual={!!multiLingualAnalysis}
            onClick={() => tagToggle(label)}
          >
            {label.title ?? label.key}
          </S.TagItem>
        );
      }
      return null;
    })
  ) : (
    <Tag variant="success">non-Flagged</Tag>
  );

  // Enables the click and hover highlights for media (ImageOCR, ImageModeration and VideoModeration) analysis results.
  const interactiveMediaAnalysis = useCallback(
    (mediaAnalysisInfo: ContentAnalysisDataFragment | undefined) => {
      if (!mediaAnalysisInfo || !mediaAnalysisInfo.results?.length) return null;

      if (inactiveAnalysisTypes.includes(mediaAnalysisInfo.type)) return null;

      const mediaAnalysisWords: string[] = [];

      // eslint-disable-next-line @typescript-eslint/no-unused-expressions
      mediaAnalysisInfo &&
        [mediaAnalysisInfo].forEach(({ results }) => {
          results?.forEach(({ subject }: any) => {
            if (!mediaAnalysisWords.includes(subject)) {
              mediaAnalysisWords.push(subject);
            }
          });
        });

      const mediaAnalysisText = reactStringReplace(
        mediaAnalysisWords.join(' | '),
        /(\|)/g,
        (match) => <span style={{ color: theme.meeseeks.color['neutrals.300'] }}>{match}</span>,
      );

      // To disable search, we will pass empty searchFilter
      const disableSearch = true;
      const filteredText = disableSearch ? '' : searchFilter;
      const replacedSentences = Object.entries(sentences).reduce<string | React.ReactNodeArray>(
        (state, [subject, labels]) => {
          return reactStringReplace(state, subject, (matchedSentence: string | ReactNodeArray) => {
            const sentence = wordReduce(
              matchedSentence,
              words,
              activeTag,
              filteredText,
              highlightListBuckets,
              clearHighlight,
            );
            return replaceSentence(
              labels,
              sentence,
              activeTag,
              highlightListBuckets,
              clearHighlight,
              false,
            );
          });
        },
        mediaAnalysisText,
      );

      const replacedWords = wordReduce(
        replacedSentences,
        words,
        activeTag,
        filteredText,
        highlightListBuckets,
        clearHighlight,
      );
      // For the moment, no search can be done - since they need to be stored in DB before
      // if (searchFilter) {
      //   replacedWords = replaceSearch(replacedWords);
      // }
      return replacedWords;
    },
    [
      activeTag,
      highlightListBuckets,
      clearHighlight,
      searchFilter,
      sentences,
      theme.meeseeks.color,
      words,
    ],
  );

  // Adds to Content Text interactions with user as search filter/highlight on bucket click or on hovering
  const interactiveContentText = useMemo(() => {
    const replacedSentences = Object.entries(sentences).reduce<string | React.ReactNodeArray>(
      (state, [subject, labels]) => {
        return reactStringReplace(state, subject, (matchedSentence: string | ReactNodeArray) => {
          const sentence = wordReduce(
            matchedSentence,
            words,
            activeTag,
            searchFilter,
            highlightListBuckets,
            clearHighlight,
          );
          return replaceSentence(
            labels,
            sentence,
            activeTag,
            highlightListBuckets,
            clearHighlight,
            !!multiLingualAnalysis,
          );
        });
      },
      content.text,
    );

    let replacedWords = wordReduce(
      replacedSentences,
      words,
      activeTag,
      searchFilter,
      highlightListBuckets,
      clearHighlight,
    );
    if (searchFilter) {
      replacedWords = replaceSearch(replacedWords, searchFilter);
    }
    return replacedWords;
  }, [
    activeTag,
    clearHighlight,
    content.text,
    highlightListBuckets,
    searchFilter,
    sentences,
    words,
    multiLingualAnalysis,
  ]);

  const interactiveAnalysis = useMemo(() => {
    return {
      imageOcr: interactiveMediaAnalysis(analysesByType.ImageOCR),
      imageModeration: interactiveMediaAnalysis(analysesByType.ImageModeration),
      videoModeration: interactiveMediaAnalysis(analysesByType.VideoModeration),
    };
  }, [interactiveMediaAnalysis, analysesByType]);

  return {
    actions: {
      setIsClamped,
    },
    interactiveContentText,
    interactiveImageOcrAnalysis: interactiveAnalysis.imageOcr,
    interactiveImageModerationAnalysis: interactiveAnalysis.imageModeration,
    interactiveVideoModerationAnalysis: interactiveAnalysis.videoModeration,
    interactiveTags,
    hasMultiLingualAnalysis: !!multiLingualAnalysis,
    isClamped,
  };
};
