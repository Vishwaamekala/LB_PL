import React, { ReactNodeArray } from 'react';

import reactStringReplace from 'react-string-replace';

import { ContentAnalysis, ContentAnalysisType, UserDataFragment } from '@Generated/graphql';
import { toxicityLabelsByKey } from '@Utils/toxicityLabels';

import * as S from './TextInteractions.styles';

const getContentLabelByKey = (
  key: string,
  user?: UserDataFragment | null,
  isBusinessDictionaryFilter?: boolean,
) => {
  // hide toxicity label when in Business Dictionary tab
  if (toxicityLabelsByKey[key] && !isBusinessDictionaryFilter) {
    return { key, ...toxicityLabelsByKey[key] };
  }

  const businessCustomer = user?.BusinessCustomer.find(
    (customer) => customer.Business.BusinessDictionary?.id === key,
  );

  // hide dictionary label on Flagged tab
  // thus display only if isBusinessDictionaryFilter === true || isBusinessDictionaryFilter === undefined
  const displayDictionaryLabel = isBusinessDictionaryFilter !== false;

  if (displayDictionaryLabel && businessCustomer) {
    return {
      key,
      title: businessCustomer.Business.name ?? businessCustomer.Business.contactEmail,
      description: '...',
    };
  }

  return null;
};

// Associates toxicity labels with toxicity buckets or business
export const getUniqueAnalysisLabels = (
  contentAnalyses: ContentAnalysis[],
  user?: UserDataFragment | null,
  isBusinessDictionaryFilter?: boolean,
  inactiveAnalysisTypes?: ContentAnalysisType[],
) => {
  let newAnalysis = [...contentAnalyses];

  if (inactiveAnalysisTypes) {
    inactiveAnalysisTypes.forEach((analysisType) => {
      newAnalysis = newAnalysis.filter((analysis) => analysis.type !== analysisType);
    });
  }

  const analysisLabels = newAnalysis.reduce((acc, cur) => {
    acc.push(...cur.labels);
    return acc;
  }, [] as string[]);
  const uniqueAnalysisLabels = Array.from(new Set(analysisLabels));

  return uniqueAnalysisLabels.map((key) =>
    getContentLabelByKey(key, user, isBusinessDictionaryFilter),
  );
};

// Highlights the text part on search
export const replaceSearch = (text: string | ReactNodeArray, searchFilter: string) => {
  return reactStringReplace(text, searchFilter, (matchedSearch) => (
    <S.Text highlightedText>{matchedSearch}</S.Text>
  ));
};

export const replaceSentence = (
  labels: string[],
  sentence: string | ReactNodeArray,
  activeTag: string,
  highlightListBuckets: (labels: string[]) => void,
  clearHighlight: () => void,
  hasMultiLingualAnalysis: boolean,
) => {
  return (
    <S.Text
      highlightedProfanity={labels.includes(activeTag)}
      onMouseEnter={() => highlightListBuckets(labels)}
      onMouseLeave={clearHighlight}
      hasMultiLingualAnalysis={hasMultiLingualAnalysis}
    >
      {sentence}
    </S.Text>
  );
};

export const replaceWords = (
  word: string | ReactNodeArray,
  searchedWord: string,
  labels: string[],
  activeTag: string,
  searchFilter: string | null,
  highlightListBuckets: (labels: string[]) => void,
  clearHighlight: () => void,
) => {
  return reactStringReplace(word, searchedWord, (matchedWord) => (
    <S.Text
      highlightedProfanity={labels.includes(activeTag)}
      onMouseEnter={() => highlightListBuckets(labels)}
      onMouseLeave={clearHighlight}
    >
      {searchFilter ? replaceSearch(matchedWord, searchFilter) : matchedWord}
    </S.Text>
  ));
};

export const wordReduce = (
  matchedSentence: string | ReactNodeArray,
  words: Record<string, string[]>,
  activeTag: string,
  searchFilter: string,
  highlightListBuckets: (labels: string[]) => void,
  clearHighlight: () => void,
) => {
  return Object.entries(words).reduce<string | ReactNodeArray>(
    (wordsState, [searchedWord, wordLabels]) => {
      return replaceWords(
        wordsState,
        searchedWord,
        wordLabels,
        activeTag,
        searchFilter,
        highlightListBuckets,
        clearHighlight,
      );
    },
    matchedSentence,
  );
};
