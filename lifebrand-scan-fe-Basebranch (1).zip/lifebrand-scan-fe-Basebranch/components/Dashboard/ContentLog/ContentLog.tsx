import React, { useCallback } from 'react';
import { format } from 'date-fns';

import TonalitySkeleton from './TonalitySkeleton';
import Interactions from './Interactions';
import ImageAnalysis from './MediaAnalysis';
import { useTextInteractions } from './TextInteractions/useTextInteractions';

import { Text } from '@UI/meeseeks';

import SocialMediaIcon from '@UI/SocialMediaIcon';
import ReadMore from '@UI/ReadMore';
import ImageGrid from '@UI/ImageGrid';
import ViewContentButton from 'components/ActionButtons/ViewContentButton';
import DeleteContentButton from 'components/ActionButtons/DeleteContentButton';

import { ContentDataFragment } from '@Generated/graphql';

import * as S from './ContentLog.styles';

export const UNDERLINE_HEIGHT = 2;

type Props = {
  content: ContentDataFragment;
  isAnalyzing?: boolean;
  disabled: boolean;
};

const ContentLog = ({ content, isAnalyzing, disabled }: Props) => {
  const {
    interactiveTags,
    interactiveContentText,
    interactiveImageOcrAnalysis,
    interactiveImageModerationAnalysis,
    interactiveVideoModerationAnalysis,
    isClamped,
    actions: { setIsClamped },
  } = useTextInteractions({
    content,
  });

  const moreToggle = useCallback(() => {
    return setIsClamped((prev) => !prev);
  }, []);

  return (
    <S.Log data-testid="content-log">
      <S.Header>
        {interactiveTags}
        {isAnalyzing && <TonalitySkeleton />}
      </S.Header>
      <S.Body>
        <S.Meta>
          <SocialMediaIcon socialMedia={content.origin} size={16} />
          <Text variant="small" textColor="neutrals.400">
            {format(new Date(content.postedAt), 'MMM dd, yyyy')}
          </Text>
        </S.Meta>
        {content.text && (
          <S.Text>
            <ReadMore
              text={interactiveContentText}
              id={`expanded-${content.id}`}
              contentLength={content.text.length}
              clampedNumberOfLines={3}
              undelineOffset={UNDERLINE_HEIGHT + 1}
              isClamped={isClamped}
              moreToggle={moreToggle}
            />
          </S.Text>
        )}
        <ImageGrid items={content.media} sourceUrl={content.url} />
        <Interactions interactions={content.interactions} origin={content.origin} />
      </S.Body>
      {interactiveImageOcrAnalysis && (
        <ImageAnalysis
          text={interactiveImageOcrAnalysis}
          imgSrc="/images/svg/flagged-image-icon.svg"
          imgAlt="flagged image text"
          title="Flagged Image Text"
          divider={!!interactiveImageModerationAnalysis}
        />
      )}
      {interactiveImageModerationAnalysis && (
        <ImageAnalysis
          text={interactiveImageModerationAnalysis}
          imgSrc="/images/svg/flagged-image-content-icon.svg"
          imgAlt="flagged image content"
          title="Flagged Image Content"
          divider={!!interactiveVideoModerationAnalysis}
        />
      )}
      {interactiveVideoModerationAnalysis && (
        <ImageAnalysis
          text={interactiveVideoModerationAnalysis}
          imgSrc="/images/svg/flagged-video-icon.svg"
          imgAlt="flagged video content"
          title="Flagged Video Content"
          divider
        />
      )}
      <S.Footer>
        <ViewContentButton url={content.url} disabled={disabled} />
        {!content.isDeleted && <DeleteContentButton content={content} disabled={disabled} />}
      </S.Footer>
    </S.Log>
  );
};

export default ContentLog;
