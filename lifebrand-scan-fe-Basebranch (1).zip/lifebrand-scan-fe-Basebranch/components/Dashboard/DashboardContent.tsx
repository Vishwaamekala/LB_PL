import React, { Fragment, useMemo } from 'react';
import { isAfter } from 'date-fns';

import ContentLog from './ContentLog';
import Loader from './Loader';
import NoPostsDashboardBanner from './Banners/NoPostsDashboardBanner';
import UpgradeBanner from './Banners/UpgradeBanner';
import NoBusinessDictionaryPostsBeforeScan from './Banners/NoBusinessDictionaryPostsBeforeScan';
import ReportRequestList from './ReportRequest/ReportRequestList';
import SkeletonGroup from './SkeletonGroup';

import { Text } from '@UI/meeseeks';

import NoFilteredResultsBanner from 'components/Dashboard/Banners/NoFilteredResultsBanner';

import { useContentsFilterContext } from '@Utils/ContentsFilterContext';
import { useSubscriptionContext } from '@Utils/SubscriptionContext/useSubscriptionContext';
import { useAuthContext } from '@Utils/AuthContext';
import { toxicityLabelsByKey } from '@Utils/toxicityLabels';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { ContentsInput, ContentsQuery } from '@Generated/graphql';

import * as S from './Dashboard.styles';

type Props = {
  contentsInput?: ContentsInput;
  contents: ContentsQuery | undefined;
  handleMore?: () => void;
  isLoading: boolean;
  hasScanRunning?: boolean;
  scanCreatedAt?: string;
  scanUpdatedAt?: string;
};

const DashboardContent = ({
  contentsInput,
  contents,
  handleMore,
  isLoading,
  hasScanRunning,
  scanCreatedAt,
  scanUpdatedAt,
}: Props) => {
  const { resetAllFilters, isBusinessDictionaryFilter } = useContentsFilterContext();
  const { features } = useSubscriptionContext();
  const { isMobile } = useBreakpoints();
  const { hasBusinessDictionary, userData } = useAuthContext();

  // to show banner if any updates on business customer have been done
  // e.g. business customer got deactivated and then reactivated - user should be prompted to scan again
  // e.g. business dictionary changed - user should be prompted to scan again

  const scannedAfterCustomerUpdates = useMemo(() => {
    if (scanUpdatedAt) {
      return userData?.BusinessCustomer.some(({ updatedAt, isActive, Business }) => {
        const scanUpdatedAtDate = new Date(scanUpdatedAt);
        const businessCustomerUpdatedAtDate = new Date(updatedAt);
        const dictionaryUpdatedAtDate = new Date(Business.BusinessDictionary?.updatedAt);

        const scannedAfterCustomerUpdate = isAfter(
          scanUpdatedAtDate,
          businessCustomerUpdatedAtDate,
        );
        const scannedAfterDictionaryUpdate = isAfter(scanUpdatedAtDate, dictionaryUpdatedAtDate);

        return (
          scannedAfterCustomerUpdate &&
          isActive &&
          Business.BusinessDictionary &&
          scannedAfterDictionaryUpdate
        );
      });
    }
    return false;
  }, [scanUpdatedAt, userData]);

  const isSomeFilterActive =
    !!contentsInput?.socialMedia?.length ||
    !!contentsInput?.labels?.length ||
    !!contentsInput?.search;

  const noPostFound = !contents?.contents.list.length;

  const noPostsBannerBeforeScan =
    hasBusinessDictionary && !scannedAfterCustomerUpdates && noPostFound;

  const appliedFilters = useMemo(() => {
    if (!contentsInput) return [];
    return [
      ...(contentsInput.socialMedia || []),
      ...(contentsInput.labels || []).map((label) => toxicityLabelsByKey[label].title),
    ];
  }, [contentsInput]);

  if (isLoading || !contents || (noPostFound && hasScanRunning)) {
    return <SkeletonGroup count={3} />;
  }

  if (noPostsBannerBeforeScan && isBusinessDictionaryFilter) {
    return <NoBusinessDictionaryPostsBeforeScan />;
  }

  if (noPostFound && contentsInput?.search) {
    return (
      <NoFilteredResultsBanner
        title={
          <>
            <Text variant="paragraph" marginBottom="xxs" fontWeight={600}>
              Sorry, we couldn’t find any results for this search.
            </Text>
            <Text variant="paragraph" marginBottom="medium" fontWeight={600}>
              Maybe give it another try?
            </Text>
          </>
        }
      />
    );
  }

  if (noPostFound && (contentsInput?.socialMedia?.length || contentsInput?.labels?.length)) {
    return <NoFilteredResultsBanner title="Sorry, we couldn’t find any results for this filter." />;
  }

  if (noPostFound) {
    return (
      <S.BannerWrap>
        <NoPostsDashboardBanner
          title={`${contentsInput?.isFlagged ? 'Nice!' : ''} No${
            contentsInput?.isFlagged ? ' Flagged' : ''
          } Posts here.`}
        />
      </S.BannerWrap>
    );
  }

  return (
    <>
      {isSomeFilterActive && (
        <S.FilterResults>
          <S.Text variant="regular">
            Showing posts
            {!!contentsInput?.search && (
              <>
                {' '}
                including
                <span className="filters"> {`"${contentsInput.search}"`}</span>
              </>
            )}
            {appliedFilters.length > 0 && (
              <>
                {' '}
                for
                <span className="filters"> {appliedFilters.join(', ')}</span>
              </>
            )}
          </S.Text>

          <S.ClearFilters>
            <Text variant="caption" fontWeight={600} onClick={resetAllFilters}>
              Clear All Filters
            </Text>
          </S.ClearFilters>
        </S.FilterResults>
      )}
      {/* TODO: add state when scan is running */}
      <S.ContentList isSomeFilterActive={isSomeFilterActive}>
        {isMobile && <ReportRequestList />}
        {contents?.contents.list.map((content, index) => (
          <Fragment key={content.id}>
            <ContentLog
              content={content}
              isAnalyzing={hasScanRunning && !!scanCreatedAt && content.createdAt >= scanCreatedAt}
              disabled={!features?.canUseAdvancedDashboard}
            />
            {index === contents.contents.list.length - 1 && handleMore && (
              <Loader onLoad={handleMore} />
            )}
          </Fragment>
        ))}
        {!features?.canUseAdvancedDashboard && <UpgradeBanner />}
      </S.ContentList>
    </>
  );
};

export default DashboardContent;
