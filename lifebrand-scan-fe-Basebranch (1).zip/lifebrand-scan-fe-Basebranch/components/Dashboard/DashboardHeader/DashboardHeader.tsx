import React from 'react';

import { useTour } from '@reactour/tour';

import RunningScanAnimation from './RunningScanAnimation';

import { Heading } from '@UI/meeseeks';

import HeaderCard from '@UI/HeaderCard';
import { OnboardingStepKeys } from 'components/Onboarding/Onboarding.config';

import { useContentsFilterContext } from '@Utils/ContentsFilterContext';
import { useSubscriptionContext } from '@Utils/SubscriptionContext/useSubscriptionContext';
import { useAuthContext } from '@Utils/AuthContext';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { DashboardContentBreakdownsQuery } from '@Generated/graphql';

import * as S from './DashboardHeader.styles';

type Props = {
  breakdownsData?: DashboardContentBreakdownsQuery['dashboardContentBreakdowns'];
  loading?: boolean;
  hasScanRunning?: boolean;
  isScrolling: boolean;
};

const DashboardHeader = ({ breakdownsData, loading, hasScanRunning, isScrolling }: Props) => {
  const { features } = useSubscriptionContext();
  const { isMobile } = useBreakpoints();
  const {
    setIsFlaggedFilter,
    setIsBusinessDictionaryFilter,
    isFlaggedFilter,
    isBusinessDictionaryFilter,
    resetAllFilters,
  } = useContentsFilterContext();
  const { isOpen: isOnboardingOn } = useTour();
  const { hasBusinessDictionary } = useAuthContext();

  return (
    <S.Wrapper
      isOnboardingOn={isOnboardingOn as boolean}
      showDivider={isScrolling}
      isMobile={isMobile}
    >
      {hasScanRunning && (
        <>
          <Heading variant="h3">🔎 Scanning in Progress</Heading>
          <S.AnimationWrapper>
            <RunningScanAnimation />
          </S.AnimationWrapper>
        </>
      )}
      <S.Breakdowns id={OnboardingStepKeys.DashboardHeader}>
        <HeaderCard
          title={isMobile ? 'Flagged' : 'Flagged Posts'}
          onClick={() => {
            setIsFlaggedFilter(true);
            setIsBusinessDictionaryFilter(false);
            resetAllFilters();
          }}
          isSelected={isFlaggedFilter && !isBusinessDictionaryFilter}
          count={breakdownsData?.flaggedCount}
          loading={loading}
        />

        <HeaderCard
          title={isMobile ? 'All' : 'All Posts'}
          onClick={() => {
            if (features?.canUseAdvancedDashboard) {
              setIsFlaggedFilter(undefined);
              setIsBusinessDictionaryFilter(undefined);
              resetAllFilters();
            }
          }}
          isSelected={
            features?.canUseAdvancedDashboard && !isFlaggedFilter && !isBusinessDictionaryFilter
          }
          count={breakdownsData?.allContentsCount}
          loading={loading}
          disabled={!features?.canUseAdvancedDashboard}
        />
        {hasBusinessDictionary && (
          <HeaderCard
            title={isMobile ? 'Dictionary' : 'Custom Dictionary'}
            onClick={() => {
              if (features?.canUseAdvancedDashboard) {
                setIsBusinessDictionaryFilter(true);
                setIsFlaggedFilter(true);
                resetAllFilters();
              }
            }}
            isSelected={
              features?.canUseAdvancedDashboard && isBusinessDictionaryFilter && isFlaggedFilter
            }
            count={breakdownsData?.businessDictionaryCount}
            loading={loading}
            disabled={!features?.canUseAdvancedDashboard}
          />
        )}
      </S.Breakdowns>
    </S.Wrapper>
  );
};

export default DashboardHeader;
