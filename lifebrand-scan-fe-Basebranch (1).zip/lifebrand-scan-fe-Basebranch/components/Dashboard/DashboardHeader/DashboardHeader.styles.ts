import styled from 'styled-components';

import { inlineGap } from '@Utils/style/gap';

export const Breakdowns = styled.div`
  display: flex;
  justify-content: space-between;
  ${({ theme }) => inlineGap(`${theme.spacing.medium}px`)}
`;

export const Wrapper = styled.div<{
  isOnboardingOn: boolean;
  showDivider: boolean;
  isMobile: boolean;
}>`
  // to prevent from collapsing into the onboarding focus area
  position: ${({ isOnboardingOn, isMobile }) => (isOnboardingOn || isMobile ? 'static' : 'sticky')};
  top: 0;
  background: ${({ theme }) => theme.meeseeks.color.white};
  z-index: 4;
  padding-bottom: ${({ theme, showDivider }) =>
    showDivider ? theme.spacing.medium : theme.spacing.large}px;
  ${({ showDivider, isMobile, theme }) =>
    showDivider && !isMobile && `border-bottom: 1px solid ${theme.meeseeks.color['neutrals.200']}`};
  box-shadow: ${({ theme }) =>
    `12px 0 8px -4px ${theme.meeseeks.color.white}, -12px 0 8px -4px ${theme.meeseeks.color.white}`};
`;

export const AnimationWrapper = styled.div`
  margin: ${({ theme }) => theme.spacing.large}px 0;
  box-shadow: 0px 2px 12px rgba(71, 71, 71, 0.08);
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  background: ${({ theme }) => theme.meeseeks.color.white};

  svg {
    display: block;
  }
`;
