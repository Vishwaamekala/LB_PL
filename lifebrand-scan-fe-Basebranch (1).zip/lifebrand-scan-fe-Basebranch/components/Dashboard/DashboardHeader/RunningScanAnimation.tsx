import React, { useEffect, useRef } from 'react';
import Lottie, { AnimationItem } from 'lottie-web';

import { useOnScreen } from '@Utils/hooks/onScreen';

import animationData from 'public/animations/running-scan.json';

const RunningScanAnimation = () => {
  const container = useRef<HTMLDivElement | null>(null);
  const lottie = useRef<AnimationItem | null>();
  const onScreen = useOnScreen(container);

  useEffect(() => {
    if (container.current) {
      // while is loading and page changes throws an error
      try {
        lottie.current = Lottie.loadAnimation({
          container: container.current,
          renderer: 'svg',
          loop: true,
          autoplay: false,
          animationData,
        });
      } catch {
        // empty-catch
      }
    }
  }, [container]);

  useEffect(() => {
    if (lottie.current) {
      // on development on page change before loaded throwing error
      try {
        if (onScreen && lottie.current.isLoaded) {
          lottie.current.play();
        } else {
          lottie.current.goToAndStop(0);
        }
      } catch {
        // empty-catch
      }
    }
  }, [onScreen, lottie]);

  return <div ref={container} />;
};

export default RunningScanAnimation;
