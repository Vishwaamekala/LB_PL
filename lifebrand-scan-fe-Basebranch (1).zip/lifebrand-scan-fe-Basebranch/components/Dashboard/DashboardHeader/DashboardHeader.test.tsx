import React from 'react';
import { render } from '@testing-library/react';

import { theme } from 'theme/theme';
import { ThemeProvider } from 'styled-components';
import { MockedProvider } from '@apollo/client/testing';

import DashboardHeader from './DashboardHeader';

import { AuthContext, ContextProps } from '@Utils/AuthContext';

jest.mock('next/router', () => ({
  useRouter() {
    return {
      route: '/dashboard',
      pathname: '',
      query: '',
      asPath: '',
    };
  },
}));

const intersectionObserverMock = () => ({
  observe: () => null,
});

window.IntersectionObserver = jest.fn().mockImplementation(intersectionObserverMock);

const authMock = {
  hasBusinessDictionary: false,
  loading: false,
  userData: undefined,
  isLoggedIn: undefined,
  socialMediaConnectionsQuery: undefined,
  isInvited: false,
  invitedBy: [],
  referredByNJREALTOR: false,
  usingDiscountNJREALTOR: false,
  triggerRefetch: (() => {
    return {};
  }) as ContextProps['triggerRefetch'],
  isInstagramTokenExpired: false,
  setIsInstagramTokenExpired: () => {},
  isFacebookTokenExpired: false,
  setIsFacebookTokenExpired: () => {},
};

describe('DashboardHeader ', () => {
  beforeAll(() => {
    window.resizeTo = function resizeTo(width, height) {
      Object.assign(this, {
        innerWidth: width,
        innerHeight: height,
        outerWidth: width,
        outerHeight: height,
        configurable: true,
      }).dispatchEvent(new this.Event('resize'));
    };
  });

  it('renders cards', async () => {
    const { getAllByText } = render(
      <ThemeProvider theme={theme}>
        <AuthContext.Provider value={authMock}>
          <MockedProvider addTypename>
            <DashboardHeader isScrolling={false} />
          </MockedProvider>
        </AuthContext.Provider>
      </ThemeProvider>,
    );
    expect(getAllByText(/Flagged/gi)[0]).toBeInTheDocument();
    expect(getAllByText(/All/gi)[0]).toBeInTheDocument();
  });

  it('renders scanning in progress', async () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <AuthContext.Provider value={authMock}>
          <MockedProvider addTypename>
            <DashboardHeader hasScanRunning isScrolling={false} />
          </MockedProvider>
        </AuthContext.Provider>
      </ThemeProvider>,
    );

    expect(getByText('🔎 Scanning in Progress')).toBeInTheDocument();
  });

  it('renders custom dictionary tab', async () => {
    window.resizeTo(1400, 1000);
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <AuthContext.Provider value={{ ...authMock, hasBusinessDictionary: true }}>
          <MockedProvider addTypename>
            <DashboardHeader isScrolling={false} />
          </MockedProvider>
        </AuthContext.Provider>
      </ThemeProvider>,
    );

    expect(getByText('Custom Dictionary')).toBeInTheDocument();
  });
});
