export { default } from './NoBusinessDictionaryPostsBeforeScan';
export * from './NoBusinessDictionaryPostsBeforeScan';
