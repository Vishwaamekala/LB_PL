import styled from 'styled-components';

import BannerBase from '@UI/Banner';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Banner = styled(BannerBase)`
  margin-top: ${({ theme }) => theme.spacing.large}px;
  height: 480px;

  & > .banner-content {
    ${useBreakpoint.mobile`
      margin: 3rem ${({ theme }) => theme.spacing.small}px;
    `}
  }
  z-index: 0;
`;
