import React from 'react';

import { useTheme } from 'styled-components';

import { Heading, Icon } from '@UI/meeseeks';

import ScanButton from 'components/ScanButton';

import { TriggerClass } from '@Utils/google-tag-manager';

import * as S from './NoBusinessDictionaryPostsBeforeScan.styles';

const NoBusinessDictionaryPostsBeforeScan = () => {
  const { meeseeks } = useTheme();

  return (
    <S.Banner
      backgroundColor={meeseeks.color['neutrals.100']}
      backgroundImage="/images/png/custom-dictionary-clouds.png"
    >
      <Heading variant="h4" textColor="heading" marginBottom="xs">
        No posts here yet.
      </Heading>
      <Heading variant="h5" textColor="body" marginBottom="medium">
        You need to scan again to see the results.
      </Heading>
      <ScanButton
        title="Scan Again"
        variant="primary"
        size="medium"
        iconLeft={<Icon name="RefreshCcw" color="white" />}
        triggerClassName={TriggerClass.RunScanNoBusinessDictionary}
      />
    </S.Banner>
  );
};

export default NoBusinessDictionaryPostsBeforeScan;
