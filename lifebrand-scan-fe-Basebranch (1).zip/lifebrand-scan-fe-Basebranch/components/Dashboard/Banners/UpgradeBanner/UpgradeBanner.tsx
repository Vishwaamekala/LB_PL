import React from 'react';

import { Icon, Heading, Text } from '@UI/meeseeks';

import UpgradeButton from '@Layout/Header/UpgradeButton';

import * as S from './UpgradeBanner.styles';

const UpgradeBanner = () => {
  return (
    <S.Card>
      <S.Content>
        <Heading variant="h3" textColor="white" marginBottom="medium">
          Want to see all flagged posts?
        </Heading>
        <Text variant="body" textColor="neutrals.100" marginBottom="medium">
          To view and delete all of your potentially harmful posts, send reports and more
          <br /> please upgrade!
        </Text>

        <UpgradeButton variant="secondary" customIcon={<Icon name="Bolt" color="#fff" />} />
      </S.Content>
      <S.Image src="/images/png/upgrade-image.png" alt="upgrade" />
    </S.Card>
  );
};

export default UpgradeBanner;
