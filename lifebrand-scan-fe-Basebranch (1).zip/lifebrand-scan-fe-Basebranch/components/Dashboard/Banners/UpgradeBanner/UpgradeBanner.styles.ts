import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Card = styled.div`
  background-color: ${({ theme }) => theme.color.primary};
  padding: ${({ theme }) =>
    `${theme.spacing.medium * 2}px ${theme.spacing.medium + theme.spacing.large}px`};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  position: relative;
  overflow: hidden;
  z-index: 1;
`;

export const Content = styled.div`
  max-width: 380px;
  ${useBreakpoint.smDesktop`
    max-width: 350px;
  `}

  ${useBreakpoint.mobile`
    height: 400px;
  `}
`;

export const Image = styled.img`
  width: 396px;
  position: absolute;
  right: -60px;
  bottom: -40px;
  z-index: -1;
  ${useBreakpoint.smDesktop`
    right: -60px;
  `}
`;
