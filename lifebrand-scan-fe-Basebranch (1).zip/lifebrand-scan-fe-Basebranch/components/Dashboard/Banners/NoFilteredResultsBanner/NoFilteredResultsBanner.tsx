import React from 'react';

import { Button, Text } from '@UI/meeseeks';
import { ImagePosition } from '@UI/Banner';

import { useContentsFilterContext } from '@Utils/ContentsFilterContext';

import * as S from './NoFilteredResultsBanner.styles';

type Props = {
  title?: string | React.ReactNode;
};

const NoFilteredResultsBanner = ({ title }: Props) => {
  const { resetAllFilters } = useContentsFilterContext();

  return (
    <S.Banner
      backgroundImage={'/images/png/banner-b2c-no-found-results-hd.png'}
      backgroundImagePosition={ImagePosition.Left}
      className="ImagePhoneContain"
    >
      {typeof title === 'string' ? (
        <Text variant="paragraph" marginBottom="medium" textColor="heading" fontWeight={600}>
          {title}
        </Text>
      ) : (
        title
      )}
      <Button variant="tertiary" size="medium" onClick={resetAllFilters}>
        Clear All Filters
      </Button>
    </S.Banner>
  );
};

export default NoFilteredResultsBanner;
