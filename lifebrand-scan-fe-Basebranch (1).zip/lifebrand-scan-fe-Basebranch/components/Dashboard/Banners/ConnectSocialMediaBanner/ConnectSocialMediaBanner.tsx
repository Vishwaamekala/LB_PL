import React from 'react';
import Skeleton from 'react-loading-skeleton';

import { Heading, Text } from '@UI/meeseeks';
import ProviderButton from 'components/Authentication/ProviderButton';
import SocialMediaIcon from '@UI/SocialMediaIcon';
import ScanButton from 'components/ScanButton';

import { useAuthContext } from '@Utils/AuthContext';
import { TriggerClass } from '@Utils/google-tag-manager';

import { useConnections, SocialMediatoProviderKeys } from '@Utils/hooks/useConnections';
import { parseToFirstName } from '@Utils/formatters/name';

import * as S from './ConnectSocialMediaBanner.styles';

const ConnectSocialMediaBanner = () => {
  const { userData, loading } = useAuthContext();
  const { socialMediaConnection, actions, isActionsDisabled, state } = useConnections();

  return (
    <S.Banner>
      <Heading variant="h2" marginBottom="medium">
        Welcome {loading ? <Skeleton width={90} /> : parseToFirstName(userData?.name)}.
      </Heading>
      <div>
        <Text variant="paragraph" marginBottom="xxs" fontWeight={400}>
          Please connect at least one social media account,
        </Text>
        <Text variant="paragraph" marginBottom="large" fontWeight={400}>
          to be able start scanning for flagged posts.
        </Text>
      </div>
      <S.ButtonGroup>
        {socialMediaConnection.map((connection) => (
          <ProviderButton
            className={TriggerClass.ConnectSM}
            loading={state.connectingState[SocialMediatoProviderKeys[connection.socialMedia]]}
            disabled={connection.isConnected || isActionsDisabled}
            connected={connection.isConnected}
            provider={connection.socialMedia}
            onClick={() => actions.connectWith(connection.socialMedia)}
            iconLeft={<SocialMediaIcon socialMedia={connection.socialMedia} />}
            key={connection.socialMedia}
            fluid
          >
            {connection.isConnected
              ? `${connection.userName}`
              : `Connect ${connection.socialMedia}`}
          </ProviderButton>
        ))}
      </S.ButtonGroup>
      <S.Footer>
        <ScanButton
          variant="secondary"
          size="large"
          fluid
          title="Start My First Scan"
          triggerClassName={TriggerClass.RunScanConnectedSocialMedia}
        />
      </S.Footer>
    </S.Banner>
  );
};

export default ConnectSocialMediaBanner;
