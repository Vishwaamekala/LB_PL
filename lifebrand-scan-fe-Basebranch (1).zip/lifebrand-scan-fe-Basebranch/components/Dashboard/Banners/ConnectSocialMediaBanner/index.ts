export { default } from './ConnectSocialMediaBanner';
export * from './ConnectSocialMediaBanner';
