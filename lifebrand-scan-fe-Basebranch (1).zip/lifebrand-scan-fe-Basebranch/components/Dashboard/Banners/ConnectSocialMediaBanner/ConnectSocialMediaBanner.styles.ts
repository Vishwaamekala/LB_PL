import styled from 'styled-components';

import { navBarDesktopWidth, navBarTabletWidth } from '@Layout/NavBar/NavBar.styles';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Banner = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-left: calc(50% - ${navBarDesktopWidth / 2}px);
  transform: translate(-50%, 0);
  max-width: 480px;
  width: 100%;
  padding: ${({ theme }) => theme.spacing.large * 3}px 0px;
  text-align: center;

  ${useBreakpoint.mdDesktop`
    margin-left: calc(50% - ${navBarTabletWidth / 2}px);
  `}

  ${useBreakpoint.mobile`
    margin-left: 50%;
  `}
`;

export const ButtonGroup = styled.div`
  width: 100%;
  max-width: 364px;

  > button {
    margin-bottom: ${({ theme }) => theme.spacing.medium}px;
  }
`;

export const Footer = styled.div`
  margin-top: ${({ theme }) => theme.spacing.small}px;
  width: 100%;
  max-width: 364px;
`;
