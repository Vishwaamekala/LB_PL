import React from 'react';

import { Heading } from '@UI/meeseeks';
import Banner from '@UI/Banner';

import AnalyticsOverviewButton from 'components/ActionButtons/AnalyticsOverviewButton';

type Props = {
  title: string;
};

const NoPostsDashboardBanner = ({ title }: Props) => {
  return (
    <Banner backgroundImage="/images/png/banner-b2c-no-filtered-results-hd.png">
      <Heading variant="h4" textColor="heading" marginBottom="xs">
        {title}
      </Heading>
      <Heading variant="h5" textColor="body" marginBottom="medium">
        You can check your Analytics Overview and Create Report from there.
      </Heading>
      <AnalyticsOverviewButton />
    </Banner>
  );
};

export default NoPostsDashboardBanner;
