import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import { theme } from 'theme/theme';
import { ThemeProvider } from 'styled-components';
import { MockedProvider } from '@apollo/client/testing';
import { GraphQLError } from 'graphql';

import ReportRequestList from './ReportRequestList';

import {
  PendingReportRequestsDocument,
  IndividualReportsDocument,
  ReportType,
  RejectReportRequestDocument,
} from '@Generated/graphql';

jest.mock('next/router', () => ({
  useRouter: jest.fn().mockReturnValue({
    route: '/dashboard',
    pathname: '',
    query: '',
    asPath: '',
    push: jest.fn(),
  }),
}));

const mocksList = [
  {
    request: {
      query: PendingReportRequestsDocument,
      variables: {},
    },
    result: {
      data: {
        reportRequests: [
          {
            id: '123',
            status: '',
            origin: 'Facebook',
            userId: '',
            createdAt: '',
            updatedAt: '',
            __typename: 'ReportRequest',
            Business: {
              id: '1233',
              name: 'name',
              contactEmail: null,
              __typename: 'Business',
            },
          },
          {
            id: '321',
            status: '',
            origin: 'Facebook',
            userId: '',
            createdAt: '',
            updatedAt: '',
            __typename: 'ReportRequest',
            Business: {
              id: '3211',
              name: null,
              contactEmail: 'email',
              __typename: 'Business',
            },
          },
        ],
      },
    },
  },
];

const date = new Date();
date.setDate(date.getDate() - 7);

const mocksButton = [
  {
    request: {
      query: IndividualReportsDocument,
      variables: {},
    },
    result: {
      data: {
        individualReports: [
          {
            __typename: 'Report',
            id: '123',
            userId: '',
            type: ReportType.Employer,
            name: 'test',
            isFCRACompliant: true,
            createdAt: date,
            startDate: '',
            endDate: '',
            isShared: false,
            pdfUrl: '',
            flaggedContentsCount: 2,
            nonFlaggedContentsCount: 0,
            deletedFlaggedContentsCount: 1,
            allByTimelineBreakdown: 2,
            flaggedByTimelineBreakdown: 2,
            originsLastScannedBreakdown: {
              __typename: 'ScanDateOriginsBreakdown',
              Facebook: 2,
              Twitter: 0,
              Instagram: 0,
            },
            flaggedByOriginsBreakdown: {
              __typename: 'OriginsBreakdown',
              Facebook: 2,
              Twitter: 0,
              Instagram: 0,
            },
            flaggedByLabelsBreakdown: {
              __typename: 'FlaggedPostLabelsBreakdownResponse',
              identity_attack: 0,
              insult: 0,
              obscene: 0,
              threat: 1,
              sexual_explicit: 1,
              sexual: 0,
              severe_toxicity: 0,
              toxicity: 0,
              inappropriate: 0,
              blasphemy: 0,
              discriminatory: 0,
            },
            allByOriginsBreakdown: {
              __typename: 'OriginsBreakdown',
              Facebook: 2,
              Twitter: 0,
              Instagram: 0,
            },
          },
        ],
      },
    },
  },
  {
    request: {
      query: PendingReportRequestsDocument,
      variables: {},
    },
    result: {
      data: {
        reportRequests: [
          {
            id: '123',
            status: '',
            origin: 'Facebook',
            userId: '',
            createdAt: '',
            updatedAt: '',
            __typename: 'ReportRequest',
            Business: {
              id: '1233',
              name: 'name',
              contactEmail: null,
              __typename: 'Business',
            },
          },
        ],
      },
    },
    newData: jest.fn(() => ({
      data: {
        reportRequests: [
          {
            id: '123',
            status: '',
            origin: 'Facebook',
            userId: '',
            createdAt: '',
            updatedAt: '',
            __typename: 'ReportRequest',
            Business: {
              id: '1233',
              name: 'name',
              contactEmail: null,
              __typename: 'Business',
            },
          },
        ],
      },
    })),
  },
  {
    request: {
      query: RejectReportRequestDocument,
      variables: { reportRequestId: '123' },
    },
    result: {
      data: {
        rejectReportRequest: {
          id: '123',
          status: '',
          origin: 'Facebook',
          userId: '',
          createdAt: '',
          updatedAt: '',
          __typename: 'ReportRequest',
          Business: {
            id: '1233',
            name: 'name',
            contactEmail: null,
            __typename: 'Business',
          },
        },
      },
    },
  },
];

describe('Report request list', () => {
  it('renders report list', async () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider mocks={mocksList} addTypename={false}>
          <ReportRequestList />
        </MockedProvider>
      </ThemeProvider>,
    );

    await waitFor(() => {
      expect(getByText('Report was requested by name')).toBeInTheDocument();
      expect(getByText('Report was requested by email')).toBeInTheDocument();
    });
  });

  it('not renders report list cards if no data', async () => {
    const { queryByText } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider
          mocks={[
            {
              request: {
                query: PendingReportRequestsDocument,
                variables: {},
              },
              result: {
                data: {
                  reportRequests: [],
                },
              },
            },
          ]}
          addTypename={false}
        >
          <ReportRequestList />
        </MockedProvider>
      </ThemeProvider>,
    );

    await waitFor(() => {
      expect(
        queryByText(
          'When you are done with cleaning up you Flagged posts, go to Analytics Overview. You can Create and Share Report from there.',
        ),
      ).toBeNull();
    });
  });

  it('renders business name or email', async () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider mocks={mocksList} addTypename={false}>
          <ReportRequestList />
        </MockedProvider>
      </ThemeProvider>,
    );

    await waitFor(() => {
      expect(getByText('Report was requested by name')).toBeInTheDocument();
      expect(getByText('Report was requested by email')).toBeInTheDocument();
    });
  });

  it('renders modal after click on button, redirect to the view report page', async () => {
    const { getByTestId, getByText, getByRole } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider mocks={mocksButton} addTypename={false}>
          <ReportRequestList />
        </MockedProvider>
      </ThemeProvider>,
    );

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 10)));

    const SelectButton = getByTestId('select-report-button');
    expect(SelectButton).toBeInTheDocument();

    fireEvent.click(SelectButton);

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 10)));

    expect(getByText('Select a Report to Submit')).toBeInTheDocument();
    expect(
      getByText('You have 0 Reports generated within last week, select one to submit to name.'),
    ).toBeInTheDocument();

    await waitFor(() => {
      expect(getByRole('button', { name: 'View Report' })).toBeDisabled();
    });
  });

  it('renders modal with text - no reports were created in the last week', async () => {
    const [individualReportsMock, ...otherMocks] = mocksButton;
    const { getByTestId, getByRole } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider
          mocks={[
            {
              request: individualReportsMock.request,
              result: {
                data: {
                  individualReports: [],
                },
              },
            },
            ...otherMocks,
          ]}
          addTypename={false}
        >
          <ReportRequestList />
        </MockedProvider>
      </ThemeProvider>,
    );

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 10)));

    const SelectButton = getByTestId('select-report-button');
    expect(SelectButton).toBeInTheDocument();

    fireEvent.click(SelectButton);

    await waitFor(() => {
      expect(getByRole('button', { name: 'View Report' })).toBeDisabled();
    });
  });

  it('renders reject report modal after click on button, success decline message', async () => {
    const { getByTestId, getByText, getByRole } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider mocks={mocksButton} addTypename={false}>
          <ReportRequestList />
        </MockedProvider>
      </ThemeProvider>,
    );

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    const RejectButton = getByTestId('reject-report-button');
    expect(RejectButton).toBeInTheDocument();

    fireEvent.click(RejectButton);

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    expect(
      getByText('Are you sure you want to decline the report request from name ?'),
    ).toBeInTheDocument();

    const SubmitButton = getByRole('button', { name: 'Submit' });
    expect(SubmitButton).toBeInTheDocument();

    fireEvent.click(SubmitButton);

    await waitFor(() => {
      expect(getByText('Your report request was successfully declined.')).toBeInTheDocument();
    });
  });

  it('renders reject report modal after click on button, error decline message', async () => {
    const [rejectReportRequestMock, ...otherMocks] = mocksButton.reverse();
    const { getByTestId, getByText, getByRole } = render(
      <ThemeProvider theme={theme}>
        <MockedProvider
          mocks={[
            {
              request: rejectReportRequestMock.request,
              result: {
                errors: [new GraphQLError('Some backend error!')],
              },
            },
            ...otherMocks,
          ]}
          addTypename={false}
        >
          <ReportRequestList />
        </MockedProvider>
      </ThemeProvider>,
    );

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    const RejectButton = getByTestId('reject-report-button');
    expect(RejectButton).toBeInTheDocument();

    fireEvent.click(RejectButton);

    await waitFor(() => new Promise((resolve) => setTimeout(resolve, 0)));

    const SubmitButton = getByRole('button', { name: 'Submit' });
    expect(SubmitButton).toBeInTheDocument();

    fireEvent.click(SubmitButton);

    await waitFor(() => {
      expect(getByText('Failed to decline report request. Please try again.')).toBeInTheDocument();
    });
  });
});
