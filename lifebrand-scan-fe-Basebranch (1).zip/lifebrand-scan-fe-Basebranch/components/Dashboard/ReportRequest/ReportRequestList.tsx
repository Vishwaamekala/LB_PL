import React from 'react';

import ReportRequestCard from './ReportRequestCard';

import { usePendingReportRequestsQuery } from '@Generated/graphql';

const ReportRequestList = () => {
  const { data, loading } = usePendingReportRequestsQuery();

  if (!data || loading) {
    return null;
  }

  return (
    <>
      {data.reportRequests.map((reportRequest) => (
        <ReportRequestCard key={reportRequest.id} reportRequest={reportRequest} />
      ))}
    </>
  );
};

export default ReportRequestList;
