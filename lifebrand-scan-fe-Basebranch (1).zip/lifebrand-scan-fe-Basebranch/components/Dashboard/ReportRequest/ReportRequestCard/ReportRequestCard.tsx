import React from 'react';

import { Heading, Text } from '@UI/meeseeks';

import RejectReportRequestButton from 'components/ActionButtons/RejectReportRequestButton';
import SelectReportButton from 'components/ActionButtons/SelectReportButton/SelectReportButton';

import * as S from '../../ToolbarPanel/ToolbarPanel.styles';

import { ReportRequestDataFragment } from '@Generated/graphql';

type Props = {
  reportRequest: ReportRequestDataFragment;
};

const ReportRequestCard = ({ reportRequest }: Props) => {
  return (
    <S.Card withBoxShadow data-testid={`report-card-${reportRequest.id}`}>
      <Heading variant="h5" marginBottom="xxs" textColor="heading">
        Report was requested by {reportRequest.Business.name || reportRequest.Business.contactEmail}
      </Heading>
      <Text variant="small" textColor="body" marginBottom="medium">
        When you are done with cleaning up you Flagged posts, go to Analytics Overview. You can
        Create and Share Report from there.
      </Text>
      <S.ActionWrapper>
        <SelectReportButton reportRequest={reportRequest} />
        <RejectReportRequestButton reportRequest={reportRequest} fluid />
      </S.ActionWrapper>
    </S.Card>
  );
};

export default ReportRequestCard;
