import React from 'react';

import { Button } from '@UI/meeseeks';

import { ConnectionButtonProps } from '../types';

import { TriggerClass } from '@Utils/google-tag-manager';

const ConnectButton = ({
  disabled,
  loading,
  onClick,
  title = 'Connect',
  ...rest
}: ConnectionButtonProps) => (
  <Button
    className={TriggerClass.ConnectSM}
    variant="primary"
    size="small"
    disabled={disabled || loading}
    loading={loading}
    onClick={onClick}
    {...rest}
  >
    {title}
  </Button>
);

export default ConnectButton;
