import { ButtonProps } from '@UI/meeseeks';

import { SocialMedia } from '@Generated/graphql';

export type ConnectionButtonProps = {
  provider?: SocialMedia;
  isMainIdentity?: boolean;
} & Partial<ButtonProps>;
