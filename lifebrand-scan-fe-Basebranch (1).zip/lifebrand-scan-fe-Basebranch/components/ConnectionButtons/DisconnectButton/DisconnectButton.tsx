import React from 'react';

import { Button } from '@UI/meeseeks';

import Info from 'components/Info';
import { ConnectionButtonProps } from '../types';

import { TriggerClass } from '@Utils/google-tag-manager';

const DisconnectButton = ({
  isMainIdentity,
  disabled,
  loading,
  onClick,
  ...rest
}: ConnectionButtonProps) => {
  return isMainIdentity ? (
    <Info
      title="Main Account"
      description="You cannot disconnect from your the account you used for registration."
      placement="top"
      hideInfoIcon
    >
      <Button variant="tertiary" size="small" fluid={rest.fluid} disabled>
        Disconnect
      </Button>
    </Info>
  ) : (
    <Button
      className={TriggerClass.DisconnectSM}
      variant="tertiary"
      size="small"
      disabled={disabled || loading}
      loading={loading}
      onClick={onClick}
      {...rest}
    >
      Disconnect
    </Button>
  );
};

export default DisconnectButton;
