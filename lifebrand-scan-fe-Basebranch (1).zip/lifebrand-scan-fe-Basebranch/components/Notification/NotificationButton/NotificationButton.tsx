import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { Popover } from 'antd';

import { ElementId } from 'components/enums';

import NotificationPreview from '../NotificationPreview';
import { NOTIFICATION_POLL_INTERVAL } from '../Notification.config';

import { ROUTES } from '@Utils/helper/routes';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { useIndividualNotificationUnreadCountQuery } from '@Generated/graphql';

import * as S from './NotificationButton.styles';

const NOTIFICATION_PREVIEW_SIZE = { width: '440px', height: '420px' };

type NotificationButtonProps = {
  sizeIcon?: number;
};

const NotificationButton = ({ sizeIcon = 24 }: NotificationButtonProps) => {
  const [isPopoverVisible, setIsPopoverVisible] = useState(false);

  const { isMobile } = useBreakpoints();
  const router = useRouter();
  const { data } = useIndividualNotificationUnreadCountQuery({
    pollInterval: NOTIFICATION_POLL_INTERVAL,
  });

  // When the user is in Notification-center page, the dropdown won't appear
  const inNotificationCenter = router.pathname.includes(ROUTES.NOTIFICATION_CENTER);

  const handleClick = () => {
    if (isMobile || inNotificationCenter) {
      router.push(ROUTES.NOTIFICATION_CENTER);
    }
  };

  const handlePopoverVisibleChange = () => {
    setIsPopoverVisible(!isPopoverVisible);
  };

  useEffect(() => {
    if (router.query.modal) setIsPopoverVisible(false);
  }, [router.query]);

  const button = (
    <S.Badge
      count={data?.individualNotificationsUnreadCount}
      offset={isMobile ? [-5, 10] : [-15, 5]}
      data-test-id={ElementId.BellIcon}
    >
      <S.IconButton
        name="Bell"
        size={isMobile ? 20 : sizeIcon}
        color="neutrals.700"
        onClick={handleClick}
        cursor={inNotificationCenter ? '' : 'pointer'}
        data-testid="notification-button"
      />
    </S.Badge>
  );

  if (isMobile || inNotificationCenter) {
    return button;
  }

  return (
    <Popover
      visible={isPopoverVisible}
      content={<NotificationPreview />}
      placement="bottomRight"
      overlayStyle={NOTIFICATION_PREVIEW_SIZE}
      trigger="click"
      onVisibleChange={handlePopoverVisibleChange}
    >
      {button}
      <S.PopoverNotificationStyle />
    </Popover>
  );
};

export default NotificationButton;
