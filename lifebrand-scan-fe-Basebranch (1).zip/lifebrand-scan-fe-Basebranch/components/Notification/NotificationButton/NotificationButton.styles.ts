import styled, { createGlobalStyle } from 'styled-components';

import { Badge as AntdBadge } from 'antd';

import { Icon } from '@UI/meeseeks';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const IconButton = styled(Icon).attrs({ role: 'button' })`
  margin: ${({ theme }) => `0 ${theme.spacing.small}px`};

  ${useBreakpoint.mobile`
    margin: 0px;
  `}
`;

export const PopoverNotificationStyle = createGlobalStyle`
  .ant-popover-inner-content {
    padding: 0;
  }

  .ant-popover-title {
    padding: 0;
  }
`;

export const Badge = styled(AntdBadge)`
  height: 40px;
  display: grid;
  place-content: center;

  .ant-badge-count {
    background-color: ${({ theme }) => theme.color.primary};
    color: ${({ theme }) => theme.meeseeks.color.white};
    height: ${({ theme }) => theme.spacing.medium}px;
    width: 16px;
    font-size: 10px;
    line-height: ${({ theme }) => theme.spacing.medium}px;
    padding: 0;
    min-width: 16px;
  }
`;
