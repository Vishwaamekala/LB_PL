// we might want to export this enum directly from backend

export enum IndividualNotificationTypeEnum {
  BusinessCustomerDeactivated = 'BusinessCustomerDeactivated',
  CurrentEmployeeAutoSharing = 'CurrentEmployeeAutoSharing',
  BusinessCustomerInvitationAccepted = 'BusinessCustomerInvitationAccepted',
}
