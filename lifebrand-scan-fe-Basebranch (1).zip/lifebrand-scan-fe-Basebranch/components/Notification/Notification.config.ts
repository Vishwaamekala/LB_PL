import { Router } from 'next/router';

import { IndividualNotificationTypeEnum } from './Notification.types';

export const NOTIFICATION_POLL_INTERVAL = 5000; // 5s

export const redirectsByNotificationType: Record<string, Partial<Router> | string> = {
  [IndividualNotificationTypeEnum.BusinessCustomerInvitationAccepted]: {
    query: { modal: IndividualNotificationTypeEnum.BusinessCustomerInvitationAccepted },
  },
};
