import styled from 'styled-components';

import { Text } from '@UI/meeseeks';

export const List = styled.div<{ isLoading?: boolean }>`
  & > *:first-child {
    padding: ${({ theme }) =>
      `${theme.spacing.xs * 5}px ${theme.spacing.xs * 5}px ${theme.spacing.large / 3}px`};
  }

  & > * {
    padding: ${({ theme }) => `${theme.spacing.large / 3}px ${theme.spacing.xs * 5}px`};
    ${({ isLoading, theme }) =>
      !isLoading &&
      `&:hover {
          background-color: rgba(${theme.color.primaryRgb}, 0.1);
        };
  `}
  }
`;

export const Header = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 ${({ theme }) => theme.spacing.xs * 5}px;
  height: 48px;
  border-bottom: 1px solid ${({ theme }) => theme.meeseeks.color.tertiary};
`;

export const Body = styled.div`
  position: relative;
  width: 100%;
  height: 324px;
  overflow: auto;
`;

export const Footer = styled.div`
  position: relative;
  display: flex;
  cursor: pointer;
  width: 100%;
  height: 48px;
  justify-content: center;
  align-items: center;
  background-color: ${({ theme }) => theme.meeseeks.color.white};
  box-shadow: ${({ theme }) => theme.shadow.card};
`;

export const MarkAsRead = styled.div`
  display: flex;
  flex-direction: row;
  cursor: pointer;
`;

export const MarkAsReadText = styled(Text)`
  margin-left: ${({ theme }) => theme.spacing.small / 2}px;
`;

export const Loader = styled.div`
  display: flex;
  justify-content: center;
`;
