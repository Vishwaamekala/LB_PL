import React, { useCallback, useEffect, useMemo } from 'react';
import { useInView } from 'react-intersection-observer';
import { useRouter } from 'next/router';

import { Icon, Heading } from '@UI/meeseeks';

import EmptyState from '../NotificationCenter/EmptyState';
import NotificationLog from '../NotificationLog';
import NotificationLoading from '../NotificationCenter/NotificationLoading';
import { useNotificationActions } from '../NotificationCenter/NotificationCenter.utils';
import { NOTIFICATION_POLL_INTERVAL } from '../Notification.config';

import Loading from '@UI/Loading';

import { ROUTES } from '@Utils/helper/routes';
import { useIndividualNotificationsQuery } from '@Generated/graphql';

import * as S from './NotificationPreview.styles';

const DEFAULT_LIMIT = 10;

const NotificationPreview = () => {
  const router = useRouter();
  const { handleMarkAsRead, handleNotificationAction } = useNotificationActions();

  const { data, loading, fetchMore } = useIndividualNotificationsQuery({
    variables: { input: { take: DEFAULT_LIMIT } },
    pollInterval: NOTIFICATION_POLL_INTERVAL,
  });

  const [loaderRef, inView] = useInView({
    threshold: 0,
  });

  const { nextCursorId, list: individualNotifications } = data?.individualUserNotifications || {};

  const showActions = !loading && !!individualNotifications?.length;

  const handleMore = useCallback(async () => {
    if (!loading) {
      fetchMore({ variables: { input: { take: DEFAULT_LIMIT, cursorId: nextCursorId } } });
    }
  }, [loading, nextCursorId]);

  useEffect(() => {
    if (inView) {
      handleMore();
    }
  }, [inView, handleMore]);

  const content = useMemo(() => {
    if (loading) {
      return (
        <S.List isLoading={true}>
          <NotificationLoading />
        </S.List>
      );
    }

    if (individualNotifications?.length) {
      return (
        <S.List>
          {individualNotifications.map((item) => (
            <NotificationLog
              key={item.id}
              data={item}
              onClick={() => {
                handleMarkAsRead([item.id]);
                handleNotificationAction(item.type);
              }}
              isSelecting={false}
              isSelected={false}
              onSelect={undefined}
            />
          ))}
        </S.List>
      );
    }

    return <EmptyState />;
  }, [individualNotifications, loading, handleNotificationAction]);

  return (
    <>
      <S.Header>
        <Heading variant="h5" color="neutrals.800">
          Notifications
        </Heading>
        {showActions && (
          <S.MarkAsRead onClick={() => handleMarkAsRead()}>
            <Icon name="Check" size={16} color="secondary" />
            <S.MarkAsReadText variant="caption" color="neutrals.700" fontWeight={600}>
              Mark All As Read
            </S.MarkAsReadText>
          </S.MarkAsRead>
        )}
      </S.Header>
      <S.Body>
        {content}
        {nextCursorId && (
          <S.Loader ref={loaderRef}>
            <Loading />
          </S.Loader>
        )}
      </S.Body>
      {showActions && (
        <S.Footer onClick={() => router.push(ROUTES.NOTIFICATION_CENTER)}>
          <Heading variant="h6" textAlign="center" textColor="body">
            See All Notifications
          </Heading>
        </S.Footer>
      )}
    </>
  );
};

export default NotificationPreview;
