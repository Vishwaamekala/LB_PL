import { useCallback, useState } from 'react';
import router from 'next/router';
import { Reference } from '@apollo/client';

import { message } from '@UI/meeseeks';

import { IndividualNotificationTypeEnum } from '../Notification.types';
import { redirectsByNotificationType } from '../Notification.config';

import { IndividualNotificationFragmentName } from '@Utils/apollo/fragmentNames';

import {
  IndividualNotificationUnreadCountDocument,
  IndividualNotificationDataFragmentDoc,
  IndividualNotificationDataFragment,
  useDeleteIndividualNotificationsMutation,
  useMarkIndividualNotificationsAsReadMutation,
  IndividualNotificationsQuery,
  IndividualNotificationsDocument,
} from '@Generated/graphql';

const SELECTION_LIMIT = 100;

export const useNotificationActions = () => {
  const [isSelecting, setIsSelecting] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const makeHandleSelect = useCallback(
    (notificationId: string) => (checked: boolean) => {
      setSelectedIds((current) => {
        if (checked) {
          if (current.length >= SELECTION_LIMIT) {
            message.error({
              title: "You've reached the limit. Please submit before you continue.",
            });
            return current;
          }
          return [...current, notificationId];
        }
        return current.filter((id) => id !== notificationId);
      });
    },
    [],
  );

  const [markNotificationsAsRead] = useMarkIndividualNotificationsAsReadMutation();

  /**
   * Marks notifications as read.
   * If `notificationIds` is not specified, will mark all notifications as read.
   */
  const handleMarkAsRead = useCallback(
    async (notificationIds?: string[]) => {
      try {
        await markNotificationsAsRead({
          variables: { notificationIds },
          refetchQueries: [{ query: IndividualNotificationUnreadCountDocument }],
          update(cache) {
            if (notificationIds) {
              notificationIds?.forEach((notificationId) => {
                const fragmentId = `${IndividualNotificationFragmentName}:${notificationId}`;
                const notificationFragment = cache.readFragment<IndividualNotificationDataFragment>(
                  {
                    fragment: IndividualNotificationDataFragmentDoc,
                    id: fragmentId,
                  },
                );
                cache.writeFragment({
                  fragment: IndividualNotificationDataFragmentDoc,
                  id: fragmentId,
                  data: {
                    ...notificationFragment,
                    isRead: true,
                  },
                });
              });
              return;
            }
            const cachedQuery = cache.readQuery<IndividualNotificationsQuery>({
              query: IndividualNotificationsDocument,
            });
            if (cachedQuery) {
              cache.writeQuery<IndividualNotificationsQuery>({
                query: IndividualNotificationsDocument,
                data: {
                  ...cachedQuery,
                  individualUserNotifications: {
                    ...cachedQuery.individualUserNotifications,
                    list: cachedQuery.individualUserNotifications?.list.map((notification) => ({
                      ...notification,
                      isRead: true,
                    })),
                  },
                },
              });
            }
          },
        });
        setSelectedIds([]);
      } catch {
        message.error({
          title: 'Failed to mark notifications as read. Please try again.',
        });
      }
    },
    [markNotificationsAsRead],
  );

  const handleNotificationAction = useCallback(
    (notificationType: IndividualNotificationTypeEnum | string) => {
      if (redirectsByNotificationType[notificationType]) {
        router.push(redirectsByNotificationType[notificationType]);
      }
    },
    [],
  );

  const [deleteNotifications] = useDeleteIndividualNotificationsMutation();

  const handleDeleteSelected = useCallback(async () => {
    try {
      await deleteNotifications({
        variables: { notificationIds: selectedIds },
        update: (cache) => {
          cache.modify({
            fields: {
              individualUserNotifications(existing, { readField }) {
                return {
                  ...existing,
                  list: existing.list.filter((existingRef: Reference) => {
                    const existingId = readField('id', existingRef);
                    return !existingId || !selectedIds.includes(existingId as string);
                  }),
                };
              },
            },
          });
        },
      });
      setSelectedIds([]);
    } catch {
      message.error({
        title: 'Failed to delete notifications. Please try again.',
      });
    }
  }, [deleteNotifications, selectedIds]);

  return {
    isSelecting,
    setIsSelecting,
    selectedIds,
    handleMarkAsRead,
    makeHandleSelect,
    handleDeleteSelected,
    handleNotificationAction,
  };
};
