import React, { useCallback, useEffect, useMemo } from 'react';
import { useRouter } from 'next/router';
import { useInView } from 'react-intersection-observer';
import { NetworkStatus } from '@apollo/client';
import { Dropdown, Menu } from 'antd';

import EmptyState from './EmptyState';
import { useNotificationActions } from './NotificationCenter.utils';

import { Icon, Heading } from '@UI/meeseeks';
import Loading from '@UI/Loading';

import NotificationLog from '../NotificationLog';
import NotificationLoading from '../NotificationCenter/NotificationLoading';
import { NOTIFICATION_POLL_INTERVAL } from '../Notification.config';

import useScrollTop from '@Utils/hooks/useScrollTop';
import { useBreakpoints } from '@Utils/hooks/useBreakpoints';

import { ROUTES } from '@Utils/helper/routes';
import { useIndividualNotificationsQuery } from '@Generated/graphql';

import * as S from './NotificationCenter.styles';

const DEFAULT_LIMIT = 10;

const NotificationCenter = () => {
  const { scrollTop, onScroll } = useScrollTop();
  const { isMobile } = useBreakpoints();
  const router = useRouter();
  const {
    isSelecting,
    setIsSelecting,
    selectedIds,
    handleMarkAsRead,
    makeHandleSelect,
    handleDeleteSelected,
    handleNotificationAction,
  } = useNotificationActions();

  const [loaderRef, inView] = useInView({
    threshold: 0,
  });

  const { data, loading: fetching, fetchMore, networkStatus } = useIndividualNotificationsQuery({
    variables: { input: { take: DEFAULT_LIMIT } },
    notifyOnNetworkStatusChange: true,
    pollInterval: NOTIFICATION_POLL_INTERVAL,
  });

  const { nextCursorId, list: individualNotifications } = data?.individualUserNotifications || {};

  const loading = fetching && !data;

  const isFetchingMore = networkStatus === NetworkStatus.fetchMore;

  // TODO: Scrolling currently buggy in some cases, revisit with Ruslan
  const handleMore = useCallback(async () => {
    if (!isFetchingMore) {
      fetchMore({ variables: { input: { take: DEFAULT_LIMIT, cursorId: nextCursorId } } });
    }
  }, [nextCursorId, isFetchingMore]);

  useEffect(() => {
    if (inView) {
      handleMore();
    }
  }, [inView, handleMore]);

  const menu = useMemo(
    () => (
      <S.Menu>
        <Menu.Item
          icon={<Icon name="Check" size={16} color="neutrals.700" />}
          onClick={() => handleMarkAsRead()}
        >
          Mark all as “read”
        </Menu.Item>
        <Menu.Item
          icon={<Icon name="Edit" size={16} color="neutrals.700" />}
          onClick={() => setIsSelecting(true)}
        >
          Manage notifications
        </Menu.Item>
      </S.Menu>
    ),
    [handleMarkAsRead, setIsSelecting],
  );

  const content = useMemo(() => {
    if (loading) {
      return <NotificationLoading />;
    }
    if (individualNotifications?.length) {
      return (
        <S.List>
          {individualNotifications.map((item) => (
            <NotificationLog
              key={item.id}
              data={item}
              onClick={() => {
                handleMarkAsRead([item.id]);
                handleNotificationAction(item.type);
              }}
              isSelecting={isSelecting}
              isSelected={selectedIds.includes(item.id)}
              onSelect={makeHandleSelect(item.id)}
            />
          ))}
        </S.List>
      );
    }
    return <EmptyState />;
  }, [
    individualNotifications,
    handleMarkAsRead,
    isSelecting,
    selectedIds,
    makeHandleSelect,
    loading,
    handleNotificationAction,
  ]);

  return (
    <S.Card>
      <S.Header isSelecting={isSelecting && !!individualNotifications?.length}>
        <Heading variant="h3">Notifications</Heading>
        <S.SelectControls>
          <S.LinkButton
            onClick={() => handleMarkAsRead(selectedIds)}
            disabled={!selectedIds.length}
          >
            Mark As Read
          </S.LinkButton>
          <S.LinkDangerButton onClick={handleDeleteSelected} disabled={!selectedIds.length}>
            Delete
          </S.LinkDangerButton>
          <S.LinkButton onClick={() => setIsSelecting(false)}>Cancel</S.LinkButton>
        </S.SelectControls>
        <S.Actions>
          {!loading && !!individualNotifications?.length && (
            <Dropdown overlay={menu} trigger={['click']} placement="bottomRight">
              <S.IconButton
                name="MoreHorizontal"
                size={24}
                onClick={(e: React.MouseEvent<SVGElement>) => e.preventDefault()}
                className="ant-dropdown-link"
              />
            </Dropdown>
          )}
          {isMobile && (
            <S.IconButton name="X" size={24} onClick={() => router.push(ROUTES.DASHBOARD)} />
          )}
        </S.Actions>
      </S.Header>
      <S.ContentContainer
        onScroll={onScroll}
        isScrollingDown={scrollTop > 0}
        isSelecting={isSelecting && !!individualNotifications?.length}
      >
        {content}
        {nextCursorId && (
          <S.Loader ref={loaderRef}>
            <Loading />
          </S.Loader>
        )}
      </S.ContentContainer>
    </S.Card>
  );
};

export default NotificationCenter;
