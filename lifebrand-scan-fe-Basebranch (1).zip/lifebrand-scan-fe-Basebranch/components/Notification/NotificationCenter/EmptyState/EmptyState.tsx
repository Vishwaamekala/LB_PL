import React from 'react';

import { Heading } from '@UI/meeseeks';

import * as S from './EmptyState.styles';

type Props = {
  text?: string;
};

const EmptyState = ({ text = 'No notifications yet.' }: Props) => {
  return (
    <S.Wrapper>
      <img src="/images/png/notification-bell.png" height={86} alt="send" />
      <Heading variant="h6" textColor="neutrals.700">
        {text}
      </Heading>
    </S.Wrapper>
  );
};

export default EmptyState;
