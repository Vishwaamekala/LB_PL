import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Wrapper = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: ${({ theme }) => theme.meeseeks.color['neutrals.100']};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  min-height: 184px;
  flex: 1;
  height: 100%;
  padding: 0;

  // Heading
  & > *:last-child {
    margin-top: ${({ theme }) => theme.spacing.medium}px;
  }

  //max-height: padding from card (medium 16px), header height (50px)
  ${useBreakpoint.mobile`
    padding: 0;
    height: calc(100vh - 16px - 50px);
  `}
`;
