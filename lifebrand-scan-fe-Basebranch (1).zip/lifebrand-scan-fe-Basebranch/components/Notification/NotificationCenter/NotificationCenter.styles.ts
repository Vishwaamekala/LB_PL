import styled from 'styled-components';
import { Menu as MenuBase } from 'antd';

import { Button, Icon } from '@UI/meeseeks';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Card = styled.div<{ height?: number }>`
  width: 668px;
  margin: 0 auto;
  margin-top: ${({ theme }) => theme.spacing.large + theme.spacing.small}px;
  background-color: ${({ theme }) => theme.meeseeks.color.white};
  border: 1px solid ${({ theme }) => theme.meeseeks.color.tertiary};
  border-radius: ${({ theme }) => theme.borderRadius.small}px;
  padding: 0px;
  padding-bottom: ${({ theme }) => theme.spacing.medium * 2}px;
  ${({ height }) => height && `height: ${height}px`};
  overflow: hidden;

  ${useBreakpoint.tablet`
    width: 100%;
  `}

  ${useBreakpoint.mobile`
    margin: 0;
    padding: 0;
    border: none;
    height: 100vh;
  `}
`;

export const Actions = styled.div`
  display: flex;
  align-items: center;

  & > *:not(:first-child) {
    margin-left: ${({ theme }) => theme.spacing.medium}px;
  }
`;

export const SelectControls = styled.div`
  display: flex;
  align-items: center;

  & > *:not(:first-child) {
    margin-left: ${({ theme }) => theme.spacing.medium}px;
  }

  ${useBreakpoint.mobile`
    order: 3;
    flex-grow: 1;
    justify-content: space-around;
    margin-top: ${({ theme }) => theme.spacing.small}px;
    box-shadow: ${({ theme }) => theme.shadow.card};
  `}
`;

export const Header = styled.div<{ isSelecting: boolean }>`
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  padding: 0 ${({ theme }) => theme.spacing.medium * 2}px;
  height: 98px;

  ${Actions} {
    display: ${({ isSelecting }) => (isSelecting ? 'none' : 'flex')};
  }

  ${SelectControls} {
    display: ${({ isSelecting }) => (isSelecting ? 'flex' : 'none')};
  }

  ${useBreakpoint.mobile`
    height: auto;
    padding: ${({ theme }) => theme.spacing.medium}px;

    ${Actions} {
      display: flex;
    }
  `}
`;

export const LinkButton = styled(Button).attrs({ variant: 'link', size: 'medium' })<{
  danger?: boolean;
}>`
  padding: ${({ theme }) => theme.spacing.small}px;
`;

export const LinkDangerButton = styled(LinkButton)`
  color: ${({ theme }) => theme.meeseeks.color['danger.500']};

  & :not(:disabled):hover {
    color: ${({ theme }) => theme.meeseeks.color['danger.600']};
  }

  & :disabled {
    color: ${({ theme }) => theme.meeseeks.color['danger.200']};
  }
`;

// max-height ContentContainer:
// excluding the Header height (68px), Footer height (64px)
// and Main paddings (medium x2 - 32px), margin top from card (extraLarge - 32px)
// header (98px), top padding (32px)
export const ContentContainer = styled.div<{ isScrollingDown: boolean; isSelecting: boolean }>`
  width: 100%;
  padding: 0 ${({ theme }) => theme.spacing.medium * 2}px;
  max-height: calc(100vh - 68px - 64px - 32px - 32px - 98px - 32px);
  overflow: auto;
  border-top: ${({ isScrollingDown, theme }) =>
    isScrollingDown ? theme.border.scrollable : '1px solid transparent'};

  // max-height: Header is 64px by default, and 114 px if select controls are visible.
  ${({ isSelecting }) => useBreakpoint.mobile`
    padding: 0;
    max-height: ${isSelecting ? 'calc(100vh - 114px)' : 'calc(100vh - 64px)'};
  `}
`;

export const List = styled.div`
  padding-bottom: ${({ theme }) => theme.spacing.medium}px;

  & > *:not(:first-child) {
    margin-top: ${({ theme }) => theme.spacing.large / 2}px;
  }
`;

export const IconButton = styled(Icon).attrs({ role: 'button' })`
  cursor: pointer;
`;

export const Menu = styled(MenuBase)`
  font-family: 'Poppins';
  box-shadow: ${({ theme }) => theme.shadow.card};

  & .ant-dropdown-menu-item {
    display: flex;
    align-items: center;
    padding: ${({ theme }) => `${theme.spacing.small}px ${theme.spacing.medium}px`};
    color: ${({ theme }) => theme.meeseeks.color['neutrals.500']};

    & .ant-dropdown-menu-item-icon {
      margin-right: ${({ theme }) => theme.spacing.small}px;
    }
  }
`;

export const Loader = styled.div`
  display: flex;
  justify-content: center;
`;
