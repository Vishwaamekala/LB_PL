import React from 'react';
import Skeleton from 'react-loading-skeleton';

import * as S from '../NotificationLog/NotificationLog.styles';

const Item = (
  <S.Log>
    <S.Content isLoading={true}>
      <S.SkeletonCircleContainer>
        <Skeleton circle width={40} height={40} />
      </S.SkeletonCircleContainer>
      <S.SkeletonContainer>
        <Skeleton width={210} height={10} />
        <Skeleton width={253} height={10} />
        <Skeleton width={50} height={10} />
      </S.SkeletonContainer>
    </S.Content>
  </S.Log>
);

const NotificationLoading = () => {
  return <>{Array(4).fill(Item)}</>;
};

export default NotificationLoading;
