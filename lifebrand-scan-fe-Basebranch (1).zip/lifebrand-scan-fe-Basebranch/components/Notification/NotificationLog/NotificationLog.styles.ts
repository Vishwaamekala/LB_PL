import styled from 'styled-components';

import { Text, Checkbox as CheckboxBase } from '@UI/meeseeks';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Controls = styled.div`
  margin-top: ${({ theme }) => theme.spacing.small}px;
  margin-right: ${({ theme }) => theme.spacing.small}px;
`;

export const Content = styled.div<{ isRead?: boolean; isLoading?: boolean }>`
  flex-grow: 1;
  display: flex;
  position: relative;
  flex-direction: row;
  cursor: ${({ isRead, isLoading }) => (isRead || isLoading ? '' : 'pointer')};

  ${({ isRead, theme }) =>
    `
    & .text > * { color: ${isRead ? theme.meeseeks.color.caption : theme.meeseeks.color.heading} };
    & .date-text { color: ${isRead ? theme.meeseeks.color['neutrals.300'] : theme.color.primary} };
  `}
`;

export const ImageContainer = styled.div`
  width: 40px;
  height: 40px;
  margin-right: ${({ theme }) => theme.spacing.large / 2}px;
  padding: ${({ theme }) => theme.spacing.small}px;
  background-color: ${({ theme }) => theme.meeseeks.color['neutrals.100']};
  border-radius: 50%;
  display: grid;
  place-content: center;
`;

export const TextContainer = styled.div`
  margin-right: ${({ theme }) => theme.spacing.extraLarge}px;
`;

export const Log = styled.div<{ isSelecting?: boolean }>`
  display: flex;

  ${Controls} {
    display: ${({ isSelecting }) => (isSelecting ? 'block' : 'none')};
  }

  ${({ theme, isSelecting }) => useBreakpoint.mobile`
    margin-left: ${theme.spacing.medium}px;
    margin-right: ${theme.spacing.medium}px;

    ${ImageContainer} {
      display: ${isSelecting ? 'none' : 'block'};
    }
  `}
`;

export const Checkbox = styled(CheckboxBase)`
  width: 24px;
  height: 24px;

  & > span {
    width: 100%;
    height: 100%;
  }
`;

export const DateText = styled(Text).attrs({
  variant: 'small',
  fontWeight: 600,
})``;

export const IsNotReadDot = styled.div`
  position: absolute;
  right: 0;
  top: 20px;
  width: 10px;
  height: 10px;
  background-color: ${({ theme }) => theme.color.primary};
  border-radius: 50%;
`;

export const SkeletonContainer = styled.div`
  display: flex;
  flex-direction: column;
`;

export const SkeletonCircleContainer = styled.div`
  margin-right: ${({ theme }) => theme.spacing.large / 2}px;
`;
