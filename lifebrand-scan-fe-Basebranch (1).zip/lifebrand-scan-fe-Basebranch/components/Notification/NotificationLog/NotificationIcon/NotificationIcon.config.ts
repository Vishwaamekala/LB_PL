import { IndividualNotificationTypeEnum } from 'components/Notification/Notification.types';

export const NotificationIconByType = {
  [IndividualNotificationTypeEnum.BusinessCustomerDeactivated]: {
    icon: '🚫',
    label: 'Invitation Deactivated',
  },
  [IndividualNotificationTypeEnum.CurrentEmployeeAutoSharing]: {
    icon: '🙂',
    label: 'Auto Sharing',
  },
  [IndividualNotificationTypeEnum.BusinessCustomerInvitationAccepted]: {
    icon: '🔍',
    label: 'Business Customer Invitation Accepted',
  },
};
