import React from 'react';

import { NotificationIconByType } from './NotificationIcon.config';

import { IndividualNotificationTypeEnum } from 'components/Notification/Notification.types';

type Props = {
  notificationType: IndividualNotificationTypeEnum;
};

const NotificationIcon = ({ notificationType }: Props) => {
  return (
    <span
      role="img"
      style={{ fontFamily: 'Open Sans', fontSize: 24 }}
      aria-label={NotificationIconByType[notificationType].label}
    >
      {NotificationIconByType[notificationType].icon}
    </span>
  );
};

export default NotificationIcon;
