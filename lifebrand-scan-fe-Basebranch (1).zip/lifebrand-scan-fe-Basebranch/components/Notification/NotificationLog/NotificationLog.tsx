import React from 'react';

import NotificationIcon from './NotificationIcon';

import { Heading } from '@UI/meeseeks';

import { IndividualNotificationTypeEnum } from '../Notification.types';

import { formatDateDistanceFromYesterday } from '@Utils/formatters/date';

import { IndividualNotification } from '@Generated/graphql';

import * as S from './NotificationLog.styles';

type Props = {
  data: IndividualNotification;
  onClick: () => void;
  isSelecting: boolean;
  isSelected: boolean;
  onSelect?: (checked: boolean) => void;
};

const NotificationLog = ({ data, onClick, isSelecting, isSelected, onSelect }: Props) => {
  return (
    <S.Log isSelecting={isSelecting}>
      <S.Controls>
        <S.Checkbox
          checked={isSelected}
          onChange={(event) => {
            event.stopPropagation();
            onSelect?.(event.target.checked);
          }}
        />
      </S.Controls>
      <S.Content id={data.id} isRead={data.isRead} onClick={onClick}>
        <S.ImageContainer>
          <NotificationIcon notificationType={data.type as IndividualNotificationTypeEnum} />
        </S.ImageContainer>
        <S.TextContainer className="text">
          <Heading variant="h6" marginBottom="xxs">
            {data.title}
          </Heading>
          <Heading variant="h6" marginBottom="xs" fontWeight={400}>
            {data.text}
          </Heading>
          <S.DateText className="date-text">
            {formatDateDistanceFromYesterday(new Date(data.createdAt))}
          </S.DateText>
        </S.TextContainer>
        {!data.isRead && <S.IsNotReadDot />}
      </S.Content>
    </S.Log>
  );
};

export default NotificationLog;
