import styled from 'styled-components';

import { useBreakpoint } from '@Utils/style/breakpoint';

export const Code = styled.div`
  height: 200px;
  width: 100%;
  background-color: ${({ theme }) => theme.meeseeks.color['neutrals.900']};
  border-radius: ${({ theme }) => theme.borderRadius.medium}px;
  padding: ${({ theme }) => theme.spacing.medium}px;
  overflow: scroll;
`;

export const Action = styled.div`
  display: flex;
  justify-content: right;
  margin-top: ${({ theme }) => theme.spacing.large}px;

  ${useBreakpoint.mobile`
    flex-direction: column;

    & > * + * {
      margin-top: ${({ theme }) => theme.spacing.medium}px;
    }
  `}
`;
