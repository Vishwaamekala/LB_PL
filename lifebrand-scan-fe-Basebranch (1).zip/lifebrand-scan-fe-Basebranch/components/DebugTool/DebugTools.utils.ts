import { ConnectedSM } from './DebugTool';

export const formatSM = (socialMediaTuples: ConnectedSM[]) => {
  if (socialMediaTuples.length === 0) {
    return 'None';
  }
  return socialMediaTuples.reduce<string>((final, { socialMedia, userName }) => {
    return `${final} ${final && ','} ${socialMedia} (${userName})`;
  }, '');
};

export const removeTypename = <T extends Record<string, unknown>>(item: T) => {
  if ('__typename' in item) {
    // eslint-disable-next-line @typescript-eslint/naming-convention
    const { __typename, ...obj } = item;
    return obj;
  }
  return item;
};
