import React, { useEffect, useState } from 'react';

import { formatSM, removeTypename } from './DebugTools.utils';

import { Button, Chip, Heading, message, Text } from '@UI/meeseeks';
import Modal from '@UI/Modal';
import Spacing from '@UI/Spacing';

import InfoPair from 'components/SubscriptionPayments/InfoPair';
import { ElementId } from 'components/enums';

import { useBreakpoints } from '@Utils/hooks/useBreakpoints';
import { useAuthContext } from '@Utils/AuthContext';
import { useSubscriptionContext } from '@Utils/SubscriptionContext/useSubscriptionContext';
import { useConnections } from '@Utils/hooks/useConnections';

import * as S from './DebugTool.styles';

export type ConnectedSM = {
  socialMedia: string;
  userName?: string | null;
};

function DebugTool() {
  const [isVisible, setIsVisible] = useState(false);
  const [errors, setErrors] = useState<any[]>([]);
  const breakpoints = useBreakpoints();
  const { isMobile } = breakpoints;

  const { userData, isInvited, invitedBy, referredByNJREALTOR } = useAuthContext();
  const { plan, features } = useSubscriptionContext();
  const { socialMediaConnection } = useConnections();

  const inviteeTypes = invitedBy
    .map(({ Business, type }) => `${Business.contactEmail} (as ${type})`)
    .join(', ');

  const currentResolutionList = Object.entries(breakpoints).reduce<string[]>((total, item) => {
    const [resolution, isPresent] = item;
    if (isPresent) {
      total.push(resolution);
    }
    return total;
  }, []);

  const connectedSM = socialMediaConnection.reduce<ConnectedSM[]>(
    (total, { isConnected, userName, socialMedia }) => {
      if (isConnected) {
        total.push({ socialMedia, userName });
      }
      return total;
    },
    [],
  );

  useEffect(() => {
    let isMounted = true;
    const originalConsoleError = window.console.error;
    window.console.error = (error: any) => {
      if (isMounted) {
        setErrors((prevErrors) => [...prevErrors, error]);
        originalConsoleError(error);
      }
    };

    // Clean up
    return () => {
      window.console.error = originalConsoleError;
      isMounted = false;
    };
  }, []);

  const textInformation = {
    environment: {
      environment: window.location.hostname,
      userAgent: navigator.userAgent,
      resolution: currentResolutionList,
      page: window.location.pathname,
    },
    user: {
      authId: userData?.authId,
      username: userData?.name,
      userId: userData?.id,
      email: userData?.email,
      plan: plan && removeTypename<typeof plan>(plan),
      features: features && removeTypename<typeof features>(features),
      connectedSM,
      isInvited,
      businessInviter: inviteeTypes,
      referredByNJREALTOR,
    },
    other: {
      consoleErrors: errors,
    },
  };

  // Formatting text
  const textToCopy = JSON.stringify(textInformation, null, 2);

  const copyToClipboard = () => {
    try {
      navigator.clipboard.writeText(
        JSON.stringify({ ...textInformation, currentTimestamp: new Date() }, null, 2),
      );
      message.success({
        title: 'Copied in clipboard!',
      });
    } catch {
      message.error({
        title: "Couldn't copy in clipboard. Please try again.",
      });
    }
  };

  return (
    <>
      <Modal
        visible={isVisible}
        footer={null}
        onCancel={() => setIsVisible(false)}
        width={630}
        closable={true}
      >
        <>
          <Heading variant="h4"> Quick Info </Heading>
          <InfoPair title="Email" value={textInformation.user.email!} />
          <InfoPair
            title="Package"
            value={`${textInformation.user.plan?.name} (${
              textInformation.user.plan?.isCancelled ? 'Cancelled' : 'Active'
            })`}
          />
          <InfoPair
            title="Invited By"
            value={textInformation.user.isInvited ? textInformation.user.businessInviter : 'No one'}
          />
          <InfoPair
            title="SM Connected"
            value={formatSM(textInformation.user.connectedSM as ConnectedSM[])}
          />
          <Spacing size="large" />
          <Text variant="regular">
            Please, if there is a bug, attach the information below in the ticket
          </Text>
          <S.Code>
            <Text variant="body" textColor="highlight.300">
              <pre>{textToCopy}</pre>
            </Text>
          </S.Code>
          <S.Action>
            <Button variant="primary" size="medium" onClick={copyToClipboard} fluid={isMobile}>
              Copy in Clipboard
            </Button>
          </S.Action>
        </>
      </Modal>
      <Chip
        checked={isVisible}
        onChange={() => setIsVisible(!isVisible)}
        data-test-id={ElementId.Debug}
      >
        Debug
      </Chip>
    </>
  );
}

export default DebugTool;
