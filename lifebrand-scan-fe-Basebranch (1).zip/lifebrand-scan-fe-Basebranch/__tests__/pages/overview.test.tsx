import React from 'react';
import { useRouter } from 'next/router';
import { fireEvent, render, waitFor } from '@testing-library/react';
import 'jest-canvas-mock';

import { ThemeProvider } from 'styled-components';
import { MockedProvider, MockedResponse } from '@apollo/client/testing';

import { theme } from '../../theme/theme';
import OverviewPage from '../../pages/analytics/overview';

import {
  mockCreateReportPersonal,
  mockCreateReportPersonalError,
  mockFinishedScansEqualZero,
  mockFinishedScansGreaterThanZero,
  mockIndividualPersonalReport,
  mockOverviewContentBreakdownsOverallZero,
  TestReportInfo,
} from 'components/Analytics/mocks/constants';

import { useScanContext } from '@Utils/ScanContext';
import { SubscriptionContext, SubscriptionContextProps } from '@Utils/SubscriptionContext';
import { ROUTES } from '@Utils/helper/routes';

const intersectionObserverMock = () => ({
  observe: () => null,
});
window.IntersectionObserver = jest.fn().mockImplementation(intersectionObserverMock);

jest.mock('@Utils/hooks/useConnections', () => ({
  ...jest.requireActual('@Utils/hooks/useConnections'),
  useConnections() {
    return {
      ...jest.requireActual('@Utils/hooks/useConnections'),
      isActionsDisabled: false,
      isAnySocialMediaConnected: true,
      isAuthenticated: true,
      socialMediaConnection: [
        {
          isConnected: true,
          isMainIdentity: false,
          socialMedia: 'Facebook',
          userName: 'Erica Lumley',
        },
      ],
    };
  },
}));

jest.mock('next/router', () => ({
  useRouter: jest.fn().mockReturnValue({
    route: '/',
    pathname: '',
    query: '',
    asPath: '',
    push: jest.fn(),
  }),
}));

jest.mock('@Utils/ScanContext', () => ({
  ...jest.requireActual('@Utils/ScanContext'),
  useScanContext: jest.fn(),
}));

jest.mock('@Utils/hooks/useFeatureFlags', () => ({
  ...jest.requireActual('@Utils/hooks/useFeatureFlags'),
  useFeatureFlags() {
    return {
      ...jest.requireActual('@Utils/hooks/useFeatureFlags'),
      isEnabled: false,
      payload: {},
    };
  },
}));

const mockUseScan = (hasScanRunning = false) => {
  (useScanContext as jest.Mock).mockReturnValue({
    hasScanRunning,
  });
};

// to avoid error TypeError: window.matchMedia is not a function
window.matchMedia =
  window.matchMedia ||
  function () {
    return {
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  };

type RenderProps = {
  subscriptionValue: SubscriptionContextProps;
  mockFinishedScansData?: MockedResponse;
  mockOverviewContentBreakdownsData?: MockedResponse;
  mockCreateReportFCRAData?: MockedResponse;
  mockIndividualReportData?: MockedResponse;
};

const renderComponent = ({
  subscriptionValue,
  mockFinishedScansData = mockFinishedScansEqualZero,
  mockOverviewContentBreakdownsData = mockOverviewContentBreakdownsOverallZero,
  mockCreateReportFCRAData = mockCreateReportPersonal,
  mockIndividualReportData = mockIndividualPersonalReport,
}: RenderProps) => {
  const mocks = [
    mockFinishedScansData,
    mockOverviewContentBreakdownsData,
    mockCreateReportFCRAData,
    mockIndividualReportData,
  ];
  return render(
    <ThemeProvider theme={theme}>
      <MockedProvider mocks={mocks} addTypename={false}>
        <SubscriptionContext.Provider value={subscriptionValue}>
          <OverviewPage />
        </SubscriptionContext.Provider>
      </MockedProvider>
    </ThemeProvider>,
  );
};

const generateTestData = () => {
  const subscriptions = {
    free: {
      features: {
        canScan: true,
        canUpgrade: true,
        canAccessAnalytics: false,
        canUseAdvancedDashboard: false,
      },
      plan: {
        name: 'Free',
        isCancellable: false,
        isCancelled: false,
        currentPeriodEnds: null,
      },
    },
    basic: {
      features: {
        canScan: false,
        canUpgrade: true,
        canAccessAnalytics: true,
        canUseAdvancedDashboard: true,
      },
      plan: {
        name: 'Basic',
        isCancellable: true,
        isCancelled: false,
        currentPeriodEnds: null,
      },
    },
    unlimited: {
      features: {
        canScan: true,
        canUpgrade: true,
        canAccessAnalytics: true,
        canUseAdvancedDashboard: true,
      },
      plan: {
        name: 'Unlimited',
        isCancellable: true,
        isCancelled: false,
        currentPeriodEnds: null,
      },
    },
  } as Record<string, Omit<SubscriptionContextProps, 'loading'>>;

  return {
    subscriptions,
  };
};

const testData = generateTestData();

describe('Overview page', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  // Not working
  // beforeEach(() => {
  //   document.getElementsByClassName('JqfPe')[0].innerHTML = '';
  // });

  it('renders Banner for No posts scanned', async () => {
    mockUseScan(false);
    const { getAllByRole, getByRole, findByText } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      mockFinishedScansData: mockFinishedScansEqualZero,
    });

    expect(await findByText(/No posts/gi)).toBeInTheDocument();
    const createReportButton = getByRole('button', { name: /Create Report/gi });
    expect(createReportButton).toBeDisabled();

    const scanButton = getAllByRole('button', { name: /Scan/gi })[0];
    expect(scanButton).toBeEnabled();
  });

  it('renders Upgrade Banner for Free User', () => {
    mockUseScan(false);
    const { getByRole } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.free, loading: false },
      mockFinishedScansData: mockFinishedScansGreaterThanZero,
    });

    const createReportButton = getByRole('button', { name: /Create Report/gi });
    expect(createReportButton).toBeDisabled();

    const upgradeButton = getByRole('button', { name: /Upgrade/gi });
    expect(upgradeButton).toBeEnabled();
  });

  it('renders Scan In Progress Banner when running scan', () => {
    mockUseScan(true);
    const { getByText, getByRole } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.free, loading: false },
      mockFinishedScansData: mockFinishedScansEqualZero,
    });

    const createReportButton = getByRole('button', { name: /Create Report/gi });
    expect(createReportButton).toBeDisabled();
    expect(getByText(/Scan In Progress/i)).toBeInTheDocument();
  });

  it('renders Skeleton while loading', () => {
    mockUseScan(false);
    const { getByText, getByRole, getAllByTestId } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.unlimited, loading: false },
      mockFinishedScansData: mockFinishedScansGreaterThanZero,
    });

    expect(getByText(/Overall Data/i)).toBeInTheDocument();
    expect(getByText(/FCRA Compliant/i)).toBeInTheDocument();

    expect(getAllByTestId('skeleton')[0]).toBeInTheDocument();
    const createReportButton = getByRole('button', { name: /Create Report/gi });
    expect(createReportButton).toBeDisabled();
  });

  it('renders No Flagged Posts found Banner', async () => {
    mockUseScan(false);
    const { findByText, getByRole } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.basic, loading: false },
      mockFinishedScansData: mockFinishedScansGreaterThanZero,
      mockOverviewContentBreakdownsData: mockOverviewContentBreakdownsOverallZero,
    });

    expect(await findByText(/You Blow Our Mind/i)).toBeInTheDocument();

    const createReportButton = getByRole('button', { name: /Create Report/gi });
    expect(createReportButton).toBeEnabled();
  });

  it('renders CreateReport button full flow', async () => {
    mockUseScan(false);
    const {
      getByText,
      getByRole,
      getByTestId,
      getByLabelText,
      findByTestId,
      findByText,
    } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.basic, loading: false },
      mockFinishedScansData: mockFinishedScansGreaterThanZero,
      mockOverviewContentBreakdownsData: mockOverviewContentBreakdownsOverallZero,
      mockCreateReportFCRAData: mockCreateReportPersonal,
      mockIndividualReportData: mockIndividualPersonalReport,
    });

    expect(await findByText(/You Blow Our Mind/i)).toBeInTheDocument();
    const createReportButton = getByRole('button', { name: /Create Report/gi });
    fireEvent.click(createReportButton);

    const createReportModal = await findByTestId('create-report-modal');
    expect(createReportModal).toBeInTheDocument();

    fireEvent.mouseDown(getByText(/FCRA Compliant Report/gi));
    fireEvent.click(await findByText('General Report (Personal Use Only)'));
    const reportNameInput = getByLabelText('report-name');
    fireEvent.change(reportNameInput, { target: { value: TestReportInfo.Personal.reportName } });

    const confirmReportButton = getByTestId('create-report-confirm');
    fireEvent.click(confirmReportButton);

    expect(await findByText(/Creating report/i)).toBeInTheDocument();
    expect(await findByText('Report successfully created.')).toBeInTheDocument();

    await waitFor(() => {
      expect((useRouter as jest.Mock).mock.results[0].value.push).toBeCalledWith({
        pathname: ROUTES.REPORT,
        query: { id: TestReportInfo.Personal.reportId },
      });
    });
  });

  it('renders error while creating report', async () => {
    mockUseScan(false);
    const {
      getByText,
      getByRole,
      getByTestId,
      getByLabelText,
      findByTestId,
      findByText,
    } = renderComponent({
      subscriptionValue: { ...testData.subscriptions.basic, loading: false },
      mockFinishedScansData: mockFinishedScansGreaterThanZero,
      mockOverviewContentBreakdownsData: mockOverviewContentBreakdownsOverallZero,
      mockCreateReportFCRAData: mockCreateReportPersonalError,
      mockIndividualReportData: mockIndividualPersonalReport,
    });

    expect(await findByText(/You Blow Our Mind/i)).toBeInTheDocument();
    const createReportButton = getByRole('button', { name: /Create Report/gi });
    fireEvent.click(createReportButton);

    const createReportModal = await findByTestId('create-report-modal');
    expect(createReportModal).toBeInTheDocument();

    fireEvent.mouseDown(getByText(/FCRA Compliant Report/gi));
    fireEvent.click(await findByText('General Report (Personal Use Only)'));

    const reportNameInput = getByLabelText('report-name');
    fireEvent.change(reportNameInput, { target: { value: TestReportInfo.Personal.reportName } });

    const confirmReportButton = getByTestId('create-report-confirm');
    fireEvent.click(confirmReportButton);

    expect(await findByText('Failed to load report. Please try again.')).toBeInTheDocument();
  });
});
