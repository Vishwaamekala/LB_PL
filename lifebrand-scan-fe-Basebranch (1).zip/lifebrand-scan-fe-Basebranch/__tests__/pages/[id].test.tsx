import React from 'react';
import { useRouter } from 'next/router';
import { fireEvent, render, waitFor } from '@testing-library/react';
import 'jest-canvas-mock';

import { ThemeProvider } from 'styled-components';
import { MockedProvider, MockedResponse } from '@apollo/client/testing';

import ReportId from 'pages/analytics/report/[id]';

import { theme } from '../../theme/theme';

import { mockIndividualPersonalReport } from 'components/Analytics/mocks/constants';

import { ROUTES } from '@Utils/helper/routes';

jest.mock('next/router', () => ({
  useRouter: jest.fn().mockReturnValue({
    route: '/',
    pathname: '',
    query: '',
    asPath: '',
    push: jest.fn(),
  }),
}));

// to avoid error TypeError: window.matchMedia is not a function
window.matchMedia =
  window.matchMedia ||
  function () {
    return {
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  };

type RenderProps = {
  mockIndividualReportData?: MockedResponse;
};

const renderComponent = ({
  mockIndividualReportData = mockIndividualPersonalReport,
}: RenderProps) => {
  const mocks = [mockIndividualReportData];
  return render(
    <ThemeProvider theme={theme}>
      <MockedProvider mocks={mocks} addTypename={false}>
        <ReportId />
      </MockedProvider>
    </ThemeProvider>,
  );
};

describe('Report Id Page', () => {
  it('goes back to ReportHistory Page', async () => {
    const { getByText } = renderComponent({});

    const goReportHistory = getByText(/Report History/i);
    fireEvent.click(goReportHistory);

    await waitFor(() => {
      expect((useRouter as jest.Mock).mock.results[0].value.push).toBeCalledWith(
        ROUTES.REPORT_HISTORY,
      );
    });
  });
});
